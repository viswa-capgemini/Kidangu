// import { title } from "process";
import { type Product } from "../types/products";

export const PRODUCT_GROUPS: Product[] = [
  // {
  //   id: "double-deep",
  //   name: "Double Deep Pallet Racking",
  // },
  {
    id: "shuttle",
    name: "Shuttle Racking",
  },
  {
    id: "Mother-Child Shuttle",
    name: "Mother/Child Shuttle",
  },
  {
    id: "Mobile Shelving",
    name: "Mobile Shelving",
  },
  {
    id: "Mezzanine",
    name: "Mezzanine",
  },
  {
    id: "selective-pallet",
    name: "Selective Pallet Racking",
  },
  {
    id: "Single-Tier Shelving",
    name: "Single-Tier Shelving",
  },
  {
    id: "Multi-Tier Shelving",
    name: "Multi-Tier Shelving",
  },
];

// export const componentIcons = [
//   { name: "Switch1", iconClass: "icon-[material-symbols--switch-outline]" },
//   { name: "Switch2", iconClass: "icon-[material-symbols--switch-outline]" },
//   { name: "Bulb", iconClass: "icon-[stash--light-bulb]" },
//   {
//     name: "Fluorescent",
//     iconClass: "icon-[material-symbols--fluorescent-outline-rounded]",
//   },
//   { name: "Pallets", iconClass: "icon-[bi--hdd-rack-fill]" },
//   { name: "Rack", iconClass: "icon-[material-symbols--pallet-outline-sharp]" },
// ];

export const componentSections = [
  {
    title: "Electricals",
    rowStructure: [4],
    items: [
      { name: "Switch1", iconClass: "icon-[material-symbols--switch-outline]" },
      { name: "Switch2", iconClass: "icon-[material-symbols--switch-outline]" },
      { name: "Bulb", iconClass: "icon-[stash--light-bulb]" },
      // {
      //   name: "Fluorescent",
      //   iconClass: "icon-[material-symbols--fluorescent-outline-rounded]",
      // },
    ],
  },
  {
    title: "SKU",
    rowStructure: [4], // 4 items in one row
    items: [
      { name: "Box", iconClass: "icon-[bi--box-fill]" },
      // { name: "Bins", image: "src/assets/images/trash.svg" },
      { name: "Gunny bag", iconClass: "icon-[streamline-freehand--money-bag]", style:"width: 16px; height: 16px" },
      { name: "Drum", iconClass: "icon-[emojione--oil-drum]" },
    ],
  },
  {
    title: "Pallets",
    rowStructure: [1], // 4 items in one row
    items: [{ name: "Pallets", iconClass: "icon-[bi--hdd-rack-fill]" }],
  },
  {
    title: "Rack",
    rowStructure: [1],
    items: [
      {
        name: "Rack",
        iconClass: "icon-[material-symbols--pallet-outline-sharp]",
      },
    ],
  },
  {
    title: "Uprights",
    rowStructure: [2], // 2 items in one row
    items: [
      { name: "GXL110", image: "src/assets/images/GXL110.svg" },
      { name: "GXL120", image: "src/assets/images/GXL120.svg" },
      // { name: "GXL110", image: "/images/upright-gxl110.svg" },
      // { name: "GXL120", image: "/images/upright-gxl120.svg" },
    ],
  },
  {
    title: "Beams",
    rowStructure: [2], // 4 items in one row
    items: [
      { name: "Loading beam", image: "src/assets/images/LOADING_BEAM.svg" },
      { name: "Walkway beam", image: "src/assets/images/WALKWAY_BEAM.svg" },
    ],
  },
  {
    title: "Bracings",
    rowStructure: [2], // 4 items in one row
    items: [
      { name: "GL Bracing", image: "src/assets/images/GL_BRACING.svg" },
      { name: "GX Bracing", image: "src/assets/images/GX_BRACING.svg" },
    ],
  },
  {
    title: "Dacking Panel",
    rowStructure: [2], // 4 items in one row
    items: [
      { name: "6 Band Panel", image: "src/assets/images/6BAND_PANEL.svg" },
      { name: "14 Band Panel", image: "src/assets/images/14BAND_PANEL.svg" },
      // { name: "GXL110", image: "/images/upright-gxl110.svg" },
      // { name: "GXL120", image: "/images/upright-gxl120.svg" },
    ],
  },
];

export const smartProductGroups = [
  "Men’s Room",
  "Women’s Room",
  "Break Room",
  "IT Room",
  "Office",
  "Show Room",
  "Reception",
  "Conference",
];
