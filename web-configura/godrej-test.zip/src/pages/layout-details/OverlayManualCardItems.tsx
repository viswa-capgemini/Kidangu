import React from "react";
import ScratchCard from "./scratch-layout/ScratchCard";
import SmartWizardCard from "./smart-layout/SmartWizardCard";
import TemplateCard from "./overlay-templates/Template";
import ImportCard from "./import-layout/OverlayImport";

const OverlayCardItems = () => {
  // const cardsData = [
  //   { id: 1, title: 'Templates', description: 'Description for Card 1' },
  //   { id: 2, title: 'Import Layout', description: 'Description for Card 2' },
  //   { id: 3, title: 'Product Group', description: 'Description for Card 3' },
  //   { id: 2, title: 'Components', description: 'Description for Card 2' },
  //   { id: 3, title: 'Smart Product Group', description: 'Description for Card 3' },
  // ];
  
  return (
    <div className="w-full h-full flex flex-col">
      <div data-testid="select-product-container" className="mb-6">
        <p data-testid="select-product-title" className="text-godrej-purple text-3xl font-medium">
          Select warehouse layout design
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
        <ScratchCard />
        <SmartWizardCard />
        <TemplateCard />
        <ImportCard />
      </div>
    </div>
  );
};

export default OverlayCardItems;