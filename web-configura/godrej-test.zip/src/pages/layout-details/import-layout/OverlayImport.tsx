import React from "react";
import Button from "../../../components/button/Button";

const OverlayImport = () => {
  return (
    <div data-testid="overlayImportContainer" className="bg-white shadow-md rounded-md p-5 h-[420px] flex flex-col">
      <h3 data-testid="overlayImportHeader" className="text-godrej-purple text-xl font-medium mb-5">
        Import Layout
      </h3>
      
      <div className="mb-2">
        <div className="border border-gray-300 rounded w-full">
          <input 
            type="text" 
            placeholder="Upload files" 
            className="outline-none w-full p-2"
            readOnly
          />
        </div>
        <p className="text-gray-500 text-xs mt-1">
          File size up to 15 Mb, in .dwg, .dxf format
        </p>
      </div>
      
      <div className="flex justify-center mt-6">
        <Button
          id={`overlayImport-importBtn`} 
          // className="btn-primary-32 text-white px-8 py-2 rounded flex items-center gap-2 transition-colors"
          className="btn-primary-40 flex items-center gap-3"
          label={"Import"}
          iconClass="icon-[mdi--import]" 
        />
      </div>
      
      <div className="mt-auto">
        <p className="text-gray-500 text-xs">
          Note: File may be component, product group, plan layout, smart product group
        </p>
      </div>
    </div>
  );
};

export default OverlayImport;