import React from "react";
import { useNavigate } from 'react-router-dom';

const Template = () => {
  const navigate = useNavigate();

  const handleConfigurationLayout = () => {
    navigate('/configuration-layout');
  };

  return (
    <div data-testid="templateContainer" className="bg-white shadow-md rounded-md p-5 h-[420px] flex flex-col">
      <h3 data-testid="templateHeader" className="text-godrej-purple text-xl font-medium mb-5">
        Start from a Templates
      </h3>

      <div className="space-y-3">
        <div className="flex items-center p-2 hover:bg-gray-50 rounded-md transition-colors cursor-pointer">
          <div className="w-10 h-10 bg-gray-100 border border-gray-200 flex justify-center items-center mr-3">
            <img src="images/overlay-template.png" alt="warehouse" className="max-w-full max-h-full" />
          </div>
          <div>
            <span className="text-sm font-medium block">Flat Warehouse</span>
            <span className="text-xs text-gray-600">100m x 200m</span>
          </div>
        </div>

        <div className="flex items-center p-2 hover:bg-gray-50 rounded-md transition-colors cursor-pointer">
          <div className="w-10 h-10 bg-gray-100 border border-gray-200 flex justify-center items-center mr-3">
            <img src="images/overlay-template.png" alt="warehouse" className="max-w-full max-h-full" />
          </div>
          <div>
            <span className="text-sm font-medium block">Roof Warehouse</span>
            <span className="text-xs text-gray-600">150m x 200m</span>
          </div>
        </div>

        <div className="flex items-center p-2 hover:bg-gray-50 rounded-md transition-colors cursor-pointer">
          <div className="w-10 h-10 bg-gray-100 border border-gray-200 flex justify-center items-center mr-3">
            <img src="images/overlay-template.png" alt="warehouse" className="max-w-full max-h-full" />
          </div>
          <div>
            <span className="text-sm font-medium block">Inclined Warehouse</span>
            <span className="text-xs text-gray-600">100m x 100m</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Template;