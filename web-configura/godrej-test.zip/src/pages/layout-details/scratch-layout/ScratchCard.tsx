import React from "react";
import { useNavigate } from 'react-router-dom';

const ScratchCard = () => {
  const navigate = useNavigate();

  const handleNewWarehouse = () => {
    navigate('/configuration-layout');
  };

  return (
    <div data-testid="scratchContainer" className="bg-white shadow-md rounded-md p-5 h-[420px] flex flex-col">
      <h3 data-testid="scratchHeader" className="text-godrej-purple text-xl font-medium mb-5">
        Start from Scratch
      </h3>

      <div data-testid="warehouseTypeContainer" className="mb-4">
        <label className="text-sm mb-2 block font-medium">Warehouse Type</label>
        <div className="flex items-center gap-3">
          <div className="border border-gray-300 rounded">
            <select className="outline-none p-2 w-[120px] bg-white">
              <option value="flat">Flat</option>
              <option value="roof">Roof</option>
              <option value="inclined">Inclined</option>
            </select>
          </div>
          <button 
            data-testid="newWarehouseBtn" 
            className="text-godrej-purple hover:underline font-medium"
            onClick={handleNewWarehouse}
          >
            New Warehouse
          </button>
        </div>
      </div>

      <div className="flex-grow">
        {/* Empty space for the rest of the card */}
      </div>
    </div>
  );
};

export default ScratchCard;