import React from "react";
import { useState } from "react";
import OverlayManualCardItems from "./OverlayManualCardItems";

type OverlayLayoutCardProps = {
  showOverlay: boolean;
  setShowOverlay: (value: boolean) => void;
};

const OverlayLayoutCard: React.FC<OverlayLayoutCardProps> = ({
  showOverlay,
  setShowOverlay,
}) => {
  return (
    <div>
      {showOverlay && (
        <div 
          data-testid="overlay-popup-container" 
          className="fixed inset-0 flex items-center justify-center bg-opacity bg-opacity-50 z-50 p-4"
        >
          <div 
            data-testid="overlay-popup" 
            className="bg-white border rounded-lg border-gray-300 shadow-xl w-[70%] h-[55%] flex flex-col relative"
            style={{ maxHeight: '90vh' }}
          >
            <button 
              data-testid="overlay-popup-close-btn" 
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-800 transition-colors z-10" 
              onClick={() => setShowOverlay(false)}
            >
              <span className="icon-[carbon--close-outline] text-3xl"></span>
            </button>
            
            <div className="p-6">
              <OverlayManualCardItems />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OverlayLayoutCard;
