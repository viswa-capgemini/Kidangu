import { useState } from "react";
import OverlayLayoutCard from "./OverlayLayoutCard";
import Button from "../../components/button/Button"
import { useNavigate } from 'react-router-dom';

// const fields = [
//   { iconClass: "icon-[material-symbols--upload-rounded]", label: "Upload BOM" },
//   { iconClass: "icon-[mdi--import]", label: "Import" },
//   { iconClass: "icon-[ix--export]", label: "Export" },
// ];

const Layout = () => {
  const [selectedOption, setSelectedOption] = useState("");
  const [showOverlay, setShowOverlay] = useState(false);

  const navigate = useNavigate();

  const handleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedOption(event.target.value);
  };

  return (
    <>
      <div data-testid="layout-container" className="relative flex flex-col md:flex-row justify-between border-b border-gray-300 p-4 z-0">
        <h1 className="text-3xl md:text-4xl text-godrej-purple font-medium mb-4 md:mb-0">
          Layout Details
        </h1>

        <div data-testid="layout-wrapper" className="flex flex-col md:flex-row items-center gap-3 mb-4 md:mb-0">
          <select
            data-testid="customer-select"
            value={selectedOption}
            onChange={handleChange}
            className="border border-gray-300 rounded px-3 py-2 w-full md:w-auto"
          >
            <option data-testid="select-customer" value="" disabled>
              Select Customer
            </option>
            <option data-testid="customer-1" value="customer1">Customer 1</option>
          </select>
          <select
            data-testid="enquiry-ref-select"
            value={selectedOption}
            onChange={handleChange}
            className="border border-gray-300 rounded px-3 py-2 w-full md:w-auto"
          >
            <option data-testid="select-ref-num" value="" disabled>
              Select Enquiry Reference Number
            </option>
            <option data-testid="customer-1" value="customer1">Customer 1</option>
          </select>
        </div>
        {/* {fields.map((field, idx) => (
          <button
            key={idx}
            className={`flex items-center space-x-1 bg-godrej-purple hover:bg-pink-300 px-3 py-1 rounded-full`}
          >
            <span className={`${field.iconClass} text-xl text-white`}></span>
            <span className="text-md text-white font-small">{field.label}</span>
          </button>
        ))} */}

        <div className="flex flex-wrap justify-center md:justify-end items-center gap-3">
          <Button
            className="btn-primary-32 flex items-center gap-2"
            label="Upload BOM"
            iconClass="icon-[material-symbols--upload-rounded]"
          />
          <Button
            className="btn-primary-32 flex items-center gap-2"
            label="Import"
            iconClass="icon-[mdi--import]"
          />
          <Button
            className="btn-primary-32 flex items-center gap-2"
            label="Export"
            iconClass="icon-[ix--export]"
          />
        </div>
      </div>

      <div className="p-8">
        <div
          data-testid="create-project-container"
          className="create-project relative border border-gray-300 rounded-lg w-[250px] h-[250px] flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50 transition-colors"
          onClick={() => setShowOverlay(true)}
        >
          <span
            data-testid="create-project-icon"
            className="icon-[octicon--project-symlink-16] text-4xl mb-4 text-godrej-purple"
          ></span>
          <h3
            data-testid="create-project-header"
            className="text-lg font-medium text-godrej-purple"
          >
            New Project
          </h3>
        </div>
      </div>

      <OverlayLayoutCard
        showOverlay={showOverlay}
        setShowOverlay={setShowOverlay}
      />
    </>
  );
};

export default Layout;