import React from "react";
import Button from "../../../components/button/Button";

const SmartWizardCard = () => {
  return (
    <div data-testid="wizardContainer" className="bg-white shadow-md rounded-md p-5 h-[420px] flex flex-col">
      <h3 data-testid="wizardHeader" className="text-godrej-purple text-xl font-medium mb-5">
        Smart Wizard
      </h3>
      
      <div className="mb-3">
        <label className="text-sm font-medium mb-1 block">Rack Type</label>
        <div className="border border-gray-300 rounded">
          <select className="outline-none w-full p-2 bg-white">
            <option value="shuttle">Shuttle Pallet</option>
            <option value="drive">Drive-In</option>
            <option value="selective">Selective</option>
          </select>
        </div>
      </div>
      
      <div className="mb-3">
        <div className="flex items-center justify-between mb-1">
          <label className="text-sm font-medium">Dimension</label>
          <div className="flex items-center">
            <span className="text-xs mr-2 flex items-center">
              <input type="radio" name="unit" id="m" className="mr-1" checked />
              <label htmlFor="m">m</label>
            </span>
            <span className="text-xs flex items-center">
              <input type="radio" name="unit" id="feet" className="mr-1" />
              <label htmlFor="feet">feet</label>
            </span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="border border-gray-300 rounded">
            <input type="text" placeholder="Length" className="outline-none w-full p-2" />
          </div>
          <div className="border border-gray-300 rounded">
            <input type="text" placeholder="Width" className="outline-none w-full p-2" />
          </div>
          <div className="border border-gray-300 rounded">
            <input type="text" placeholder="Height" className="outline-none w-full p-2" />
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <label className="text-sm font-medium mb-1 block">Select Product Group</label>
        <div className="grid grid-cols-2 gap-y-2 gap-x-3">
          <div className="flex items-center">
            <input type="checkbox" id="mens" className="mr-2 h-4 w-4" />
            <label htmlFor="mens" className="text-sm">Men's Room</label>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="womens" className="mr-2 h-4 w-4" />
            <label htmlFor="womens" className="text-sm">Women's Room</label>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="office" className="mr-2 h-4 w-4" />
            <label htmlFor="office" className="text-sm">Office</label>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="reception" className="mr-2 h-4 w-4" />
            <label htmlFor="reception" className="text-sm">Reception</label>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="conference" className="mr-2 h-4 w-4" />
            <label htmlFor="conference" className="text-sm">Conference</label>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="showroom" className="mr-2 h-4 w-4" />
            <label htmlFor="showroom" className="text-sm">Show Room</label>
          </div>
        </div>
      </div>
      
      <div className="mt-auto flex justify-center">
        <Button 
          id="create-btn" 
          className="btn-primary-32 flex items-center gap-3"
          label="Create"
        />
      </div>
    </div>
  );
};

export default SmartWizardCard;