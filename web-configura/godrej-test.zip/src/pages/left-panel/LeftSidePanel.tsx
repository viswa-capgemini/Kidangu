import { Link, useLocation } from "react-router";
import { slugify } from "../../helper";

type LeftSidePanelProps = {
  showLabels: boolean;
  selectedIdx: number;
  setShowLabels: (value: boolean) => void;
  setSelectedIdx: (idx: number) => void;
  isOpen: boolean;
  reducedLeftPan?: boolean;
};

export const fields = [
  {
    iconClass: "icon-[material-symbols--dashboard-outline]",
    label: "Dashboard",
  },
  { iconClass: "icon-[icon-park-outline--form-one]", label: "Enquiry Form" },
  { iconClass: "icon-[ic--baseline-list-alt]", label: "Enquiry List" },
  { iconClass: "icon-[lsicon--user-all-filled]", label: "Customer" },
  { iconClass: "icon-[mingcute--layout-line]", label: "Layout Details" },
  { iconClass: "icon-[ant-design--product-outlined]", label: "Master Inventory" },
  { iconClass: "icon-[eos-icons--products-outlined]", label: "Product Groups" },
  { iconClass: "icon-[material-symbols--rule]", label: "Rules" },
  { iconClass: "icon-[hugeicons--analytics-up]", label: "Analytics" },
  { iconClass: "icon-[material-symbols--preview-outline]", label: "Previews" },
  // { iconClass: "icon-[cuida--help-outline]", label: "Help" },
];

const LeftSidePanel: React.FC<LeftSidePanelProps> = ({
  showLabels,
  setShowLabels,
  selectedIdx,
  setSelectedIdx,
  isOpen,
  reducedLeftPan
}) => {
  // const location = useLocation();
  // const reduceLeftSidePanel = ["/configuration-layout"];
  // const reducedLeftPan = reduceLeftSidePanel.includes(location.pathname);
  return (
    <div
      data-testid="left-side-container"
      className={`left-side-panel absolute top-0 left-0 h-screen z-10 bg-godrej-lite-purple text-white p-2 space-y-2 transition-all duration-300 ${
        showLabels || isOpen ? "w-50" : "w-10"
      } ${reducedLeftPan ? "top-12 h-[calc(100vh-3rem)]" : "top-0 h-screen"}`}
      onMouseEnter={() => setShowLabels(true)}
      onMouseLeave={() => setShowLabels(false)}
    >
      {/* Hamburger icon only when reduced */}
      {/* {reducedLeftPan && (
        <div className="relative">
        <button >
        <span data-testid="hamburger-icon" className="icon-[solar--hamburger-menu-outline]"style={{color: "black"}}></span>
        </button>
        </div>
      )} */}

      <div data-testid="left-side-wrapper" className="flex flex-col space-y-4">
        {fields.map((field, idx) => (
          <button
            data-testid={`${field.label
              .toLocaleLowerCase()
              .replace(" ", "-")}-btn`}
            key={idx}
            className={`flex items-center space-x-3 py-2 transition-all duration-300 ${
              selectedIdx === idx ? "text-godrej-purple" : "hover:bg-pink-100"
            }`}
            onClick={() => setSelectedIdx(idx)}
          >
            <span
              className={`${field.iconClass} text-2xl shrink-0 ${
                selectedIdx === idx ? "text-godrej-purple" : "text-black"
              }`}
            ></span>

            {(showLabels || isOpen) && (
              <Link to={`${slugify(field.label)}`}>
                <span
                  className={`text-sm font-medium whitespace-nowrap ${
                    selectedIdx === idx ? "text-godrej-purple" : "text-black"
                  }`}
                >
                  {field.label}
                </span>
              </Link>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default LeftSidePanel;
