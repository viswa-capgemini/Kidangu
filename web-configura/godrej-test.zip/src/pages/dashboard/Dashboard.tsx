import React from 'react'

const Dashboard = () => {
  return (
    <>
      <div>
        <h1 data-testid="" className='text-godrej-purple text-4xl'>Dashboard</h1>
      </div>

      <p className="flex flex-col gap-4 p-4 absolute bottom-2 right-2 text-white select-all label01">
          Version-1.0.0
        </p>
    </>
  )
}

export default Dashboard
