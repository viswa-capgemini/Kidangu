import React from "react";

interface TabsProps {
  tabs: string[];
  activeTab: string;
  onChange: (tab: string) => void;
}

const Tabs: React.FC<TabsProps> = ({ tabs, activeTab, onChange }) => {
  return (
    <div className="flex w-full border-b border-gray-300 bg-gray-100" role="tablist">
      {tabs.map((tab, index) => {
        const isActive = activeTab === tab;
        const isFirst = index === 0;
        const isLast = index === tabs.length - 1;

        // Base active styles
        let activeClasses = "bg-gray-200 font-bold border-gray-500";

        // Add conditional borders
        if (isActive) {
          if (isFirst) {
            activeClasses += " border-b border-r"; // bottom + right
          } else if (isLast) {
            activeClasses += " border-b border-l"; // bottom + left
          } else {
            activeClasses += " border-b border-l border-r"; // bottom + left + right
          }
        }

        return (
          <button
            key={tab}
            onClick={() => onChange(tab)}
            className={`flex-1 text-center px-4 py-2 text-sm font-medium transition-colors
              ${isActive ? activeClasses : "text-gray-700 hover:bg-gray-50"}
            `}
            aria-selected={isActive}
            role="tab"
          >
            {tab}
          </button>
        );
      })}
    </div>
  );
};

export default Tabs;