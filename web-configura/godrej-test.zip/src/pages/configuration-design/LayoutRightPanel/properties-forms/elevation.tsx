import React from "react";
import FloatingOrderQuantity from "../../../../components/custom-inputs/FloatingOrderQunatity";
import FloatingLabelInputFields from "../../../../components/custom-inputs/FloatingLabelInputFields";

const Elevation = () => {
  return (
    <div className="space-y-3 w-full">
        <div className="grid grid-cols-2 m-2 gap-2">
      <input
        type="text"
        placeholder="ID"
        className="w-full text-sm border p-2 rounded"
      />
      <input
        type="text"
        placeholder="Enter product group name"
        className="w-full border p-2 rounded"
      />
      <input
        type="text"
        placeholder="Enter configuration name"
        className="w-full border p-2 rounded"
      />
      <input
        type="text"
        placeholder="Version Number"
        className="w-full border p-2 rounded"
      />
      <input
        type="text"
        placeholder="Last updated Date"
        className="w-full border p-2 rounded"
      />

      {/* <FloatingLabelInputFields label="Id"/> */}
      <FloatingLabelInputFields label="Enter product group name"/>
      {/* <FloatingLabelInputFields label="Enter configuration name"/>
      <FloatingLabelInputFields label="Version Number"/>
      <FloatingLabelInputFields label="Last updated Date"/> */}
      </div>

      {/* Arrangement */}
      <div className="flex flex-wrap items-center gap-4 w-full">
        <span className="font-semibold">Arrangement</span>
        <label>
          <input type="radio" name="arrangement" /> Single Row
        </label>
        <label>
          <input type="radio" name="arrangement" /> Multi Row
        </label>
        <FloatingOrderQuantity
          maxVal={10}
          width="w-[90px]"
          label="No. of rows"
        />
      </div>

      {/* Orientation */}
      <div className="flex flex-wrap items-center gap-4 w-full">
        <span className="font-semibold">Orientation</span>
        <label>
          <input type="radio" name="orientation" /> Horizontal
        </label>
        <label>
          <input type="radio" name="orientation" /> Vertical
        </label>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <FloatingOrderQuantity
          maxVal={100}
          width="w-[110px]"
          label="No. of rack columns"
        />
        <FloatingOrderQuantity
          maxVal={500}
          width="w-[110px]"
          label="No. of add ons"
        />
        <FloatingOrderQuantity
          maxVal={2000}
          width="w-[110px]"
          label="No. of Pallet"
        />
      </div>
    </div>
  );
};

export default Elevation;
