import React from "react";
// import FloatingInputLabel from "../../../FloatingSelect";
import FloatingSelect from "../../../../components/custom-inputs/FloatingSelect";

const Rack = () => {
  return (
    <div>
      <div className="flex flex-col gap-4">
        <FloatingSelect
          label="Uprights"
          options={["GXL90", "GXL100", "GXL120"]}
        />
        <FloatingSelect
          label="Base Plates"
          options={["GXL90", "GXL100", "GXL120"]}
        />
        <FloatingSelect label="Shim" options={["GXL90", "GXL100", "GXL120"]} />
        <FloatingSelect
          label="Splice"
          options={["GXL90", "GXL100", "GXL120"]}
        />
        <FloatingSelect label="Beams" options={["GXL90", "GXL100", "GXL120"]} />
        <FloatingSelect
          label="Beams+Cleat"
          options={["GXL90", "GXL100", "GXL120"]}
        />
      </div>

      <p>Abhishek Kumar</p>
      <p className="text-label01">Abhishek</p>
    </div>
  );
};

export default Rack;
