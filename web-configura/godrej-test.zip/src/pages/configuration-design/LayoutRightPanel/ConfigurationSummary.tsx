import React, { useState } from "react";

const ConfigurationSummary = () => {
  const [isOpen, setIsOpen] = useState(true);
  const summaryData = [
    { label: "Total Area", value: "10,000 sqm" },
    { label: "Utilized Area", value: "20%" },
    { label: "Material Tonnage", value: "500MT" },
    { label: "No of product group", value: "2" },
    { label: "No of Components", value: "25" },
    { label: "No of Smart Product Group", value: "11" },
  ];
  return (
    <div className="border-t border-gray-600 bg-gray-50 flex flex-col">
      {/* Accordion Header */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer w-full"
      >
        <h3 className="text-sm font-semibold">Configuration Summary</h3>
        {/* <span>{isOpen ? "▲" : "▼"}</span> */}
        <span>
          {isOpen ? (
            <span
              className="icon-[ic--sharp-expand-less] w-6 h-6"
              style={{ color: "#810055" }}
            />
          ) : (
            <span
              className="icon-[ic--sharp-expand-more] w-6 h-6"
              style={{ color: "#810055" }}
            />
          )}
        </span>
      </div>

      {/* Accordion Content */}
      <div
        className={`transition-all duration-300 ${
          isOpen
            ? "max-h-60 overflow-y-auto scrollbar-hide"
            : "max-h-0 overflow-hidden"
        } w-full`}
      >
        <div className="grid grid-cols-2 gap-y-2 px-2">
          {summaryData.map((item, index) => (
            <React.Fragment key={index}>
              <div className="text-[12px] text-gray-600">{item.label}</div>
              <div className="text-right text-[12px]">{item.value}</div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConfigurationSummary;
