import React, { useState } from "react";

type Item = {
  product: string;
  quantity: number;
  price: number;
};

const bomData: Item[] = [
  { product: "Beam", quantity: 5, price: 13 },
  { product: "Bracing", quantity: 12, price: 25 },
  { product: "Frame", quantity: 6, price: 120 },
  { product: "Joints", quantity: 12, price: 50 },
];

const BOMTable: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);

  const total = bomData.reduce(
    (sum, item) => sum + item.quantity * item.price,
    0
  );

  return (
    <div className="h-full w-full bg-gray-50 flex flex-col border-t border-gray-600">
      {/* Accordion Header */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer w-full"
      >
        <h3 className="text-sm font-semibold">BOM Table</h3>
        {/* <span>{isOpen ? "▲" : "▼"}</span> */}
        <span>
          {isOpen ? (
            <span
              className="icon-[ic--sharp-expand-less] w-6 h-6"
              style={{ color: "#810055" }}
            />
          ) : (
            <span
              className="icon-[ic--sharp-expand-more] w-6 h-6"
              style={{ color: "#810055" }}
            />
          )}
        </span>
      </div>

      {/* Table */}
      {isOpen && (
        <table className="w-full text-center text-sm">
          <thead className="text-[12px] border-b">
            <tr>
              <th className="py-2 text-gray-600">Product</th>
              <th className="py-2 text-gray-600">Quantity</th>
              <th className="py-2 text-gray-600">Price(₹)</th>
              <th className="py-2 text-gray-600">Total Price(₹)</th>
            </tr>
          </thead>
          <tbody className="px-2">
            {bomData.map((item, index) => (
              <tr
                key={index}
                className="border-b last:border-none text-[12px] text-gray-600"
              >
                <td>{item.product}</td>
                <td>{item.quantity}</td>
                <td>{item.price}/pc</td>
                <td>{item.quantity * item.price}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="border-t font-bold text-gray-600">
            <tr>
              <td colSpan={3} className="text-right">
                Total
              </td>
              <td>{total}</td>
            </tr>
          </tfoot>
        </table>
      )}
    </div>
  );
};

export default BOMTable;
