import React, { useState } from "react";
import Tabs from "./Tabs";
import SKU from "./properties-forms/sku";
import Rack from "./properties-forms/rack";
import MheForm from "./properties-forms/mhe";
import FloatingOrderQuantity from "../../../components/custom-inputs/FloatingOrderQunatity";
import Elevation from "./properties-forms/elevation";

const PropertiesSection: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [activeTab, setActiveTab] = useState("Elevation");

  const tabList = ["Elevation", "SKU", "Rack"];

  return (
    <div className="bg-gray-50 flex flex-col">
      {/* Accordion Header */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer"
      >
        <h3 className="text-sm font-semibold">Properties</h3>
        {/* <span>{isOpen ? "▲" : "▼"}</span> */}
        <span>
          {isOpen ? (
            <span
              className="icon-[ic--sharp-expand-less] w-6 h-6"
              style={{ color: "#810055" }}
            />
          ) : (
            <span
              className="icon-[ic--sharp-expand-more] w-6 h-6"
              style={{ color: "#810055" }}
            />
          )}
        </span>
      </div>

      {/* Accordion Content */}
      <div
        className={`transition-all duration-300 ${
          isOpen
            ? "max-h-80 overflow-y-auto scrollbar-hide"
            : "max-h-0 overflow-hidden"
        } w-full overflow-x-hidden`}
      >
        <div className="p-2">
          {/* Tabs */}
          <div className="w-full">
            <Tabs
              tabs={tabList}
              activeTab={activeTab}
              onChange={setActiveTab}
            />
          </div>

          {/* Tab Content */}
          <div className="mt-4 space-y-3 w-full">
            {activeTab === "Elevation" && (
              <div className="w-full">
                <Elevation />
              </div>
            )}
            {activeTab === "SKU" && (
              <div className="w-full">
                <SKU />
              </div>
            )}
            {activeTab === "Rack" && (
              <div className="w-full">
                <Rack />
              </div>
            )}
            {/* {activeTab === "MHE" && <div className="w-full"><MheForm/></div>} */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertiesSection;
