import Accordion from "../../../components/accordion/Accordion";
import { componentSections } from "../../../constants/constants";

type ComponentItem =
  | { name: string; iconClass: string }
  | { name: string; image: string };

type ComponentSection = {
  title: string;
  rowStructure: number[];
  items: ComponentItem[];
};

const ComponentsSection: React.FC = () => {
  const getGridClass = (cols: number) => {
    switch (cols) {
      case 1:
        return "grid-cols-1";
      case 2:
        return "grid-cols-2";
      case 4:
        return "grid-cols-3";
      default:
        return "grid-cols-2";
    }
  };

  return (
    <Accordion title="Components" defaultOpen={false}>
      <div className="space-y-6">
        {(componentSections as ComponentSection[]).map((section, index) => (
          <div key={index}>
            <h4 className="text-xs font-bold mb-2">{section.title}</h4>
            <div className={`grid ${getGridClass(section.rowStructure[0])} gap-4`}>
              {section.items.map((item, i) => (
                <div key={i} className="flex flex-col items-center">
                  {"iconClass" in item ? (
                    <span className={`${item.iconClass} w-8 h-8`} />
                  ) : (
                    <img src={item.image} alt={item.name} className="w-8 h-8 " />
                  )}
                  <span className="text-[9px] mt-1 text-gray-600">{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Accordion>
  );
};

export default ComponentsSection;
