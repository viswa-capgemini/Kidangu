import React, { useState } from "react";
import ProductGroup from "./LayoutLeftPanel/ProductGroup";
import ComponentsSection from "./LayoutLeftPanel/ComponentsSection";
import SmartProductGroup from "./LayoutLeftPanel/SmartProductGroup";
import CollapseIcon from "../../assets/images/Component 186 – 3.svg";
import ExpandIcon from "../../assets/images/Component 191 – 3.svg";
import LayoutRightPanel from "./LayoutRightPanel";

const LayoutLeftPanel = () => {
  const [isOpen, setIsOpen] = React.useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);

  return (
    <div>
      <div
        className={`relative ${
          isOpen
            ? "flex justify-end w-[190px] m-1 items-center p-1 bg-gray-200"
            : "flex justify-start m-1"
        } `}
      >
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-white border rounded shadow p-1 hover:bg-gray-100"
        >
          {isOpen ? (
            <img src={CollapseIcon} alt="Collapse" className="w-5 h-5" />
          ) : (
            <img src={ExpandIcon} alt="Expand" className="w-5 h-5" />
          )}
        </button>
      </div>
      {isOpen && (
        <div className="absolute bg-white overflow-y-auto w-[190px] h-screen scrollbar-hide m-1">
          <ProductGroup
            onSelect={(name) => setSelectedItem({ type: "product", name })}
          />
          <ComponentsSection />
          <SmartProductGroup />
        </div>
      )}

      {/* Right Panel */}
      {selectedProduct && (
        <div className=" flex flex-end w-1/4 bg-gray-50 border-l border-gray-300 p-4">
          <LayoutRightPanel />
        </div>
      )}
    </div>
  );
};

export default LayoutLeftPanel;