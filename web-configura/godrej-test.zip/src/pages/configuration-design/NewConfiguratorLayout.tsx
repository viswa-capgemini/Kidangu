import React from "react";
import NewLayoutLeftPanel from "./NewLayoutLeftPanel";
import LayoutRightPanel from "./LayoutRightPanel";
import { LayoutProvider } from "../../context/propertyPanelContext";

const NewConfiguratorLayout: React.FC = () => {
  return (
    <LayoutProvider>
      <div data-testid="configurationLayoutContainer" className="flex justify-between h-screen overflow-hidden scrollbar-hide">
        <NewLayoutLeftPanel />
        <LayoutRightPanel />
      </div>
    </LayoutProvider>
  );
};

export default NewConfiguratorLayout;