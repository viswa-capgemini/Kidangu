// import React from 'react';

// const Toolbar = ({ onToolSelect, selectedTool }) => {
//   const tools = [
//     { id: 'line', name: 'Line' },
//     { id: 'rectangle', name: 'Rectangle' },
//     { id: 'circle', name: 'Circle' },
//     { id: 'pencil', name: 'Pencil' },
//     { id: 'text', name: 'Text' },
//   ];

//   return (
//     <div className="toolbar">
//       <h2 className="toolbar-title">Floor Plan Tools</h2>
//       {tools.map((tool) => (
//         <button
//           key={tool.id}
//           className={`tool-button ${selectedTool === tool.id ? 'selected' : ''}`}
//           onClick={() => onToolSelect(tool.id)}
//         >
//           {tool.name}
//         </button>
//       ))}
//     </div>
//   );
// };

// export default Toolbar;

import React from 'react';

const Toolbar = ({ onToolSelect, selectedTool }) => {
  const tools = [
    { id: 'line', name: 'Line' },
    { id: 'rectangle', name: 'Rectangle' },
    { id: 'circle', name: 'Circle' },
    { id: 'pencil', name: 'Pencil' },
    { id: 'text', name: 'Text' },
  ];

  return (
    <div className="toolbar">
      <h2 className="toolbar-title">Drawing Tools</h2>
      {tools.map((tool) => (
        <button
          key={tool.id}
          className={`tool-button ${selectedTool === tool.id ? 'selected' : ''}`}
          onClick={() => onToolSelect(tool.id)}
        >
          {tool.name}
        </button>
      ))}
    </div>
  );
};

export default Toolbar;