
// import React, { useState } from 'react';

// const TopBar = ({ 
//   selectedTool, 
//   onToolSelect, 
//   onUndo, 
//   onRedo, 
//   canUndo, 
//   canRedo,
//   showDimensions,
//   onToggleDimensions,
//   scale,
//   onScaleChange,
//   zoomLevel,
//   onZoomIn,
//   onZoomOut,
//   onResetZoom,
//   viewMode,
//   onToggleViewMode
// }) => {
//   const [showScaleInput, setShowScaleInput] = useState(false);

//   const tools = [
//     { id: 'line', name: 'Line', icon: 'M3,3 L21,21' },
//     { id: 'rectangle', name: 'Rectangle', icon: 'M4,4 H20 V20 H4 Z' },
//     { id: 'circle', name: 'Circle', icon: 'M12,12 m-8,0 a8,8 0 1,0 16,0 a8,8 0 1,0 -16,0' },
//     { id: 'pencil', name: 'Pencil', icon: 'M3,17.25 L3,21 L6.75,21 L17.81,9.94 L14.06,6.19 L3,17.25 Z M20.71,7.04 C21.1,6.65 21.1,6.02 20.71,5.63 L18.37,3.29 C17.98,2.9 17.35,2.9 16.96,3.29 L15.13,5.12 L18.88,8.87 L20.71,7.04 Z' },
//     { id: 'text', name: 'Text', icon: 'M5,3 H19 V7 H16 V19 H8 V7 H5 V3 Z' }
//   ];

//   const handleScaleChange = (e) => {
//     const newScale = parseFloat(e.target.value);
//     if (!isNaN(newScale) && newScale > 0) {
//       onScaleChange(newScale);
//     }
//   };

//   return (
//     <div className="top-bar">
//       <div className="tool-group">
//         {tools.map((tool) => (
//           <button
//             key={tool.id}
//             className={`tool-icon ${selectedTool === tool.id ? 'selected' : ''}`}
//             onClick={() => onToolSelect(tool.id)}
//             title={tool.name}
//             disabled={viewMode === '3D'} // Disable drawing tools in 3D mode
//           >
//             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//               <path d={tool.icon} />
//             </svg>
//           </button>
//         ))}
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className="tool-icon" 
//           onClick={onUndo} 
//           disabled={!canUndo || viewMode === '3D'} // Disable in 3D mode
//           title="Undo"
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M3,10 C3,10 7,5 12,5 C17,5 21,10 21,10" />
//             <path d="M3,10 L8,10 L8,5" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onRedo} 
//           disabled={!canRedo || viewMode === '3D'} // Disable in 3D mode
//           title="Redo"
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M21,10 C21,10 17,5 12,5 C7,5 3,10 3,10" />
//             <path d="M21,10 L16,10 L16,5" />
//           </svg>
//         </button>
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className={`tool-icon ${showDimensions ? 'selected' : ''}`} 
//           onClick={onToggleDimensions}
//           title="Toggle Dimensions"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M3,6 H21" />
//             <path d="M3,6 L3,3" />
//             <path d="M21,6 L21,3" />
//             <path d="M12,3 L12,21" />
//             <path d="M12,21 L9,21" />
//             <path d="M12,21 L15,21" />
//           </svg>
//         </button>
        
//         <div className="scale-control">
//           <button 
//             className="tool-icon" 
//             onClick={() => setShowScaleInput(!showScaleInput)}
//             title="Scale Settings"
//           >
//             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//               <path d="M3,6 H21" />
//               <path d="M3,12 H21" />
//               <path d="M3,18 H21" />
//             </svg>
//           </button>
          
//           {showScaleInput && (
//             <div className="scale-popup">
//               <label>
//                 Scale (m/px):
//                 <input
//                   type="number"
//                   value={scale}
//                   onChange={handleScaleChange}
//                   step="0.001"
//                   min="0.001"
//                   max="0.1"
//                 />
//               </label>
//               <div className="scale-info">
//                 1m = {Math.round(1 / scale)} pixels
//               </div>
//             </div>
//           )}
//         </div>
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className="tool-icon" 
//           onClick={onZoomIn}
//           title="Zoom In"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <line x1="12" y1="8" x2="12" y2="16" />
//             <line x1="8" y1="12" x2="16" y2="12" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onZoomOut}
//           title="Zoom Out"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <line x1="8" y1="12" x2="16" y2="12" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onResetZoom}
//           title="Reset Zoom"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <path d="M8,12 L16,12" />
//             <path d="M12,8 L12,16" />
//           </svg>
//         </button>
//         {viewMode === '2D' && (
//           <div className="zoom-level">
//             {Math.round(zoomLevel * 100)}%
//           </div>
//         )}
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className={`tool-icon ${viewMode === '3D' ? 'selected' : ''}`} 
//           onClick={onToggleViewMode}
//           title={viewMode === '2D' ? 'Switch to 3D View' : 'Switch to 2D View'}
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M12,2 L22,8 L12,14 L2,8 Z" />
//             <path d="M12,14 L12,22" />
//             <path d="M22,8 L22,16 L12,22 L2,16 L2,8" />
//           </svg>
//         </button>
//         <div className="view-mode-label">
//           {viewMode} View
//         </div>
//       </div>
//     </div>
//   );
// };

// export default TopBar;


import React, { useState } from 'react';
import generateCanvasPDF from './generateCanvasPDF';

const TopBar = ({ 
  selectedTool, 
  onToolSelect, 
  onUndo, 
  onRedo, 
  canUndo, 
  canRedo,
  showDimensions,
  onToggleDimensions,
  scale,
  onScaleChange,
  unit,
  onUnitChange,
  zoomLevel,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  viewMode,
  onToggleViewMode,
  stageRef
}) => {
  const [showScaleInput, setShowScaleInput] = useState(false);

  const tools = [
    { id: 'line', name: 'Line', icon: 'M3,3 L21,21' },
    { id: 'rectangle', name: 'Rectangle', icon: 'M4,4 H20 V20 H4 Z' },
    { id: 'circle', name: 'Circle', icon: 'M12,12 m-8,0 a8,8 0 1,0 16,0 a8,8 0 1,0 -16,0' },
    { id: 'pencil', name: 'Pencil', icon: 'M3,17.25 L3,21 L6.75,21 L17.81,9.94 L14.06,6.19 L3,17.25 Z M20.71,7.04 C21.1,6.65 21.1,6.02 20.71,5.63 L18.37,3.29 C17.98,2.9 17.35,2.9 16.96,3.29 L15.13,5.12 L18.88,8.87 L20.71,7.04 Z' },
    { id: 'text', name: 'Text', icon: 'M5,3 H19 V7 H16 V19 H8 V7 H5 V3 Z' }
  ];

  // Units configuration with conversion factors (relative to meters)
  const units = [
    { id: 'meters', label: 'Meters', abbr: 'm', toMeters: 1 },
    { id: 'centimeters', label: 'Centimeters', abbr: 'cm', toMeters: 0.01 },
    { id: 'feet', label: 'Feet', abbr: 'ft', toMeters: 0.3048 },
    { id: 'inches', label: 'Inches', abbr: 'in', toMeters: 0.0254 },
    { id: 'yards', label: 'Yards', abbr: 'yd', toMeters: 0.9144 }
  ];
  
  // Find the current unit object
  const currentUnit = units.find(u => u.id === unit) || units[0];

  const handleScaleChange = (e) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value > 0) {
      // Convert the input scale (in current unit per pixel) to meters per pixel
      const metersPerPixel = value * currentUnit.toMeters;
      onScaleChange(metersPerPixel);
    }
  };

  // function to handle PDF export
  const handleExportPDF = () => {
  generateCanvasPDF({
    stageRef,
    showDimensions,
    scale,
    unit,
    title: 'Floor Plan'
  });
};

  // Calculate display value for the current unit
  const displayScale = scale / currentUnit.toMeters;
  
  // Calculate pixels per unit for display
  const pixelsPerUnit = 1 / displayScale;

  return (
    <div className="top-bar">
      <div className="tool-group">
        {tools.map((tool) => (
          <button
            key={tool.id}
            className={`tool-icon ${selectedTool === tool.id ? 'selected' : ''}`}
            onClick={() => onToolSelect(tool.id)}
            title={tool.name}
            disabled={viewMode === '3D'} // Disable drawing tools in 3D mode
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d={tool.icon} />
            </svg>
          </button>
        ))}
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className="tool-icon" 
          onClick={onUndo} 
          disabled={!canUndo || viewMode === '3D'} // Disable in 3D mode
          title="Undo"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3,10 C3,10 7,5 12,5 C17,5 21,10 21,10" />
            <path d="M3,10 L8,10 L8,5" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onRedo} 
          disabled={!canRedo || viewMode === '3D'} // Disable in 3D mode
          title="Redo"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21,10 C21,10 17,5 12,5 C7,5 3,10 3,10" />
            <path d="M21,10 L16,10 L16,5" />
          </svg>
        </button>
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className={`tool-icon ${showDimensions ? 'selected' : ''}`} 
          onClick={onToggleDimensions}
          title="Toggle Dimensions"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3,6 H21" />
            <path d="M3,6 L3,3" />
            <path d="M21,6 L21,3" />
            <path d="M12,3 L12,21" />
            <path d="M12,21 L9,21" />
            <path d="M12,21 L15,21" />
          </svg>
        </button>
        
        <div className="scale-control">
          <button 
            className="tool-icon" 
            onClick={() => setShowScaleInput(!showScaleInput)}
            title="Scale Settings"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3,6 H21" />
              <path d="M3,12 H21" />
              <path d="M3,18 H21" />
            </svg>
          </button>
          
          {showScaleInput && (
            <div className="scale-popup">
              <label>
                Unit:
                <select 
                  value={unit} 
                  onChange={(e) => onUnitChange(e.target.value)}
                  className="unit-select"
                >
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.label}</option>
                  ))}
                </select>
              </label>
              <label>
                Scale ({currentUnit.abbr}):
                <input
                  type="number"
                  value={displayScale.toFixed(6)}
                  onChange={handleScaleChange}
                  step={currentUnit.id === 'meters' ? 0.001 : 0.01}
                  min={currentUnit.id === 'meters' ? 0.001 : 0.01}
                  max={currentUnit.id === 'meters' ? 0.1 : 10}
                />
              </label>
              {/* <div className="scale-info">
                1 {currentUnit.abbr} = {Math.round(pixelsPerUnit)} pixels
              </div>
              <div className="scale-info">
                100 pixels = {(100 * scale / currentUnit.toMeters).toFixed(2)} {currentUnit.abbr}
              </div> */}
            </div>
          )}
        </div>
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className="tool-icon" 
          onClick={onZoomIn}
          title="Zoom In"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="16" />
            <line x1="8" y1="12" x2="16" y2="12" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onZoomOut}
          title="Zoom Out"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="8" y1="12" x2="16" y2="12" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onResetZoom}
          title="Reset Zoom"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <path d="M8,12 L16,12" />
            <path d="M12,8 L12,16" />
          </svg>
        </button>
        {viewMode === '2D' && (
          <div className="zoom-level">
            {Math.round(zoomLevel * 100)}%
          </div>
        )}
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className={`tool-icon ${viewMode === '3D' ? 'selected' : ''}`} 
          onClick={onToggleViewMode}
          title={viewMode === '2D' ? 'Switch to 3D View' : 'Switch to 2D View'}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12,2 L22,8 L12,14 L2,8 Z" />
            <path d="M12,14 L12,22" />
            <path d="M22,8 L22,16 L12,22 L2,16 L2,8" />
          </svg>
        </button>
        <div className="view-mode-label">
          {viewMode} View
        </div>
      </div>

      <div className="tool-group">
        <button
          className="tool-icon"
          onClick={handleExportPDF}
          title="Export as PDF"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
            <line x1="16" y1="13" x2="8" y2="13"></line>
            <line x1="16" y1="17" x2="8" y2="17"></line>
            <polyline points="10 9 9 9 8 9"></polyline>
          </svg>
        </button>
        <div className="view-mode-label">
          Export PDF
        </div>
      </div>
    </div>
  );
};

export default TopBar;