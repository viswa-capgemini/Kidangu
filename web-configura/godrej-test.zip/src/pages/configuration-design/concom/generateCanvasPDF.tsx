import { Stage } from 'react-konva';
import jsPDF from 'jspdf';
import Konva from 'konva';
 
interface GeneratePDFProps {
  stageRef: React.RefObject<Stage>;
  showDimensions: boolean;
  scale?: number;
  unit?: string;
  title?: string;
}
 
/**
 * Generates a PDF from the Konva stage with proper handling of grid lines and backgrounds
 * @param props Configuration for PDF generation
 */
const generateCanvasPDF = async ({
  stageRef,
  showDimensions,
  scale = 1,
  unit = 'meters',
  title = 'Floor Plan'
}: GeneratePDFProps): Promise<void> => {
  if (!stageRef.current) {
    console.error('Stage reference is not available');
    return;
  }
 
  try {
    // Show loading indicator
    const loadingElement = document.createElement('div');
    loadingElement.style.position = 'fixed';
    loadingElement.style.top = '50%';
    loadingElement.style.left = '50%';
    loadingElement.style.transform = 'translate(-50%, -50%)';
    loadingElement.style.padding = '20px';
    loadingElement.style.background = 'rgba(0,0,0,0.7)';
    loadingElement.style.color = 'white';
    loadingElement.style.borderRadius = '5px';
    loadingElement.style.zIndex = '9999';
    loadingElement.textContent = 'Generating PDF...';
    document.body.appendChild(loadingElement);
   
    // Get the Konva stage
    const stage = stageRef.current.getStage();
   
    // Get the current viewport position and scale
    const stagePosition = stage.position();
    const stageScale = stage.scale();
   
    // Calculate the visible area bounds
    const visibleWidth = stage.width() / stageScale.x;
    const visibleHeight = stage.height() / stageScale.y;
    const visibleX = -stagePosition.x / stageScale.x;
    const visibleY = -stagePosition.y / stageScale.y;
   
    // Create a new temporary stage for export
    const tempContainer = document.createElement('div');
    tempContainer.style.position = 'absolute';
    tempContainer.style.top = '-9999px';
    tempContainer.style.left = '-9999px';
    document.body.appendChild(tempContainer);
   
    const tempStage = new Konva.Stage({
      container: tempContainer,
      width: visibleWidth,
      height: visibleHeight
    });
   
    // Create background layer
    const bgLayer = new Konva.Layer();
    tempStage.add(bgLayer);
   
    // Add solid white background
    const background = new Konva.Rect({
      x: 0,
      y: 0,
      width: visibleWidth,
      height: visibleHeight,
      fill: 'white'
    });
    bgLayer.add(background);
   
    // Clone all layers from the original stage
    stage.getLayers().forEach((originalLayer, index) => {
      if (index === 0) {
        // For the first layer (grid layer), we'll recreate the grid
        const gridLayer = new Konva.Layer();
        tempStage.add(gridLayer);
       
        // Recreate grid lines with proper styling
        const gridSize = 20;
        const startX = Math.floor(visibleX / gridSize) * gridSize;
        const startY = Math.floor(visibleY / gridSize) * gridSize;
        const endX = Math.ceil((visibleX + visibleWidth) / gridSize) * gridSize;
        const endY = Math.ceil((visibleY + visibleHeight) / gridSize) * gridSize;
       
        // Vertical lines
        for (let i = startX; i <= endX; i += gridSize) {
          const line = new Konva.Line({
            points: [i - visibleX, 0, i - visibleX, visibleHeight],
            stroke: '#ddd',
            strokeWidth: 1
          });
          gridLayer.add(line);
        }
       
        // Horizontal lines
        for (let i = startY; i <= endY; i += gridSize) {
          const line = new Konva.Line({
            points: [0, i - visibleY, visibleWidth, i - visibleY],
            stroke: '#ddd',
            strokeWidth: 1
          });
          gridLayer.add(line);
        }
      } else {
        // For other layers, clone and adjust position
        const clonedLayer = originalLayer.clone();
        tempStage.add(clonedLayer);
       
        // Adjust position to match the visible area
        clonedLayer.x(-visibleX);
        clonedLayer.y(-visibleY);
      }
    });
   
    // Draw all layers to ensure they're rendered
    tempStage.draw();
   
    // Wait a moment to ensure rendering is complete
    await new Promise(resolve => setTimeout(resolve, 500));
   
    // Convert stage to dataURL with high quality
    const dataURL = tempStage.toDataURL({
      pixelRatio: 2,
      mimeType: 'image/png', // Use PNG for better quality
      quality: 1
    });
   
    // Create PDF with appropriate dimensions and orientation
    const orientation = visibleWidth > visibleHeight ? 'landscape' : 'portrait';
    const pdf = new jsPDF({
      orientation,
      unit: 'mm',
    });
   
    // Add title
    pdf.setFontSize(16);
    pdf.text(title, 15, 15);
   
    // Add scale information if available
    // if (scale) {
    //   const scaleText = `Scale: 1:${Math.round(1/scale)} (1 pixel = ${scale} ${unit})`;
    //   pdf.setFontSize(10);
    //   pdf.text(scaleText, 15, 22);
    // }
   
    // Add timestamp
    // const now = new Date();
    // const timestamp = `Generated: ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
    // pdf.setFontSize(8);
    // pdf.text(timestamp, 15, 26);
   
    // Calculate dimensions to fit on PDF page
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 30; // mm, space for title and margins
   
    const imgProps = pdf.getImageProperties(dataURL);
    const imgWidth = imgProps.width;
    const imgHeight = imgProps.height;
   
    // Calculate the maximum dimensions that will fit on the page
    const maxWidth = pageWidth - margin;
    const maxHeight = pageHeight - margin;
   
    // Calculate the scale factor to fit the image within the available space
    const scaleFactor = Math.min(
      maxWidth / imgWidth,
      maxHeight / imgHeight
    );
   
    // Calculate the actual dimensions to use
    const finalWidth = imgWidth * scaleFactor;
    const finalHeight = imgHeight * scaleFactor;
   
    // Center the image on the page
    const xPos = (pageWidth - finalWidth) / 2;
    const yPos = margin + (maxHeight - finalHeight) / 2;
   
    // Add image to PDF
    pdf.addImage(
      dataURL,
      'PNG',
      xPos,
      yPos,
      finalWidth,
      finalHeight
    );
   
    // Save the PDF
    pdf.save(`${title.toLowerCase().replace(/\s+/g, '-')}.pdf`);
   
    // Clean up
    tempStage.destroy();
    document.body.removeChild(tempContainer);
    document.body.removeChild(loadingElement);
   
  } catch (error) {
    console.error('Error generating PDF:', error);
    alert('There was an error generating the PDF. Please try again.');
   
    // Remove loading indicator if there was an error
    const loadingElement = document.querySelector('div[style*="Generating PDF"]');
    if (loadingElement && loadingElement.parentNode) {
      loadingElement.parentNode.removeChild(loadingElement);
    }
  }
};
 
export default generateCanvasPDF;