

// import React from 'react';

// const ElementsPanel = ({ onElementDragStart }) => {
//   // Define the elements that can be dragged onto the canvas
//   const elements = {
//     openings: [
//       {
//         type: 'door',
//         name: 'Door',
//         width: 80,
//         height: 10,
//         fill: '#fff',
//         stroke: '#000',
//         strokeWidth: 2,
//         category: 'openings'
//       },
//       {
//         type: 'window',
//         name: 'Window',
//         width: 60,
//         height: 8,
//         fill: '#d4f1f9',
//         stroke: '#000',
//         strokeWidth: 2,
//         category: 'openings'
//       },
//       {
//         type: 'sliding-door',
//         name: 'Sliding Door',
//         width: 100,
//         height: 10,
//         fill: '#fff',
//         stroke: '#000',
//         strokeWidth: 2,
//         category: 'openings',
//         dash: [10, 5]
//       }
//     ],
//     structure: [
//       {
//         type: 'wall',
//         name: 'Wall',
//         width: 100,
//         height: 10,
//         fill: '#888',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'structure'
//       },
//       {
//         type: 'pillar',
//         name: 'Pillar',
//         width: 30,
//         height: 30,
//         fill: '#888',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'structure',
//         isCircle: true
//       }
//     ],
//     furniture: [
//       {
//         type: 'bed',
//         name: 'Bed',
//         width: 120,
//         height: 200,
//         fill: '#f9d4d4',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'furniture'
//       },
//       {
//         type: 'sofa',
//         name: 'Sofa',
//         width: 180,
//         height: 80,
//         fill: '#d4d4f9',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'furniture'
//       },
//       {
//         type: 'table',
//         name: 'Table',
//         width: 100,
//         height: 60,
//         fill: '#d4f9d4',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'furniture'
//       },
//       {
//         type: 'chair',
//         name: 'Chair',
//         width: 40,
//         height: 40,
//         fill: '#f9f9d4',
//         stroke: '#000',
//         strokeWidth: 1,
//         category: 'furniture'
//       }
//     ]
//   };

//   const handleDragStart = (e, element) => {
//     // Set data for drag operation
//     e.dataTransfer.setData('application/json', JSON.stringify(element));
    
//     // Use a transparent drag image to make the preview more accurate
//     const dragImage = document.createElement('div');
//     dragImage.style.width = '1px';
//     dragImage.style.height = '1px';
//     dragImage.style.position = 'absolute';
//     dragImage.style.top = '-1000px';
//     document.body.appendChild(dragImage);
    
//     e.dataTransfer.setDragImage(dragImage, 0, 0);
    
//     // Clean up the drag image after a short delay
//     setTimeout(() => {
//       document.body.removeChild(dragImage);
//     }, 0);
    
//     // Notify parent component
//     onElementDragStart(element);
//   };

//   const renderElementItem = (element) => {
//     return (
//       <div 
//         key={element.type} 
//         className="element-item"
//         draggable
//         onDragStart={(e) => handleDragStart(e, element)}
//       >
//         <div className="element-icon">
//           {element.isCircle ? (
//             <svg width="40" height="40">
//               <circle cx="20" cy="20" r="15" fill={element.fill} stroke={element.stroke} strokeWidth={element.strokeWidth} />
//             </svg>
//           ) : (
//             <svg width="40" height="40">
//               <rect 
//                 x={(40 - Math.min(40, element.width / 3)) / 2} 
//                 y={(40 - Math.min(40, element.height / 3)) / 2} 
//                 width={Math.min(40, element.width / 3)} 
//                 height={Math.min(40, element.height / 3)} 
//                 fill={element.fill} 
//                 stroke={element.stroke} 
//                 strokeWidth={element.strokeWidth}
//                 strokeDasharray={element.dash ? element.dash.join(' ') : 'none'}
//               />
//             </svg>
//           )}
//         </div>
//         <div className="element-name">{element.name}</div>
//       </div>
//     );
//   };

//   return (
//     <div className="elements-panel">
//       <h2 className="elements-title">Elements</h2>
      
//       <div className="elements-section">
//         <h3 className="elements-section-title">Openings</h3>
//         <div className="elements-grid">
//           {elements.openings.map(renderElementItem)}
//         </div>
//       </div>
      
//       <div className="elements-section">
//         <h3 className="elements-section-title">Structure</h3>
//         <div className="elements-grid">
//           {elements.structure.map(renderElementItem)}
//         </div>
//       </div>
      
//       <div className="elements-section">
//         <h3 className="elements-section-title">Furniture</h3>
//         <div className="elements-grid">
//           {elements.furniture.map(renderElementItem)}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ElementsPanel;


import React from 'react';

const ElementsPanel = ({ onElementDragStart }) => {
  // Define the elements that can be dragged onto the canvas
  const elements = {
    openings: [
      {
        type: 'door',
        name: 'Door',
        width: 80,
        height: 10,
        fill: '#fff',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings'
      },
      {
        type: 'window',
        name: 'Window',
        width: 60,
        height: 8,
        fill: '#d4f1f9',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings'
      },
      {
        type: 'sliding-door',
        name: 'Sliding Door',
        width: 100,
        height: 10,
        fill: '#fff',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings',
        dash: [10, 5]
      }
    ],
    structure: [
      {
        type: 'wall',
        name: 'Wall',
        width: 100,
        height: 10,
        fill: '#888',
        stroke: '#000',
        strokeWidth: 1,
        category: 'structure'
      },
      {
        type: 'pillar',
        name: 'pillar',
        width: 30,
        height: 30,
        fill: '#888',
        stroke: '#000',
        strokeWidth: 1,
        category: 'structure',
        isCircle: true
      }
    ],
    furniture: [
      {
        type: 'bed',
        name: '',
        width: 120,
        height: 200,
        fill: '#f9d4d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'sofa',
        name: 'MobileShelving',
        width: 180,
        height: 80,
        fill: '#d4d4f9',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'table',
        name: 'Cantilever',
        width: 100,
        height: 60,
        fill: '#d4f9d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'chair',
        name: 'DDPR',
        width: 40,
        height: 40,
        fill: '#f9f9d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'rack',
        name: 'SPR',
        width: 60,
        height: 20,
        fill: '#d4e6f9',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      }
    ]
  };

  const handleDragStart = (e, element) => {
    // Calculate the offset within the dragged element
    const rect = e.currentTarget.getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;

    // Set data for drag operation
    e.dataTransfer.setData('application/json', JSON.stringify(element));

    // Use a transparent drag image to make the preview more accurate
    const dragImage = document.createElement('div');
    dragImage.style.width = '1px';
    dragImage.style.height = '1px';
    dragImage.style.position = 'absolute';
    dragImage.style.top = '-1000px';
    document.body.appendChild(dragImage);

    e.dataTransfer.setDragImage(dragImage, 0, 0);

    // Clean up the drag image after a short delay
    setTimeout(() => {
      document.body.removeChild(dragImage);
    }, 0);

    // Notify parent component with the element and offset
    onElementDragStart(element, { offsetX, offsetY });
  };

  const renderElementItem = (element) => {
    return (
      <div
        key={element.type}
        className="element-item"
        draggable
        onDragStart={(e) => handleDragStart(e, element)}
      >
        <div className="element-icon">
          {element.isCircle ? (
            <svg width="40" height="40">
              <circle cx="20" cy="20" r="15" fill={element.fill} stroke={element.stroke} strokeWidth={element.strokeWidth} />
            </svg>
          ) : (
            <svg width="40" height="40">
              <rect
                x={(40 - Math.min(40, element.width / 3)) / 2}
                y={(40 - Math.min(40, element.height / 3)) / 2}
                width={Math.min(40, element.width / 3)}
                height={Math.min(40, element.height / 3)}
                fill={element.fill}
                stroke={element.stroke}
                strokeWidth={element.strokeWidth}
                strokeDasharray={element.dash ? element.dash.join(' ') : 'none'}
              />
            </svg>
          )}
        </div>
        <div className="element-name">{element.name}</div>
      </div>
    );
  };

  return (
    <div className="elements-panel">
      <h2 className="elements-title">Elements</h2>

      <div className="elements-section">
        <h3 className="elements-section-title">Openings</h3>
        <div className="elements-grid">
          {elements.openings.map(renderElementItem)}
        </div>
      </div>

      <div className="elements-section">
        <h3 className="elements-section-title">Structure</h3>
        <div className="elements-grid">
          {elements.structure.map(renderElementItem)}
        </div>
      </div>

      <div className="elements-section">
        <h3 className="elements-section-title">Product Group</h3>
        <div className="elements-grid">
          {elements.furniture.map(renderElementItem)}
        </div>
      </div>
    </div>
  );
};

export default ElementsPanel;