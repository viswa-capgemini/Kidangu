import React, { useEffect, useState } from "react";
import CustomSelectFilter, { type Option } from "../../components/custom-inputs/CustomSelectFilter"
import CustomSelect from "../../components/custom-inputs/CustomSelect";

const customers = [
  { label: "Coca Cola", value: "coca-cola" },
  { label: "Pepsi", value: "pepsi" },
  { label: "Hindustan Lever", value: "hindustan lever" },
  { label: "L & T", value: "l&t" },
];
const dateModified = ["Today", "Last 7 days", "Last 30 days", "Last 90 days"];

const productOptions: Option[] = [
  { label: "SPR", value: "spr" },
  { label: "Cantilever", value: "cantilever" },
  { label: "Mejanine", value: "mejanine" },
  { label: "Drive In", value: "drive-in" },
  { label: "Long Span", value: "long-span" },
];

const EnquirySearch = () => {
  const [isFocused, setIsFocused] = React.useState(false);
  const [searchText, setSearchText] = useState("");
  const [clearText, setClearText] = useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<string | null>(null);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const handleToggle = (id: string) => {
    setOpenDropdown((prev) => (prev === id ? null : id));
  };

  const handleCustomerSelect = (value: string) => {
    setSelectedCustomer(value);
    setOpenDropdown(null); // Close dropdown after selection
  };

  const handleProductSelect = (value: string) => {
    setSelectedProduct(value);
    setOpenDropdown(null);
  };

  const handleTimePeriod = (val: string) => {
    setSelectedPeriod(val);
    setOpenDropdown(null);
  };

  const handleClearText = () => {
    setSearchText("");
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsFocused(false);
        setOpenDropdown(null); // close dropdown
        setSelectedCustomer(null); // reset customer
        setSelectedProduct(null); // reset product
        setSelectedPeriod(null); // reset timePeriod
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchText(event.target.value);
  };

  return (
    <div ref={containerRef} className="relative w-[400px]" overflow-hidden>
      <div
        className={`transition-all duration-300 transform origin-center border border-gray-300 rounded-md flex flex-col gap-2 ${
          isFocused ? "scale-140 z-10" : "scale-120"
        } ${isFocused ? "shadow-lg" : ""} w-full`}
      >
        <div className="relative group">
          {/* Gradient Border */}
          <div className="absolute inset-0 rounded-md blur p-[2px] opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition duration-300">
            <div className="w-full h-full rounded-md bg-gradient-to-r from-purple-500 via-blue-500 to-green-400"></div>
          </div>

          {/* Original Search Box */}
          <div className="relative flex items-center px-2 py-2 gap-2 bg-white rounded-md border border-gray-300 transition-all duration-300">
            <div className="mt-2">
              <span className="icon-[bx--search] text-2xl text-godrej-purple"></span>
            </div>
            <input
              type="text"
              value={searchText}
              onFocus={() => setIsFocused(true)}
              onChange={handleInputChange}
              className="outline-none w-full bg-transparent"
              placeholder="Search Product Group, Customer, Status..."
            />
            <div onClick={handleClearText}>
              {searchText.length > 0 && (
                <span className="icon-[pajamas--clear]"></span>
              )}
            </div>
          </div>

          {isFocused && (
            <div className="mt-auto flex flex-wrap justify-start gap-2 bg-light-pink rounded-md">
              <CustomSelectFilter
                options={customers}
                value={selectedCustomer}
                onSelect={handleCustomerSelect}
                isOpen={openDropdown === "customers"}
                onToggle={() => handleToggle("customers")}
                placeholder="Customers"
              />

              <CustomSelectFilter
                options={productOptions}
                value={selectedProduct}
                onSelect={handleProductSelect}
                isOpen={openDropdown === "productOptions"}
                onToggle={() => handleToggle("productOptions")}
                placeholder="Product Group"
              />

              <CustomSelect
                options={dateModified}
                selectedPeriod={selectedPeriod}
                onSelect={handleTimePeriod}
                onToggle={() => handleToggle("timePeriod")}
                isOpen={openDropdown === "timePeriod"}
                placeholder="Time Period"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnquirySearch;
