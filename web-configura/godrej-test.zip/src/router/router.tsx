import { createBrowserRouter } from "react-router";
import App from "../App";
import { fields } from "../pages/left-panel/LeftSidePanel";
import { slugify } from "../helper";

import Layout from "../pages/layout-details/Layout"
import Enquiry from "../pages/enquiry-form/Enquiry";
import type { JSX } from "react";
import EnquiryList from "../pages/enquiry-list/EnquiryList"
import ConfigurationLayout from "../pages/configuration-design/ConfigurationLayout";
import Previews from "../components/Previews";
import PageNotFound from "../components/PageNotFound";
import MasterInventoryUploadPage from "../components/master-inventory/MasterInventoryUploadPage";
import MasterInventory from "../components/master-inventory/MasterInventory";
import RulePolicy from "../components/rules/RulesListPage";
import CreateRule from "../components/rules/CreateRule";
import NewConfiguratorLayout from "../pages/configuration-design/NewConfiguratorLayout";
import Dashboard from "../pages/dashboard/Dashboard";

const masterData = {
  productGroups: [
    { value: 'Selective Pallet Racking', label: 'Selective Pallet Racking' },
    { value: 'Single-Tier Shelving', label: 'Single-Tier Shelving' },
    { value: 'Mezzanine', label: 'Mezzanine' },
    { value: 'Multi-Tier Shelving', label: 'Multi-Tier Shelving' },
    { value: 'Shuttle Pallet Racking', label: 'Shuttle Pallet Racking' },
    { value: 'Altius Single-Tier', label: 'Altius Single-Tier' },
    { value: 'Altius Multi-Tier', label: 'Altius Multi-Tier' }
  ],
  categories: [
    { value: 'Upright', label: 'Upright' },
    { value: 'Beam', label: 'Beam' },
    { value: 'Bracing', label: 'Bracing' },
    { value: 'BasePlate', label: 'Base Plate' },
    { value: 'Accessories', label: 'Accessories' },
    { value: 'Safety Equipment', label: 'Safety Equipment' }
  ],
  componentTypes: [
    { value: 'Structural', label: 'Structural' },
    { value: 'Level Accessories', label: 'Level Accessories' },
    { value: 'Fastener', label: 'Fastener' },
    { value: 'Safety', label: 'Safety' },
    { value: 'Finish', label: 'Finish' },
  ],
};

const pageComponents: Record<string, JSX.Element> = {
  "enquiry-form": <Enquiry />,
  "enquiry-list": <EnquiryList />,
  "layout-details": <Layout />,
  "configuration-layout": <ConfigurationLayout />,
  "previews": <Previews />,
  "master-inventory": <MasterInventory />,
  "product-upload": < MasterInventoryUploadPage masterData={masterData} />,
  "rules": <RulePolicy />,
  "layout-design": <NewConfiguratorLayout />,
  "dashboard": <Dashboard />,
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <PageNotFound />,
    children: [
      ...fields.map((field) => {
        const slug = slugify(field.label);
        return {
          path: slug,
          element: pageComponents[slug],
        };
      }),
      {
        path: "configuration-layout",
        element: <ConfigurationLayout />,
      },
      {
        path: "/previews",
        element: <Previews />,
      },
      {
        path: '/master-inventory',
        element: <MasterInventory />
      },
      {
        path: "/product-upload",
        element: <MasterInventoryUploadPage masterData={masterData} />
      },
      {
        path: "createrule",
        element: <CreateRule />,
      },
      {
        path: "/rules",
        element: <RulePolicy />,
      },
      {
        path: "/layout-design",
        element: <NewConfiguratorLayout />,
      },
      {
        path: "/dashboard",
        element: <Dashboard />,
      }
    ],

  },
]);

export default router;