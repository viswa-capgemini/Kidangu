import React, { useState, useRef } from "react";

const FloatingUploadFile = () => {
  const [fileName, setFileName] = useState("");
  const [focused, setFocused] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const clearFile = () => {
    setFileName("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div data-testid="floatingUploadFile" className="relative w-80">
      <label
        data-testid="floatingUploadFileLabel"
        className={`flex items-center w-full border rounded-md px-4 cursor-pointer transition-all
    ${focused ? "border-blue-500" : "border-gray-300"}
    ${fileName ? "pt-6 pb-2" : "py-3"}`}
      >
        {/* Floating label */}
        <span
          className={`absolute left-2 text-gray-500 px-1 transition-all
      ${
        focused || fileName
          ? "text-xs top-[2px] text-blue-500"
          : "text-sm top-3"
      }`}
        >
          Upload address proof*
        </span>

        {/* File name */}
        <span className="text-sm text-gray-800 truncate flex-1">
          {fileName || ""}
        </span>

        {/* Upload icon only if no file selected */}
        {!fileName && (
          <span className="icon-[material-symbols--upload-rounded] text-gray-500 ml-2"></span>
        )}

        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          className="absolute inset-0 opacity-0 cursor-pointer"
          onChange={(e) => {
            const files = e.target.files;
            if (files && files.length > 0) {
              setFileName(files[0]?.name || "");
            }
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          accept=".jpg, .jpeg, .png, .pdf"
        />
      </label>

      {/* Clear icon outside the label */}
      {fileName && (
        <button
          type="button"
          onClick={clearFile}
          className="absolute right-3 top-3 text-gray-500 hover:text-red-500 z-10"
          title="Clear file"
        >
          ❌
        </button>
      )}

      <p
        className={`text-xs text-gray-500 mt-1 transition-all 
          ${focused || fileName ? "opacity-100" : "opacity-0"}`}
      >
        File size up to 15 MB, in JPG or PDF format
      </p>
    </div>
  );
};

export default FloatingUploadFile;
