import React, { useState } from "react";

type FloatPasswordProps = {
  type: string;
  id: string;
  label: string;
  value: string;
  placeholder: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
};

const FLoatingPasswordFields: React.FC<FloatPasswordProps> = ({
  type,
  id,
  label,
  value,
  placeholder,
  onChange,
  className,
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [touched, setTouched] = useState(false);

  const validations = {
    minLength: value.length >= 8 && value.length <= 15,
    hasUpperLower: /(?=.*[a-z])(?=.*[A-Z])/.test(value),
    hasNumber: /(?=.*\d)/.test(value),
  };

  const isValidpassword =
    validations.minLength && validations.hasUpperLower && validations.hasNumber;

  const showError = touched && !isValidpassword && value?.trim() !== "";

  const isFilled = Boolean(value && value.toString().length > 0);
  return (
    <div data-testid="floatingPasswordContainer" className="flex flex-col gap-4 p-4 justify-center items-center w-[320px] font-inter">
      <div className="relative w-full">
        <input
          data-testid="floatingPasswordInput"
          type={type}
          id={id}
          value={value}
          placeholder={placeholder}
          onChange={onChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setTouched(true);
          }}
          className={`peer block w-full rounded-md px-3 pt-[22px] pb-[8px] text-[15px] text-black outline-none transition-all border ${
            showError
              ? "border-red-500 focus:ring-red-500"
              : "border-gray-300 focus:ring-godrej-grey"
          }
            
            ${className}`}
        />

        <label
          data-testid="floatingPasswordLabel"
          htmlFor={id}
          className={`absolute left-3 px-1 transition-all duration-200 ease-in-out
    ${
      isFilled || isFocused
        ? "top-[6px] translate-y-0 text-[13px] text-godrej-grey"
        : "top-1/2 -translate-y-1/2 text-[15px] text-gray-400"
    }
    peer-focus:top-[6px] peer-focus:translate-y-0 peer-focus:text-[13px] peer-focus:text-godrej-grey`}
        >
          {label}
        </label>

        {showError && (
          <p data-testid="floatingPasswordError" className="text-red-500 text-[13px] mt-1 transition-all duration-200 ease-in-out">
            Invalid password.
          </p>
        )}
      </div>

      {/* Helper Text */}
      {isFocused && (
        <div className="text-gray-500 text-[13px] mt-1 transition-all duration-200 ease-in-out">
          <p data-testid="floatingPasswordHelperText">Your Password must have:</p>
          <ul data-testid="floatingPassword-ul" className="mt-1 space-y-[2px]">
            <li
              data-testid="floatingPassword-minLength"
              className={`flex items-center gap-2 ${
                validations.minLength ? "text-green-500" : "text-red-500"
              }`}
            >
              <span className={`text-sm `}>
                {validations.minLength ? "✔️" : "❌"}
              </span>
              8 or more characters
            </li>
            <li
              data-testid="floatingPassword-upperLower"
              className={`flex items-center gap-2 ${
                validations.hasUpperLower ? "text-green-500" : "text-red-500"
              }`}
            >
              <span className={`text-sm  `}>
                {validations.hasUpperLower ? "✔️" : "❌"}
              </span>
              Upper & Lowercase letters
            </li>
            <li
              data-testid="floatingPassword-number"
              className={`flex items-center gap-2 ${
                validations.hasNumber ? "text-green-500" : "text-red-500"
              }`}
            >
              <span className={`text-sm  `}>
                {validations.hasNumber ? "✔️" : "❌"}
              </span>
              At least one number
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default FLoatingPasswordFields;
