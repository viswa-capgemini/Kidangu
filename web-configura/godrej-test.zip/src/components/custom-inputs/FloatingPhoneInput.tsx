import React, { useState } from "react";

const FloatingPhoneInput = () => {
  const [isd, setIsd] = useState("+91");
  const [phone, setPhone] = useState("");

  const countryCodes = ["+91", "+1", "+44", "+81"];

  return (
    <div data-testid="floatingPhoneContainer" className="flex flex-col items-center gap-2 w-full">
      <div data-testid="floatingPhoneWrapper" className="flex items-start gap-2 w-[320px]">

        <div className="relative w-[90px]">
        <select
          data-testid="floatingPhoneIsdSelect"
          value={isd}
          onChange={(e) => setIsd(e.target.value)}
          className="w-full appearance-none bg-gray-50 text-gray-700 border border-gray-300 rounded-lg px-3 py-[13px] outline-none focus:border-blue-500 transition"
        >
          {countryCodes.map((code, index) => (
            <option data-testid={`isd-${index}`} key={code} value={code}>
              {code}
            </option>
          ))}
        </select>
        <label data-testid="floatingIsdLabel" className="absolute left-3 top-[2px] px-1 text-xs text-gray-500">
          ISD*
        </label>
        </div>

        <div className="relative flex-1 w-[320px]">
          <input
            data-testid="floatingPhoneInput"
            type="tel"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder=""
            className="peer w-full px-3 pt-5 pb-2 text-gray-900 bg-gray-50 border border-gray-300 rounded-lg bg-transparent outline-none placeholder-transparent"
          />

          <label
            data-testid="floatingPhoneLabel"
            htmlFor="phone"
            className="absolute left-3 top-3 text-gray-500 text-sm transition-all peer-placeholder-shown:top-3 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:text-base peer-focus:top-1 peer-focus:text-xs peer-focus:text-blue-500"
          >
            Mobile number*
          </label>
        </div>
      </div>
      <p data-testid="floatingPhoneHelperText" className="text-xs text-gray-500">
        You will receive a verification code on this number
      </p>
    </div>
  );
};

export default FloatingPhoneInput;
