import React, { useState } from "react";

export interface Option {
  label: string;
  value: string;
}

interface CustomSelectProps {
  options: Option[];
  value: string | null;
  onSelect: (value: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  placeholder?: string;
}

const CustomSelectFilter: React.FC<CustomSelectProps> = ({
  options,
  value,
  onSelect,
  isOpen,
  onToggle,
  placeholder = "Select...",
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredOptions = options.filter((option) =>
    option.label.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (val: string) => {
    onSelect(val);
    setSearchTerm("");
  };

  const selectedLabel = options.find((opt) => opt.value === value)?.label;

  return (
    <div data-testid="customSelectFilterContainer" className="relative w-[120px] text-xs">
      <button
        data-testid="customSelectFilterBtn"
        onClick={onToggle}
        className={`border border-gray-300 rounded-full px-2 py-1 m-2 w-full text-left flex justify-between items-center
    ${
      value ? "bg-rose-100" : "bg-white"
    } hover:bg-rose-200 focus:bg-rose-200 transition-colors duration-300`}
      >
        {selectedLabel || placeholder}
        {!isOpen ? (
          <span className="icon-[ri--arrow-drop-down-line] text-xl"></span>
        ) : (
          <span className="icon-[ri--arrow-drop-up-line] text-xl"></span>
        )}
      </button>

      {isOpen && (
        <div data-testid="customSelectFilterOpen" className="absolute z-10 w-full bg-white border border-gray-300 rounded shadow-lg mt-1 max-h-[120px] overflow-y-auto">
          <input
            data-testid="customSelectFilterSearch"
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-2 py-1 border-b border-gray-200 focus:outline-none text-xs"
          />
          <ul>
            {filteredOptions.map((option, index) => (
              <li
                data-testid={`customSelectFilterOption-${index}`}
                key={option.value}
                onClick={() => handleSelect(option.value)}
                className="px-2 py-1 hover:bg-rose-100 cursor-pointer"
              >
                {option.label}
              </li>
            ))}
            {filteredOptions.length === 0 && (
              <li data-testid="customSelectFilter-NoOption" className="px-2 py-1 text-gray-500">No options found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default CustomSelectFilter;
