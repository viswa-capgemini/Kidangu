import React, { useState, useRef, useEffect } from "react";
import { ChevronDownIcon } from "@heroicons/react/24/solid"; // Heroicons for Tailwind

type FloatingSelectProps = {
  label: string;
  options: string[];
};

const FloatingSelect: React.FC<FloatingSelectProps> = ({ label, options }) => {
  const [selected, setSelected] = useState("");
  const [focused, setFocused] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setFocused(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div data-test="floatingSelectCobtainer" ref={containerRef} className="relative w-full">
      {/* Floating Label */}
      <label
        data-testid="floatingSelectLabel"
        className={`absolute left-3 text-gray-500 transition-all duration-200 px-1 ${
          focused || selected
            ? "top-1 text-label01 text-blue-600"
            : "top-1/2 -translate-y-1/2 text-label01"
        }`}
      >
        {label}
      </label>

      {/* Selected Value Box */}
      <div
        data-testid="floatingSelectSelectedBox"
        className="border border-gray-300 rounded-md px-2 py-2 h-[56px] flex items-center justify-between cursor-pointer"
        onClick={() => setFocused(!focused)}
      >
        <span data-testid="floatingSelectSelectedValue" className="text-gray-900">{selected || ""}</span>
        {/* Arrow Icon */}
        <ChevronDownIcon
          className={`w-5 h-5 text-gray-500 transition-transform duration-200 ${
            focused ? "rotate-180" : ""
          }`}
        />
      </div>

      {/* Dropdown */}
      {focused && (
        <ul data-testid="floatingSelectOptions" className="absolute z-10 bg-white border border-gray-300 rounded-md mt-1 w-full shadow-md">
          {options.map((option) => (
            <li
              data-testid={`floatingSelectOption-${option}`}
              key={option}
              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
              onClick={() => {
                setSelected(option);
                setFocused(false);
              }}
            >
              {option}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FloatingSelect;