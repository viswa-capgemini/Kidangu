import React, { useState, useRef, useEffect } from "react";

type FloatingOrderQuantityProps = {
  maxVal?: number;
  label?: string;
  width?: string;
  height?: string;
};

const FloatingOrderQuantity: React.FC<FloatingOrderQuantityProps> = ({maxVal, width, label}) => {
  const [quantity, setQuantity] = useState(0);
  const [focused, setFocused] = useState(false);
  const maxQuantity = maxVal ?? 10;
  const containerRef = useRef<HTMLDivElement>(null);

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleIncrease = () => {
    if (quantity < maxQuantity) {
      setQuantity(quantity + 1);
    }
  };

  // Detect outside click
  // useEffect(() => {
  //   const handleClickOutside = (event: { target: any }) => {
  //     if (
  //       containerRef.current &&
  //       !containerRef.current.contains(event.target)
  //     ) {
  //       setFocused(true);
  //     }
  //   };

  //   document.addEventListener("mousedown", handleClickOutside);
  //   return () => {
  //     document.removeEventListener("mousedown", handleClickOutside);
  //   };
  // }, []);

  return (
    <div data-testid="orderQuantityContainer" ref={containerRef} className={`relative ${width || "w-[320px]"} `}>
      <div
        data-testid="orderQuantityInputWrapper"
        className={`relative border border-gray-300 rounded-md px-3 py-2 h-[56px] flex items-center justify-between ${
          focused ? "focus-within:border-blue-500" : ""
        }`}
        onClick={() => setFocused(true)}
      >
        <label
          data-testid="orderQuantityLabel"
          htmlFor="orderQuantity"
          className={`absolute left-3 text-gray-500 text-sm transition-all duration-200 pointer-events-none px-1 ${
            focused
              ? "top-1 text-xs text-blue-600"
              : "top-1/2 -translate-y-1/2 text-base"
          }`}
        >
          {label ? label: "Order quantity*"}
        </label>

        {focused && (
          <div data-testid="orderQuantityFocused"  className="flex items-center justify-between w-full mt-4">
            <button
              data-testid="orderQuantityDecreaseBtn"
              type="button"
              onClick={handleDecrease}
              className="w-8 h-8 flex items-center justify-center rounded-md bg-gray-200 text-gray-700"
            >
              -
            </button>
            <input
              data-testid="orderQuantityInput"
              id="orderQuantity"
              type="number"
              readOnly
              value={quantity}
              className="w-12 text-center outline-none bg-transparent text-gray-900 text-base"
            />
            <button
              data-testid="orderQuantityIncreaseBtn"
              type="button"
              onClick={handleIncrease}
              className="w-8 h-8 flex items-center justify-center rounded-md bg-gray-200 text-gray-700"
            >
              +
            </button>
          </div>
        )}
      </div>
      {focused && (
        <p data-testid="orderQuantityHelperText" className="text-xs text-gray-500 mt-1">
          You can order up to {maxQuantity} products
        </p>
      )}
    </div>
  );
};

export default FloatingOrderQuantity;
