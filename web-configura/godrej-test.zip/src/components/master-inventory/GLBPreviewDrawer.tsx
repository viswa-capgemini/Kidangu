import React, { Suspense, useState, useEffect } from 'react';
import { Drawer, Box, Typography, CircularProgress } from '@mui/material';

// Lazy load the 3D components to avoid initialization issues
const ThreeScene = React.lazy(() => 
  import('./ThreeScene').catch(() => ({ 
    default: () => <div>Failed to load 3D viewer</div> 
  }))
);

interface GLBPreviewDrawerProps {
  file: File | null;
  open: boolean;
  onClose: () => void;
}

const GLBPreviewDrawer: React.FC<GLBPreviewDrawerProps> = ({ file, open, onClose }) => {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Create object URL when file changes
  useEffect(() => {
    if (file && open) {
      setIsLoading(true);
      try {
        const url = URL.createObjectURL(file);
        console.log('Created object URL:', url);
        setObjectUrl(url);
        setError(null);
        
        // Clean up the URL when component unmounts or file changes
        return () => {
          console.log('Revoking object URL:', url);
          URL.revokeObjectURL(url);
          setObjectUrl(null);
        };
      } catch (err) {
        console.error("Error creating object URL:", err);
        setError("Failed to load file");
      } finally {
        setIsLoading(false);
      }
    }
  }, [file, open]);

  // Reset state when drawer closes
  useEffect(() => {
    if (!open) {
      setError(null);
    }
  }, [open]);

  console.log('GLBPreviewDrawer render:', { file, open, objectUrl, error, isLoading });

  return (
    <Drawer 
      anchor="right" 
      open={open} 
      onClose={onClose}
      PaperProps={{ 
        sx: { 
          width: { xs: '100%', sm: '80%', md: 720 },
          maxWidth: '100%'
        } 
      }}
    >
      <Box sx={{ 
        p: 3, 
        height: '100%', 
        display: 'flex', 
        flexDirection: 'column',
        overflow: 'hidden'
      }}>
        <Typography variant="h6" gutterBottom>
          Preview: {file?.name || 'No file selected'}
        </Typography>
        
        <Box 
          sx={{ 
            flex: 1, 
            minHeight: 500,
            borderRadius: 1, 
            overflow: 'hidden', 
            bgcolor: '#111',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            position: 'relative'
          }}
        >
          {isLoading ? (
            <Box sx={{ color: 'white', display: 'flex', alignItems: 'center' }}>
              <CircularProgress size={24} sx={{ color: 'white', mr: 1 }} />
              <Typography>Preparing model...</Typography>
            </Box>
          ) : error ? (
            <Box sx={{ color: 'error.main', p: 2, textAlign: 'center' }}>
              <Typography>{error}</Typography>
            </Box>
          ) : objectUrl ? (
            <ErrorBoundary onError={(err) => setError(err.message)}>
              <Suspense fallback={
                <Box sx={{ color: 'white', display: 'flex', alignItems: 'center' }}>
                  <CircularProgress size={24} sx={{ color: 'white', mr: 1 }} />
                  <Typography>Loading model...</Typography>
                </Box>
              }>
                <Box sx={{ width: '100%', height: '100%', position: 'relative' }}>
                  <ThreeScene url={objectUrl} />
                </Box>
              </Suspense>
            </ErrorBoundary>
          ) : (
            <Typography color="text.secondary">No model to display</Typography>
          )}
        </Box>
        
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <Typography variant="caption" color="text.secondary">
            Press 'D' for debug mode • Press 'T' to show test object
          </Typography>
        </Box>
      </Box>
    </Drawer>
  );
};

// Error boundary component
class ErrorBoundary extends React.Component<
  { children: React.ReactNode; onError: (error: Error) => void },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode; onError: (error: Error) => void }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.error("Error in 3D component:", error);
    this.props.onError(error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Box sx={{ color: 'white', p: 2, textAlign: 'center' }}>
          <Typography>Failed to load 3D preview</Typography>
        </Box>
      );
    }
    return this.props.children;
  }
}

export default GLBPreviewDrawer;