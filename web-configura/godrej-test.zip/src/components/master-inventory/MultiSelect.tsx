import React from 'react';
import { Autocomplete, TextField } from '@mui/material';

type Option = { value: string; label: string };

export const MultiSelect: React.FC<{
  label: string;
  options: Option[];
  value: string[];
  onChange: (value: string[]) => void;
}> = ({ label, options, value, onChange }) => {
  return (
    <Autocomplete
      multiple
      options={options}
      getOptionLabel={(o) => o.label}
      value={options.filter((o) => value.includes(o.value))}
      onChange={(_, newVal) => onChange(newVal.map((v) => v.value))}
      renderInput={(params) => <TextField {...params} label={label} size="small" />}
      sx={{ minWidth: 220 }}
    />
  );
};
