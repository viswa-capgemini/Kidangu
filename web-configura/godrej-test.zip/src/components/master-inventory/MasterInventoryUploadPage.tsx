import React, { useCallback, useMemo, useState } from 'react';
import { Box, Button, Typography, Stack, Paper, LinearProgress, IconButton, Chip, TextField, CircularProgress } from '@mui/material';
import { useDropzone } from 'react-dropzone';
import { useForm, Controller } from 'react-hook-form';
import DeleteIcon from '@mui/icons-material/Delete';
import PreviewIcon from '@mui/icons-material/Preview';
import UploadIcon from '@mui/icons-material/CloudUpload';
import ClearAllIcon from '@mui/icons-material/ClearAll';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { v4 as uuid } from 'uuid';
import { MultiSelect } from './MultiSelect';
import GLBPreviewDrawer from './GLBPreviewDrawer';
// import { uploadFileToS3, saveProductMetadata } from '../../api/productService';
import { uploadFileToS3, saveProductMetadata } from '../api/productService';

type Option = { value: string; label: string };

interface FileTag {
  productGroups: string[];
  categories: string[];
  componentTypes: string[];
}

interface PendingFile {
  id: string;
  file: File;
  name: string;
  displayName: string;
  size: number;
  mime: string;
  tags: FileTag;
  status: 'valid' | 'error' | 'uploading' | 'uploaded';
  error?: string;
  progress?: number;
  s3Key?: string;
  s3Url?: string;
}

interface MasterDataOptions {
  productGroups: Option[];
  categories: Option[];
  componentTypes: Option[];
}

const ACCEPTED_MIME = { 'model/gltf-binary': ['.glb'] };
const MAX_SIZE_BYTES = 200 * 1024 * 1024;
const S3_BUCKET_NAME = 'my-dxf-bucket';
const S3_FOLDER = 'models';
const API_BASE_URL = 'http://localhost:5000/api';

const MasterInventoryUploadPage: React.FC<{ masterData: MasterDataOptions; }> = ({ masterData }) => {
  const [files, setFiles] = useState<PendingFile[]>([]);
  const [previewFile, setPreviewFile] = useState<PendingFile | null>(null);
  const [modelName, setModelName] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const defaultTags: FileTag = useMemo(() => ({ productGroups: [], categories: [], componentTypes: [] }), []);
  const { control, getValues, reset } = useForm<FileTag>({ defaultValues: defaultTags });

  const onDrop = useCallback((accepted: File[]) => {
    const next: PendingFile[] = [];
    accepted.forEach(f => {
      const isGLB = (f.type === 'model/gltf-binary') || f.name.toLowerCase().endsWith('.glb');
      const tooBig = f.size > MAX_SIZE_BYTES;
      
      // Extract name without extension for display
      let displayName = f.name.replace(/\.[^/.]+$/, "");
      
      // If user provided a model name, use that instead
      if (modelName.trim()) {
        displayName = modelName.trim();
      }
      
      console.log(`Processing file: ${f.name}, display name: ${displayName}`);
      
      next.push({
        id: uuid(),
        file: f,
        name: f.name,
        displayName: displayName,
        size: f.size,
        mime: f.type || 'model/gltf-binary',
        tags: { ...getValues() },
        status: (!isGLB ? 'error' : tooBig ? 'error' : 'valid'),
        error: !isGLB ? 'File is not .glb' : (tooBig ? 'File exceeds size limit' : undefined),
      });
    });
    setFiles(prev => [...next, ...prev]);
    setModelName('');
  }, [getValues, modelName]);

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    onDrop,
    accept: ACCEPTED_MIME,
    multiple: true,
    noClick: true,
    noKeyboard: true,
  });

  const applyBulkToUntagged = () => {
    const bulk = getValues();
    setFiles(prev => prev.map(p => {
      const isUntagged = !p.tags.productGroups.length && !p.tags.categories.length && !p.tags.componentTypes.length;
      return isUntagged ? { ...p, tags: { ...bulk } } : p;
    }));
  };

  const clearAllTags = () => {
    setFiles(prev => prev.map(p => ({ ...p, tags: { productGroups: [], categories: [], componentTypes: [] } })));
    reset(defaultTags);
  };

  const updateFileTags = (id: string, tags: Partial<FileTag>) => {
    setFiles(prev => prev.map(p => p.id === id ? { ...p, tags: { ...p.tags, ...tags } } : p));
  };

  const updateFileName = (id: string, newName: string) => {
    setFiles(prev => prev.map(p => p.id === id ? { ...p, displayName: newName } : p));
  };

  const removeFile = (id: string) => setFiles(prev => prev.filter(p => p.id !== id));

  const canSubmit = files.length > 0 && files.every(f =>
    f.status !== 'error' &&
    f.tags.productGroups.length > 0 &&
    f.tags.categories.length > 0 &&
    f.tags.componentTypes.length > 0
  ) && !isUploading;

  // Generate a unique S3 key for the file
  const generateS3Key = (file: PendingFile): string => {
    const timestamp = new Date().getTime();
    
    // Ensure we have a valid display name
    let displayName = 'unnamed';
    
    if (file.displayName && typeof file.displayName === 'string') {
      displayName = file.displayName;
    } else if (file.name && typeof file.name === 'string') {
      // Extract name without extension
      displayName = file.name.replace(/\.[^/.]+$/, "");
    }
    
    // Sanitize the name to remove invalid characters
    const sanitizedName = displayName.replace(/[^a-zA-Z0-9-_]/g, '_');
    
    // Get file extension
    let extension = 'glb';
    if (file.name && typeof file.name === 'string') {
      const parts = file.name.split('.');
      if (parts.length > 1) {
        extension = parts[parts.length - 1];
      }
    }
    
    return `${S3_FOLDER}/${sanitizedName}-${timestamp}.${extension}`;
  };

  // Upload a single file to S3
  const uploadFile = async (file: PendingFile): Promise<{success: boolean, s3Key?: string, s3Url?: string, error?: string}> => {
    try {
      console.log('Starting upload for file:', {
        id: file.id,
        name: file.name,
        displayName: file.displayName || 'undefined',
        size: file.size
      });
      
      // Validate file object
      if (!file || !file.file) {
        console.error('Invalid file object:', file);
        return {
          success: false,
          error: 'Invalid file object'
        };
      }
      
      // Update progress to show we're starting
      setFiles(prev => prev.map(p => 
        p.id === file.id ? { ...p, progress: 10 } : p
      ));
      
      // Generate a key for the file with additional error handling
      let s3Key;
      try {
        s3Key = generateS3Key(file);
        console.log(`Generated S3 key: ${s3Key}`);
      } catch (keyError) {
        console.error('Error generating S3 key:', keyError);
        return {
          success: false,
          error: 'Failed to generate S3 key'
        };
      }
      
      // Upload the file using our API service
      const result = await uploadFileToS3(file.file, s3Key);
      console.log('uploadFileToS3 result:', result);
      
      if (!result.success) {
        return {
          success: false,
          error: result.error || 'Upload failed'
        };
      }
      
      // Extract key and url from result, handling different property names
      const resultKey = result.key// || result.s3Key;
      const resultUrl = result.url;
      
      // If we have a key but no URL, construct the URL
      let finalUrl = resultUrl;
      if (!finalUrl && resultKey) {
        finalUrl = `https://${S3_BUCKET_NAME}.s3.amazonaws.com/${resultKey}`;
        console.log(`Constructed URL from key: ${finalUrl}`);
      }
      
      // Check if we have the necessary data
      if (!resultKey || !finalUrl) {
        console.error('Missing key or URL in uploadFileToS3 result:', result);
        return {
          success: false,
          error: 'Invalid response from S3 upload'
        };
      }
      
      // Update progress
      setFiles(prev => prev.map(p => 
        p.id === file.id ? { ...p, progress: 50 } : p
      ));
      
      // Return with the correct property names
      return {
        success: true,
        s3Key: resultKey,
        s3Url: finalUrl
      };
    } catch (error: any) {
      console.error('Error uploading file:', error);
      return {
        success: false,
        error: error.message || 'Failed to upload file'
      };
    }
  };

  // Save metadata to DynamoDB using our API service
  const saveMetadata = async (file: PendingFile): Promise<boolean> => {
    try {
      const currentDate = new Date().toISOString();
      const productId = `PROD-${uuid().substring(0, 8)}`;
      
      console.log('Saving metadata for file:', {
        id: file.id,
        name: file.displayName || file.name,
        s3Url: file.s3Url,
        s3Key: file.s3Key
      });
      
      // Ensure we have an S3 URL
      let s3Url = file.s3Url;
      if (!s3Url && file.s3Key) {
        s3Url = `https://${S3_BUCKET_NAME}.s3.amazonaws.com/${file.s3Key}`;
        console.log(`Constructed S3 URL from key: ${s3Url}`);
      }
      
      // Return early if s3Url is still not available
      if (!s3Url) {
        console.error('Missing s3Url and s3Key for file:', file.name);
        return false;
      }

      const metadata = {
        product_id: productId,
        name: file.displayName || file.name.replace(/\.[^/.]+$/, ""),
        pg_name: file.tags.productGroups,
        category: file.tags.categories,
        comp_type: file.tags.componentTypes,
        uploaded_date: currentDate,
        last_revised: currentDate,
        s3_bucket_url: s3Url,
        file_size: file.size,
        file_type: file.mime
      };
      
      console.log('Sending metadata to server:', metadata);
      
      const result = await saveProductMetadata(metadata);
      console.log('saveProductMetadata result:', result);
      
      return result.success;
    } catch (error: any) {
      console.error('Error saving metadata:', error);
      return false;
    }
  };

  const uploadFiles = async () => {
  console.log('Starting upload process...');
  setIsUploading(true);
  
  try {
    // Mark all valid files as uploading
    setFiles(prev => prev.map(p => 
      p.status === 'valid' ? { ...p, status: 'uploading', progress: 0 } : p
    ));
    
    const validFiles = files.filter(f => f.status === 'valid' || f.status === 'uploading');
    const totalFiles = validFiles.length;
    
    console.log(`Processing ${totalFiles} files...`);
    
    for (let i = 0; i < totalFiles; i++) {
      const file = validFiles[i];
      
      console.log(`Processing file ${i+1}/${totalFiles}:`, {
        id: file.id,
        name: file.name,
        displayName: file.displayName,
        size: file.size
      });
      
      try {
        // Upload to S3
        const s3Result = await uploadFile(file);
        
        if (!s3Result.success) {
          console.error('S3 upload failed:', s3Result.error);
          setFiles(prev => prev.map(p => 
            p.id === file.id ? { ...p, status: 'error', error: s3Result.error } : p
          ));
          continue;
        }
        
        console.log('S3 upload successful:', s3Result);
        
        // Check if s3Result has the expected properties
        if (!s3Result.s3Url) {
          console.error('Missing s3Url in upload result:', s3Result);
          setFiles(prev => prev.map(p => 
            p.id === file.id ? { ...p, status: 'error', error: 'Missing S3 URL in upload result' } : p
          ));
          continue;
        }
        
        // Create an updated file object with the S3 information
        const updatedFile = {
          ...file,
          progress: 75,
          s3Key: s3Result.s3Key,
          s3Url: s3Result.s3Url
        };
        // Update the files state
setFiles(prev => prev.map(p => 
  p.id === file.id ? updatedFile : p
));

// Save metadata using the updated file object
console.log('Saving metadata for file:', updatedFile.name);
const dbResult = await saveMetadata(updatedFile);

if (!dbResult) {
  console.error('Failed to save metadata for file:', updatedFile.name);
  setFiles(prev => prev.map(p => 
    p.id === file.id ? { ...p, status: 'error', error: 'Failed to save metadata' } : p
  ));
  continue;
}

// Mark as completed
console.log('File processed successfully:', updatedFile.name);
setFiles(prev => prev.map(p => 
  p.id === file.id ? { ...p, status: 'uploaded', progress: 100 } : p
));

} catch (error: any) {
  console.error('Error processing file:', error);
  setFiles(prev => prev.map(p => 
    p.id === file.id ? { ...p, status: 'error', error: error.message || 'Upload failed' } : p
  ));
}
}

console.log('All files processed. Upload complete.');
} catch (error: any) {
  console.error('Error in upload process:', error);
} finally {
  setIsUploading(false);
}
};

const handleSubmit = async () => {
  console.log('Submit button clicked');
  if (!canSubmit) {
    console.log('Cannot submit: validation failed or already uploading');
    return;
  }
  
  try {
    await uploadFiles();
    console.log('Upload completed successfully');
  } catch (error: any) {
    console.error('Error in handleSubmit:', error);
  }
};

const testS3Upload = async () => {
  try {
    // First, test the backend connection
    const response = await fetch(`${API_BASE_URL}/products/test-s3`);
    const data = await response.json();
    
    if (!data.success) {
      alert(`S3 connection test failed: ${data.error}`);
      return;
    }
    
    alert(`S3 connection successful! Test object created at: ${data.testObjectUrl}`);
  } catch (error: any) {
    console.error('Error testing S3 connection:', error);
    alert(`Error testing S3 connection: ${error.message}`);
  }
};
  return (
    <Stack spacing={2} sx={{padding: '16px'}}>
      <Typography variant="h5">Master Inventory – Upload 3D Models</Typography>

      <Paper variant="outlined" sx={{ p: 2 }}>
        <Stack spacing={2}>
          
          {/* Dropzone Area */}
          <Box {...getRootProps()} sx={{ 
            border: '1px dashed #ccc', 
            borderRadius: 1, 
            p: 2,
            bgcolor: isDragActive ? 'rgba(0, 0, 0, 0.04)' : 'transparent',
            transition: 'background-color 0.2s ease'
          }}>
            <input {...getInputProps()} />
            <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={2}>
              <Box>
                <Typography variant="subtitle1">
                  {isDragActive ? 'Drop files to upload…' : 'Drag & drop .glb files here'}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Accepted: .glb • Max {Math.round(MAX_SIZE_BYTES / 1024 / 1024)} MB per file
                </Typography>
              </Box>
              <Button variant="contained" startIcon={<UploadIcon />} onClick={open}>Browse</Button>
            </Stack>
          </Box>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Bulk Metadata</Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
          <Controller control={control} name="productGroups" render={({ field }) => (
            <MultiSelect label="Product Group" options={masterData.productGroups} {...field} />
          )} />
          <Controller control={control} name="categories" render={({ field }) => (
            <MultiSelect label="Category" options={masterData.categories} {...field} />
          )} />
          <Controller control={control} name="componentTypes" render={({ field }) => (
            <MultiSelect label="Component Type" options={masterData.componentTypes} {...field} />
          )} />
        </Stack>
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <Button startIcon={<CheckCircleIcon />} sx={{'&:hover': {backgroundColor: '#e0f0ff'}}} onClick={applyBulkToUntagged}>Apply to All Un‑tagged</Button>
          <Button startIcon={<ClearAllIcon />} sx={{'&:hover': {backgroundColor: '#f9dbc0ff'}}} onClick={clearAllTags} color="warning">Clear All</Button>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Files to Upload ({files.length})</Typography>
        <Stack spacing={1}>
          {files.map(f => (
            <Paper key={f.id} variant="outlined" sx={{ p: 1.5 }}>
              <Stack direction={{ xs: 'column', md: 'row' }} alignItems={{ md: 'center' }} spacing={2}>
                <Box sx={{ flex: 1, minWidth: 220 }}>
                  {/* Display Name with Edit Option */}
                  <Box sx={{ mb: 0.5 }}>
                    <TextField
                      variant="standard"
                      value={f.displayName}
                      onChange={(e) => updateFileName(f.id, e.target.value)}
                      fullWidth
                      InputProps={{
                        sx: { 
                          fontSize: '1rem',
                          fontWeight: 500
                        }
                      }}
                      disabled={f.status === 'uploading' || f.status === 'uploaded'}
                    />
                  </Box>
                  
                  {/* Original filename and size */}
                  <Typography variant="caption" color="text.secondary">
                    {f.name} ({(f.size / 1024 / 1024).toFixed(1)} MB)
                  </Typography>
                  
                  <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 0.5 }}>
                    {f.status === 'error' && <Chip color="error" label={f.error || 'Error'} size="small" />}
                    {f.status === 'valid' && <Chip color="success" label="Valid" size="small" />}
                    {f.status === 'uploading' && (
                      <Box sx={{ minWidth: 160 }}>
                        <LinearProgress variant="determinate" value={f.progress ?? 0} />
                      </Box>
                    )}
                    {f.status === 'uploaded' && <Chip color="success" label="Uploaded" size="small" />}
                  </Stack>
                </Box>

                <MultiSelect label="Product Group" options={masterData.productGroups} value={f.tags.productGroups} onChange={(val) => updateFileTags(f.id, { productGroups: val })} />
                <MultiSelect label="Category" options={masterData.categories} value={f.tags.categories} onChange={(val) => updateFileTags(f.id, { categories: val })} />
                <MultiSelect label="Component Type" options={masterData.componentTypes} value={f.tags.componentTypes} onChange={(val) => updateFileTags(f.id, { componentTypes: val })} />

                <Stack direction="row" spacing={1}>
                  <IconButton aria-label="Preview" onClick={() => setPreviewFile(f)} disabled={f.status === 'error'}>
                    <PreviewIcon />
                  </IconButton>
                  <IconButton aria-label="Remove" onClick={() => removeFile(f.id)} color="error" disabled={f.status === 'uploading'}>
                    <DeleteIcon />
                  </IconButton>
                </Stack>
              </Stack>
            </Paper>
          ))}
          {files.length === 0 && (
            <Typography variant="body2" color="text.secondary">No files added yet.</Typography>
          )}
        </Stack>
      </Paper>

      <Stack direction="row" justifyContent="flex-end" spacing={2}>
        <Button variant="text" onClick={() => setFiles([])} disabled={isUploading}>Cancel</Button>
        <Button 
          variant="contained" 
          disabled={!canSubmit} 
          onClick={handleSubmit}
          startIcon={isUploading ? <CircularProgress size={16} color="inherit" /> : null}
        >
          {isUploading ? 'Uploading...' : `Submit ${files.length > 0 ? `(${files.length})` : ''}`}
        </Button>
        {/* <Button onClick={testS3Upload}>Test S3 Upload</Button> */}
      </Stack>

      <GLBPreviewDrawer file={previewFile?.file ?? null} open={!!previewFile} onClose={() => setPreviewFile(null)} />
    </Stack>
  );
};

export default MasterInventoryUploadPage;