import GodrejLogo from "../../assets/images/godrej-logo.png";
import { useState } from "react";

interface HeaderProps {
  setRunTour: (value: boolean) => void;
  tour?: boolean;
  setTour: (value: boolean) => void;
  onHamburgerClick: () => void;
}

const Header: React.FC<HeaderProps> = ({
  setTour,
  tour,
  setRunTour,
  onHamburgerClick,
}) => {
  const handleTour = () => {
    setRunTour(true);
    setTour(!tour);
  };

  return (
    <header
      data-testid="main-header"
      className="border-b-2 border-godrej-purple bg-white-500 text-black text-lg font-medium pr-3 pl-3 py-4 flex items-center justify-between"
    >
      {/* <div data-testid="main-header-wrapper"> */}
      <div
        data-testid="logo-container"
        className="text-2xl font-bold flex items-center space-x-4"
      >
        <button onClick={onHamburgerClick}>
          <span
            data-testid="hamburger-icon"
            className="icon-[solar--hamburger-menu-outline]"
          ></span>
        </button>
        <span>
          <img
            data-testid="godrej-logo"
            src={GodrejLogo}
            alt="Godrej Logo"
            className="h-8 w-auto"
          />
        </span>
      </div>
      <div className="flex space-x-10">
        <button
          data-testid="help-btn"
          // className="border-2 rounded-full w-10 bg-gray-200"
          onClick={handleTour}
        >
          <span className="icon-[cuida--help-outline]"></span>
        </button>
        <div>
          <span
            data-testid="user-icon"
            className="icon-[qlementine-icons--user-24]"
          ></span>
          <span data-testid="user-name" className="user px-4">
            {"Abhishek Kumar"}
          </span>
        </div>
      </div>
      {/* </div> */}
    </header>
  );
};

export default Header;
