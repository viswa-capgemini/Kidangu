import React, { useState } from "react";

export interface SelectionType {
  type: "product" | "component" | "smartGroup";
  name: string;
}

export interface LeftPanelContextProps {
  selectedItem: SelectionType | null;
  setSelectedItem: (item: SelectionType | null) => void;
}

export const LayoutContext = React.createContext<LeftPanelContextProps | undefined>(undefined);

export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedItem, setSelectedItem] = useState<SelectionType | null>(null);

  return (
    <LayoutContext.Provider value={{ selectedItem, setSelectedItem }}>
      {children}
    </LayoutContext.Provider>
  );
};