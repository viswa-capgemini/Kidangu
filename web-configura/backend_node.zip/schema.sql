-- Database Schema for Master Inventory (PostgreSQL)
-- Compatible with PG Admin

CREATE TABLE IF NOT EXISTS master_inventory (
    id SERIAL PRIMARY KEY,
    uid VARCHAR(50) UNIQUE NOT NULL,
    component_group VARCHAR(100) NOT NULL,
    component_type VARCHAR(100) NOT NULL,
    model_type VARCHAR(100),
    colour VARCHAR(100),
    gfa_info VARCHAR(20),
    powder_code VARCHAR(50),
    powder_type VARCHAR(50),
    powder_weight VARCHAR(50),
    cbm DECIMAL(15, 6),
    cost DECIMAL(15, 2),
    status VARCHAR(20) DEFAULT 'Active',
    width DECIMAL(15, 2),
    length DECIMAL(15, 2),
    thickness DECIMAL(15, 2),
    depth DECIMAL(15, 2),
    height DECIMAL(15, 2),
    weight DECIMAL(15, 2),
    drawing_no VARCHAR(100),
    rev_no VARCHAR(20),
    unspc_code VARCHAR(50),
    short_description TEXT,
    description TEXT,
    long_description TEXT,
    k_factor VARCHAR(20),
    link_upright BOOLEAN DEFAULT FALSE,
    lip_connector_count INT,
    solution_type VARCHAR(100), -- Pallet Rack or Shelving
    selected_solution VARCHAR(255), -- The specific solution item
    glb_url TEXT,
    image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trigger to update updated_at on change
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_master_inventory_updated_at
    BEFORE UPDATE ON master_inventory
    FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();
