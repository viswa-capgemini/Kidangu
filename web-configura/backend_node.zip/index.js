require('dotenv').config();
const express = require('express');
const multer = require('multer');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { Pool } = require('pg');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Database Connection
const pool = new Pool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// S3 Client
const s3Client = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    }
});

// Multer Storage (Memory storage for direct S3 upload)
const storage = multer.memoryStorage();
const upload = multer({ storage }).fields([
    { name: 'glbFile', maxCount: 1 },
    { name: 'imageFile', maxCount: 1 }
]);

// Helper: Upload to S3
const uploadToS3 = async (file, folder) => {
    if (!file) return null;
    const fileName = `${folder}/${Date.now()}_${file.originalname}`;
    const params = {
        Bucket: process.env.AWS_S3_BUCKET,
        Key: fileName,
        Body: file.buffer,
        ContentType: file.mimetype
    };

    try {
        await s3Client.send(new PutObjectCommand(params));
        return `https://${process.env.AWS_S3_BUCKET}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileName}`;
    } catch (err) {
        console.error('S3 Upload Error:', err);
        throw err;
    }
};

// Helper: Generate UID
const generateUID = async (componentType) => {
    const typeMap = {
        'Upright': 'upt',
        'Beams': 'bms',
        'Accessories': 'acc',
        'Panels': 'pnl'
    };
    const prefix = typeMap[componentType] || componentType.substring(0, 3).toLowerCase();

    const query = 'SELECT COUNT(*) FROM master_inventory WHERE component_type = $1';
    const res = await pool.query(query, [componentType]);
    const count = parseInt(res.rows[0].count) + 1;
    const sequence = count.toString().padStart(4, '0');

    return `XXX_${prefix}_${sequence}`;
};

// Health Check / Root
app.get('/', (req, res) => {
    res.json({ status: 'API is running', version: '1.0.0', database: 'PostgreSQL' });
});

// API: Get all inventory
app.get('/api/inventory', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM master_inventory ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Database fetch error' });
    }
});

// API: Create new item
app.post('/api/inventory', upload, async (req, res) => {
    try {
        const data = req.body;
        const files = req.files;

        // 1. Validation Logic
        if (!data.componentGroup || !data.componentType) {
            return res.status(400).json({ error: 'Component Group and Type are mandatory' });
        }
        if (!files.glbFile) {
            return res.status(400).json({ error: 'GLB file is mandatory' });
        }

        // 2. Upload to S3
        const glbUrl = await uploadToS3(files.glbFile[0], 'models');
        const imageUrl = await uploadToS3(files.imageFile ? files.imageFile[0] : null, 'images');

        // 3. Generate UID
        const uid = await generateUID(data.componentType);

        // 4. Insert into RDS
        const query = `
            INSERT INTO master_inventory (
                uid, component_group, component_type, model_type, colour, gfa_info,
                powder_code, powder_type, powder_weight, cbm, cost, status,
                width, length, thickness, depth, height, weight,
                drawing_no, rev_no, unspc_code, short_description, description,
                long_description, k_factor, link_upright, lip_connector_count,
                solution_type, selected_solution, glb_url, image_url
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,
                $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23,
                $24, $25, $26, $27, $28, $29, $30, $31
            ) RETURNING *
        `;

        const values = [
            uid, data.componentGroup, data.componentType, data.modelType, data.colour, data.gfaInfo,
            data.powderCode, data.powderType, data.powderWeight, data.cbm || 0, data.cost || 0, data.status,
            data.width || 0, data.length || 0, data.thickness || 0, data.depth || 0, data.height || 0, data.weight || 0,
            data.drawingNo, data.revNo, data.unspcCode, data.shortDescription, data.description,
            data.longDescription, data.kFactor, data.linkUpright === 'true', parseInt(data.lipConnectorCount) || 0,
            data.solutionType, data.selectedSolution, glbUrl, imageUrl
        ];

        const result = await pool.query(query, values);
        res.status(201).json(result.rows[0]);

    } catch (err) {
        console.error('Server Error:', err);
        res.status(500).json({ error: 'Internal server error', details: err.message });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
