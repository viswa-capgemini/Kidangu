
import { createBrowserRouter } from "react-router-dom";
import AuthWrapper from "../components/AuthWrapper";
import { leftPanelFields } from "../config/leftPanelFields";
import { slugify } from "../helper";

import Layout from "../pages/layout-details/Layout";
import Enquiry from "../pages/enquiry-form/Enquiry";
import type { JSX } from "react";
import EnquiryList from "../pages/enquiry-list/EnquiryList";
import EnquiryDetails from "../pages/enquiry-list/EnquiryDetails";
import ConfigurationLayout from "../pages/configuration-design/ConfigurationLayout";
import Previews from "../components/Previews";
import PageNotFound from "../components/PageNotFound";
import MasterInventoryUploadPage from "../components/master-inventory/MasterInventoryUploadPage";
import MasterInventory from "../components/master-inventory/MasterInventory";
import RulePolicy from "../components/rules/RulesListPage";
import CreateRule from "../components/rules/CreateRule";
import NewConfiguratorLayout from "../pages/configuration-design/NewConfiguratorLayout";

// ★ NEW: bring in ProtectedRoute and role access mapping
import { ProtectedRoute } from "../../src/components/ProtectedRoute";
import { roleAccessBySlug } from "../../src/components/RoleAccess"; // adjust path if you placed it elsewhere
// If you don't have a NotAuthorized component yet, create a simple one (snippet below)
import NotAuthorized from "../features/login-signup/NotAuthorized";
import Login from "../features/login-signup/Login";
import Dashboard from "../pages/dashboard/Dashboard";
import Analytics from "../pages/analytics/Analytics";
import PGComparison from "../pages/pg-comparison/PGComparison";
import Reckoner from "../pages/reckoner/Reckoner";
import MhePage from "../pages/mhe-details/MhePage";

const masterData = {
  productGroups: [
    { value: 'Selective Pallet Racking', label: 'Selective Pallet Racking' },
    { value: 'Single-Tier Shelving', label: 'Single-Tier Shelving' },
    { value: 'Mezzanine', label: 'Mezzanine' },
    { value: 'Multi-Tier Shelving', label: 'Multi-Tier Shelving' },
    { value: 'Shuttle Pallet Racking', label: 'Shuttle Pallet Racking' },
    { value: 'Altius Single-Tier', label: 'Altius Single-Tier' },
    { value: 'Altius Multi-Tier', label: 'Altius Multi-Tier' }
  ],
  categories: [
    { value: 'Upright', label: 'Upright' },
    { value: 'Beam', label: 'Beam' },
    { value: 'Bracing', label: 'Bracing' },
    { value: 'BasePlate', label: 'Base Plate' },
    { value: 'Accessories', label: 'Accessories' },
    { value: 'Safety Equipment', label: 'Safety Equipment' }
  ],
  componentTypes: [
    { value: 'Structural', label: 'Structural' },
    { value: 'Level Accessories', label: 'Level Accessories' },
    { value: 'Fastener', label: 'Fastener' },
    { value: 'Safety', label: 'Safety' },
    { value: 'Finish', label: 'Finish' },
  ],
};

const pageComponents: Record<string, JSX.Element> = {
  "dashboard": <Dashboard />,
  // "enquiry-list": <EnquiryList />,
  "design-deck": <Layout />,
  "analytics": <Analytics />,
  "pg-comparison": <PGComparison />,
  "reckoner": <Reckoner />,
  "user-management": <div>User Management</div>,
  "rules-configuration": <RulePolicy />,
  "3D-models-configuration": <div>3D Models Configuration</div>,
  "pre-defined-configuration": <div>Pre-defined Configuration</div>,
  "2-factor-approval": <div>2 Factor Approval</div>,
  "enquiry-form": <Enquiry />,
  "configuration-layout": <ConfigurationLayout />,
  "previews": <Previews />,
  "master-inventory": <MasterInventory />,
  "product-upload": <MasterInventoryUploadPage masterData={masterData} />, 
  "layout-design": <NewConfiguratorLayout />,
  "mhe-details" : <MhePage />
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <AuthWrapper />,
    errorElement: <PageNotFound />,
    children: [
      // Dynamically generated routes from left panel fields
      ...leftPanelFields.map((field) => {
        const slug = slugify(field.label);
        const element = pageComponents[slug];

        if (!element) {
          // If slug isn't in pageComponents, skip or render a not found
          return {
            path: slug,
            element: <PageNotFound />,
          };
        }

        const allowed = roleAccessBySlug[slug] ?? ['dealer', 'admin'];

        return {
          path: slug,
          element: (
            <ProtectedRoute allowedRoles={allowed}>
              {element}
            </ProtectedRoute>
          ),
        };
      }),

      // Explicit routes (keep these for certainty; they duplicate some slugs above)
      {
        path: "configuration-layout",
        element: (
          <ProtectedRoute allowedRoles={['dealer']}>
            <ConfigurationLayout />
          </ProtectedRoute>
        ),
      },
      {
        path: "/previews",
        element: (
          <ProtectedRoute allowedRoles={['dealer', 'admin']}>
            <Previews />
          </ProtectedRoute>
        ),
      },
      {
        path: '/master-inventory',
        element: (
          <ProtectedRoute allowedRoles={['admin']}>
            <MasterInventory />
          </ProtectedRoute>
        ),
      },
      {
        path: "/product-upload",
        element: (
          <ProtectedRoute allowedRoles={['admin']}>
            <MasterInventoryUploadPage masterData={masterData} />
          </ProtectedRoute>
        ),
      },
      {
        path: "createrule",
        element: (
          <ProtectedRoute allowedRoles={['admin']}>
            <CreateRule />
          </ProtectedRoute>
        ),
      },
      {
        path: "/rules",
        element: (
          <ProtectedRoute allowedRoles={['admin']}>
            <RulePolicy />
          </ProtectedRoute>
        ),
      },
      {
        path: "/layout-design",
        element: (
          <ProtectedRoute allowedRoles={['dealer']}>
            <NewConfiguratorLayout />
          </ProtectedRoute>
        ),
      },

      // ★ NEW: not authorized page
      {
        path: "/not-authorized",
        element: <NotAuthorized />,
      },
      // Login page (so ProtectedRoute can `Navigate` here)
      {
        path: "/login",
        element: <Login />,
      },
      // Enquiry details page
      {
        path: "/enquiry-details/:id",
        element: (
          <ProtectedRoute allowedRoles={['dealer','admin']}>
            <EnquiryDetails />
          </ProtectedRoute>
        ),
      },
       {
        path: "/mhe-details",
        element: (
            <ProtectedRoute allowedRoles={['dealer','admin']}>
            <MhePage />
          </ProtectedRoute>
        ),
      },
    ],
  },
]);

export default router;
