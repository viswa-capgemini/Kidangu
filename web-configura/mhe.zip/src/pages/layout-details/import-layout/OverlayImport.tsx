import React from "react";
import Button from "../../../components/button/Button";

const OverlayImport = () => {
  return (
    <div data-testid="overlayImportContainer" className="p-2 bg-white shadow-md w-[400px] h-[320px]">
      <h3 data-testid="overlayImportHeader" className="text-godrej-purple text-xl">Import Layout</h3>
      {/* <div className="bg-gray-100 text-center text-godrej-purple mt-4 font-normal">
        Import
      </div> */}
      <div data-testid="overlayImportUpload" className="mt-4 border border-gray-300 w-full h-[30px] text-center">
        <input type="text" placeholder="Upload files" className="outline-none w-full"></input>
      </div>
      <p data-testid="overlayImportUploadHelperText" className="text-gray-500 text-xs">File size up to 15Mb, in.dwg, .dxf format</p>
      <div className="flex flex-row justify-center items-center mt-8 gap-4">
        <Button id={`overlayImport-importBtn`} className="btn-primary-32 flex items-center" label={"Import"} iconClass="icon-[mdi--import]" />


      </div>
      <p data-testid="overlayImportHelperText" className="text-gray-500 text-xs mt-4">Note: File may be component, product group, plan layout, smart product group</p>
    </div>
  );
};

export default OverlayImport;
