import React from "react";
import { useNavigate } from 'react-router-dom';
import ConfigurationLayout from "../../configuration-design/ConfigurationLayout";

const Template = () => {
  const navigate = useNavigate();

  const [showConfigurationLayout, setShowConfigurationLayout] = React.useState(false);

  const handleConfigurationLayout = () => {
    // setShowConfigurationLayout(!showConfigurationLayout);
    navigate('/configuration-layout');
  }
  return (
    <div data-testid="templateContainer" className="p-2 bg-white shadow-md w-[400px] h-[320px]">
      <h3 data-testid="templateHeader" className="text-godrej-purple text-xl">Template</h3>

      <div data-testid="templateWarehouseContainer" className="flex flex-row justify-between items-center mt-4 mb-4 bg-gray-100">
        <button data-testid="templateWarehouseBtn" onClick={handleConfigurationLayout}>
          <select data-testid="templateSelect" className="border border-gray-300 ">
            <option value="template1">FLat</option>
            <option value="template2">Roof</option>
            <option value="template3">Inclined</option>
          </select>

          <span className="p-2 text-godrej-purple">New Warehouse</span>
        </button>
      </div>
      {/* {showConfigurationLayout && <ConfigurationLayout />} */}

      <div className="flex flex-row justify-start items-center p-2 gap-2">
        <span data-testid="warehouse100*200" className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center">
          <img src="images/overlay-template.png" alt="warehouse" />
        </span>
        <span data-testid="warehouse100*200-Header">Flat Warehouse 100m x 200m</span>
      </div>
      <div className="flex flex-row justify-start items-center p-2 gap-2">
        <span data-testid="warehouse150*200" className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center">
          <img src="images/overlay-template.png" alt="warehouse" />
        </span>
        <span data-testid="warehouse150*200-Header">Roof Warehouse 150m x 200m</span>
      </div>
      <div className="flex flex-row justify-start items-center p-2 gap-2">
        <span data-testid="warehouse100*100" className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center">
          <img src="images/overlay-template.png" alt="warehouse" />
        </span>
        <span data-testid="warehouse100*100-Header" className="text-sm">Inclined Warehouse 100m x 100m</span>
      </div>
    </div>
  );
};

export default Template;
