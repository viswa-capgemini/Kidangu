
import React from "react";
import { useState } from "react";
import OverlayManualCardItems from "./OverlayManualCardItems";

type OverlayLayoutCardProps = {
  showOverlay: boolean;
  setShowOverlay: (value: boolean) => void;
};

const OverlayLayoutCard: React.FC<OverlayLayoutCardProps> = ({
  showOverlay,
  setShowOverlay,
}) => {
  const [openOverlay, setOpenOverlay] = useState(false);

  return (
    <div>
      {showOverlay && (
        <div data-testi="overlay-popup-container" className="fixed inset-0 flex items-center justify-center  mt-10 z-10">
          <div data-testi="overlay-popup" className="bg-overlay-popup border rounded-md border-gray-300 shadow-lg p-6 w-[53%] h-[65%] flex flex-col">
            <div data-testid="overlay-popup-wrapper" className="relative">
              {/* <button
                className="m-4 px-3 py-1 bg-red-500 text-white rounded"
                onClick={() => setShowOverlay(false)}
              >
                X
              </button> */}
              <button data-testid="overlay-popup-close-btn" className={'absolute top-1 right-1 text-4xl'} onClick={() => setShowOverlay(false)}><span className="icon-[carbon--close-outline]"></span></button>
            </div>
            <div>
              <OverlayManualCardItems />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OverlayLayoutCard;
