// import React from 'react'

// const ConfigurationLayout = () => {
//   return (
//     <div>
//       <p>Configuration Layout Page</p>
//     </div>
//   )
// }

// export default ConfigurationLayout;

// import React, { useState, useCallback } from 'react';
// import Canvas from './concom/Canvas';
// import TopBar from './concom/TopBar';
// import ElementsPanel from './concom/ElementsPanel';
// import PropertiesPanel from './concom/PropertiesPanel';
// import ThreeJsView from './concom/ThreeJsView';
// import './Test.css';

// function ConfigurationLayout() {
//   const [selectedTool, setSelectedTool] = useState(null);
//   const [shapes, setShapes] = useState([]);
//   const [selectedShape, setSelectedShape] = useState(null);
//   const [isDraggingElement, setIsDraggingElement] = useState(false);
//   const [dragElement, setDragElement] = useState(null);

//   // History state for undo/redo
//   const [history, setHistory] = useState([]);
//   const [historyIndex, setHistoryIndex] = useState(-1);

//   // Dimension settings
//   const [showDimensions, setShowDimensions] = useState(true);
//   const [scale, setScale] = useState(0.01); // 1 pixel = 0.01 meters (1cm)
//   const [unit, setUnit] = useState('meters'); // Default unit is meters

//   // Zoom settings
//   const [zoomLevel, setZoomLevel] = useState(1);

//   // View mode (2D or 3D)
//   const [viewMode, setViewMode] = useState('2D');

//   const handleToolSelect = (tool) => {
//     // If selecting the same tool, toggle it off
//     if (tool === selectedTool) {
//       setSelectedTool(null);
//     } else {
//       setSelectedTool(tool);
//       // Deselect shape when selecting a tool
//       setSelectedShape(null);
//     }
//   };

//   const handleAddShape = useCallback((newShapes) => {
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleElementDragStart = (element) => {
//     setIsDraggingElement(true);
//     setDragElement(element);
//     setSelectedTool(null); // Deselect any active drawing tool
//     setSelectedShape(null); // Deselect any selected shape
//   };

//   const handleElementDrop = useCallback((element, position) => {
//     setIsDraggingElement(false);
//     setDragElement(null);

//     // Create a new shape based on the dropped element
//     const newElement = {
//       ...element,
//       x: position.x,
//       y: position.y,
//       id: Date.now(),
//     };

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes([...shapes, newElement]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleShapeSelect = useCallback((shape) => {
//     // Deselect tool when selecting a shape
//     setSelectedTool(null);
//     setSelectedShape(shape);
//   }, []);

//   const handleUpdateShape = useCallback((updatedShape) => {
//     // Check if the shape should be deleted
//     if (updatedShape._delete) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);

//       // Filter out the shape to be deleted
//       const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
//       setShapes(newShapes);
//       setSelectedShape(null);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
//       return;
//     }

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     // Update the shape
//     const newShapes = shapes.map(shape =>
//       shape.id === updatedShape.id ? { ...updatedShape } : shape
//     );

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleUndo = useCallback(() => {
//     if (historyIndex > 0) {
//       setHistoryIndex(historyIndex - 1);
//       setShapes(history[historyIndex - 1]);
//       // Deselect shape when undoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleRedo = useCallback(() => {
//     if (historyIndex < history.length - 1) {
//       setHistoryIndex(historyIndex + 1);
//       setShapes(history[historyIndex + 1]);
//       // Deselect shape when redoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleToggleDimensions = useCallback(() => {
//     setShowDimensions(!showDimensions);
//   }, [showDimensions]);

//   const handleScaleChange = useCallback((newScale) => {
//     setScale(newScale);
//   }, []);

//   const handleUnitChange = useCallback((newUnit) => {
//     setUnit(newUnit);
//   }, []);

//   const handleZoomIn = useCallback(() => {
//     setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
//   }, []);

//   const handleZoomOut = useCallback(() => {
//     setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
//   }, []);

//   const handleResetZoom = useCallback(() => {
//     setZoomLevel(1);
//   }, []);

//   const handleToggleViewMode = useCallback(() => {
//     setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
//     // Deselect shape when switching view modes
//     setSelectedShape(null);
//   }, []);

//   return (
//     <div className="app">
//       <TopBar
//         selectedTool={selectedTool}
//         onToolSelect={handleToolSelect}
//         onUndo={handleUndo}
//         onRedo={handleRedo}
//         canUndo={historyIndex > 0}
//         canRedo={historyIndex < history.length - 1}
//         showDimensions={showDimensions}
//         onToggleDimensions={handleToggleDimensions}
//         scale={scale}
//         onScaleChange={handleScaleChange}
//         unit={unit}
//         onUnitChange={handleUnitChange}
//         zoomLevel={zoomLevel}
//         onZoomIn={handleZoomIn}
//         onZoomOut={handleZoomOut}
//         onResetZoom={handleResetZoom}
//         viewMode={viewMode}
//         onToggleViewMode={handleToggleViewMode}
//       />
//       <div className="main-content">
//         <div className="sidebar left-sidebar">
//           <ElementsPanel onElementDragStart={handleElementDragStart} />
//         </div>

//         {viewMode === '2D' ? (
//           <Canvas
//             selectedTool={selectedTool}
//             shapes={shapes}
//             onAddShape={handleAddShape}
//             isDraggingElement={isDraggingElement}
//             dragElement={dragElement}
//             onElementDrop={handleElementDrop}
//             showDimensions={showDimensions}
//             scale={scale}
//             unit={unit}
//             zoomLevel={zoomLevel}
//             onShapeSelect={handleShapeSelect}
//             selectedShape={selectedShape}
//           />
//         ) : (
//           <ThreeJsView
//             shapes={shapes}
//             scale={scale}
//             unit={unit}
//           />
//         )}

//         {viewMode === '2D' && (
//           <div className="sidebar right-sidebar">
//             <PropertiesPanel
//               selectedShape={selectedShape}
//               onUpdateShape={handleUpdateShape}
//             />
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default ConfigurationLayout;

// import React, { useState, useCallback } from 'react';
// import Canvas from './components/Canvas';
// import TopBar from './components/TopBar';
// import ElementsPanel from './components/ElementsPanel';
// import PropertiesPanel from './components/PropertiesPanel';
// import ThreeJsView from './components/ThreeJsView';
// import './App.css';

///////////////////////////////////////////////////////////////////////////////////

// import React, { useState, useCallback } from 'react';
// import Canvas from './concom/Canvas';
// import TopBar from './concom/TopBar';
// import ElementsPanel from './concom/ElementsPanel';
// import LayoutLeftPanel from './LayoutLeftPanel';
// import PropertiesPanel from './concom/PropertiesPanel';
// import ThreeJsView from './concom/ThreeJsView';
// import './Test.css';

// function ConfigurationLayout() {
//   const [selectedTool, setSelectedTool] = useState(null);
//   const [shapes, setShapes] = useState([]);
//   const [selectedShape, setSelectedShape] = useState(null);
//   const [isDraggingElement, setIsDraggingElement] = useState(false);
//   const [dragElement, setDragElement] = useState(null);

//   // History state for undo/redo
//   const [history, setHistory] = useState([]);
//   const [historyIndex, setHistoryIndex] = useState(-1);

//   // Dimension settings
//   const [showDimensions, setShowDimensions] = useState(true);
//   const [scale, setScale] = useState(0.01); // 1 pixel = 0.01 meters (1cm)
//   const [unit, setUnit] = useState('meters'); // Default unit is meters

//   // Zoom settings
//   const [zoomLevel, setZoomLevel] = useState(1);

//   // View mode (2D or 3D)
//   const [viewMode, setViewMode] = useState('2D');

//   const handleToolSelect = (tool) => {
//     // If selecting the same tool, toggle it off
//     if (tool === selectedTool) {
//       setSelectedTool(null);
//     } else {
//       setSelectedTool(tool);
//       // Deselect shape when selecting a tool
//       setSelectedShape(null);
//     }
//   };

//   const handleAddShape = useCallback((newShapes) => {
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleElementDragStart = (element) => {
//     setIsDraggingElement(true);
//     setDragElement(element);
//     setSelectedTool(null); // Deselect any active drawing tool
//     setSelectedShape(null); // Deselect any selected shape
//   };

//   const handleElementDrop = useCallback((element, position) => {
//     setIsDraggingElement(false);
//     setDragElement(null);

//     // Create a new shape based on the dropped element
//     const newElement = {
//       ...element,
//       x: position.x,
//       y: position.y,
//       id: Date.now(),
//     };

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes([...shapes, newElement]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleShapeSelect = useCallback((shape) => {
//     // Deselect tool when selecting a shape
//     setSelectedTool(null);
//     setSelectedShape(shape);
//   }, []);

//   const handleUpdateShape = useCallback((updatedShape) => {
//     // Check if the shape should be deleted
//     if (updatedShape._delete) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);

//       // Filter out the shape to be deleted
//       const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
//       setShapes(newShapes);
//       setSelectedShape(null);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
//       return;
//     }

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     // Update the shape
//     const newShapes = shapes.map(shape =>
//       shape.id === updatedShape.id ? { ...updatedShape } : shape
//     );

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

// const handleDuplicateShape = useCallback((duplicates) => {
//   // If it's a single duplicate (for backward compatibility)
//   if (!Array.isArray(duplicates)) {
//     const originalShape = duplicates;
//     const offsetX = arguments[1] || 0;
//     const offsetY = arguments[2] || 0;

//     // Create a new shape based on the selected one with the specified offset
//     // Use a deep copy to ensure all properties are duplicated
//     const duplicatedShape = JSON.parse(JSON.stringify({
//       ...originalShape,
//       id: Date.now(),
//       x: originalShape.x + offsetX,
//       y: originalShape.y + offsetY
//     }));

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     // Add the duplicated shape to the shapes array
//     const newShapes = [...shapes, duplicatedShape];
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);

//     // Select the new shape
//     setSelectedShape(duplicatedShape);
//     return;
//   }

//   // Handle multiple duplicates
//   if (duplicates.length === 0) return;

//   // Add current state to history before updating
//   const newHistory = history.slice(0, historyIndex + 1);
//   newHistory.push(shapes);

//   // Create all duplicated shapes
//   const newShapes = [...shapes];
//   let lastShape = null;

//   duplicates.forEach(({ shape, offsetX, offsetY }) => {
//     // Create a deep copy to ensure all properties are duplicated
//     const duplicatedShape = JSON.parse(JSON.stringify({
//       ...shape,
//       id: Date.now() + Math.random(), // Ensure unique ID
//       x: shape.x + offsetX,
//       y: shape.y + offsetY
//     }));

//     newShapes.push(duplicatedShape);
//     lastShape = duplicatedShape;
//   });

//   setShapes(newShapes);
//   setHistory(newHistory);
//   setHistoryIndex(newHistory.length - 1);

//   // Select the last shape created
//   if (lastShape) {
//     setSelectedShape(lastShape);
//   }
// }, [shapes, history, historyIndex]);

//   const handleUndo = useCallback(() => {
//     if (historyIndex > 0) {
//       setHistoryIndex(historyIndex - 1);
//       setShapes(history[historyIndex - 1]);
//       // Deselect shape when undoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleRedo = useCallback(() => {
//     if (historyIndex < history.length - 1) {
//       setHistoryIndex(historyIndex + 1);
//       setShapes(history[historyIndex + 1]);
//       // Deselect shape when redoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleToggleDimensions = useCallback(() => {
//     setShowDimensions(!showDimensions);
//   }, [showDimensions]);

//   const handleScaleChange = useCallback((newScale) => {
//     setScale(newScale);
//   }, []);

//   const handleUnitChange = useCallback((newUnit) => {
//     setUnit(newUnit);
//   }, []);

//   const handleZoomIn = useCallback(() => {
//     setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
//   }, []);

//   const handleZoomOut = useCallback(() => {
//     setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
//   }, []);

//   const handleResetZoom = useCallback(() => {
//     setZoomLevel(1);
//   }, []);

//   const handleToggleViewMode = useCallback(() => {
//     setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
//     // Deselect shape when switching view modes
//     setSelectedShape(null);
//   }, []);

//   return (
//     <div className="app">
//       <TopBar
//         selectedTool={selectedTool}
//         onToolSelect={handleToolSelect}
//         onUndo={handleUndo}
//         onRedo={handleRedo}
//         canUndo={historyIndex > 0}
//         canRedo={historyIndex < history.length - 1}
//         showDimensions={showDimensions}
//         onToggleDimensions={handleToggleDimensions}
//         scale={scale}
//         onScaleChange={handleScaleChange}
//         unit={unit}
//         onUnitChange={handleUnitChange}
//         zoomLevel={zoomLevel}
//         onZoomIn={handleZoomIn}
//         onZoomOut={handleZoomOut}
//         onResetZoom={handleResetZoom}
//         viewMode={viewMode}
//         onToggleViewMode={handleToggleViewMode}
//       />
//       <div className="main-content">
//         <div className="sidebar left-sidebar">
//           <ElementsPanel onElementDragStart={handleElementDragStart} />
//           <LayoutLeftPanel />
//         </div>

//         {viewMode === '2D' ? (
//           <Canvas
//             selectedTool={selectedTool}
//             shapes={shapes}
//             onAddShape={handleAddShape}
//             isDraggingElement={isDraggingElement}
//             dragElement={dragElement}
//             onElementDrop={handleElementDrop}
//             showDimensions={showDimensions}
//             scale={scale}
//             unit={unit}
//             zoomLevel={zoomLevel}
//             onShapeSelect={handleShapeSelect}
//             selectedShape={selectedShape}
//             onDuplicateShape={handleDuplicateShape}
//           />
//         ) : (
//           <ThreeJsView
//             shapes={shapes}
//             scale={scale}
//             unit={unit}
//           />
//         )}

//         {viewMode === '2D' && (
//           <div className="sidebar right-sidebar">
//             <PropertiesPanel
//               selectedShape={selectedShape}
//               onUpdateShape={handleUpdateShape}
//             />
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default ConfigurationLayout;

// import React, { useState, useCallback } from 'react';
// import Canvas from './concom/Canvas';
// import TopBar from './concom/TopBar';
// import ElementsPanel from './concom/ElementsPanel';
// import LayoutLeftPanel from './LayoutLeftPanel';
// import PropertiesPanel from './concom/PropertiesPanel';
// import ThreeJsView from './concom/ThreeJsView';
// import './Test.css';

// function ConfigurationLayout() {
//   const [selectedTool, setSelectedTool] = useState(null);
//   const [shapes, setShapes] = useState([]);
//   const [selectedShape, setSelectedShape] = useState(null);
//   const [isDraggingElement, setIsDraggingElement] = useState(false);
//   const [dragElement, setDragElement] = useState(null);

//   // History state for undo/redo
//   const [history, setHistory] = useState([]);
//   const [historyIndex, setHistoryIndex] = useState(-1);

//   // Dimension settings
//   const [showDimensions, setShowDimensions] = useState(true);
//   const [scale, setScale] = useState(0.01); // 1 pixel = 0.01 meters (1cm)
//   const [unit, setUnit] = useState('meters'); // Default unit is meters

//   // Zoom settings
//   const [zoomLevel, setZoomLevel] = useState(1);

//   // View mode (2D or 3D)
//   const [viewMode, setViewMode] = useState('2D');

//   const handleToolSelect = (tool) => {
//     // If selecting the same tool, toggle it off
//     if (tool === selectedTool) {
//       setSelectedTool(null);
//     } else {
//       setSelectedTool(tool);
//       // Deselect shape when selecting a tool
//       setSelectedShape(null);
//     }
//   };

//   const handleAddShape = useCallback((newShapes) => {
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleElementDragStart = (element) => {
//     setIsDraggingElement(true);
//     setDragElement(element);
//     setSelectedTool(null); // Deselect any active drawing tool
//     setSelectedShape(null); // Deselect any selected shape
//   };

//   const handleElementDrop = useCallback((element, position) => {
//     setIsDraggingElement(false);
//     setDragElement(null);

//     // Create a new shape based on the dropped element
//     const newElement = {
//       ...element,
//       x: position.x,
//       y: position.y,
//       id: Date.now(),
//     };

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     setShapes([...shapes, newElement]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleShapeSelect = useCallback((shape) => {
//     // Deselect tool when selecting a shape
//     setSelectedTool(null);
//     setSelectedShape(shape);
//   }, []);

//   const handleUpdateShape = useCallback((updatedShape) => {
//     // Check if the shape should be deleted
//     if (updatedShape._delete) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);

//       // Filter out the shape to be deleted
//       const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
//       setShapes(newShapes);
//       setSelectedShape(null);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
//       return;
//     }

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     // Update the shape
//     const newShapes = shapes.map(shape =>
//       shape.id === updatedShape.id ? { ...updatedShape } : shape
//     );

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleDuplicateShape = useCallback((duplicates) => {
//     // If it's a single duplicate (for backward compatibility)
//     if (!Array.isArray(duplicates)) {
//       const originalShape = duplicates;
//       const offsetX = arguments[1] || 0;
//       const offsetY = arguments[2] || 0;

//       // Create a new shape based on the selected one with the specified offset
//       // Use a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...originalShape,
//         id: Date.now(),
//         x: originalShape.x + offsetX,
//         y: originalShape.y + offsetY
//       }));

//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);

//       // Add the duplicated shape to the shapes array
//       const newShapes = [...shapes, duplicatedShape];
//       setShapes(newShapes);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);

//       // Select the new shape
//       setSelectedShape(duplicatedShape);
//       return;
//     }

//     // Handle multiple duplicates
//     if (duplicates.length === 0) return;

//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);

//     // Create all duplicated shapes
//     const newShapes = [...shapes];
//     let lastShape = null;

//     duplicates.forEach(({ shape, offsetX, offsetY }) => {
//       // Create a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...shape,
//         id: Date.now() + Math.random(), // Ensure unique ID
//         x: shape.x + offsetX,
//         y: shape.y + offsetY
//       }));

//       newShapes.push(duplicatedShape);
//       lastShape = duplicatedShape;
//     });

//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);

//     // Select the last shape created
//     if (lastShape) {
//       setSelectedShape(lastShape);
//     }
//   }, [shapes, history, historyIndex]);

//   const handleUndo = useCallback(() => {
//     if (historyIndex > 0) {
//       setHistoryIndex(historyIndex - 1);
//       setShapes(history[historyIndex - 1]);
//       // Deselect shape when undoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleRedo = useCallback(() => {
//     if (historyIndex < history.length - 1) {
//       setHistoryIndex(historyIndex + 1);
//       setShapes(history[historyIndex + 1]);
//       // Deselect shape when redoing
//       setSelectedShape(null);
//     }
//   }, [history, historyIndex]);

//   const handleToggleDimensions = useCallback(() => {
//     setShowDimensions(!showDimensions);
//   }, [showDimensions]);

//   const handleScaleChange = useCallback((newScale) => {
//     setScale(newScale);
//   }, []);

//   const handleUnitChange = useCallback((newUnit) => {
//     setUnit(newUnit);
//   }, []);

//   const handleZoomIn = useCallback(() => {
//     setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
//   }, []);

//   const handleZoomOut = useCallback(() => {
//     setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
//   }, []);

//   const handleResetZoom = useCallback(() => {
//     setZoomLevel(1);
//   }, []);

//   const handleToggleViewMode = useCallback(() => {
//     setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
//     // Deselect shape when switching view modes
//     setSelectedShape(null);
//   }, []);

//   // Function to save the current layout
//   const handleSaveLayout = useCallback(() => {
//     // Create a layout object with all necessary data
//     const layout = {
//       shapes,
//       scale,
//       unit,
//       version: '1.0', // Add version for future compatibility
//     };

//     // Convert to JSON string
//     const jsonString = JSON.stringify(layout, null, 2);

//     // Create a blob and download link
//     const blob = new Blob([jsonString], { type: 'application/json' });
//     const url = URL.createObjectURL(blob);

//     // Create a temporary anchor element to trigger download
//     const a = document.createElement('a');
//     a.href = url;
//     a.download = `floor-plan-${new Date().toISOString().slice(0, 10)}.json`;
//     document.body.appendChild(a);
//     a.click();

//     // Clean up
//     document.body.removeChild(a);
//     URL.revokeObjectURL(url);
//   }, [shapes, scale, unit]);

//   // Function to load a layout from file
//   const handleLoadLayout = useCallback((file) => {
//     const reader = new FileReader();

//     reader.onload = (e) => {
//       try {
//         const layout = JSON.parse(e.target.result);

//         // Validate the layout data
//         if (!layout.shapes || !Array.isArray(layout.shapes)) {
//           throw new Error('Invalid layout file: missing shapes array');
//         }

//         // Update state with loaded data
//         setShapes(layout.shapes);
//         if (layout.scale) setScale(layout.scale);
//         if (layout.unit) setUnit(layout.unit);

//         // Reset history
//         setHistory([layout.shapes]);
//         setHistoryIndex(0);

//         // Deselect any selected shape
//         setSelectedShape(null);

//         // Show success message
//         alert('Layout loaded successfully!');
//       } catch (error) {
//         console.error('Error loading layout:', error);
//         alert(`Error loading layout: ${error.message}`);
//       }
//     };

//     reader.readAsText(file);
//   }, []);

//   return (
//     <div className="app">
//       <TopBar
//         selectedTool={selectedTool}
//         onToolSelect={handleToolSelect}
//         onUndo={handleUndo}
//         onRedo={handleRedo}
//         canUndo={historyIndex > 0}
//         canRedo={historyIndex < history.length - 1}
//         showDimensions={showDimensions}
//         onToggleDimensions={handleToggleDimensions}
//         scale={scale}
//         onScaleChange={handleScaleChange}
//         unit={unit}
//         onUnitChange={handleUnitChange}
//         zoomLevel={zoomLevel}
//         onZoomIn={handleZoomIn}
//         onZoomOut={handleZoomOut}
//         onResetZoom={handleResetZoom}
//         viewMode={viewMode}
//         onToggleViewMode={handleToggleViewMode}
//         onSaveLayout={handleSaveLayout}
//         onLoadLayout={handleLoadLayout}
//       />
//       <div className="main-content">
//         <div className="sidebar left-sidebar">
//           <ElementsPanel onElementDragStart={handleElementDragStart} />
//           <LayoutLeftPanel />
//         </div>

//         {viewMode === '2D' ? (
//           <Canvas
//             selectedTool={selectedTool}
//             shapes={shapes}
//             onAddShape={handleAddShape}
//             isDraggingElement={isDraggingElement}
//             dragElement={dragElement}
//             onElementDrop={handleElementDrop}
//             showDimensions={showDimensions}
//             scale={scale}
//             unit={unit}
//             zoomLevel={zoomLevel}
//             onShapeSelect={handleShapeSelect}
//             selectedShape={selectedShape}
//             onDuplicateShape={handleDuplicateShape}
//           />
//         ) : (
//           <ThreeJsView
//             shapes={shapes}
//             scale={scale}
//             unit={unit}
//           />
//         )}

//         {viewMode === '2D' && (
//           <div className="sidebar right-sidebar">
//             <PropertiesPanel
//               selectedShape={selectedShape}
//               onUpdateShape={handleUpdateShape}
//             />
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default ConfigurationLayout;

import React, { useState, useCallback, useEffect } from "react";
import Canvas from "./concom/Canvas";
import TopBar from "./concom/TopBar";
import ElementsPanel from "./concom/ElementsPanel";
import LayoutLeftPanel from "./LayoutLeftPanel";
import PropertiesPanel from "./concom/PropertiesPanel";
import ThreeJsView from "./concom/ThreeJsView";
import "./Test.css";

function ConfigurationLayout() {
  const [selectedTool, setSelectedTool] = useState(null);
  const [shapes, setShapes] = useState([]);
  const [selectedShape, setSelectedShape] = useState(null);
  const [isDraggingElement, setIsDraggingElement] = useState(false);
  const [dragElement, setDragElement] = useState(null);

  // History state for undo/redo
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Dimension settings
  const [showDimensions, setShowDimensions] = useState(true);
  const [scale, setScale] = useState(0.01); // 1 pixel = 0.01 meters (1cm)
  const [unit, setUnit] = useState("meters"); // Default unit is meters

  // Zoom settings
  const [zoomLevel, setZoomLevel] = useState(1);

  // View mode (2D or 3D)
  const [viewMode, setViewMode] = useState("2D");

  // Show radial menu
  const [showRadialMenu, setShowRadialMenu] = useState(false);

  // offset for dropping the element
  const [dragOffset, setDragOffset] = useState({ offsetX: 0, offsetY: 0 });

  const handleToolSelect = (tool) => {
    // If selecting the same tool, toggle it off
    if (tool === selectedTool) {
      setSelectedTool(null);
    } else {
      setSelectedTool(tool);
      // Deselect shape when selecting a tool
      setSelectedShape(null);
    }
  };

  const handleAddShape = useCallback(
    (newShapes) => {
      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);

      setShapes(newShapes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    },
    [shapes, history, historyIndex]
  );

  const handleElementDragStart = (element, offset) => {
    setIsDraggingElement(true);
    setDragElement(element);
    setDragOffset(offset || { offsetX: 0, offsetY: 0 }); // Store the drag offset
    setSelectedTool(null);
    setSelectedShape(null);

    document.body.classList.add("dragging");
    document.body.style.cursor = "grabbing";
  };

  const handleElementDrop = useCallback(
    (element, position) => {
      setIsDraggingElement(false);
      setDragElement(null);
      setDragOffset({ offsetX: 0, offsetY: 0 });

      // Remove the dragging class
      document.body.classList.remove("dragging");

      // Reset cursor style
      document.body.style.cursor = "";

      // Create a new shape based on the dropped element
      const newElement = {
        ...element,
        x: position.x,
        y: position.y,
        id: Date.now(),
      };

      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);

      setShapes([...shapes, newElement]);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    },
    [dragElement, shapes, history, historyIndex]
  );

  // Handle drag end events (including cancelled drags)
  useEffect(() => {
    const handleDragEnd = () => {
      if (isDraggingElement) {
        setIsDraggingElement(false);
        setDragElement(null);
        document.body.classList.remove("dragging");
        document.body.style.cursor = "";
      }
    };

    // Handle drag end events
    document.addEventListener("dragend", handleDragEnd);

    // Handle cases where drag is cancelled without firing dragend
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && isDraggingElement) {
        handleDragEnd();
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    // Handle mouse up outside the window
    const handleMouseUp = () => {
      if (isDraggingElement) {
        handleDragEnd();
      }
    };

    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.removeEventListener("dragend", handleDragEnd);
      document.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("mouseup", handleMouseUp);
      document.body.classList.remove("dragging");
      document.body.style.cursor = "";
    };
  }, [isDraggingElement]);

  const handleShapeSelect = useCallback((shape) => {
    // Deselect tool when selecting a shape
    setSelectedTool(null);
    setSelectedShape(shape);
  }, []);

  const handleUpdateShape = useCallback(
    (updatedShape) => {
      // Check if the shape should be deleted
      if (updatedShape._delete) {
        // Add current state to history before updating
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(shapes);

        // Filter out the shape to be deleted
        const newShapes = shapes.filter(
          (shape) => shape.id !== updatedShape.id
        );
        setShapes(newShapes);
        setSelectedShape(null);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        return;
      }

      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);

      // Update the shape
      const newShapes = shapes.map((shape) =>
        shape.id === updatedShape.id ? { ...updatedShape } : shape
      );

      setShapes(newShapes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    },
    [shapes, history, historyIndex]
  );

  const handleDuplicateShape = useCallback(
    (duplicates) => {
      // If it's a single duplicate (for backward compatibility)
      if (!Array.isArray(duplicates)) {
        const originalShape = duplicates;
        const offsetX = arguments[1] || 0;
        const offsetY = arguments[2] || 0;

        // Create a new shape based on the selected one with the specified offset
        // Use a deep copy to ensure all properties are duplicated
        const duplicatedShape = JSON.parse(
          JSON.stringify({
            ...originalShape,
            id: Date.now(),
            x: originalShape.x + offsetX,
            y: originalShape.y + offsetY,
          })
        );

        // Add current state to history before updating
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(shapes);

        // Add the duplicated shape to the shapes array
        const newShapes = [...shapes, duplicatedShape];
        setShapes(newShapes);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);

        // Select the new shape
        setSelectedShape(duplicatedShape);
        return;
      }

      // Handle multiple duplicates
      if (duplicates.length === 0) return;

      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);

      // Create all duplicated shapes
      const newShapes = [...shapes];
      let lastShape = null;

      duplicates.forEach(({ shape, offsetX, offsetY }) => {
        // Create a deep copy to ensure all properties are duplicated
        const duplicatedShape = JSON.parse(
          JSON.stringify({
            ...shape,
            id: Date.now() + Math.random(), // Ensure unique ID
            x: shape.x + offsetX,
            y: shape.y + offsetY,
          })
        );

        newShapes.push(duplicatedShape);
        lastShape = duplicatedShape;
      });

      setShapes(newShapes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);

      // Select the last shape created
      if (lastShape) {
        setSelectedShape(lastShape);
      }
    },
    [shapes, history, historyIndex]
  );

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setShapes(history[historyIndex - 1]);
      // Deselect shape when undoing
      setSelectedShape(null);
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setShapes(history[historyIndex + 1]);
      // Deselect shape when redoing
      setSelectedShape(null);
    }
  }, [history, historyIndex]);

  const handleToggleDimensions = useCallback(() => {
    setShowDimensions(!showDimensions);
  }, [showDimensions]);

  const handleScaleChange = useCallback((newScale) => {
    setScale(newScale);
  }, []);

  const handleUnitChange = useCallback((newUnit) => {
    setUnit(newUnit);
  }, []);

  const handleZoomIn = useCallback(() => {
    setZoomLevel((prevZoom) => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoomLevel((prevZoom) => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
  }, []);

  const handleResetZoom = useCallback(() => {
    setZoomLevel(1);
  }, []);

  const handleToggleViewMode = useCallback(() => {
    setViewMode((prevMode) => (prevMode === "2D" ? "3D" : "2D"));
    // Deselect shape when switching view modes
    setSelectedShape(null);
  }, []);

  // Function to save the current layout
  const handleSaveLayout = useCallback(() => {
    // Create a layout object with all necessary data
    const layout = {
      shapes,
      scale,
      unit,
      version: "1.0", // Add version for future compatibility
    };

    // Convert to JSON string
    const jsonString = JSON.stringify(layout, null, 2);

    // Create a blob and download link
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    // Create a temporary anchor element to trigger download
    const a = document.createElement("a");
    a.href = url;
    a.download = `floor-plan-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();

    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [shapes, scale, unit]);

  // Function to load a layout from file
  const handleLoadLayout = useCallback((file) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const layout = JSON.parse(e.target.result);

        // Validate the layout data
        if (!layout.shapes || !Array.isArray(layout.shapes)) {
          throw new Error("Invalid layout file: missing shapes array");
        }

        // Update state with loaded data
        setShapes(layout.shapes);
        if (layout.scale) setScale(layout.scale);
        if (layout.unit) setUnit(layout.unit);

        // Reset history
        setHistory([layout.shapes]);
        setHistoryIndex(0);

        // Deselect any selected shape
        setSelectedShape(null);

        // Show success message
        alert("Layout loaded successfully!");
      } catch (error) {
        console.error("Error loading layout:", error);
        alert(`Error loading layout: ${error.message}`);
      }
    };

    reader.readAsText(file);
  }, []);

  // Add CSS for drag and drop
  useEffect(() => {
    // Create a style element
    const styleElement = document.createElement("style");
    styleElement.textContent = `
      .dragging {
        cursor: grabbing !important;
      }
      
      .canvas-container {
        position: relative;
      }
      
      .canvas-container.drag-over {
        outline: 2px dashed #3498db;
      }
      
      .element-item {
        cursor: grab;
        user-select: none;
        transition: transform 0.2s, box-shadow 0.2s;
      }
      
      .element-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      }
      
      .element-item:active {
        cursor: grabbing;
        transform: translateY(0);
      }
    `;

    // Add the style element to the document head
    document.head.appendChild(styleElement);

    // Clean up function
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  return (
    <div className="app">
      <TopBar
        selectedTool={selectedTool}
        onToolSelect={handleToolSelect}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        showDimensions={showDimensions}
        onToggleDimensions={handleToggleDimensions}
        scale={scale}
        onScaleChange={handleScaleChange}
        unit={unit}
        onUnitChange={handleUnitChange}
        zoomLevel={zoomLevel}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetZoom={handleResetZoom}
        viewMode={viewMode}
        onToggleViewMode={handleToggleViewMode}
        onSaveLayout={handleSaveLayout}
        onLoadLayout={handleLoadLayout}
      />
      <div className="main-content">
        <div className="sidebar left-sidebar">
          <ElementsPanel onElementDragStart={handleElementDragStart} />
          <LayoutLeftPanel />
        </div>

        {viewMode === "2D" ? (
          <Canvas
            selectedTool={selectedTool}
            shapes={shapes}
            onAddShape={handleAddShape}
            isDraggingElement={isDraggingElement}
            dragElement={dragElement}
            dragOffset={dragOffset} // Pass the drag offset
            onElementDrop={handleElementDrop}
            showDimensions={showDimensions}
            scale={scale}
            unit={unit}
            zoomLevel={zoomLevel}
            onShapeSelect={handleShapeSelect}
            selectedShape={selectedShape}
            onDuplicateShape={handleDuplicateShape}
            showRadialMenu={showRadialMenu}
            setShowRadialMenu={setShowRadialMenu}
          />
        ) : (
          <ThreeJsView shapes={shapes} scale={scale} unit={unit} />
        )}

        {viewMode === "2D" && (
          <div className="sidebar right-sidebar">
            <PropertiesPanel
              selectedShape={selectedShape}
              onUpdateShape={handleUpdateShape}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default ConfigurationLayout;
