import { PRODUCT_GROUPS } from "../../../constants/constants";
import ProductGroupItem from "./ProductGroupItems";
import { useState } from "react";
import { type Product, type TreeNode } from "../../../types/products";
import Accordion from "../../../components/accordion/Accordion";
import { PRODUCT_GROUP_DATA } from "../../../constants/constants";
import ProductTree from "./ProductTree";


type ProductGroupProps = {
  selectedId: string | null;
  onSelect: (node: { id: string; label: string }) => void;
};



const ProductGroup: React.FC<ProductGroupProps> = ({ selectedId, onSelect }) => {
  // No normalization: PRODUCT_GROUP_DATA uses `Children`
  const data: TreeNode[] = PRODUCT_GROUP_DATA;


  return (
    <div>
      {/* Accordion Header */}
      {/* <div
        data-testid="productGroupAccordion"
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer"
      >
        <h3
          data-testid="productGroupAccordionHeader"
          className="text-sm font-semibold"
        >
          Product Group
        </h3>
        <span>
          {isOpen ? (
            <span
              className="icon-[ic--sharp-expand-less] w-6 h-6"
              style={{ color: "#810055" }}
            />
          ) : (
            <span
              className="icon-[ic--sharp-expand-more] w-6 h-6"
              style={{ color: "#810055"}}
            />
          )}
        </span>
      </div> */}
      {/* <span class="icon-[ic--sharp-expand-less]" style="color: #000;"></span>
      <span class="icon-[ic--sharp-expand-more]" style="color: #000;"></span> */}
      {/* Accordion Content */}
      {/* <div
        data-testid="productGroupAccordionContent"
        className={`transition-all duration-300 ${
          isOpen
            ? "max-h-48 overflow-y-auto scrollbar-hide"
            : "max-h-0 overflow-hidden"
        }`}
      >
        <div className="p-1 bg-gray-50">
          {PRODUCT_GROUPS.map((product: Product) => (
            <div
              key={product.id}
              onClick={() => {
                setSelectedProduct(product.name);
                onSelect(product.name);
              }}
              className={`cursor-pointer hover:bg-purple-200 rounded`}
            >
              <ProductGroupItem
                product={product}
                selectedProduct={selectedProduct}
              />
            </div>
          ))}
        </div>
      </div> */}
      
    <Accordion title="Product Group" defaultOpen={true}>
      {/* <div className="p-1 bg-gray-50">
        {PRODUCT_GROUPS.map((product: Product) => (
          <div
            key={product.id}
            onClick={() => {
              setSelectedProduct(product.name);
              onSelect(product.name);
            }}
            className="cursor-pointer hover:bg-purple-200 rounded"
          >
            <ProductGroupItem product={product} selectedProduct={selectedProduct} />
          </div>
        ))}
      </div> */}
      <ProductTree data={data} selectedId={selectedId} onSelect={onSelect} />
    </Accordion>

    </div>
  );
};

export default ProductGroup;
