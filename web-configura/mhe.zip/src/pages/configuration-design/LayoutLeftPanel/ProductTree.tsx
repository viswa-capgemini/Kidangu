
import React from "react";
import { type TreeNode } from "../../../types/products";
import ProductTreeItem from "./ProductTreeItem";

interface TreeProps {
  data: TreeNode[];
  selectedId: string | null;
  onSelect: (node: { id: string; label: string }) => void;
}

const ProductTree: React.FC<TreeProps> = ({ data, selectedId, onSelect }) => {
  return (
    <ul className="relative pl-3" role="tree" aria-label="Product Group">
      {data.map((node) => (
        <ProductTreeItem
          key={node.id}
          node={node}
          depth={1}
          selectedId={selectedId}
          onSelect={onSelect}
        />
      ))}
    </ul>
  );
};

export default ProductTree;
