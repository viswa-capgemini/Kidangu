
import React, { useEffect, useMemo, useState } from "react";
import { type TreeNode } from "../../../types/products";

interface ProductTreeItemProps {
  node: TreeNode;
  depth: number;
  selectedId: string | null;
  onSelect: (node: { id: string; label: string }) => void;
}

const ProductTreeItem: React.FC<ProductTreeItemProps> = ({
  node,
  depth,
  selectedId,
  onSelect,
}) => {
  const hasChildren = !!(node.children && node.children.length > 0);
  const isSelected = selectedId === node.id;

  // Auto-expand if any descendant is selected
  const descendantSelected = useMemo(() => {
    if (!hasChildren || !selectedId) return false;
    const stack: TreeNode[] = [...(node.children ?? [])];
    while (stack.length) {
      const n = stack.pop()!;
      if (n.id === selectedId) return true;
      if (n.children) stack.push(...n.children);
    }
    return false;
  }, [node, hasChildren, selectedId]);

  const [open, setOpen] = useState<boolean>(false);

  useEffect(() => {
    if (descendantSelected) setOpen(true);
  }, [descendantSelected]);

  return (
    <li
      className="relative pl-4"
      role="treeitem"
      aria-expanded={hasChildren ? open : undefined}
      aria-selected={isSelected || undefined}
    >
      <div className="flex items-start gap-1">
        {/* Chevron toggles expand/collapse */}
        <button
          type="button"
          className="select-none mt-2 h-4 w-4 text-slate-500"
          aria-label={open ? "Collapse" : "Expand"}
          onClick={() => hasChildren && setOpen(!open)}
        >
          {hasChildren ? (open ? "▼" : "▶") : "•"}
        </button>

        {/* Label selects the item */}
        <div
          className={
            "relative cursor-pointer select-none px-2 py-1 rounded " +
            (isSelected
              ? "bg-violet-100 text-violet-800 font-medium"
              : "hover:bg-slate-50")
          }
          onClick={() => onSelect({ id: node.id, label: node.label })}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onSelect({ id: node.id, label: node.label });
            }
            if (e.key === "ArrowRight" && hasChildren && !open) setOpen(true);
            if (e.key === "ArrowLeft" && hasChildren && open) setOpen(false);
          }}
        >
          {node.label}
        </div>
      </div>

      {hasChildren && open && (
        <ul className="pl-4" role="group">
          {node.children!.map((child) => (
            <ProductTreeItem
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedId={selectedId}
              onSelect={onSelect}
            />
          ))}
        </ul>
      )}
    </li>
  );
};

export default ProductTreeItem;
