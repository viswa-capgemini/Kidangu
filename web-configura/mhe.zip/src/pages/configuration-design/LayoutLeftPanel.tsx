import React, { useContext } from "react";
import GodrejLogo from "../../assets/images/godrej-logo.png";
import ProductGroup from "./LayoutLeftPanel/ProductGroup";
import ComponentsSection from "./LayoutLeftPanel/ComponentsSection";
import SmartProductGroup from "./LayoutLeftPanel/SmartProductGroup";
import LayoutRightPanel from "./LayoutRightPanel";
import { LayoutContext } from "../../context/propertyPanelContext";

// NOTE: paths above may need tweaking to match your project

const LayoutLeftPanel = () => {
  const [isOpen, setIsOpen] = React.useState(true);

  const context = useContext(LayoutContext);
  if (!context)
    throw new Error("LayoutLeftPanel must be used within LayoutProvider");

  const { selectedItem, rightPanelOpen, selectProduct } = context;

  return (
    <div className="flex h-screen">
      {/* LEFT SIDE */}
      <div className={`${isOpen ? "w-[160px]" : "w-auto"} bg-white`}>
        <div
          data-testid="leftPanelToggle"
          className={`relative flex justify-between ${
            isOpen
              ? "w-[160px] h-[35px] items-center bg-white"
              : "flex justify-start m-1"
          }`}
        >
          <button>
            {isOpen && (
              <span>
                <img
                  data-testid="godrej-logo"
                  src={GodrejLogo}
                  alt="Godrej Logo"
                  className="h-8 w-auto pl-1"
                />
              </span>
            )}
          </button>

          <button
            data-testid="leftPanelToggleBtn"
            onClick={() => setIsOpen(!isOpen)}
            className={`px-3 ${
              isOpen ? "py-3" : "py-2"
            } border border-gray-100 rounded hover:bg-gray-300`}
            aria-label={isOpen ? "Collapse left panel" : "Expand left panel"}
          >
            {isOpen ? (
              <span className="icon-[icon-park-outline--expand-right] p-2" />
            ) : (
              // <>
              //   <span className="icon-[icon-park-outline--expand-left]" />

              //   <span>
              //     <img
              //       data-testid="godrej-logo"
              //       src={GodrejLogo}
              //       alt="Godrej Logo"
              //       className="h-8 w-auto pl-1"
              //     />
              //   </span>
              // </>
             <span className="inline-flex items-center space-x-1">
             <span className="icon-[icon-park-outline--expand-left]" />
              <img
                 data-testid="godrej-logo"
                 src={GodrejLogo}
                 alt="Godrej Logo"
                  className="h-8 w-auto"
               />
             </span>
            )}
          </button>
        </div>

        {isOpen && (
          <div
            data-testid="leftPanelContainer"
            className="bg-gray-100 border-r border-gray-300 overflow-y-auto w-[160px] h-[calc(100vh-35px)] scrollbar-hide"
          >
            <ProductGroup
              selectedId={selectedItem?.id ?? null}
              onSelect={(node) => selectProduct(node)}
            />

            <ComponentsSection />
            <SmartProductGroup />
          </div>
        )}
      </div>

      {/* RIGHT SIDE (opens when something selected) */}
      {rightPanelOpen && (
        <div
          data-testid="rightPanelWrapper"
          className="flex-1 bg-gray-50 border-l border-gray-300 p-4 overflow-y-auto"
        >
          {/* Use your existing component as-is */}
          <LayoutRightPanel />
        </div>
      )}
    </div>
  );
};

export default LayoutLeftPanel;
