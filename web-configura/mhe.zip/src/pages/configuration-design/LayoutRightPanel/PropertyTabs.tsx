
import React, { useState } from "react";
import Tabs from "./Tabs";
import SKU from "./properties-forms/sku";
import Rack from "./properties-forms/rack";
import Elevation from "./properties-forms/elevation";
import Accordion from "../../../components/accordion/Accordion";

const PropertiesSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState("Elevation");

  const tabList = ["Elevation", "SKU", "Rack"];

  return (
    <Accordion title="Properties" defaultOpen={true}>
      <div className="w-full">
        {/* Tabs */}
        <Tabs tabs={tabList} activeTab={activeTab} onChange={setActiveTab} />

        {/* Tab Content */}
        <div className="mt-4 space-y-3 w-full">
          {activeTab === "Elevation" && (
            <div className="w-full">
              <Elevation />
            </div>
          )}
          {activeTab === "SKU" && (
            <div className="w-full">
              <SKU />
            </div>
          )}
          {activeTab === "Rack" && (
            <div className="w-full">
              <Rack />
            </div>
          )}
        </div>
      </div>
    </Accordion>
  );
};

export default PropertiesSection;
