import React, { useContext } from "react";
import CollapseIcon from "../../assets/images/Component 186 – 3.svg";
import PropertiesSection from "./LayoutRightPanel/PropertyTabs";
import ExpandIcon from "../../assets/images/Component 191 – 3.svg";
import { LayoutContext } from "../../context/propertyPanelContext";
import ConfigurationSummary from "./LayoutRightPanel/ConfigurationSummary";
import BOMTable from "./LayoutRightPanel/BOM";

interface PropertiesPanelProps {
  product: string;
}

const LayoutRightPanel = () => {
  const [isOpen, setIsOpen] = React.useState(true);

  const context = useContext(LayoutContext);
  if (!context)
    throw new Error("LayoutRightPanel must be used within LayoutProvider");

  const { selectedItem } = context;
  if (!selectedItem) return null; // Hide panel if nothing selected

  return (
    // <CollapsibleWrapper>
    <div>
      <div
        data-testid="rightPanelToggle"
        className={`flex justify-between relative ${
          isOpen
            ? "flex justify-between w-full h-[48px] items-center bg-white"
            : "flex justify-start m-1"
        } `}
      >
        <button
          data-testid="rightPanelToggleBtn"
          onClick={() => setIsOpen(!isOpen)}
          className={`border border-gray-100 px-3 ${isOpen ? "h-full" : "py-2"} rounded p-1 hover:bg-gray-300`}
        >
          {isOpen ? (
            // <img src={ExpandIcon} alt="Collapse" className="w-6 h-6" />
            <div className="flex items-center">
              <span className="icon-[icon-park-outline--expand-left]"></span>
            </div>
          ) : (
            // <img src={CollapseIcon} alt="Expand" className="w-6 h-6" />
            <span className="icon-[icon-park-outline--expand-right]"></span>
          )}
        </button>
        <button>
          {isOpen && <span
            data-testid="rightPanel-user-icon"
            className="icon-[qlementine-icons--user-24]"
            style={{ marginRight: "12px" }}
          ></span>}
        </button>
      </div>
      {isOpen && (
        <div
          data-testid="rightPanelContainer"
          className="bg-gray-100 border-l border-gray-300 overflow-y-auto w-[250px] h-screen scrollbar-hide"
        >
          <PropertiesSection />
          <ConfigurationSummary />
          <BOMTable />
        </div>
      )}
    </div>
  );
};

export default LayoutRightPanel;
