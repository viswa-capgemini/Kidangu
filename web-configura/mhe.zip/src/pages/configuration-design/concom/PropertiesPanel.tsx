import React, { useState, useEffect } from 'react';
import { SketchPicker } from 'react-color'; // You'll need to install react-color
import './PropertiesPanel.css';

const PropertiesPanel = ({ selectedShapes, onUpdateShape, onGroupShapes, onUngroupShapes }) => {
  const [localShape, setLocalShape] = useState(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  
  // Update local state when selected shape changes
  useEffect(() => {
    // If it's an array of shapes (multiple selection)
    if (Array.isArray(selectedShapes) && selectedShapes.length > 0) {
      setLocalShape(null); // Clear single shape selection
    } 
    // If it's a single shape
    else if (selectedShapes && !Array.isArray(selectedShapes)) {
      setLocalShape(selectedShapes);
    } else {
      setLocalShape(null);
    }
  }, [selectedShapes]);
  
  // Handle multiple selections
  if (Array.isArray(selectedShapes) && selectedShapes.length > 1) {
    return (
      <div className="properties-panel">
        <h3>Multiple Selection</h3>
        <div className="multiple-selection-info">
          <p>{selectedShapes.length} elements selected</p>
          <div className="property-actions">
            <button 
              className="group-button"
              onClick={() => onGroupShapes(selectedShapes)}
            >
              Group Elements
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  // Handle group selection
  if (localShape && localShape.type === 'group') {
    return (
      <div className="properties-panel">
        <h3>Group Properties</h3>
        <div className="group-info">
          <p>Group with {localShape.shapeIds.length} elements</p>
          <div className="property-group">
            <h4>Position</h4>
            <div className="property-row">
              <label>X:</label>
              <input
                type="number"
                name="x"
                value={localShape.x}
                onChange={(e) => {
                  const updatedShape = {
                    ...localShape,
                    x: parseFloat(e.target.value)
                  };
                  setLocalShape(updatedShape);
                  onUpdateShape(updatedShape);
                }}
              />
            </div>
            <div className="property-row">
              <label>Y:</label>
              <input
                type="number"
                name="y"
                value={localShape.y}
                onChange={(e) => {
                  const updatedShape = {
                    ...localShape,
                    y: parseFloat(e.target.value)
                  };
                  setLocalShape(updatedShape);
                  onUpdateShape(updatedShape);
                }}
              />
            </div>
          </div>
          <div className="property-actions">
            <button 
              className="ungroup-button"
              onClick={() => onUngroupShapes(localShape)}
            >
              Ungroup Elements
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  if (!localShape) {
    return (
      <div className="properties-panel">
        <h3>Properties</h3>
        <p className="no-selection">No element selected</p>
      </div>
    );
  }
  
  // Check if shape is locked
  if (localShape.locked) {
    return (
      <div className="properties-panel locked-panel">
        <h3>Properties: {localShape.name || localShape.type}</h3>
        <div className="locked-message">
          <div className="lock-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
              <path fill="#424242" d="M24 4c-5.5 0-10 4.5-10 10v4h4v-4c0-3.3 2.7-6 6-6s6 2.7 6 6v4h4v-4c0-5.5-4.5-10-10-10"/>
              <path fill="#fb8c00" d="M36 44H12c-2.2 0-4-1.8-4-4V22c0-2.2 1.8-4 4-4h24c2.2 0 4 1.8 4 4v18c0 2.2-1.8 4-4 4"/>
              <circle cx="24" cy="31" r="3" fill="#c76e00"/>
            </svg>
          </div>
          <p>This element is locked and cannot be edited</p>
          <button 
            className="unlock-button"
            onClick={() => {
              // Create updated shape with locked set to false
              const updatedShape = {
                ...localShape,
                locked: false
              };
              
              // Update local state
              setLocalShape(updatedShape);
              
              // Notify parent component to update the shape
              onUpdateShape(updatedShape);
            }}
          >
            Unlock Element
          </button>
        </div>
      </div>
    );
  }
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const numericValue = name !== 'name' && name !== 'text' ? parseFloat(value) : value;
    
    const updatedShape = {
      ...localShape,
      [name]: numericValue
    };
    
    setLocalShape(updatedShape);
    onUpdateShape(updatedShape);
  };
  
  const handleColorChange = (color) => {
    const updatedShape = {
      ...localShape,
      fill: color.hex
    };
    
    setLocalShape(updatedShape);
    onUpdateShape(updatedShape);
  };
  
  const renderTransformationControls = () => {
    switch (localShape.type) {
      case 'line':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>Start X:</label>
                <input
                  type="number"
                  name="points[0]"
                  value={localShape.points[0]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[0] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>Start Y:</label>
                <input
                  type="number"
                  name="points[1]"
                  value={localShape.points[1]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[1] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>End X:</label>
                <input
                  type="number"
                  name="points[2]"
                  value={localShape.points[2]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[2] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>End Y:</label>
                <input
                  type="number"
                  name="points[3]"
                  value={localShape.points[3]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[3] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
            </div>
          </>
        );
        
      case 'rectangle':
      case 'wall':
      case 'door':
      case 'window':
      case 'sliding-door':
      case 'bed':
      case 'sofa':
      case 'table':
      case 'chair':
      case 'rack':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Size</h4>
              <div className="property-row">
                <label>Width:</label>
                <input
                  type="number"
                  name="width"
                  value={localShape.width}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Height:</label>
                <input
                  type="number"
                  name="height"
                  value={localShape.height}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            {(localShape.rotation !== undefined) && (
              <div className="property-group">
                <h4>Rotation</h4>
                <div className="property-row">
                  <label>Angle:</label>
                  <input
                    type="number"
                    name="rotation"
                    value={localShape.rotation || 0}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            )}
          </>
        );
        
      case 'circle':
      case 'pillar':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Size</h4>
              <div className="property-row">
                <label>Radius:</label>
                <input
                  type="number"
                  name="radius"
                  value={localShape.radius || localShape.width / 2}
                  onChange={(e) => {
                    const value = parseFloat(e.target.value);
                    if (localShape.type === 'pillar') {
                      // For pillars, update both width and height to maintain the circle
                      const updatedShape = {
                        ...localShape,
                        width: value * 2,
                        height: value * 2
                      };
                      setLocalShape(updatedShape);
                      onUpdateShape(updatedShape);
                    } else {
                      // For regular circles
                      const updatedShape = {
                        ...localShape,
                        radius: value
                      };
                      setLocalShape(updatedShape);
                      onUpdateShape(updatedShape);
                    }
                  }}
                />
              </div>
            </div>
          </>
        );
        
      case 'text':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Text</h4>
              <div className="property-row">
                <label>Content:</label>
                <input
                  type="text"
                  name="text"
                  value={localShape.text}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Font Size:</label>
                <input
                  type="number"
                  name="fontSize"
                  value={localShape.fontSize}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </>
        );
        
      case 'pencil':
        return (
          <div className="property-group">
            <h4>Pencil Properties</h4>
            <p className="no-selection">Pencil shapes have limited editable properties</p>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
  <div className="properties-panel">
    <h3>Properties: {localShape.name || localShape.type}</h3>
    
    {renderTransformationControls()}
    
    <div className="property-group">
      <h4>Appearance</h4>
      {localShape.fill !== undefined && (
        <div className="property-row">
          <label>Fill Color:</label>
          <div className="color-picker-container">
            <div 
              className="color-preview" 
              style={{ backgroundColor: localShape.fill }}
              onClick={() => setShowColorPicker(!showColorPicker)}
            ></div>
            {showColorPicker && (
              <div className="color-picker-popover">
                <div 
                  className="color-picker-cover" 
                  onClick={() => setShowColorPicker(false)}
                />
                <SketchPicker 
                  color={localShape.fill} 
                  onChange={handleColorChange}
                />
              </div>
            )}
          </div>
        </div>
      )}
      
      {localShape.stroke !== undefined && (
        <div className="property-row">
          <label>Stroke:</label>
          <input
            type="text"
            name="stroke"
            value={localShape.stroke}
            onChange={handleInputChange}
          />
        </div>
      )}
      
      {localShape.strokeWidth !== undefined && (
        <div className="property-row">
          <label>Stroke Width:</label>
          <input
            type="number"
            name="strokeWidth"
            value={localShape.strokeWidth}
            onChange={handleInputChange}
          />
        </div>
      )}
    </div>
    
    <div className="property-group">
      <h4>Identification</h4>
      <div className="property-row">
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={localShape.name || ''}
          onChange={handleInputChange}
          placeholder={localShape.type}
        />
      </div>
    </div>
    
    <div className="property-actions">
      <button 
        className="lock-button"
        onClick={() => {
          const updatedShape = {
            ...localShape,
            locked: true
          };
          setLocalShape(updatedShape);
          onUpdateShape(updatedShape);
        }}
      >
        Lock Element
      </button>
      <button 
        className="delete-button"
        onClick={() => onUpdateShape({ ...localShape, _delete: true })}
      >
        Delete Element
      </button>
    </div>
  </div>
);
};

export default PropertiesPanel;