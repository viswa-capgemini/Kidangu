// import React, { useState, useRef, useEffect } from 'react';
// import { Stage, Layer, Line, Rect, Circle, Text, Group } from 'react-konva';
// import DuplicateControls from './DuplicateControls';

// const Canvas = ({ 
//   selectedTool, 
//   shapes, 
//   onAddShape, 
//   isDraggingElement, 
//   dragElement, 
//   onElementDrop,
//   showDimensions,
//   scale,
//   unit,
//   zoomLevel,
//   onShapeSelect,
//   selectedShape,
//   onDuplicateShape
// }) => {
//   const [isDrawing, setIsDrawing] = useState(false);
//   const [points, setPoints] = useState([]);
//   const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
//   const [currentShape, setCurrentShape] = useState(null);
//   const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
//   const [stageSize, setStageSize] = useState({
//     width: window.innerWidth - 500, // Adjusted for both sidebars
//     height: window.innerHeight - 50 // Adjust for top bar height
//   });
//   const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 });
//   const stageRef = useRef(null);
//   const containerRef = useRef(null);

//   // Units configuration with conversion factors and formatting rules
//   const units = {
//     meters: { 
//       toMeters: 1, 
//       abbr: 'm', 
//       smallerUnit: { divisor: 100, id: 'centimeters', abbr: 'cm', threshold: 1 } 
//     },
//     centimeters: { 
//       toMeters: 0.01, 
//       abbr: 'cm', 
//       smallerUnit: null 
//     },
//     feet: { 
//       toMeters: 0.3048, 
//       abbr: 'ft', 
//       smallerUnit: { divisor: 12, id: 'inches', abbr: 'in', threshold: 1 } 
//     },
//     inches: { 
//       toMeters: 0.0254, 
//       abbr: 'in', 
//       smallerUnit: null 
//     },
//     yards: { 
//       toMeters: 0.9144, 
//       abbr: 'yd', 
//       smallerUnit: { divisor: 3, id: 'feet', abbr: 'ft', threshold: 1 } 
//     }
//   };

//   // Collision detection function
//   const checkCollision = (newShape, existingShapes) => {
//     // Skip collision check for walls, lines, and the shape itself
//     const shapesToCheck = existingShapes.filter(shape => 
//       shape.id !== newShape.id && 
//       shape.type !== 'line' && 
//       shape.type !== 'wall'
//     );
    
//     // Get bounding box for the new shape
//     let newBounds;
    
//     if (newShape.type === 'circle') {
//       newBounds = {
//         x: newShape.x - newShape.radius,
//         y: newShape.y - newShape.radius,
//         width: newShape.radius * 2,
//         height: newShape.radius * 2
//       };
//     } else if (newShape.type === 'pillar') {
//       newBounds = {
//         x: newShape.x,
//         y: newShape.y,
//         width: newShape.width,
//         height: newShape.height
//       };
//     } else if (newShape.type === 'line') {
//       const points = newShape.points;
//       const minX = Math.min(points[0], points[2]);
//       const maxX = Math.max(points[0], points[2]);
//       const minY = Math.min(points[1], points[3]);
//       const maxY = Math.max(points[1], points[3]);
      
//       newBounds = {
//         x: minX,
//         y: minY,
//         width: maxX - minX,
//         height: maxY - minY
//       };
//     } else {
//       // For rectangles and other shapes with x, y, width, height
//       newBounds = {
//         x: newShape.x,
//         y: newShape.y,
//         width: newShape.width,
//         height: newShape.height
//       };
      
//       // Apply rotation if needed
//       if (newShape.rotation === 90) {
//         // For 90-degree rotated shapes, swap width and height
//         newBounds = {
//           x: newShape.x,
//           y: newShape.y,
//           width: newShape.height,
//           height: newShape.width
//         };
//       }
//     }
    
//     // Check collision with each existing shape
//     for (const shape of shapesToCheck) {
//       let shapeBounds;
      
//       if (shape.type === 'circle') {
//         shapeBounds = {
//           x: shape.x - shape.radius,
//           y: shape.y - shape.radius,
//           width: shape.radius * 2,
//           height: shape.radius * 2
//         };
//       } else if (shape.type === 'pillar') {
//         shapeBounds = {
//           x: shape.x,
//           y: shape.y,
//           width: shape.width,
//           height: shape.height
//         };
//       } else if (shape.type === 'line') {
//         const points = shape.points;
//         const minX = Math.min(points[0], points[2]);
//         const maxX = Math.max(points[0], points[2]);
//         const minY = Math.min(points[1], points[3]);
//         const maxY = Math.max(points[1], points[3]);
        
//         shapeBounds = {
//           x: minX,
//           y: minY,
//           width: maxX - minX,
//           height: maxY - minY
//         };
//       } else {
//         // For rectangles and other shapes with x, y, width, height
//         shapeBounds = {
//           x: shape.x,
//           y: shape.y,
//           width: shape.width,
//           height: shape.height
//         };
        
//         // Apply rotation if needed
//         if (shape.rotation === 90) {
//           // For 90-degree rotated shapes, swap width and height
//           shapeBounds = {
//             x: shape.x,
//             y: shape.y,
//             width: shape.height,
//             height: shape.width
//           };
//         }
//       }
      
//       // Check for rectangle intersection
//       if (
//         newBounds.x < shapeBounds.x + shapeBounds.width &&
//         newBounds.x + newBounds.width > shapeBounds.x &&
//         newBounds.y < shapeBounds.y + shapeBounds.height &&
//         newBounds.y + newBounds.height > shapeBounds.y
//       ) {
//         // Collision detected
//         return true;
//       }
//     }
    
//     // No collision
//     return false;
//   };

//   // Handle window resize
//   useEffect(() => {
//     const handleResize = () => {
//       setStageSize({
//         width: window.innerWidth - 500, // Adjusted for both sidebars
//         height: window.innerHeight - 50 // Adjust for top bar height
//       });
//     };

//     handleResize(); // Call once to set initial size
//     window.addEventListener('resize', handleResize);
//     return () => window.removeEventListener('resize', handleResize);
//   }, []);

//   // Handle wheel events for zooming
//   useEffect(() => {
//     const container = containerRef.current;
    
//     const handleWheel = (e) => {
//       e.preventDefault();
      
//       const stage = stageRef.current;
//       if (!stage) return;
      
//       const oldScale = stage.scaleX();
      
//       // Calculate new scale
//       const pointer = stage.getPointerPosition();
      
//       // Get pointer position relative to stage
//       const mousePointTo = {
//         x: (pointer.x - stage.x()) / oldScale,
//         y: (pointer.y - stage.y()) / oldScale
//       };
      
//       // Calculate new scale with wheel delta
//       const newScale = e.deltaY < 0 ? oldScale * 1.1 : oldScale / 1.1;
      
//       // Limit zoom level
//       const limitedScale = Math.min(Math.max(newScale, 0.2), 5);
      
//       // Set new position to keep the point under mouse in the same position
//       const newPos = {
//         x: pointer.x - mousePointTo.x * limitedScale,
//         y: pointer.y - mousePointTo.y * limitedScale
//       };
      
//       // Update stage scale and position
//       stage.scale({ x: limitedScale, y: limitedScale });
//       stage.position(newPos);
//       stage.batchDraw();
//     };
    
//     if (container) {
//       container.addEventListener('wheel', handleWheel, { passive: false });
//     }
    
//     return () => {
//       if (container) {
//         container.removeEventListener('wheel', handleWheel);
//       }
//     };
//   }, []);

//   // Update stage scale when zoomLevel changes
//   useEffect(() => {
//     const stage = stageRef.current;
//     if (stage) {
//       // Get current center of viewport
//       const centerX = stageSize.width / 2;
//       const centerY = stageSize.height / 2;
      
//       // Get current center point in the world coordinates
//       const oldScale = stage.scaleX();
//       const pointTo = {
//         x: (centerX - stage.x()) / oldScale,
//         y: (centerY - stage.y()) / oldScale
//       };
      
//       // Set new position to keep the center point in the same position
//       const newPos = {
//         x: centerX - pointTo.x * zoomLevel,
//         y: centerY - pointTo.y * zoomLevel
//       };
      
//       // Update stage scale and position
//       stage.scale({ x: zoomLevel, y: zoomLevel });
//       stage.position(newPos);
//       stage.batchDraw();
      
//       // Update state
//       setStagePosition(newPos);
//     }
//   }, [zoomLevel, stageSize]);

//   // Handle drag over for drag and drop
//   useEffect(() => {
//     const container = containerRef.current;
    
//     const handleDragOver = (e) => {
//       e.preventDefault();
//       const stage = stageRef.current;
//       if (stage) {
//         const pos = stage.getPointerPosition();
//         if (pos) {
//           setMousePosition(pos);
//         }
//       }
//     };
    
//     const handleDrop = (e) => {
//       e.preventDefault();
//       const data = e.dataTransfer.getData('application/json');
//       if (data) {
//         try {
//           const element = JSON.parse(data);
//           const stage = stageRef.current;
//           if (stage) {
//             const pos = stage.getPointerPosition();
//             if (pos) {
//               console.log('Drop position:', pos);
              
//               // Convert position from screen coordinates to world coordinates
//               const worldPos = {
//                 x: (pos.x - stage.x()) / stage.scaleX(),
//                 y: (pos.y - stage.y()) / stage.scaleY()
//               };
              
//               // Check if we need to snap to a wall
//               if (element.type === 'door' || element.type === 'window' || element.type === 'sliding-door') {
//                 const snappedPos = findWallToSnapTo(worldPos, element);
//                 console.log('Snapped position:', snappedPos);
                
//                 // Create the new element
//                 const newElement = {
//                   ...element,
//                   ...snappedPos.elementProps,
//                   id: Date.now(),
//                   x: snappedPos.position.x,
//                   y: snappedPos.position.y
//                 };
                
//                 // Check for collisions if it's a rack
//                 if (element.type === 'rack' && checkCollision(newElement, shapes)) {
//                   // Show collision warning
//                   alert("Cannot place rack here - it overlaps with another element.");
//                   return;
//                 }
                
//                 onElementDrop({...element, ...snappedPos.elementProps}, snappedPos.position);
//               } else {
//                 // For other elements, center them at the drop position
//                 const dropPosition = {
//                   x: worldPos.x - element.width / 2,
//                   y: worldPos.y - element.height / 2
//                 };
//                 console.log('Centered drop position:', dropPosition);
                
//                 // Create the new element
//                 const newElement = {
//                   ...element,
//                   id: Date.now(),
//                   x: dropPosition.x,
//                   y: dropPosition.y
//                 };
                
//                 // Check for collisions if it's a rack
//                 if (element.type === 'rack' && checkCollision(newElement, shapes)) {
//                   // Show collision warning
//                   alert("Cannot place rack here - it overlaps with another element.");
//                   return;
//                 }
                
//                 onElementDrop(element, dropPosition);
//               }
//             }
//           }
//         } catch (error) {
//           console.error('Error parsing dropped element:', error);
//         }
//       }
//     };
    
//     if (container) {
//       container.addEventListener('dragover', handleDragOver);
//       container.addEventListener('drop', handleDrop);
//     }
    
//     return () => {
//       if (container) {
//         container.removeEventListener('dragover', handleDragOver);
//         container.removeEventListener('drop', handleDrop);
//       }
//     };
//   }, [onElementDrop, shapes]);

//   // Add keyboard shortcut support for duplication
//   useEffect(() => {
//     const handleKeyDown = (e) => {
//       if (!selectedShape || selectedTool) return;
      
//       // Duplicate with arrow keys when holding Ctrl or Cmd
//       if ((e.ctrlKey || e.metaKey) && selectedShape) {
//         let offsetX = 0;
//         let offsetY = 0;
//         const offsetAmount = 100; // Fixed offset amount
        
//         switch (e.key) {
//           case 'ArrowUp':
//             e.preventDefault();
//             offsetY = -offsetAmount;
//             handleDuplicate(selectedShape, offsetX, offsetY);
//             break;
//           case 'ArrowRight':
//             e.preventDefault();
//             offsetX = offsetAmount;
//             handleDuplicate(selectedShape, offsetX, offsetY);
//             break;
//           case 'ArrowDown':
//             e.preventDefault();
//             offsetY = offsetAmount;
//             handleDuplicate(selectedShape, offsetX, offsetY);
//             break;
//           case 'ArrowLeft':
//             e.preventDefault();
//             offsetX = -offsetAmount;
//             handleDuplicate(selectedShape, offsetX, offsetY);
//             break;
//           default:
//             break;
//         }
//       }
//     };
    
//     window.addEventListener('keydown', handleKeyDown);
    
//     return () => {
//       window.removeEventListener('keydown', handleKeyDown);
//     };
//   }, [selectedShape, selectedTool]);

//   // Helper function to format dimension text with appropriate units
//   const formatDimension = (pixels) => {
//     // Convert pixels to meters
//     const meters = pixels * scale;
    
//     // Get the current unit configuration
//     const currentUnit = units[unit] || units.meters;
    
//     // Convert meters to the current unit
//     const value = meters / currentUnit.toMeters;
    
//     // Format based on unit and value
//     if (currentUnit.smallerUnit && value < currentUnit.smallerUnit.threshold) {
//       // Use smaller unit for small values
//       const smallerValue = value * currentUnit.smallerUnit.divisor;
//       return `${smallerValue.toFixed(1)} ${currentUnit.smallerUnit.abbr}`;
//     } else {
//       // Use regular unit
//       return `${value.toFixed(2)} ${currentUnit.abbr}`;
//     }
//   };

//   // Function to handle duplication
//   // const handleDuplicate = (shape, offsetX, offsetY) => {
//   //   if (!shape) return;
    
//   //   // Create a duplicate with offset
//   //   const duplicatedShape = {
//   //     ...shape,
//   //     id: Date.now(),
//   //     x: shape.x + offsetX,
//   //     y: shape.y + offsetY
//   //   };
    
//   //   // Check for collisions if it's a rack
//   //   if (shape.type === 'rack' && checkCollision(duplicatedShape, shapes)) {
//   //     // Show collision warning
//   //     alert("Cannot duplicate rack here - it would overlap with another element.");
//   //     return;
//   //   }
    
//   //   // Add the new shape
//   //   onAddShape([...shapes, duplicatedShape]);
    
//   //   // Select the new shape
//   //   onShapeSelect(duplicatedShape);
//   // };


//   // Function to handle duplication with enhanced multi-copy support
//   const handleDuplicate = (duplicates) => {
//     // If it's a single duplicate (for backward compatibility)
//     if (!Array.isArray(duplicates)) {
//       const shape = duplicates;
//       const offsetX = arguments[1] || 0;
//       const offsetY = arguments[2] || 0;
      
//       // Create a duplicate with offset
//       const duplicatedShape = {
//         ...shape,
//         id: Date.now(),
//         x: shape.x + offsetX,
//         y: shape.y + offsetY
//       };
      
//       // Check for collisions if it's a rack
//       if (shape.type === 'rack' && checkCollision(duplicatedShape, shapes)) {
//         // Show collision warning
//         alert("Cannot duplicate rack here - it overlaps with another element.");
//         return;
//       }
      
//       // Add the new shape
//       onAddShape([...shapes, duplicatedShape]);
      
//       // Select the new shape
//       onShapeSelect(duplicatedShape);
//       return;
//     }
    
//     // Handle multiple duplicates
//     const newShapes = [...shapes];
//     let lastShape = null;
//     let hasCollision = false;
    
//     // Process each duplicate
//     duplicates.forEach(({ shape, offsetX, offsetY }) => {
//       const duplicatedShape = {
//         ...shape,
//         id: Date.now() + Math.random(), // Ensure unique ID
//         x: shape.x + offsetX,
//         y: shape.y + offsetY
//       };
      
//       // Check for collisions if it's a rack
//       if (shape.type === 'rack' && checkCollision(duplicatedShape, [...shapes, ...newShapes.filter(s => s.id !== shape.id)])) {
//         hasCollision = true;
//         return;
//       }
      
//       newShapes.push(duplicatedShape);
//       lastShape = duplicatedShape;
//     });
    
//     if (hasCollision) {
//       alert("Some duplicates couldn't be placed due to overlaps.");
//     }
    
//     if (newShapes.length > shapes.length) {
//       // Add the new shapes
//       onAddShape(newShapes);
      
//       // Select the last shape created
//       if (lastShape) {
//         onShapeSelect(lastShape);
//       }
//     }
//   };

//   // Function to find the closest wall to snap to
//   const findWallToSnapTo = (position, element) => {
//     const snapThreshold = 20 / zoomLevel; // Adjust threshold based on zoom level
//     let closestWall = null;
//     let minDistance = snapThreshold;
//     let orientation = null;
//     let snapPosition = { x: position.x, y: position.y };
//     let elementProps = {};
    
//     // Look through all shapes to find walls (lines or rectangles)
//     shapes.forEach(shape => {
//       if (shape.type === 'line') {
//         // For line walls
//         const points = shape.points;
//         const x1 = points[0];
//         const y1 = points[1];
//         const x2 = points[2];
//         const y2 = points[3];
        
//         // Calculate distance from point to line segment
//         const distance = distanceToLineSegment(position.x, position.y, x1, y1, x2, y2);
        
//         if (distance < minDistance) {
//           minDistance = distance;
//           closestWall = shape;
          
//           // Determine if the line is more horizontal or vertical
//           const dx = Math.abs(x2 - x1);
//           const dy = Math.abs(y2 - y1);
          
//           if (dx > dy) {
//             // Horizontal wall
//             orientation = 'horizontal';
//             snapPosition = {
//               x: position.x,
//               y: (y1 + y2) / 2
//             };
            
//             // Adjust element properties for horizontal alignment
//             elementProps = {
//               rotation: 0,
//               width: element.width,
//               height: element.height
//             };
//           } else {
//             // Vertical wall
//             orientation = 'vertical';
//             snapPosition = {
//               x: (x1 + x2) / 2,
//               y: position.y
//             };
            
//             // Adjust element properties for vertical alignment
//             elementProps = {
//               rotation: 90,
//               width: element.height, // Swap dimensions for vertical orientation
//               height: element.width
//             };
//           }
//         }
//       } else if (shape.type === 'rectangle' || shape.type === 'wall') {
//         // For rectangle walls
//         const { x, y, width, height } = shape;
        
//         // Check each edge of the rectangle
//         // Top edge
//         const topDistance = Math.abs(position.y - y);
//         if (position.x >= x && position.x <= x + width && topDistance < minDistance) {
//           minDistance = topDistance;
//           closestWall = shape;
//           orientation = 'horizontal';
//           snapPosition = { x: position.x, y };
//           elementProps = {
//             rotation: 0,
//             width: element.width,
//             height: element.height
//           };
//         }
        
//         // Bottom edge
//         const bottomDistance = Math.abs(position.y - (y + height));
//         if (position.x >= x && position.x <= x + width && bottomDistance < minDistance) {
//           minDistance = bottomDistance;
//           closestWall = shape;
//           orientation = 'horizontal';
//           snapPosition = { x: position.x, y: y + height };
//           elementProps = {
//             rotation: 0,
//             width: element.width,
//             height: element.height
//           };
//         }
        
//         // Left edge
//         const leftDistance = Math.abs(position.x - x);
//         if (position.y >= y && position.y <= y + height && leftDistance < minDistance) {
//           minDistance = leftDistance;
//           closestWall = shape;
//           orientation = 'vertical';
//           snapPosition = { x, y: position.y };
//           elementProps = {
//             rotation: 90,
//             width: element.height, // Swap dimensions for vertical orientation
//             height: element.width
//           };
//         }
        
//         // Right edge
//         const rightDistance = Math.abs(position.x - (x + width));
//         if (position.y >= y && position.y <= y + height && rightDistance < minDistance) {
//           minDistance = rightDistance;
//           closestWall = shape;
//           orientation = 'vertical';
//           snapPosition = { x: x + width, y: position.y };
//           elementProps = {
//             rotation: 90,
//             width: element.height, // Swap dimensions for vertical orientation
//             height: element.width
//           };
//         }
//       }
//     });
    
//     // If we found a wall to snap to, adjust the position
//     if (closestWall) {
//       if (orientation === 'horizontal') {
//         // For horizontal walls, center horizontally and align to the wall vertically
//         snapPosition = {
//           x: snapPosition.x - (element.width / 2),
//           y: snapPosition.y - (element.height / 2)
//         };
//       } else {
//         // For vertical walls, we need special handling
//         // The element will be rotated 90 degrees, so width and height are swapped
//         // We need to center it on the wall
//         snapPosition = {
//           x: snapPosition.x - (element.height / 2), // Use height because it becomes width after rotation
//           y: snapPosition.y - (element.width / 2)   // Use width because it becomes height after rotation
//         };
//       }
      
//       return {
//         position: snapPosition,
//         elementProps
//       };
//     }
    
//     // No wall to snap to, return original position
//     return {
//       position: {
//         x: position.x - element.width / 2,
//         y: position.y - element.height / 2
//       },
//       elementProps: {}
//     };
//   };

//   // Helper function to calculate distance from point to line segment
//   const distanceToLineSegment = (px, py, x1, y1, x2, y2) => {
//     const A = px - x1;
//     const B = py - y1;
//     const C = x2 - x1;
//     const D = y2 - y1;
    
//     const dot = A * C + B * D;
//     const lenSq = C * C + D * D;
//     let param = -1;
    
//     if (lenSq !== 0) {
//       param = dot / lenSq;
//     }
    
//     let xx, yy;
    
//     if (param < 0) {
//       xx = x1;
//       yy = y1;
//     } else if (param > 1) {
//       xx = x2;
//       yy = y2;
//     } else {
//       xx = x1 + param * C;
//       yy = y1 + param * D;
//     }
    
//     const dx = px - xx;
//     const dy = py - yy;
    
//     return Math.sqrt(dx * dx + dy * dy);
//   };

//   // Function to render dimensions for a shape
//   const renderDimensions = (shape) => {
//     if (!showDimensions) return null;

//     switch (shape.type) {
//       case 'line': {
//         const points = shape.points;
//         const x1 = points[0];
//         const y1 = points[1];
//         const x2 = points[2];
//         const y2 = points[3];
        
//         // Calculate length of line
//         const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
//         const dimensionText = formatDimension(length);
        
//         // Calculate midpoint and angle for text placement
//         const midX = (x1 + x2) / 2;
//         const midY = (y1 + y2) / 2;
//         const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        
//         // Offset the text perpendicular to the line
//         const offset = 15 / zoomLevel; // Adjust offset based on zoom level
//         const perpAngle = (angle + 90) * Math.PI / 180;
//         const offsetX = Math.cos(perpAngle) * offset;
//         const offsetY = Math.sin(perpAngle) * offset;
        
//         return (
//           <Group key={`dim-${shape.id}`}>
//             <Line
//               points={[x1, y1, midX + offsetX, midY + offsetY, x2, y2]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel} // Adjust stroke width based on zoom level
//               dash={[3 / zoomLevel, 3 / zoomLevel]} // Adjust dash based on zoom level
//             />
//             <Text
//               x={midX + offsetX}
//               y={midY + offsetY}
//               text={dimensionText}
//               fontSize={12 / zoomLevel} // Adjust font size based on zoom level
//               fill="#555"
//               align="center"
//               verticalAlign="middle"
//               rotation={angle > 90 || angle < -90 ? angle + 180 : angle}
//               offsetX={0}
//               offsetY={0}
//             />
//           </Group>
//         );
//       }
//       case 'rectangle':
//       case 'wall':
//       case 'door':
//       case 'window':
//       case 'sliding-door':
//       case 'bed':
//       case 'sofa':
//       case 'table':
//       case 'chair':
//       case 'rack': {
//         const { x, y, width, height, rotation = 0 } = shape;
//         const widthText = formatDimension(Math.abs(width));
//         const heightText = formatDimension(Math.abs(height));
        
//         // Create dimension lines and labels
//         return (
//           <Group key={`dim-${shape.id}`} rotation={rotation} x={x} y={y}>
//             {/* Width dimension */}
//             <Line
//               points={[0, -10 / zoomLevel, width, -10 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//               dash={[3 / zoomLevel, 3 / zoomLevel]}
//             />
//             <Line
//               points={[0, -15 / zoomLevel, 0, -5 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Line
//               points={[width, -15 / zoomLevel, width, -5 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Text
//               x={width / 2}
//               y={-20 / zoomLevel}
//               text={widthText}
//               fontSize={12 / zoomLevel}
//               fill="#555"
//               align="center"
//             />
            
//             {/* Height dimension */}
//             <Line
//               points={[width + 10 / zoomLevel, 0, width + 10 / zoomLevel, height]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//               dash={[3 / zoomLevel, 3 / zoomLevel]}
//             />
//             <Line
//               points={[width + 5 / zoomLevel, 0, width + 15 / zoomLevel, 0]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Line
//               points={[width + 5 / zoomLevel, height, width + 15 / zoomLevel, height]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Text
//               x={width + 20 / zoomLevel}
//               y={height / 2}
//               text={heightText}
//               fontSize={12 / zoomLevel}
//               fill="#555"
//               align="left"
//               verticalAlign="middle"
//             />
//           </Group>
//         );
//       }
//       case 'circle':
//       case 'pillar': {
//         let x, y, radius;
        
//         if (shape.type === 'circle') {
//           x = shape.x;
//           y = shape.y;
//           radius = shape.radius;
//         } else { // pillar
//           x = shape.x + shape.width / 2;
//           y = shape.y + shape.height / 2;
//           radius = shape.width / 2;
//         }
        
//         const diameterText = formatDimension(radius * 2);
        
//         return (
//           <Group key={`dim-${shape.id}`}>
//             <Line
//               points={[x, y - radius - 10 / zoomLevel, x, y + radius + 10 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//               dash={[3 / zoomLevel, 3 / zoomLevel]}
//             />
//             <Line
//               points={[x - 5 / zoomLevel, y - radius - 10 / zoomLevel, x + 5 / zoomLevel, y - radius - 10 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Line
//               points={[x - 5 / zoomLevel, y + radius + 10 / zoomLevel, x + 5 / zoomLevel, y + radius + 10 / zoomLevel]}
//               stroke="#555"
//               strokeWidth={1 / zoomLevel}
//             />
//             <Text
//               x={x + 10 / zoomLevel}
//               y={y}
//               text={diameterText}
//               fontSize={12 / zoomLevel}
//               fill="#555"
//               verticalAlign="middle"
//             />
//           </Group>
//         );
//       }
//       default:
//         return null;
//     }
//   };

//   const handleMouseDown = (e) => {
//     const stage = e.target.getStage();
    
//     // If clicking on the stage background with a tool selected, start drawing
//     if (e.target === stage && selectedTool) {
//       const pos = stage.getPointerPosition();
      
//       // Convert position from screen coordinates to world coordinates
//       const worldPos = {
//         x: (pos.x - stage.x()) / stage.scaleX(),
//         y: (pos.y - stage.y()) / stage.scaleY()
//       };
      
//       setIsDrawing(true);
//       setStartPoint(worldPos);

//       if (selectedTool === 'pencil') {
//         setPoints([worldPos.x, worldPos.y]);
//       } else if (selectedTool === 'text') {
//         // Handle text input
//         const textInput = document.createElement('input');
//         const stageBox = stage.container().getBoundingClientRect();
        
//         textInput.style.position = 'absolute';
//         textInput.style.left = `${stageBox.left + pos.x}px`;
//         textInput.style.top = `${stageBox.top + pos.y}px`;
//         textInput.style.zIndex = 1000;
        
//         document.body.appendChild(textInput);
//         textInput.focus();
        
//         textInput.addEventListener('keydown', (e) => {
//           if (e.key === 'Enter') {
//             const newTextShape = {
//               type: 'text',
//               x: worldPos.x,
//               y: worldPos.y,
//               text: textInput.value,
//               fontSize: 16,
//               fill: '#000',
//               id: Date.now(),
//             };
//             onAddShape([...shapes, newTextShape]);
//             document.body.removeChild(textInput);
//           }
//         });
        
//         textInput.addEventListener('blur', () => {
//           document.body.removeChild(textInput);
//         });
//       } else {
//         // Initialize shape based on tool
//         let newShape;
//         switch (selectedTool) {
//           case 'line':
//             newShape = {
//               type: 'line',
//               points: [worldPos.x, worldPos.y, worldPos.x, worldPos.y],
//               stroke: '#000',
//               strokeWidth: 2,
//               id: Date.now(),
//             };
//             break;
//           case 'rectangle':
//             newShape = {
//               type: 'rectangle',
//               x: worldPos.x,
//               y: worldPos.y,
//               width: 0,
//               height: 0,
//               stroke: '#000',
//               fill: 'transparent',
//               strokeWidth: 2,
//               id: Date.now(),
//             };
//             break;
//           case 'circle':
//             newShape = {
//               type: 'circle',
//               x: worldPos.x,
//               y: worldPos.y,
//               radius: 0,
//               stroke: '#000',
//               fill: 'transparent',
//               strokeWidth: 2,
//               id: Date.now(),
//             };
//             break;
//           default:
//             break;
//         }
        
//         if (newShape) {
//           setCurrentShape(newShape);
//         }
//       }
//     } 
//     // If clicking on the stage background with no tool selected, deselect any selected shape
//     else if (e.target === stage && !selectedTool) {
//       onShapeSelect(null);
//     }
//     // If clicking on a shape, let the shape's click handler handle it
//   };

//   const handleMouseMove = (e) => {
//     const stage = e.target.getStage();
//     const pos = stage.getPointerPosition();
    
//     // Convert position from screen coordinates to world coordinates
//     const worldPos = {
//       x: (pos.x - stage.x()) / stage.scaleX(),
//       y: (pos.y - stage.y()) / stage.scaleY()
//     };
    
//     setMousePosition(worldPos);
    
//     if (!isDrawing) return;

//     if (selectedTool === 'pencil') {
//       setPoints([...points, worldPos.x, worldPos.y]);
//     } else if (currentShape) {
//       // Update shape based on mouse movement
//       let updatedShape = { ...currentShape };
      
//       switch (selectedTool) {
//         case 'line':
//           updatedShape.points = [startPoint.x, startPoint.y, worldPos.x, worldPos.y];
//           break;
//         case 'rectangle':
//           updatedShape.width = worldPos.x - startPoint.x;
//           updatedShape.height = worldPos.y - startPoint.y;
//           break;
//         case 'circle':
//           const dx = worldPos.x - startPoint.x;
//           const dy = worldPos.y - startPoint.y;
//           updatedShape.radius = Math.sqrt(dx * dx + dy * dy);
//           break;
//         default:
//           break;
//       }
      
//       setCurrentShape(updatedShape);
//     }
//   };

//   const handleMouseUp = () => {
//     if (!isDrawing) return;
//     setIsDrawing(false);

//     if (selectedTool === 'pencil' && points.length > 2) {
//       const newShape = {
//         type: 'pencil',
//         points: points,
//         stroke: '#000',
//         strokeWidth: 2,
//         id: Date.now(),
//       };
//       onAddShape([...shapes, newShape]);
//       setPoints([]);
//     } else if (currentShape) {
//       onAddShape([...shapes, currentShape]);
//       setCurrentShape(null);
//     }
//   };

//   const handleDragEnd = (e, shape) => {
//     // Get the new position
//     const newX = e.target.x();
//     const newY = e.target.y();
    
//     // Create a temporary shape with the new position to check for collisions
//     const movedShape = {
//       ...shape,
//       x: newX,
//       y: newY
//     };
    
//     // Check for collisions if it's a rack
//     if (shape.type === 'rack' && checkCollision(movedShape, shapes)) {
//       // Revert to original position
//       e.target.position({
//         x: shape.x,
//         y: shape.y
//       });
      
//       // Show collision warning
//       alert("Cannot move rack here - it overlaps with another element.");
//       return;
//     }
    
//     // Check if this is a door or window that needs to snap to a wall
//     if (shape.type === 'door' || shape.type === 'window' || shape.type === 'sliding-door') {
//       // Calculate center position based on current rotation
//       let centerPos;
      
//       // If already rotated, use the rotated dimensions for center calculation
//       if (shape.rotation === 90) {
//         centerPos = {
//           x: newX + shape.height / 2, // Height becomes width when rotated 90°
//           y: newY + shape.width / 2   // Width becomes height when rotated 90°
//         };
//       } else {
//         centerPos = {
//           x: newX + shape.width / 2,
//           y: newY + shape.height / 2
//         };
//       }
      
//       // Get original element properties (before any rotation)
//       const originalElement = {
//         width: shape.rotation === 90 ? shape.height : shape.width,
//         height: shape.rotation === 90 ? shape.width : shape.height
//       };
      
//       const snappedPos = findWallToSnapTo(centerPos, originalElement);
      
//       // Create a temporary shape with the snapped position to check for collisions
//       const snappedShape = {
//         ...shape,
//         ...snappedPos.elementProps,
//         x: snappedPos.position.x,
//         y: snappedPos.position.y
//       };
      
//       // Check for collisions if it's a rack
//       if (shape.type === 'rack' && checkCollision(snappedShape, shapes)) {
//         // Revert to original position
//         e.target.position({
//           x: shape.x,
//           y: shape.y
//         });
        
//         // Show collision warning
//         alert("Cannot move rack here - it overlaps with another element.");
//         return;
//       }
      
//       // Update the shape with the snapped position and properties
//       const updatedShapes = shapes.map(s => {
//         if (s.id === shape.id) {
//           return {
//             ...s,
//             ...snappedPos.elementProps,
//             x: snappedPos.position.x,
//             y: snappedPos.position.y
//           };
//         }
//         return s;
//       });
      
//       onAddShape(updatedShapes);
      
//       // Update selected shape if this is the currently selected one
//       if (selectedShape && selectedShape.id === shape.id) {
//         const updatedShape = updatedShapes.find(s => s.id === shape.id);
//         onShapeSelect(updatedShape);
//       }
//     } else {
//       // For other shapes, just update the position
//       const updatedShapes = shapes.map(s => {
//         if (s.id === shape.id) {
//           return {
//             ...s,
//             x: newX,
//             y: newY
//           };
//         }
//         return s;
//       });
      
//       onAddShape(updatedShapes);
      
//       // Update selected shape if this is the currently selected one
//       if (selectedShape && selectedShape.id === shape.id) {
//         const updatedShape = updatedShapes.find(s => s.id === shape.id);
//         onShapeSelect(updatedShape);
//       }
//     }
//   };

//   const renderShape = (shape) => {
//     // Determine if this shape is selected
//     const isSelected = selectedShape && selectedShape.id === shape.id;
    
//     // Common props for all shapes
//     const commonProps = {
//       onClick: (e) => {
//         // Only handle selection if no drawing tool is active
//         if (!selectedTool) {
//           e.cancelBubble = true; // Stop event propagation
//           onShapeSelect(shape);
//         }
//       },
//       onTap: (e) => {
//         // Only handle selection if no drawing tool is active
//         if (!selectedTool) {
//           e.cancelBubble = true; // Stop event propagation
//           onShapeSelect(shape);
//         }
//       },
//     };
    
//     // Make shapes draggable only when no drawing tool is selected
//     const isDraggable = !selectedTool && !isDrawing;
    
//     switch (shape.type) {
//       case 'line':
//         return (
//           <Line
//             key={shape.id}
//             points={shape.points}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'rectangle':
//         return (
//           <Rect
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'circle':
//         return (
//           <Circle
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             radius={shape.radius}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'pencil':
//         return (
//           <Line
//             key={shape.id}
//             points={shape.points}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             tension={0.5}
//             lineCap="round"
//             lineJoin="round"
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'text':
//         return (
//           <Text
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             text={shape.text}
//             fontSize={shape.fontSize}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : ''}
//             strokeWidth={isSelected ? 1 : 0}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'door':
//       case 'window':
//       case 'sliding-door':
//         return (
//           <Rect
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             dash={shape.dash}
//             rotation={shape.rotation || 0}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'wall':
//         return (
//           <Rect
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       case 'pillar':
//         return (
//           <Circle
//             key={shape.id}
//             x={shape.x + shape.width / 2}
//             y={shape.y + shape.height / 2}
//             radius={shape.width / 2}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => {
//               // Update position when dragged
//               const updatedShapes = shapes.map(s => {
//                 if (s.id === shape.id) {
//                   return {
//                     ...s,
//                     x: e.target.x() - shape.width / 2,
//                     y: e.target.y() - shape.height / 2
//                   };
//                 }
//                 return s;
//               });
//               onAddShape(updatedShapes);
              
//               // Update selected shape if this is the currently selected one
//               if (selectedShape && selectedShape.id === shape.id) {
//                 const updatedShape = updatedShapes.find(s => s.id === shape.id);
//                 onShapeSelect(updatedShape);
//               }
//             }}
//             {...commonProps}
//           />
//         );
//       case 'bed':
//       case 'sofa':
//       case 'table':
//       case 'chair':
//       case 'rack':
//         return (
//           <Rect
//             key={shape.id}
//             x={shape.x}
//             y={shape.y}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={isSelected ? '#3498db' : shape.stroke}
//             strokeWidth={isSelected ? (shape.strokeWidth || 1) + 2 : shape.strokeWidth}
//             draggable={isDraggable}
//             onDragEnd={(e) => handleDragEnd(e, shape)}
//             {...commonProps}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // Create grid lines
//   const gridSize = 20;
//   const gridLines = [];
  
//   // Calculate grid bounds based on zoom and position
//   const gridBounds = {
//     startX: -stagePosition.x / zoomLevel,
//     startY: -stagePosition.y / zoomLevel,
//     endX: (stageSize.width - stagePosition.x) / zoomLevel,
//     endY: (stageSize.height - stagePosition.y) / zoomLevel
//   };
  
//   // Round to nearest grid size to avoid too many lines
//   const startX = Math.floor(gridBounds.startX / gridSize) * gridSize;
//   const startY = Math.floor(gridBounds.startY / gridSize) * gridSize;
//   const endX = Math.ceil(gridBounds.endX / gridSize) * gridSize;
//   const endY = Math.ceil(gridBounds.endY / gridSize) * gridSize;
  
//   // Vertical lines
//   for (let i = startX; i <= endX; i += gridSize) {
//     gridLines.push(
//       <Line
//         key={`v-${i}`}
//         points={[i, startY, i, endY]}
//         stroke="#ddd"
//         strokeWidth={1 / zoomLevel}
//       />
//     );
//   }
  
//   // Horizontal lines
//   for (let i = startY; i <= endY; i += gridSize) {
//     gridLines.push(
//       <Line
//         key={`h-${i}`}
//         points={[startX, i, endX, i]}
//         stroke="#ddd"
//         strokeWidth={1 / zoomLevel}
//       />
//     );
//   }

//   // Calculate scale bar dimensions for the current unit
//   const calculateScaleBarWidth = () => {
//     const currentUnit = units[unit] || units.meters;
//     const pixelsPerMeter = 1 / scale;
//     const pixelsPerUnit = pixelsPerMeter * currentUnit.toMeters;
    
//     // Determine a nice round number for the scale bar
//     let unitValue;
//     if (pixelsPerUnit > 200) {
//       unitValue = 0.1; // Show 0.1 unit if 1 unit is too large
//     } else if (pixelsPerUnit > 100) {
//       unitValue = 0.2; // Show 0.2 unit
//     } else if (pixelsPerUnit > 50) {
//       unitValue = 0.5; // Show 0.5 unit
//     } else {
//       unitValue = 1; // Show 1 unit
//     }
    
//     return {
//       width: pixelsPerUnit * unitValue / zoomLevel,
//       label: `${unitValue} ${currentUnit.abbr}`
//     };
//   };

//   const scaleBar = calculateScaleBarWidth();

//   // Render element preview when dragging
//   const renderDragElementPreview = () => {
//     if (!isDraggingElement || !dragElement || !mousePosition) return null;
    
//     // Get the stage for coordinate conversion
//     const stage = stageRef.current;
//     if (!stage) return null;
    
//     // Simple preview that follows the mouse cursor directly
//     switch (dragElement.type) {
//       case 'door':
//       case 'window':
//       case 'sliding-door':
//         // For doors and windows, check if we need to snap to a wall
//         const snappedPos = findWallToSnapTo(mousePosition, dragElement);
        
//         // Check for collisions if it's a rack
//         if (dragElement.type === 'rack') {
//           const previewShape = {
//             ...dragElement,
//             ...snappedPos.elementProps,
//             x: snappedPos.position.x,
//             y: snappedPos.position.y,
//             id: 'preview'
//           };
          
//           const hasCollision = checkCollision(previewShape, shapes);
          
//           return (
//             <Rect
//               x={snappedPos.position.x}
//               y={snappedPos.position.y}
//               width={snappedPos.elementProps.width || dragElement.width}
//               height={snappedPos.elementProps.height || dragElement.height}
//               fill={hasCollision ? 'rgba(255,0,0,0.4)' : dragElement.fill}
//               stroke={hasCollision ? '#ff0000' : dragElement.stroke}
//               strokeWidth={dragElement.strokeWidth}
//               dash={dragElement.dash}
//               rotation={snappedPos.elementProps.rotation || 0}
//               opacity={0.6}
//             />
//           );
//         }
        
//         return (
//           <Rect
//             x={snappedPos.position.x}
//             y={snappedPos.position.y}
//             width={snappedPos.elementProps.width || dragElement.width}
//             height={snappedPos.elementProps.height || dragElement.height}
//             fill={dragElement.fill}
//             stroke={dragElement.stroke}
//             strokeWidth={dragElement.strokeWidth}
//             dash={dragElement.dash}
//             rotation={snappedPos.elementProps.rotation || 0}
//             opacity={0.6}
//           />
//         );
//       case 'wall':
//       case 'bed':
//       case 'sofa':
//       case 'table':
//       case 'chair':
//       case 'rack':
//         // Check for collisions if it's a rack
//         if (dragElement.type === 'rack') {
//           const previewShape = {
//             ...dragElement,
//             x: mousePosition.x - dragElement.width / 2,
//             y: mousePosition.y - dragElement.height / 2,
//             id: 'preview'
//           };
          
//           const hasCollision = checkCollision(previewShape, shapes);
          
//           return (
//             <Rect
//               x={mousePosition.x - dragElement.width / 2}
//               y={mousePosition.y - dragElement.height / 2}
//               width={dragElement.width}
//               height={dragElement.height}
//               fill={hasCollision ? 'rgba(255,0,0,0.4)' : dragElement.fill}
//               stroke={hasCollision ? '#ff0000' : dragElement.stroke}
//               strokeWidth={dragElement.strokeWidth}
//               opacity={0.6}
//             />
//           );
//         }
        
//         return (
//           <Rect
//             x={mousePosition.x - dragElement.width / 2}
//             y={mousePosition.y - dragElement.height / 2}
//             width={dragElement.width}
//             height={dragElement.height}
//             fill={dragElement.fill}
//             stroke={dragElement.stroke}
//             strokeWidth={dragElement.strokeWidth}
//             opacity={0.6}
//           />
//         );
//       case 'pillar':
//         return (
//           <Circle
//             x={mousePosition.x}
//             y={mousePosition.y}
//             radius={dragElement.width / 2}
//             fill={dragElement.fill}
//             stroke={dragElement.stroke}
//             strokeWidth={dragElement.strokeWidth}
//             opacity={0.6}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // Handle stage drag
//   const handleStageDragStart = () => {
//     // Only allow stage drag when no tool is selected
//     if (selectedTool) {
//       return false;
//     }
//     return true;
//   };

//   // Handle stage click for deselection
//   const handleStageClick = (e) => {
//     // Only deselect if clicking on the stage itself, not on a shape,
//     // and no drawing tool is active
//     if (e.target === e.target.getStage() && !selectedTool) {
//       onShapeSelect(null);
//     }
//   };

//   return (
//     <div 
//       className="canvas-container" 
//       ref={containerRef}
//     >
//       <Stage
//         width={stageSize.width}
//         height={stageSize.height}
//         onMouseDown={handleMouseDown}
//         onMouseMove={handleMouseMove}
//         onMouseUp={handleMouseUp}
//         onMouseLeave={handleMouseUp}
//         onClick={handleStageClick}
//         ref={stageRef}
//         draggable={!selectedTool}
//         onDragStart={handleStageDragStart}
//         onDragEnd={() => {
//           if (stageRef.current) {
//             setStagePosition(stageRef.current.position());
//           }
//         }}
//       >
//         <Layer>
//           {/* Grid Layer */}
//           {gridLines}
//         </Layer>
//         <Layer>
//           {/* Existing Shapes */}
//           {shapes.map(renderShape)}
          
//           {/* Duplicate Controls - only show for selected shape */}
//           {selectedShape && !selectedTool && (
//             <DuplicateControls 
//               shape={selectedShape} 
//               onDuplicate={handleDuplicate}
//               zoomLevel={zoomLevel}
//             />
//           )}
          
//           {/* Dimensions */}
//           {showDimensions && shapes.map(renderDimensions)}
          
//           {/* Currently Drawing Shape */}
//           {isDrawing && selectedTool === 'pencil' && (
//             <Line
//               points={points}
//               stroke="#000"
//               strokeWidth={2}
//               tension={0.5}
//               lineCap="round"
//               lineJoin="round"
//             />
//           )}
          
//           {currentShape && renderShape(currentShape)}
          
//           {/* Element being dragged */}
//           {renderDragElementPreview()}
//         </Layer>
//       </Stage>
      
//       {/* Scale indicator */}
//       <div className="scale-indicator" style={{ display: showDimensions ? 'flex' : 'none' }}>
//         <div className="scale-bar">
//           <div 
//             className="scale-segment" 
//             style={{ width: `${scaleBar.width}px` }}
//           ></div>
//         </div>
//         <div className="scale-label">{scaleBar.label}</div>
//       </div>
//     </div>
//   );
// };

// export default Canvas;


import React, { useState, useRef, useEffect } from 'react';
import { Stage, Layer, Line, Rect, Circle, Text, Group } from 'react-konva';
import DuplicateControls from './DuplicateControls';
import RadialMenu from './radialMenu';

// Add grid and snapping utilities
const gridSize = 20;
const snapAngle = 45;

function snapToGrid(value) {
  return Math.round(value / gridSize) * gridSize;
}

function snapToAngle(dx, dy) {
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);
  const snappedAngle = Math.round(angle / snapAngle) * snapAngle;
  const rad = snappedAngle * (Math.PI / 180);
  const length = Math.sqrt(dx * dx + dy * dy);
  return { dx: Math.cos(rad) * length, dy: Math.sin(rad) * length };
}

function distance(x1, y1, x2, y2) {
  return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
}


const Canvas = ({ 
  selectedTool, 
  shapes, 
  onAddShape, 
  isDraggingElement, 
  dragElement,
  dragOffset, 
  onElementDrop,
  showDimensions,
  scale,
  unit,
  zoomLevel,
  onShapeSelect,
  selectedShape,
  onDuplicateShape,
  showRadialMenu,
  setShowRadialMenu
}) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [points, setPoints] = useState([]);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [currentShape, setCurrentShape] = useState(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [dragPreviewPos, setDragPreviewPos] = useState({ x: 0, y: 0 });
  const [stageSize, setStageSize] = useState({
    width: window.innerWidth - 500, // Adjusted for both sidebars
    height: window.innerHeight - 50 // Adjust for top bar height
  });
  const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 });
  const stageRef = useRef(null);
  const containerRef = useRef(null);

//for radial menu  
// const [showRadialMenu, setShowRadialMenu] = useState(false);
const [radialMenuPosition, setRadialMenuPosition] = useState({ x: 0, y: 0 });
const [radialMenuOpen, setRadialMenuOpen] = useState(false); // New state to track if menu is expanded
const [isRightClickSelection, setIsRightClickSelection] = useState(false);

//for group
const [selectionRect, setSelectionRect] = useState(null);
const [isSelecting, setIsSelecting] = useState(false);
const [contextMenuPosition, setContextMenuPosition] = useState(null);
const [groups, setGroups] = useState([]);
const [selectionBounds, setSelectionBounds] = useState(null);

// First, add these state variables to your Canvas component
const [selectedShapes, setSelectedShapes] = useState([]);
const [isMultiSelect, setIsMultiSelect] = useState(false);

// 1. Add a dedicated state variable to track if we're in selection mode
const [isSelectionMode, setIsSelectionMode] = useState(false);

const [dragStartPosition, setDragStartPosition] = useState({ x: 0, y: 0 });

const [dragStartPos, setDragStartPos] = useState({ konva: { x: 0, y: 0 }, data: { x: 0, y: 0 } });
const [draggedGroupId, setDraggedGroupId] = useState(null);
const [isDragging, setIsDragging] = useState(false);
const [isDraggingGroup, setIsDraggingGroup] = useState(false);
const [groupDragOffset, setGroupDragOffset] = useState({ x: 0, y: 0 });

// Initialize gridLines array
  const gridLines = [];

// First, add state for context menu and locked status 
const [contextMenu, setContextMenu] = useState({
  visible: false,
  x: 0,
  y: 0,
  targetShape: null
});

console.log("showRadialMenu", showRadialMenu)

// Function to lock a shape
const lockShape = () => {
  if (!contextMenu.targetShape) return;
  
  const updatedShapes = shapes.map(shape => {
    if (shape.id === contextMenu.targetShape.id) {
      return {
        ...shape,
        locked: true
      };
    }
    return shape;
  });
  
  onAddShape(updatedShapes);
  
  // Update selected shape if it's the one being locked
  if (selectedShape && selectedShape.id === contextMenu.targetShape.id) {
    const updatedShape = updatedShapes.find(s => s.id === contextMenu.targetShape.id);
    onShapeSelect(updatedShape);
  }
  
  // Hide context menu
  setContextMenu({ ...contextMenu, visible: false });
};

// Function to calculate the bounds of a group
const calculateGroupBounds = (groupId) => {
  if (!groupId) return null;
  
  // Get all shapes in this group
  const groupShapes = shapes.filter(s => s.groupId === groupId);
  if (groupShapes.length === 0) return null;
  
  // Initialize bounds
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  
  // Calculate combined bounds of all shapes in the group
  groupShapes.forEach(shape => {
    let shapeBounds;
    
    switch (shape.type) {
      case 'circle':
        shapeBounds = {
          x: shape.x - shape.radius,
          y: shape.y - shape.radius,
          width: shape.radius * 2,
          height: shape.radius * 2
        };
        break;
      case 'line':
        const points = shape.points;
        shapeBounds = {
          x: Math.min(points[0], points[2]),
          y: Math.min(points[1], points[3]),
          width: Math.abs(points[2] - points[0]),
          height: Math.abs(points[3] - points[1])
        };
        break;
      case 'pillar':
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width,
          height: shape.height
        };
        break;
      case 'text':
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: (shape.text?.length || 1) * (shape.fontSize || 12) * 0.6,
          height: (shape.fontSize || 12) * 1.2
        };
        break;
      default:
        // For rectangles and other shapes with x, y, width, height
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width || 0,
          height: shape.height || 0
        };
        
        // Apply rotation if needed
        if (shape.rotation === 90) {
          shapeBounds = {
            x: shape.x,
            y: shape.y,
            width: shape.height || 0,
            height: shape.width || 0
          };
        }
    }
    
    // Update overall bounds
    minX = Math.min(minX, shapeBounds.x);
    minY = Math.min(minY, shapeBounds.y);
    maxX = Math.max(maxX, shapeBounds.x + shapeBounds.width);
    maxY = Math.max(maxY, shapeBounds.y + shapeBounds.height);
  });
  
  return {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY
  };
};

const handleDragStart = (e, shape) => {
  setIsDragging(true);
  // Skip if shape is locked
  if (shape.locked) return;
  
  // If this shape is part of a group
  if (shape.groupId) {
    setIsDraggingGroup(true);
    
    // Calculate offset from mouse position to shape position
    let offsetX, offsetY;
    
    if (shape.type === 'line') {
      // For lines, use the first point
      offsetX = e.evt.clientX - shape.points[0];
      offsetY = e.evt.clientY - shape.points[1];
    } else if (shape.type === 'pillar') {
      // For pillars, use the center
      offsetX = e.evt.clientX - (shape.x + shape.width/2);
      offsetY = e.evt.clientY - (shape.y + shape.height/2);
    } else {
      // For other shapes, use the top-left corner
      offsetX = e.evt.clientX - shape.x;
      offsetY = e.evt.clientY - shape.y;
    }
    
    // Store the offset and group ID
    setGroupDragOffset({ x: offsetX, y: offsetY });
    setDraggedGroupId(shape.groupId);
  } else {
    setIsDraggingGroup(false);
    setDraggedGroupId(null);
  }
};


// Function to render group outlines
const renderGroupOutlines = () => {
  // Track which groups we've already rendered to avoid duplicates
  const renderedGroups = new Set();
  
  // Get all unique group IDs
  const groupIds = [...new Set(shapes.filter(s => s.groupId).map(s => s.groupId))];
  
  return groupIds.map(groupId => {
    // Skip if already rendered
    if (renderedGroups.has(groupId)) return null;
    renderedGroups.add(groupId);
    
    // Check if any shape in this group is locked
    const hasLockedMember = shapes.some(s => s.groupId === groupId && s.locked);
    
    // Calculate group bounds
    const bounds = calculateGroupBounds(groupId);
    if (!bounds) return null;
    
    // Add padding around the group
    const padding = 5 / zoomLevel;
    
    // Return a rectangle around the group
    return (
  <Rect
    key={`group-outline-${groupId}`}
    x={bounds.x - padding}
    y={bounds.y - padding}
    width={bounds.width + padding * 2}
    height={bounds.height + padding * 2}
    stroke={hasLockedMember ? "#E1142E" : "#2ecc71"} // Red for locked groups, green for normal groups
    strokeWidth={2 / zoomLevel}
    dash={hasLockedMember ? [5 / zoomLevel, 5 / zoomLevel] : undefined} // Only use dashed line for locked groups
    fill="transparent"
    listening={false} // Don't capture events
    perfectDrawEnabled={false} // Optimize rendering
    hitStrokeWidth={0} // Ensure stroke doesn't capture events
  />
);
  });
};

// Function to unlock a shape
const unlockShape = () => {
  if (!contextMenu.targetShape) return;
  
  const updatedShapes = shapes.map(shape => {
    if (shape.id === contextMenu.targetShape.id) {
      return {
        ...shape,
        locked: false
      };
    }
    return shape;
  });
  
  onAddShape(updatedShapes);
  
  // Hide context menu
  setContextMenu({ ...contextMenu, visible: false });
};
  

  // Units configuration with conversion factors and formatting rules
  const units = {
    meters: { 
      toMeters: 1, 
      abbr: 'm', 
      smallerUnit: { divisor: 100, id: 'centimeters', abbr: 'cm', threshold: 1 } 
    },
    centimeters: { 
      toMeters: 0.01, 
      abbr: 'cm', 
      smallerUnit: null 
    },
    feet: { 
      toMeters: 0.3048, 
      abbr: 'ft', 
      smallerUnit: { divisor: 12, id: 'inches', abbr: 'in', threshold: 1 } 
    },
    inches: { 
      toMeters: 0.0254, 
      abbr: 'in', 
      smallerUnit: null 
    },
    yards: { 
      toMeters: 0.9144, 
      abbr: 'yd', 
      smallerUnit: { divisor: 3, id: 'feet', abbr: 'ft', threshold: 1 } 
    }
  };
//animated group component
 const AnimatedGroup = ({ x, y, targetX, targetY, opacity, children, onClick }) => {
  const [currentX, setCurrentX] = useState(x);
  const [currentY, setCurrentY] = useState(y);
  const [currentOpacity, setCurrentOpacity] = useState(opacity);
  
  // Log RadialMenu state (separate useEffect)
  useEffect(() => {
    console.log("RadialMenu state:", {
      show: showRadialMenu,
      open: radialMenuOpen,
      position: radialMenuPosition,
      selectedShapeId: selectedShape?.id
    });
  }, [showRadialMenu, radialMenuOpen, radialMenuPosition, selectedShape]);

  useEffect(() => {
  if (selectedShape && showRadialMenu) {
    updateRadialMenuPosition(selectedShape);
  }
}, [selectedShape, showRadialMenu]);

// Add this to your keyboard event handlers
useEffect(() => {
  const handleKeyboardShortcuts = (e) => {
    // Group with Ctrl+G
    if ((e.ctrlKey || e.metaKey) && e.key === 'g' && !e.shiftKey) {
      e.preventDefault();
      if (selectedShapes.length >= 2) {
        createGroup();
      }
    }
    
    // Ungroup with Ctrl+Shift+G
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'G') {
      e.preventDefault();
      
      // Case 1: We have multiple shapes selected
      if (isMultiSelect && selectedShapes.length > 0) {
        // Get all grouped shapes in the selection
        const groupedShapes = selectedShapes.filter(shape => shape.groupId);
        
        if (groupedShapes.length > 0) {
          // Get all unique group IDs in the selection
          const groupIds = [...new Set(groupedShapes.map(shape => shape.groupId))];
          
          // Update the shapes to remove the group ID
          const updatedShapes = shapes.map(shape => {
            if (groupIds.includes(shape.groupId)) {
              const { groupId, ...rest } = shape;
              return rest;
            }
            return shape;
          });
          
          // Remove the groups
          setGroups(groups.filter(g => !groupIds.includes(g.id)));
          
          // Update shapes
          onAddShape(updatedShapes);
          
          // Keep the multi-selection active but with ungrouped shapes
          const updatedSelection = selectedShapes.map(shape => {
            if (groupIds.includes(shape.groupId)) {
              const { groupId, ...rest } = shape;
              return rest;
            }
            return shape;
          });
          
          setSelectedShapes(updatedSelection);
          
          // Update selection bounds
          const bounds = calculateSelectionBounds(updatedSelection);
          setSelectionBounds(bounds);
        }
      }
      // Case 2: We have a single shape selected that's part of a group
      else if (selectedShape && selectedShape.groupId) {
        const groupId = selectedShape.groupId;
        
        // Get all shapes in this group
        const groupShapes = shapes.filter(s => s.groupId === groupId);
        
        // Update shapes to remove the groupId
        const updatedShapes = shapes.map(s => {
          if (s.groupId === groupId) {
            const { groupId, ...rest } = s;
            return rest;
          }
          return s;
        });
        
        // Remove the group
        setGroups(groups.filter(g => g.id !== groupId));
        
        // Update shapes
        onAddShape(updatedShapes);
        
        // Select all the shapes that were in the group
        setSelectedShapes(groupShapes.map(s => {
          const { groupId, ...rest } = s;
          return rest;
        }));
        setIsMultiSelect(true);
        
        // Update the primary selected shape
        const updatedSelectedShape = { ...selectedShape };
        delete updatedSelectedShape.groupId;
        onShapeSelect(updatedSelectedShape);
        
        // Calculate and set the selection bounds
        const updatedGroupShapes = groupShapes.map(s => {
          const { groupId, ...rest } = s;
          return rest;
        });
        const bounds = calculateSelectionBounds(updatedGroupShapes);
        setSelectionBounds(bounds);
      }
    }
    
    // Add other keyboard shortcuts for multi-selection operations
    if (isMultiSelect && selectedShapes.length > 0) {
      // Delete selected shapes with Delete or Backspace
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        
        // Filter out the selected shapes that aren't locked
        const updatedShapes = shapes.filter(shape => 
          !selectedShapes.some(selected => selected.id === shape.id) || shape.locked
        );
        
        onAddShape(updatedShapes);
        setSelectedShapes([]);
        setIsMultiSelect(false);
        setSelectionBounds(null);
      }
      
      // Duplicate selected shapes with Ctrl+D
      if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        
        // Create duplicates with offset
        const duplicatesToAdd = [];
        
        selectedShapes.forEach(shape => {
          if (!shape.locked) {
            let duplicatedShape;
            
            if (shape.type === 'line') {
              duplicatedShape = {
                ...shape,
                id: Date.now() + Math.random(),
                points: [
                  shape.points[0] + 20,
                  shape.points[1] + 20,
                  shape.points[2] + 20,
                  shape.points[3] + 20
                ]
              };
            } else {
              duplicatedShape = {
                ...shape,
                id: Date.now() + Math.random(),
                x: shape.x + 20,
                y: shape.y + 20
              };
            }
            
            // Skip collision check for non-rack items
            if (shape.type !== 'rack' || !checkCollision(duplicatedShape, [...shapes])) {
              duplicatesToAdd.push(duplicatedShape);
            }
          }
        });
        
        if (duplicatesToAdd.length > 0) {
          onAddShape([...shapes, ...duplicatesToAdd]);
          
          // Select the new duplicates
          setSelectedShapes(duplicatesToAdd);
          
          // Update selection bounds
          const bounds = calculateSelectionBounds(duplicatesToAdd);
          setSelectionBounds(bounds);
        }
      }
    }
  };
  
  window.addEventListener('keydown', handleKeyboardShortcuts);
  return () => window.removeEventListener('keydown', handleKeyboardShortcuts);
}, [selectedShapes, selectedShape, groups, shapes, isMultiSelect, onAddShape]);


// Add this useEffect to your component
useEffect(() => {
  const handleMouseUp = () => {
    if (isSelecting) {
      setIsSelecting(false);
      setIsSelectionMode(false);
      setSelectionRect(null);
    }
  };
  
  // Listen for mouse up events on the window
  window.addEventListener('mouseup', handleMouseUp);
  
  return () => {
    window.removeEventListener('mouseup', handleMouseUp);
  };
}, [isSelecting]);
// Add keyboard navigation support
useEffect(() => {
  const handleKeyboardNavigation = (e) => {
    // If no shape is selected, or shape is locked, or a tool is active, don't handle navigation
    if (!selectedShape || selectedShape.locked || selectedTool) return;
    
    const moveAmount = e.shiftKey ? 10 : 1;
    let updatedShapes;
    
    // Check if selected shape is part of a group
    if (selectedShape.groupId) {
      // Move all shapes in the group
      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.groupId === selectedShape.groupId) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0],
                    s.points[1] - moveAmount,
                    s.points[2],
                    s.points[3] - moveAmount
                  ]
                };
              } else if (s.type === 'circle') {
                return { ...s, y: s.y - moveAmount };
              } else if (s.type === 'pillar') {
                return { ...s, y: s.y - moveAmount };
              } else {
                return { ...s, y: s.y - moveAmount };
              }
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowDown':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.groupId === selectedShape.groupId) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0],
                    s.points[1] + moveAmount,
                    s.points[2],
                    s.points[3] + moveAmount
                  ]
                };
              } else if (s.type === 'circle') {
                return { ...s, y: s.y + moveAmount };
              } else if (s.type === 'pillar') {
                return { ...s, y: s.y + moveAmount };
              } else {
                return { ...s, y: s.y + moveAmount };
              }
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowLeft':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.groupId === selectedShape.groupId) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0] - moveAmount,
                    s.points[1],
                    s.points[2] - moveAmount,
                    s.points[3]
                  ]
                };
              } else if (s.type === 'circle') {
                return { ...s, x: s.x - moveAmount };
              } else if (s.type === 'pillar') {
                return { ...s, x: s.x - moveAmount };
              } else {
                return { ...s, x: s.x - moveAmount };
              }
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowRight':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.groupId === selectedShape.groupId) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0] + moveAmount,
                    s.points[1],
                    s.points[2] + moveAmount,
                    s.points[3]
                  ]
                };
              } else if (s.type === 'circle') {
                return { ...s, x: s.x + moveAmount };
              } else if (s.type === 'pillar') {
                return { ...s, x: s.x + moveAmount };
              } else {
                return { ...s, x: s.x + moveAmount };
              }
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'Delete':
        case 'Backspace':
          e.preventDefault();
          if (!selectedShape.locked) {
            // Get all shapes in the group
            const groupId = selectedShape.groupId;
            
            // Delete all shapes in the group
            const updatedShapes = shapes.filter(s => s.groupId !== groupId);
            onAddShape(updatedShapes);
            onShapeSelect(null);
          }
          break;
          
        default:
          break;
      }
    } else {
      // Handle single shape navigation (original logic)
      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.id === selectedShape.id) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0],
                    s.points[1] - moveAmount,
                    s.points[2],
                    s.points[3] - moveAmount
                  ]
                };
              }
              return { ...s, y: s.y - moveAmount };
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowDown':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.id === selectedShape.id) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0],
                    s.points[1] + moveAmount,
                    s.points[2],
                    s.points[3] + moveAmount
                  ]
                };
              }
              return { ...s, y: s.y + moveAmount };
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowLeft':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.id === selectedShape.id) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0] - moveAmount,
                    s.points[1],
                    s.points[2] - moveAmount,
                    s.points[3]
                  ]
                };
              }
              return { ...s, x: s.x - moveAmount };
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'ArrowRight':
          e.preventDefault();
          updatedShapes = shapes.map(s => {
            if (s.id === selectedShape.id) {
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0] + moveAmount,
                    s.points[1],
                    s.points[2] + moveAmount,
                    s.points[3]
                  ]
                };
              }
              return { ...s, x: s.x + moveAmount };
            }
            return s;
          });
          onAddShape(updatedShapes);
          break;
          
        case 'Delete':
        case 'Backspace':
          e.preventDefault();
          if (!selectedShape.locked) {
            const updatedShapes = shapes.filter(s => s.id !== selectedShape.id);
            onAddShape(updatedShapes);
            onShapeSelect(null);
          }
          break;
          
        default:
          break;
      }
    }
  };
  
  window.addEventListener('keydown', handleKeyboardNavigation);
  return () => window.removeEventListener('keydown', handleKeyboardNavigation);
}, [selectedShape, shapes, onAddShape, selectedTool]);

// this effect to coordinate radial menu and duplicate controls
  useEffect(() => {
  // When a shape is selected and not locked, ensure proper UI state
  if (selectedShape && showRadialMenu && !selectedShape.locked && !isRightClickSelection) {
    // Force a redraw to ensure both elements appear
    if (stageRef.current) {
      setTimeout(() => {
        stageRef.current.batchDraw();
      }, 0);
    }
  }
}, [selectedShape, isRightClickSelection, showRadialMenu]);

// Add this useEffect for group operations keyboard shortcuts
useEffect(() => {
  const handleKeyboardGroupOperations = (e) => {
    // Only process if we have multiple shapes selected
    if (!isMultiSelect || selectedShapes.length === 0) return;
    
    // Group delete with Delete or Backspace
    if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault();
      
      // Filter out the selected shapes
      const updatedShapes = shapes.filter(shape => 
        !selectedShapes.some(selected => selected.id === shape.id) || shape.locked
      );
      
      onAddShape(updatedShapes);
      setSelectedShapes([]);
      setIsMultiSelect(false);
    }
    
    // Group move with arrow keys
    const moveAmount = e.shiftKey ? 10 : 1;
    let dx = 0;
    let dy = 0;
    
    switch (e.key) {
      case 'ArrowUp':
        e.preventDefault();
        dy = -moveAmount;
        break;
      case 'ArrowDown':
        e.preventDefault();
        dy = moveAmount;
        break;
      case 'ArrowLeft':
        e.preventDefault();
        dx = -moveAmount;
        break;
      case 'ArrowRight':
        e.preventDefault();
        dx = moveAmount;
        break;
      default:
        return;
    }
    
    if (dx !== 0 || dy !== 0) {
      // Move all selected shapes that aren't locked
      const updatedShapes = shapes.map(shape => {
        if (selectedShapes.some(selected => selected.id === shape.id) && !shape.locked) {
          // Handle different shape types
          if (shape.type === 'line') {
            // For lines, move all points
            return {
              ...shape,
              points: [
                shape.points[0] + dx,
                shape.points[1] + dy,
                shape.points[2] + dx,
                shape.points[3] + dy
              ]
            };
          } else if (shape.type === 'circle') {
            // For circles, move center
            return {
              ...shape,
              x: shape.x + dx,
              y: shape.y + dy
            };
          } else {
            // For other shapes with x, y coordinates
            return {
              ...shape,
              x: shape.x + dx,
              y: shape.y + dy
            };
          }
        }
        return shape;
      });
      
      onAddShape(updatedShapes);
      
      // Update selected shapes with new positions
      setSelectedShapes(selectedShapes.map(shape => {

        const updatedShape = updatedShapes.find(s => s.id === shape.id);
        return updatedShape || shape;
      }));
    }
    
    // Group duplicate with Ctrl+D
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
      e.preventDefault();
      
      // Create duplicates with offset
      const duplicatesToAdd = [];
      
      selectedShapes.forEach(shape => {
        if (!shape.locked) {
          let duplicatedShape;
          
          if (shape.type === 'line') {
            duplicatedShape = {
              ...shape,
              id: Date.now() + Math.random(),
              points: [
                shape.points[0] + 20,
                shape.points[1] + 20,
                shape.points[2] + 20,
                shape.points[3] + 20
              ]
            };
          } else {
            duplicatedShape = {
              ...shape,
              id: Date.now() + Math.random(),
              x: shape.x + 20,
              y: shape.y + 20
            };
          }
          
          // Skip collision check for non-rack items
          if (shape.type !== 'rack' || !checkCollision(duplicatedShape, [...shapes])) {
            duplicatesToAdd.push(duplicatedShape);
          }
        }
      });
      
      if (duplicatesToAdd.length > 0) {
        onAddShape([...shapes, ...duplicatesToAdd]);
        
        // Select the new duplicates
        setSelectedShapes(duplicatesToAdd);
      }
    }
  };
  
  window.addEventListener('keydown', handleKeyboardGroupOperations);
  return () => window.removeEventListener('keydown', handleKeyboardGroupOperations);
}, [isMultiSelect, selectedShapes, shapes, onAddShape]);
  
  // Animation useEffect
  useEffect(() => {
    // Animate position and opacity
    const animation = {
      node: {
        x: currentX,
        y: currentY,
        opacity: currentOpacity
      },
      duration: 0.3,
      easing: (t) => t, // Linear easing
      onUpdate: (newValues) => {
        setCurrentX(newValues.x);
        setCurrentY(newValues.y);
        setCurrentOpacity(newValues.opacity);
      },
      x: targetX,
      y: targetY,
      opacity: opacity
    };
    
    // Simple animation function
    const startTime = Date.now();
    const duration = animation.duration * 1000;
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const newX = animation.node.x + (animation.x - animation.node.x) * progress;
      const newY = animation.node.y + (animation.y - animation.node.y) * progress;
      const newOpacity = animation.node.opacity + (animation.opacity - animation.node.opacity) * progress;
      
      animation.onUpdate({ x: newX, y: newY, opacity: newOpacity });
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, [targetX, targetY, opacity]);
  
  return (
    <Group x={currentX} y={currentY} opacity={currentOpacity} onClick={onClick}>
      {children}
    </Group>
  );
};
  // Collision detection function
  const checkCollision = (newShape, existingShapes) => {
    // Skip collision check for walls, lines, and the shape itself
    const shapesToCheck = existingShapes.filter(shape => 
      shape.id !== newShape.id && 
      shape.type !== 'line' && 
      shape.type !== 'wall'
    );
    
    // Get bounding box for the new shape
    let newBounds;
    
    if (newShape.type === 'circle') {
      newBounds = {
        x: newShape.x - newShape.radius,
        y: newShape.y - newShape.radius,
        width: newShape.radius * 2,
        height: newShape.radius * 2
      };
    } else if (newShape.type === 'pillar') {
      newBounds = {
        x: newShape.x,
        y: newShape.y,
        width: newShape.width,
        height: newShape.height
      };
    } else if (newShape.type === 'line') {
      const points = newShape.points;
      const minX = Math.min(points[0], points[2]);
      const maxX = Math.max(points[0], points[2]);
      const minY = Math.min(points[1], points[3]);
      const maxY = Math.max(points[1], points[3]);
      
      newBounds = {
        x: minX,
        y: minY,
        width: maxX - minX,
        height: maxY - minY
      };
    } else {
      // For rectangles and other shapes with x, y, width, height
      newBounds = {
        x: newShape.x,
        y: newShape.y,
        width: newShape.width,
        height: newShape.height
      };
      
      // Apply rotation if needed
      if (newShape.rotation === 90) {
        // For 90-degree rotated shapes, swap width and height
        newBounds = {
          x: newShape.x,
          y: newShape.y,
          width: newShape.height,
          height: newShape.width
        };
      }
    }
    
    // Check collision with each existing shape
    for (const shape of shapesToCheck) {
      let shapeBounds;
      
      if (shape.type === 'circle') {
        shapeBounds = {
          x: shape.x - shape.radius,
          y: shape.y - shape.radius,
          width: shape.radius * 2,
          height: shape.radius * 2
        };
      } else if (shape.type === 'pillar') {
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width,
          height: shape.height
        };
      } else if (shape.type === 'line') {
        const points = shape.points;
        const minX = Math.min(points[0], points[2]);
        const maxX = Math.max(points[0], points[2]);
        const minY = Math.min(points[1], points[3]);
        const maxY = Math.max(points[1], points[3]);
        
        shapeBounds = {
          x: minX,
          y: minY,
          width: maxX - minX,
          height: maxY - minY
        };
      } else {
        // For rectangles and other shapes with x, y, width, height
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width,
          height: shape.height
        };
        
        // Apply rotation if needed
        if (shape.rotation === 90) {
          // For 90-degree rotated shapes, swap width and height
          shapeBounds = {
            x: shape.x,
            y: shape.y,
            width: shape.height,
            height: shape.width
          };
        }
      }
      
      // Check for rectangle intersection
      if (
        newBounds.x < shapeBounds.x + shapeBounds.width &&
        newBounds.x + newBounds.width > shapeBounds.x &&
        newBounds.y < shapeBounds.y + shapeBounds.height &&
        newBounds.y + newBounds.height > shapeBounds.y
      ) {
        // Collision detected
        return true;
      }
    }
    
    // No collision
    return false;
  };

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setStageSize({
        width: window.innerWidth - 500, // Adjusted for both sidebars
        height: window.innerHeight - 50 // Adjust for top bar height
      });
    };

    handleResize(); // Call once to set initial size
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // radial menu
useEffect(() => {
  const container = containerRef.current;
  
  const handleContextMenu = (e) => {
    e.preventDefault();
    return false;
  };
  
  if (container) {
    container.addEventListener('contextmenu', handleContextMenu);
  }
  
  return () => {
    if (container) {
      container.removeEventListener('contextmenu', handleContextMenu);
    }
  };
}, []);


const createGroup = () => {
  if (selectedShapes.length < 2) return; // Need at least 2 shapes to form a group
  
  const groupId = `group-${Date.now()}`;
  
  // Update the shapes to mark them as grouped
  const updatedShapes = shapes.map(shape => {
    if (selectedShapes.some(selected => selected.id === shape.id)) {
      return {
        ...shape,
        groupId: groupId
      };
    }
    return shape;
  });
  
  onAddShape(updatedShapes);
  
  // Get the updated shapes with groupId
  const groupedShapes = updatedShapes.filter(s => s.groupId === groupId);
  
  // Select the first shape in the group to show it's active
  if (groupedShapes.length > 0) {
    onShapeSelect(groupedShapes[0]);
    
    // Also update selectedShapes to include all shapes in the group
    setSelectedShapes(groupedShapes);
    setIsMultiSelect(true);
    
    // Calculate and set the selection bounds
    const bounds = calculateSelectionBounds(groupedShapes);
    setSelectionBounds(bounds);
  }
  
  // Force a redraw to ensure the group outline appears
  if (stageRef.current) {
    stageRef.current.batchDraw();
  }
};

// Function to ungroup elements
const ungroup = () => {
  // Check if we have a selection with at least one grouped shape
  const groupedShapes = selectedShapes.filter(shape => shape.groupId);
  if (groupedShapes.length === 0) return;
  
  // Get all unique group IDs in the selection
  const groupIds = [...new Set(groupedShapes.map(shape => shape.groupId))];
  
  // Update the shapes to remove the group ID
  const updatedShapes = shapes.map(shape => {
    if (groupIds.includes(shape.groupId)) {
      const { groupId, ...rest } = shape;
      return rest;
    }
    return shape;
  });
  
  onAddShape(updatedShapes);
  
  // Keep the multi-selection active but with ungrouped shapes
  const updatedSelection = selectedShapes.map(shape => {
    if (groupIds.includes(shape.groupId)) {
      const { groupId, ...rest } = shape;
      return rest;
    }
    return shape;
  });
  
  setSelectedShapes(updatedSelection);
  
  // Update selection bounds
  const bounds = calculateSelectionBounds(updatedSelection);
  setSelectionBounds(bounds);
  
  // Update the primary selected shape
  if (selectedShape && selectedShape.groupId && groupIds.includes(selectedShape.groupId)) {
    const { groupId, ...rest } = selectedShape;
    onShapeSelect(rest);
  }
};



// Function to check if a shape belongs to a group
const getShapeGroup = (shapeId) => {
  const shape = shapes.find(s => s.id === shapeId);
  return shape?.groupId ? groups.find(g => g.id === shape.groupId) : undefined;
};

// Function to get all shapes in a group
const getGroupShapes = (groupId) => {
  return shapes.filter(shape => shape.groupId === groupId);
};

// Add this useEffect to your component
useEffect(() => {
  // When a shape is selected and not locked, ensure the radial menu appears
  if (selectedShape && !selectedShape.locked && !isRightClickSelection) {
    // Calculate position based on shape type
    let menuX, menuY;
    
    switch (selectedShape.type) {
      case 'circle':
        menuX = selectedShape.x;
        menuY = selectedShape.y;
        break;
      case 'line':
        const points = selectedShape.points;
        menuX = (points[0] + points[2]) / 2;
        menuY = (points[1] + points[3]) / 2;
        break;
      case 'pillar':
        menuX = selectedShape.x + selectedShape.width / 2;
        menuY = selectedShape.y + selectedShape.height / 2;
        break;
      default:
        menuX = selectedShape.x + (selectedShape.width || 0) / 2;
        menuY = selectedShape.y + (selectedShape.height || 0) / 2;
    }
    
    // Update radial menu position
    setRadialMenuPosition({ x: menuX, y: menuY });
    
    // Show radial menu
    // setShowRadialMenu(true);
    setRadialMenuOpen(true);
    
    // Force a redraw
    if (stageRef.current) {
      stageRef.current.batchDraw();
    }
  }
}, [selectedShape?.id]); // Only trigger when the selected shape ID changes


const determineShapeStroke = (shape, isSelected, isGrouped) => {
  // If the shape is part of a group, don't show individual strokes at all
  if (shape.groupId) {
    return 'transparent'; // Hide stroke for grouped shapes
  }
  // If the shape is locked, show red outline
  else if (shape.locked) {
    return '#E1142E'; // Red for locked shapes
  } 
  // If the shape is selected, show blue outline
  else if (isSelected) {
    return '#3498db'; // Blue for selected shapes
  }
  // Otherwise use the shape's original stroke
  else {
    return shape.stroke;
  }
};

const determineStrokeWidth = (shape, isSelected, isGrouped, zoomLevel) => {
  // If the shape is part of a group, use minimal stroke width
  if (shape.groupId) {
    return 0; // No stroke for grouped shapes
  }
  // If the shape is locked, use a thin red stroke
  else if (shape.locked) {
    return 1 / zoomLevel;
  }
  // If the shape is selected, use a thicker stroke
  else if (isSelected) {
    return (shape.strokeWidth || 1) + 2;
  }
  // Otherwise use the shape's original stroke width
  else {
    return shape.strokeWidth;
  }
};

// Render shape function with lock indication
const renderShape = (shape) => {
  // Determine if this shape is selected
  const isSelected = selectedShape && selectedShape.id === shape.id;
  
  // Check if shape is part of a group
  const isGrouped = shape.groupId !== undefined;

  // Check if any shape in the group is locked (if this shape is part of a group)
  let isGroupLocked = false;
  if (isGrouped) {
    isGroupLocked = shapes.some(s => s.groupId === shape.groupId && s.locked);
  }
  
  // Determine if this shape should be treated as locked (either directly or via group)
  const isEffectivelyLocked = shape.locked || isGroupLocked;
  
  // Determine stroke color based on state
  let shapeStroke;
  if (shape.groupId) {
    // If shape is part of a group, use its original stroke (no blue highlight)
    shapeStroke = shape.stroke || 'transparent';
  } else if (shape.locked) {
    // If shape is individually locked, use red
    shapeStroke = '#E1142E';
  } else if (isSelected) {
    // If shape is selected and not in a group, use blue
    shapeStroke = '#3498db';
  } else {
    // Otherwise use the shape's original stroke
    shapeStroke = shape.stroke;
  }
  
  // Determine stroke width based on state
  let shapeStrokeWidth;
  if (shape.groupId) {
    // For grouped shapes, use normal stroke width
    shapeStrokeWidth = shape.strokeWidth || 1;
  } else if (shape.locked) {
    // For locked shapes, use thin stroke adjusted for zoom
    shapeStrokeWidth = 1 / zoomLevel;
  } else if (isSelected) {
    // For selected shapes, use thicker stroke
    shapeStrokeWidth = (shape.strokeWidth || 1) + 2;
  } else {
    // Otherwise use the shape's original stroke width
    shapeStrokeWidth = shape.strokeWidth;
  }
  
  // Common props for all shapes
  const commonProps = {
    onClick: (e) => {
      // Only handle selection if no drawing tool is active
      if (!selectedTool) {
        e.cancelBubble = true; // Stop event propagation
        
        // Debug logging
        console.log("Left click on shape:", e.evt.button, {
          id: shape.id,
          type: shape.type,
          locked: shape.locked,
          grouped: isGrouped,
          groupLocked: isGroupLocked
        });

        // If shape is part of a group and we're not holding shift, select the whole group
        if (shape.groupId && !e.evt.shiftKey) {
          selectEntireGroup(shape);
          return;
        }
        
        // Only proceed if shape is not locked
        if (!isEffectivelyLocked) {
          // Calculate position based on shape type
          let menuX, menuY;
          
          switch (shape.type) {
            case 'circle':
              menuX = shape.x;
              menuY = shape.y;
              break;
            case 'line':
              const points = shape.points;
              menuX = (points[0] + points[2]) / 2;
              menuY = (points[1] + points[3]) / 2;
              break;
            case 'pillar':
              menuX = shape.x + shape.width / 2;
              menuY = shape.y + shape.height / 2;
              break;
            default:
              menuX = shape.x + shape.width / 2;
              menuY = shape.y + shape.height / 2;
          }
          
          // IMPORTANT: First update all state variables that affect rendering
          // 1. Reset right-click flag to ensure arrows appear
          setIsRightClickSelection(false);
          
          // 2. Set up radial menu position
          setRadialMenuPosition({ x: menuX, y: menuY });

          // 4. Finally, select the shape (this might trigger a re-render)
          onShapeSelect(shape);
         
          // Force a redraw after a small delay to ensure everything is updated
          setTimeout(() => {
            // setShowRadialMenu(true);
            setRadialMenuOpen(true);
          
            if (stageRef.current) {
              stageRef.current.batchDraw();
            }
          }, 10);
        } else {
          // If shape is locked, just select it without showing UI elements
          onShapeSelect(shape);
        }
      }
    },
    onContextMenu: (e) => {
      // Prevent default context menu
      e.evt.preventDefault();
      e.cancelBubble = true;
      console.log("click", e.button, e.evt.button, e.evt)
      
      // Get position for context menu
      const stage = e.target.getStage();
      const pos = stage.getPointerPosition();
      
      // Hide radial menu if it's showing
      // setShowRadialMenu(false);

      // Set the right-click selection flag
      setIsRightClickSelection(true);
      
      // Show context menu at mouse position
      setContextMenu({
        visible: true,
        x: pos.x,
        y: pos.y,
        targetShape: shape
      });
      
      // Select the shape but DON'T show radial menu
      onShapeSelect(shape);
    },
    onTap: (e) => {
      // Only handle selection if no drawing tool is active
      if (!selectedTool) {
        e.cancelBubble = true; // Stop event propagation
        
        // Only proceed if shape is not locked
        if (!shape.locked) {
          // Calculate position based on shape type
          let menuX, menuY;
          
          switch (shape.type) {
            case 'circle':
              menuX = shape.x;
              menuY = shape.y;
              break;
            case 'line':
              const points = shape.points;
              menuX = (points[0] + points[2]) / 2;
              menuY = (points[1] + points[3]) / 2;
              break;
            case 'pillar':
              menuX = shape.x + shape.width / 2;
              menuY = shape.y + shape.height / 2;
              break;
            default:
              menuX = shape.x + shape.width / 2;
              menuY = shape.y + shape.height / 2;
          }
          
          // Same approach as onClick for consistency
          setIsRightClickSelection(false);
          setRadialMenuPosition({ x: menuX, y: menuY });
          // setShowRadialMenu(true);
          setRadialMenuOpen(true);
          onShapeSelect(shape);
          
          setTimeout(() => {
            if (stageRef.current) {
              stageRef.current.batchDraw();
            }
          }, 10);
        } else {
          // If shape is locked, just select it without showing UI elements
          onShapeSelect(shape);
        }
      }
    },
  };
  
  // Make shapes draggable only when no drawing tool is selected AND not locked
  const isDraggable = !selectedTool && !isDrawing && !isEffectivelyLocked;
  
  switch (shape.type) {
    case 'line': {
      const points = shape.points;
      const x1 = points[0];
      const y1 = points[1];
      const x2 = points[2];
      const y2 = points[3];
      
      // Calculate midpoint for measurement text
      const midX = (x1 + x2) / 2;
      const midY = (y1 + y2) / 2;
      
      // Calculate line length
      const lineLength = distance(x1, y1, x2, y2);
      
      return (
        <React.Fragment key={shape.id}>
          <Line
            points={shape.points}
            stroke={shapeStroke}
            strokeWidth={shapeStrokeWidth}
            draggable={isDraggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            {...commonProps}
          />
          {showDimensions && (
            <Text
              x={midX}
              y={midY - 20 / zoomLevel}
              text={formatDimension(lineLength)}
              fontSize={14 / zoomLevel}
              fill={isSelected && !shape.groupId ? '#3498db' : (isGrouped ? '#2ecc71' : '#555')}
              align="center"
              offsetX={0}
              offsetY={0}
            />
          )}
        </React.Fragment>
      );
    }
    case 'rectangle':
      return (
        <Rect
          key={shape.id}
          x={shape.x}
          y={shape.y}
          width={shape.width}
          height={shape.height}
          offsetX={shape.width / 2}  // Add this to center the drag point
          offsetY={shape.height / 2} // Add this to center the drag point
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          {...commonProps}
        />
      );
    case 'circle':
      return (
        <Circle
          key={shape.id}
          x={shape.x}
          y={shape.y}
          radius={shape.radius}
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'pencil':
      return (
        <Line
          key={shape.id}
          points={shape.points}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          tension={0.5}
          lineCap="round"
          lineJoin="round"
          draggable={isDraggable}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'text':
      return (
        <Text
          key={shape.id}
          x={shape.x}
          y={shape.y}
          text={shape.text}
          fontSize={shape.fontSize}
          fill={shape.fill}
          stroke={isSelected && !shape.groupId ? '#3498db' : (isGrouped ? 'transparent' : '')}
          strokeWidth={isSelected && !shape.groupId ? 1 : 0}
          draggable={isDraggable}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'door':
    case 'window':
    case 'sliding-door':
      return (
        <Rect
          key={shape.id}
          x={shape.x}
          y={shape.y}
          width={shape.width}
          height={shape.height}
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          dash={shape.dash}
          rotation={shape.rotation || 0}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'wall':
      return (
        <Rect
          key={shape.id}
          x={shape.x}
          y={shape.y}
          width={shape.width}
          height={shape.height}
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'pillar':
      return (
        <Circle
          key={shape.id}
          x={shape.x + shape.width / 2}
          y={shape.y + shape.height / 2}
          radius={shape.width / 2}
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    case 'bed':
    case 'sofa':
    case 'table':
    case 'chair':
    case 'rack':
      return (
        <Rect
          key={shape.id}
          x={shape.x}
          y={shape.y}
          width={shape.width}
          height={shape.height}
          fill={shape.fill}
          stroke={shapeStroke}
          strokeWidth={shapeStrokeWidth}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, shape)}
          onDragMove={(e) => handleDragMove(e, shape)}
          onDragEnd={(e) => handleDragEnd(e, shape)}
          {...commonProps}
        />
      );
    default:
      return null;
  }
};


useEffect(() => {
  const handleKeyDown = (e) => {
    if (selectedShape && !selectedTool && !selectedShape.locked && (e.key === 'm' || e.key === 'M')) {
      e.preventDefault();
      
      // Calculate position (center of selected shape)
      let menuX, menuY;
      
      switch (selectedShape.type) {
        case 'circle':
          menuX = selectedShape.x;
          menuY = selectedShape.y;
          break;
        case 'line':
          const points = selectedShape.points;
          menuX = (points[0] + points[2]) / 2;
          menuY = (points[1] + points[3]) / 2;
          break;
        case 'pillar':
          menuX = selectedShape.x + selectedShape.width / 2;
          menuY = selectedShape.y + selectedShape.height / 2;
          break;
        default:
          menuX = selectedShape.x + selectedShape.width / 2;
          menuY = selectedShape.y + selectedShape.height / 2;
      }
      
      setRadialMenuPosition({ x: menuX, y: menuY });
      // setShowRadialMenu(true);
    }
  };
  
  window.addEventListener('keydown', handleKeyDown);
  
  return () => {
    window.removeEventListener('keydown', handleKeyDown);
  };
}, [selectedShape, selectedTool]);


useEffect(() => {
  // Close radial menu when selected shape changes
  // setShowRadialMenu(false);
}, [selectedShape?.id]); // Only trigger when the ID changes, not the entire object

  // Handle wheel events for zooming
  useEffect(() => {
    const container = containerRef.current;
    
    const handleWheel = (e) => {
      e.preventDefault();
      
      const stage = stageRef.current;
      if (!stage) return;
      
      const oldScale = stage.scaleX();
      
      // Calculate new scale
      const pointer = stage.getPointerPosition();
      
      // Get pointer position relative to stage
      const mousePointTo = {
        x: (pointer.x - stage.x()) / oldScale,
        y: (pointer.y - stage.y()) / oldScale
      };
      
      // Calculate new scale with wheel delta
      const newScale = e.deltaY < 0 ? oldScale * 1.1 : oldScale / 1.1;
      
      // Limit zoom level
      const limitedScale = Math.min(Math.max(newScale, 0.2), 5);
      
      // Set new position to keep the point under mouse in the same position
      const newPos = {
        x: pointer.x - mousePointTo.x * limitedScale,
        y: pointer.y - mousePointTo.y * limitedScale
      };
      
      // Update stage scale and position
      stage.scale({ x: limitedScale, y: limitedScale });
      stage.position(newPos);
      stage.batchDraw();
    };
    
    if (container) {
      container.addEventListener('wheel', handleWheel, { passive: false });
    }
    
    return () => {
      if (container) {
        container.removeEventListener('wheel', handleWheel);
      }
    };
  }, []);

  // Update stage scale when zoomLevel changes
  useEffect(() => {
    const stage = stageRef.current;
    if (stage) {
      // Get current center of viewport
      const centerX = stageSize.width / 2;
      const centerY = stageSize.height / 2;
      
      // Get current center point in the world coordinates
      const oldScale = stage.scaleX();
      const pointTo = {
        x: (centerX - stage.x()) / oldScale,
        y: (centerY - stage.y()) / oldScale
      };
      
      // Set new position to keep the center point in the same position
      const newPos = {
        x: centerX - pointTo.x * zoomLevel,
        y: centerY - pointTo.y * zoomLevel
      };
      
      // Update stage scale and position
      stage.scale({ x: zoomLevel, y: zoomLevel });
      stage.position(newPos);
      stage.batchDraw();
      
      // Update state
      setStagePosition(newPos);
    }
  }, [zoomLevel, stageSize]);

  // Toggle radial menu open/closed
  const toggleRadialMenu = () => {
  console.log("Toggle radial menu from:", radialMenuOpen, "to:", !radialMenuOpen);
  
  // Get the stage for animation
  const stage = stageRef.current;
  if (stage) {
    // Force a redraw to ensure animations work properly
    stage.batchDraw();
  }
  
  setRadialMenuOpen(!radialMenuOpen);
};

  // Handle drag over for drag and drop
  useEffect(() => {
    const container = containerRef.current;
    
    const handleDragOver = (e) => {
      e.preventDefault(); // Allow drop

      if (isDraggingElement && dragElement) {
        // Update mouse position for drag preview
        setMousePosition({
          x: e.clientX,
          y: e.clientY
        });
      }
    };

    const handleDrop = (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (!isDraggingElement || !dragElement) return;

      // Get stage and pointer position
      const stage = stageRef.current;
      if (!stage) return;

      // Get the container's bounding rectangle
      const containerRect = containerRef.current.getBoundingClientRect();

      // Calculate the position relative to the container
      const relX = e.clientX - containerRect.left;
      const relY = e.clientY - containerRect.top;

      // Convert to stage coordinates (accounting for stage position and zoom)
      const stagePos = {
        x: (relX - stage.x()) / stage.scaleX(),
        y: (relY - stage.y()) / stage.scaleY()
      };

      // Adjust for the drag offset
      const dropPosition = {
        x: stagePos.x - (dragOffset?.offsetX || 0) / stage.scaleX(),
        y: stagePos.y - (dragOffset?.offsetY || 0) / stage.scaleY()
      };

      // Notify parent component about the drop
      onElementDrop(dragElement, dropPosition);
    };
    
    if (container) {
      container.addEventListener('dragover', handleDragOver);
      container.addEventListener('drop', handleDrop);
    }
    
    return () => {
      if (container) {
        container.removeEventListener('dragover', handleDragOver);
        container.removeEventListener('drop', handleDrop);
      }
    };
  }, [onElementDrop, shapes]);

  // Add keyboard shortcut support for duplication
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!selectedShape || selectedTool) return;
      
      // Duplicate with arrow keys when holding Ctrl or Cmd
      if ((e.ctrlKey || e.metaKey) && selectedShape) {
        let offsetX = 0;
        let offsetY = 0;
        const offsetAmount = 100; // Fixed offset amount
        
        switch (e.key) {
          case 'ArrowUp':
            e.preventDefault();
            offsetY = -offsetAmount;
            handleDuplicate(selectedShape, offsetX, offsetY);
            break;
          case 'ArrowRight':
            e.preventDefault();
            offsetX = offsetAmount;
            handleDuplicate(selectedShape, offsetX, offsetY);
            break;
          case 'ArrowDown':
            e.preventDefault();
            offsetY = offsetAmount;
            handleDuplicate(selectedShape, offsetX, offsetY);
            break;
          case 'ArrowLeft':
            e.preventDefault();
            offsetX = -offsetAmount;
            handleDuplicate(selectedShape, offsetX, offsetY);
            break;
          default:
            break;
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedShape, selectedTool]);

  // Add these handlers for drag and drop
  const handleDragOver = (e) => {
    e.preventDefault(); // Allow drop
    
    if (isDraggingElement && dragElement) {
      // Update mouse position
      setMousePosition({
        x: e.clientX,
        y: e.clientY
      });
    }
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isDraggingElement || !dragElement) return;
    
    // Get stage and pointer position
    const stage = stageRef.current;
    if (!stage) return;
    
    // Get the pointer position relative to the stage
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;
    
    // Convert to stage coordinates (accounting for stage position and zoom)
    const stagePos = {
      x: (pointerPos.x - stage.x()) / stage.scaleX(),
      y: (pointerPos.y - stage.y()) / stage.scaleY()
    };
    
    // Adjust for the drag offset
    const dropPosition = {
      x: stagePos.x - (dragOffset?.offsetX || 0) / zoomLevel,
      y: stagePos.y - (dragOffset?.offsetY || 0) / zoomLevel
    };
    
    // Notify parent component about the drop
    onElementDrop(dropPosition);
  };

  // Add mouse move handler to track position
  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: e.clientX,
        y: e.clientY
      });
    };
    
    if (isDraggingElement) {
      window.addEventListener('mousemove', handleMouseMove);
    }
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isDraggingElement]);
  
  // Update drag preview position when mouse moves
useEffect(() => {
  if (isDraggingElement && dragElement && stageRef.current) {
    const stage = stageRef.current;
    const containerRect = containerRef.current.getBoundingClientRect();
    
    // Calculate position relative to the stage
    const x = (mousePosition.x - containerRect.left - stage.x()) / stage.scaleX();
    const y = (mousePosition.y - containerRect.top - stage.y()) / stage.scaleY();
    
    // Adjust for the drag offset
    setDragPreviewPos({
      x: x - (dragOffset?.offsetX || 0) / stage.scaleX(),
      y: y - (dragOffset?.offsetY || 0) / stage.scaleY()
    });
  }
}, [mousePosition, isDraggingElement, dragElement, dragOffset]);

  // In your parent component:
const handleUpdateShape = (updatedShape) => {
  if (updatedShape._delete) {
    // Handle deletion
    const filteredShapes = shapes.filter(shape => shape.id !== updatedShape.id);
    setShapes(filteredShapes);
    setSelectedShape(null);
  } else {
    // Handle update - this will update the locked status as well
    const updatedShapes = shapes.map(shape => 
      shape.id === updatedShape.id ? updatedShape : shape
    );
    setShapes(updatedShapes);
    setSelectedShape(updatedShape);
  }
};


//handle radial menu actions
  const handleRadialMenuAction = (action) => {
  if (!selectedShape) return;
  
  switch (action) {
    case 'delete':
      // Remove the shape
      const updatedShapes = shapes.filter(s => s.id !== selectedShape.id);
      onAddShape(updatedShapes);
      onShapeSelect(null);
      break;
      
    case 'duplicate':
      // Create a duplicate with offset
      const duplicatedShape = {
        ...selectedShape,
        id: Date.now(),
        x: selectedShape.x + 20,
        y: selectedShape.y + 20
      };
      
      // Check for collisions if it's a rack
      if (selectedShape.type === 'rack' && checkCollision(duplicatedShape, shapes)) {
        alert("Cannot duplicate rack here - it overlaps with another element.");
        break;
      }
      
      onAddShape([...shapes, duplicatedShape]);
      onShapeSelect(duplicatedShape);
      break;
      
    case 'rotate':
      // Rotate the shape by 90 degrees
      const rotatedShapes = shapes.map(s => {
        if (s.id === selectedShape.id) {
          const currentRotation = s.rotation || 0;
          return {
            ...s,
            rotation: (currentRotation + 90) % 360
          };
        }
        return s;
      });
      onAddShape(rotatedShapes);
      break;
      
    case 'flipVertical':
      // Flip vertically
      const flippedVertically = shapes.map(s => {
        if (s.id === selectedShape.id) {
          return {
            ...s,
            height: -s.height,
            y: s.y + s.height
          };
        }
        return s;
      });
      onAddShape(flippedVertically);
      break;
      
    case 'flipHorizontal':
      // Flip horizontally
      const flippedHorizontally = shapes.map(s => {
        if (s.id === selectedShape.id) {
          return {
            ...s,
            width: -s.width,
            x: s.x + s.width
          };
        }
        return s;
      });
      onAddShape(flippedHorizontally);
      break;
  }
  
  // Close the menu
  setShowRadialMenu(false);
};


  // Helper function to format dimension text with appropriate units
  const formatDimension = (pixels) => {
    // Convert pixels to meters
    const meters = pixels * scale;
    
    // Get the current unit configuration
    const currentUnit = units[unit] || units.meters;
    
    // Convert meters to the current unit
    const value = meters / currentUnit.toMeters;
    
    // Format based on unit and value
    if (currentUnit.smallerUnit && value < currentUnit.smallerUnit.threshold) {
      // Use smaller unit for small values
      const smallerValue = value * currentUnit.smallerUnit.divisor;
      return `${smallerValue.toFixed(1)} ${currentUnit.smallerUnit.abbr}`;
    } else {
      // Use regular unit
      return `${value.toFixed(2)} ${currentUnit.abbr}`;
    }
  };

  // Function to handle duplication with enhanced multi-copy support
  const handleDuplicate = (duplicates) => {
    // If it's a single duplicate (for backward compatibility)
    if (!Array.isArray(duplicates)) {
      const shape = duplicates;
      const offsetX = arguments[1] || 0;
      const offsetY = arguments[2] || 0;
      
      // Create a duplicate with offset
      const duplicatedShape = {
        ...shape,
        id: Date.now(),
        x: shape.x + offsetX,
        y: shape.y + offsetY
      };
      
      // Check for collisions if it's a rack
      if (shape.type === 'rack' && checkCollision(duplicatedShape, shapes)) {
        // Show collision warning
        alert("Cannot duplicate rack here - it overlaps with another element.");
        return;
      }
      
      // Add the new shape
      onAddShape([...shapes, duplicatedShape]);
      
      // Select the new shape
      onShapeSelect(duplicatedShape);
      return;
    }
    
    // Handle multiple duplicates
    const newShapes = [...shapes];
    let lastShape = null;
    let hasCollision = false;
    
    // Process each duplicate
    duplicates.forEach(({ shape, offsetX, offsetY }) => {
      const duplicatedShape = {
        ...shape,
        id: Date.now() + Math.random(), // Ensure unique ID
        x: shape.x + offsetX,
        y: shape.y + offsetY
      };
      
      // Check for collisions if it's a rack
      if (shape.type === 'rack' && checkCollision(duplicatedShape, [...shapes, ...newShapes.filter(s => s.id !== shape.id)])) {
        hasCollision = true;
        return;
      }
      
      newShapes.push(duplicatedShape);
      lastShape = duplicatedShape;
    });
    
    if (hasCollision) {
      alert("Some duplicates couldn't be placed due to overlaps.");
    }
    
    if (newShapes.length > shapes.length) {
      // Add the new shapes
      onAddShape(newShapes);
      
      // Select the last shape created
      if (lastShape) {
        onShapeSelect(lastShape);
      }
    }
  };

  // Function to find the closest wall to snap to
  const findWallToSnapTo = (position, element) => {
    const snapThreshold = 20 / zoomLevel; // Adjust threshold based on zoom level
    let closestWall = null;
    let minDistance = snapThreshold;
    let orientation = null;
    let snapPosition = { x: position.x, y: position.y };
    let elementProps = {};
    
    // Look through all shapes to find walls (lines or rectangles)
    shapes.forEach(shape => {
      if (shape.type === 'line') {
        // For line walls
        const points = shape.points;
        const x1 = points[0];
        const y1 = points[1];
        const x2 = points[2];
        const y2 = points[3];
        
        // Calculate distance from point to line segment
        const distance = distanceToLineSegment(position.x, position.y, x1, y1, x2, y2);
        
        if (distance < minDistance) {
          minDistance = distance;
          closestWall = shape;
          
          // Determine if the line is more horizontal or vertical
          const dx = Math.abs(x2 - x1);
          const dy = Math.abs(y2 - y1);
          
          if (dx > dy) {
            // Horizontal wall
            orientation = 'horizontal';
            snapPosition = {
              x: position.x,
              y: (y1 + y2) / 2
            };
            
            // Adjust element properties for horizontal alignment
            elementProps = {
              rotation: 0,
              width: element.width,
              height: element.height
            };
          } else {
            // Vertical wall
            orientation = 'vertical';
            snapPosition = {
              x: (x1 + x2) / 2,
              y: position.y
            };
            
            // Adjust element properties for vertical alignment
            elementProps = {
              rotation: 90,
              width: element.height, // Swap dimensions for vertical orientation
              height: element.width
            };
          }
        }
      } else if (shape.type === 'rectangle' || shape.type === 'wall') {
        // For rectangle walls
        const { x, y, width, height } = shape;
        
        // Check each edge of the rectangle
        // Top edge
        const topDistance = Math.abs(position.y - y);
        if (position.x >= x && position.x <= x + width && topDistance < minDistance) {
          minDistance = topDistance;
          closestWall = shape;
          orientation = 'horizontal';
          snapPosition = { x: position.x, y };
          elementProps = {
            rotation: 0,
            width: element.width,
            height: element.height
          };
        }
        
        // Bottom edge
        const bottomDistance = Math.abs(position.y - (y + height));
        if (position.x >= x && position.x <= x + width && bottomDistance < minDistance) {
          minDistance = bottomDistance;
          closestWall = shape;
          orientation = 'horizontal';
          snapPosition = { x: position.x, y: y + height };
          elementProps = {
            rotation: 0,
            width: element.width,
            height: element.height
          };
        }
        
        // Left edge
        const leftDistance = Math.abs(position.x - x);
        if (position.y >= y && position.y <= y + height && leftDistance < minDistance) {
          minDistance = leftDistance;
          closestWall = shape;
          orientation = 'vertical';
          snapPosition = { x, y: position.y };
          elementProps = {
            rotation: 90,
            width: element.height, // Swap dimensions for vertical orientation
            height: element.width
          };
        }
        
        // Right edge
        const rightDistance = Math.abs(position.x - (x + width));
        if (position.y >= y && position.y <= y + height && rightDistance < minDistance) {
          minDistance = rightDistance;
          closestWall = shape;
          orientation = 'vertical';
          snapPosition = { x: x + width, y: position.y };
          elementProps = {
            rotation: 90,
            width: element.height, // Swap dimensions for vertical orientation
            height: element.width
          };
        }
      }
    });
    
    // If we found a wall to snap to, adjust the position
    if (closestWall) {
      if (orientation === 'horizontal') {
        // For horizontal walls, center horizontally and align to the wall vertically
        snapPosition = {
          x: snapPosition.x - (element.width / 2),
          y: snapPosition.y - (element.height / 2)
        };
      } else {
        // For vertical walls, we need special handling
        // The element will be rotated 90 degrees, so width and height are swapped
        // We need to center it on the wall
        snapPosition = {
          x: snapPosition.x - (element.height / 2), // Use height because it becomes width after rotation
          y: snapPosition.y - (element.width / 2)   // Use width because it becomes height after rotation
        };
      }
      
      return {
        position: snapPosition,
        elementProps
      };
    }
    
    // No wall to snap to, return original position
    return {
      position: {
        x: position.x - element.width / 2,
        y: position.y - element.height / 2
      },
      elementProps: {}
    };
  };

  // Helper function to calculate distance from point to line segment
  const distanceToLineSegment = (px, py, x1, y1, x2, y2) => {
    const A = px - x1;
    const B = py - y1;
    const C = x2 - x1;
    const D = y2 - y1;
    
    const dot = A * C + B * D;
    const lenSq = C * C + D * D;
    let param = -1;
    
    if (lenSq !== 0) {
      param = dot / lenSq;
    }
    
    let xx, yy;
    
    if (param < 0) {
      xx = x1;
      yy = y1;
    } else if (param > 1) {
      xx = x2;
      yy = y2;
    } else {
      xx = x1 + param * C;
      yy = y1 + param * D;
    }
    
    const dx = px - xx;
    const dy = py - yy;
    
    return Math.sqrt(dx * dx + dy * dy);
  };

  // Function to render dimensions for a shape
  const renderDimensions = (shape) => {
    if (!showDimensions) return null;

    switch (shape.type) {
      case 'line': {
        const points = shape.points;
        const x1 = points[0];
        const y1 = points[1];
        const x2 = points[2];
        const y2 = points[3];
        
        // Calculate length of line
        const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        const dimensionText = formatDimension(length);
        
        // Calculate midpoint and angle for text placement
        const midX = (x1 + x2) / 2;
        const midY = (y1 + y2) / 2;
        const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        
        // Offset the text perpendicular to the line
        const offset = 15 / zoomLevel; // Adjust offset based on zoom level
        const perpAngle = (angle + 90) * Math.PI / 180;
        const offsetX = Math.cos(perpAngle) * offset;
        const offsetY = Math.sin(perpAngle) * offset;
        
        return (
          <Group key={`dim-${shape.id}`}>
            <Line
              points={[x1, y1, midX + offsetX, midY + offsetY, x2, y2]}
              stroke="#555"
              strokeWidth={1 / zoomLevel} // Adjust stroke width based on zoom level
              dash={[3 / zoomLevel, 3 / zoomLevel]} // Adjust dash based on zoom level
            />
            <Text
              x={midX + offsetX}
              y={midY + offsetY}
              text={dimensionText}
              fontSize={12 / zoomLevel} // Adjust font size based on zoom level
              fill="#555"
              align="center"
              verticalAlign="middle"
              rotation={angle > 90 || angle < -90 ? angle + 180 : angle}
              offsetX={0}
              offsetY={0}
            />
          </Group>
        );
      }
      case 'rectangle':
      case 'wall':
      case 'door':
      case 'window':
      case 'sliding-door':
      case 'bed':
      case 'sofa':
      case 'table':
      case 'chair':
      case 'rack': {
        const { x, y, width, height, rotation = 0 } = shape;
        const widthText = formatDimension(Math.abs(width));
        const heightText = formatDimension(Math.abs(height));
        
        // Create dimension lines and labels
        return (
          <Group key={`dim-${shape.id}`} rotation={rotation} x={x} y={y}>
            {/* Width dimension */}
            <Line
              points={[0, -10 / zoomLevel, width, -10 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
              dash={[3 / zoomLevel, 3 / zoomLevel]}
            />
            <Line
              points={[0, -15 / zoomLevel, 0, -5 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Line
              points={[width, -15 / zoomLevel, width, -5 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Text
              x={width / 2}
              y={-20 / zoomLevel}
              text={widthText}
              fontSize={12 / zoomLevel}
              fill="#555"
              align="center"
            />
            
            {/* Height dimension */}
            <Line
              points={[width + 10 / zoomLevel, 0, width + 10 / zoomLevel, height]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
              dash={[3 / zoomLevel, 3 / zoomLevel]}
            />
            <Line
              points={[width + 5 / zoomLevel, 0, width + 15 / zoomLevel, 0]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Line
              points={[width + 5 / zoomLevel, height, width + 15 / zoomLevel, height]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Text
              x={width + 20 / zoomLevel}
              y={height / 2}
              text={heightText}
              fontSize={12 / zoomLevel}
              fill="#555"
              align="left"
              verticalAlign="middle"
            />
          </Group>
        );
      }
      case 'circle':
      case 'pillar': {
        let x, y, radius;
        
        if (shape.type === 'circle') {
          x = shape.x;
          y = shape.y;
          radius = shape.radius;
        } else { // pillar
          x = shape.x + shape.width / 2;
          y = shape.y + shape.height / 2;
          radius = shape.width / 2;
        }
        
        const diameterText = formatDimension(radius * 2);
        
        return (
          <Group key={`dim-${shape.id}`}>
            <Line
              points={[x, y - radius - 10 / zoomLevel, x, y + radius + 10 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
              dash={[3 / zoomLevel, 3 / zoomLevel]}
            />
            <Line
              points={[x - 5 / zoomLevel, y - radius - 10 / zoomLevel, x + 5 / zoomLevel, y - radius - 10 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Line
              points={[x - 5 / zoomLevel, y + radius + 10 / zoomLevel, x + 5 / zoomLevel, y + radius + 10 / zoomLevel]}
              stroke="#555"
              strokeWidth={1 / zoomLevel}
            />
            <Text
              x={x + 10 / zoomLevel}
              y={y}
              text={diameterText}
              fontSize={12 / zoomLevel}
              fill="#555"
              verticalAlign="middle"
            />
          </Group>
        );
      }
      default:
        return null;
    }
  };

  // Close context menu when clicking outside
useEffect(() => {
  const handleClickOutside = () => {
    if (contextMenu.visible) {
      setContextMenu(prev => ({ ...prev, visible: false }));
    }
  };
  
  document.addEventListener('click', handleClickOutside);
  return () => document.removeEventListener('click', handleClickOutside);
}, [contextMenu.visible]);

  // handleMouseDown to implement grid and angle snapping for lines
const handleMouseDown = (e) => {
  // Get the stage and pointer position
  const stage = e.target.getStage();
  if (!stage) return;
  
  const pos = stage.getPointerPosition();
  if (!pos) return;
  
  // Convert position from screen coordinates to world coordinates
  const worldPos = {
    x: (pos.x - stage.x()) / stage.scaleX(),
    y: (pos.y - stage.y()) / stage.scaleY()
  };
  
  // CASE 1: Clicking on the stage background with no tool selected - START SELECTION
  if (e.target === stage && !selectedTool) {
    e.evt.preventDefault(); // Prevent default browser behavior
    e.evt.stopPropagation(); // Stop event propagation
    
    // Set selection mode flag
    setIsSelectionMode(true);
    
    // Start marquee selection
    setIsSelecting(true);
    setSelectionRect({
      x: worldPos.x,
      y: worldPos.y,
      width: 0,
      height: 0,
      startX: worldPos.x,
      startY: worldPos.y
    });
    
    // Clear current selection if not holding shift
    if (!e.evt.shiftKey) {
      onShapeSelect(null);
      setSelectedShapes([]);
      setIsMultiSelect(false);
      setSelectionBounds(null);
    } else {
      // If shift is held, prepare for adding to selection
      setIsMultiSelect(true);
    }
    
    // Force a redraw to ensure visual feedback
    stage.batchDraw();
    return;
  } 
  
  // CASE 2: Drawing tool is active - handle drawing
  else if (selectedTool) {
    setIsDrawing(true);
    setStartPoint(worldPos);

    if (selectedTool === 'line') {
      // Create a new line with snapped coordinates
      const snappedX = snapToGrid(worldPos.x);
      const snappedY = snapToGrid(worldPos.y);
      
      const newShape = {
        type: 'line',
        points: [snappedX, snappedY, snappedX, snappedY],
        stroke: '#000',
        strokeWidth: 2,
        id: Date.now(),
      };
      
      setCurrentShape(newShape);
    } else if (selectedTool === 'pencil') {
      setPoints([worldPos.x, worldPos.y]);
    } else if (selectedTool === 'text') {
      // Handle text input
      const textInput = document.createElement('input');
      const stageBox = stage.container().getBoundingClientRect();
      
      textInput.style.position = 'absolute';
      textInput.style.left = `${stageBox.left + pos.x}px`;
      textInput.style.top = `${stageBox.top + pos.y}px`;
      textInput.style.zIndex = 1000;
      
      document.body.appendChild(textInput);
      textInput.focus();
      
      textInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const newTextShape = {
            type: 'text',
            x: worldPos.x,
            y: worldPos.y,
            text: textInput.value,
            fontSize: 16,
            fill: '#000',
            id: Date.now(),
          };
          onAddShape([...shapes, newTextShape]);
          document.body.removeChild(textInput);
        }
      });
      
      textInput.addEventListener('blur', () => {
        document.body.removeChild(textInput);
      });
    } else {
      // Initialize shape based on tool
      let newShape;
      switch (selectedTool) {
        case 'rectangle':
          newShape = {
            type: 'rectangle',
            x: worldPos.x,
            y: worldPos.y,
            width: 0,
            height: 0,
            stroke: '#000',
            fill: 'transparent',
            strokeWidth: 2,
            id: Date.now(),
          };
          break;
        case 'circle':
          newShape = {
            type: 'circle',
            x: worldPos.x,
            y: worldPos.y,
            radius: 0,
            stroke: '#000',
            fill: 'transparent',
            strokeWidth: 2,
            id: Date.now(),
          };
          break;
        default:
          break;
      }
      
      if (newShape) {
        setCurrentShape(newShape);
      }
    }
  }
  // CASE 3: Clicking on a shape - handled by shape's own click handler
};
  
  // Add this useEffect to handle drag and drop events
useEffect(() => {
  const container = containerRef.current;
  
  const handleMouseMove = (e) => {
    if (isDraggingElement) {
      setMousePosition({
        x: e.clientX,
        y: e.clientY
      });
    }
  };
  
  if (container) {
    // Add event listeners
    window.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('dragover', handleDragOver);
    container.addEventListener('drop', handleDrop);
  }
  
  return () => {
    // Clean up event listeners
    window.removeEventListener('mousemove', handleMouseMove);
    if (container) {
      container.removeEventListener('dragover', handleDragOver);
      container.removeEventListener('drop', handleDrop);
    }
  };
}, [isDraggingElement, dragElement, dragOffset, onElementDrop]);

  // Updated handleMouseMove to implement grid and angle snapping for lines
  const handleMouseMove = (e) => {
  // Get the stage and pointer position
  const stage = e.target.getStage();
  if (!stage) return;
  
  const pos = stage.getPointerPosition();
  if (!pos) return;
  
  // Convert position from screen coordinates to world coordinates
  const worldPos = {
    x: (pos.x - stage.x()) / stage.scaleX(),
    y: (pos.y - stage.y()) / stage.scaleY()
  };
  
  setMousePosition(worldPos);
  
  // PRIORITY CASE: Handle marquee selection if active
  if (isSelecting && selectionRect) {
    e.evt.preventDefault(); // Prevent default browser behavior
    
    const newWidth = worldPos.x - selectionRect.startX;
    const newHeight = worldPos.y - selectionRect.startY;
    
    setSelectionRect({
      ...selectionRect,
      x: newWidth < 0 ? worldPos.x : selectionRect.startX,
      y: newHeight < 0 ? worldPos.y : selectionRect.startY,
      width: Math.abs(newWidth),
      height: Math.abs(newHeight)
    });
    
    // Force a redraw to ensure visual feedback
    stage.batchDraw();
    return;
  }
  
  // Handle drawing if active
  if (!isDrawing) return;

  if (selectedTool === 'line' && currentShape) {
    // Get the starting point of the line
    const points = currentShape.points;
    const startX = points[0];
    const startY = points[1];
    
    // Calculate the delta from start to current position
    const dx = worldPos.x - startX;
    const dy = worldPos.y - startY;
    
    // Apply angle snapping
    const snapped = snapToAngle(dx, dy);
    
    // Apply grid snapping to the end point
    const endX = snapToGrid(startX + snapped.dx);
    const endY = snapToGrid(startY + snapped.dy);
    
    // Update the line
    const updatedShape = {
      ...currentShape,
      points: [startX, startY, endX, endY]
    };
    
    setCurrentShape(updatedShape);
  } else if (selectedTool === 'pencil') {
    setPoints([...points, worldPos.x, worldPos.y]);
  } else if (currentShape) {
    // Update shape based on mouse movement
    let updatedShape = { ...currentShape };
    
    switch (selectedTool) {
      case 'rectangle':
        updatedShape.width = worldPos.x - startPoint.x;
        updatedShape.height = worldPos.y - startPoint.y;
        break;
      case 'circle':
        const dx = worldPos.x - startPoint.x;
        const dy = worldPos.y - startPoint.y;
        updatedShape.radius = Math.sqrt(dx * dx + dy * dy);
        break;
      default:
        break;
    }
    
    setCurrentShape(updatedShape);
  }
};

  // Function to calculate the combined bounds of all selected shapes
const calculateSelectionBounds = (selectedItems) => {
  if (!selectedItems || selectedItems.length === 0) {
    console.log("No items to calculate bounds for");
    return null;
  }
  
  console.log("Calculating bounds for", selectedItems.length, "items");
  
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  
  selectedItems.forEach(shape => {
    if (!shape) {
      console.warn("Undefined shape in selection");
      return;
    }
    
    // Calculate bounds based on shape type
    let shapeMinX, shapeMinY, shapeMaxX, shapeMaxY;
    
    try {
      switch (shape.type) {
        case 'circle':
          shapeMinX = shape.x - shape.radius;
          shapeMinY = shape.y - shape.radius;
          shapeMaxX = shape.x + shape.radius;
          shapeMaxY = shape.y + shape.radius;
          break;
        case 'line':
          if (!shape.points || shape.points.length < 4) {
            console.warn("Invalid line points:", shape.points);
            return;
          }
          const points = shape.points;
          shapeMinX = Math.min(points[0], points[2]);
          shapeMaxX = Math.max(points[0], points[2]);
          shapeMinY = Math.min(points[1], points[3]);
          shapeMaxY = Math.max(points[1], points[3]);
          break;
        case 'pillar':
          shapeMinX = shape.x;
          shapeMinY = shape.y;
          shapeMaxX = shape.x + shape.width;
          shapeMaxY = shape.y + shape.height;
          break;
        case 'text':
          shapeMinX = shape.x;
          shapeMinY = shape.y;
          shapeMaxX = shape.x + (shape.text?.length || 1) * (shape.fontSize || 12) * 0.6;
          shapeMaxY = shape.y + (shape.fontSize || 12) * 1.2;
          break;
        default:
          // For rectangles and other shapes with x, y, width, height
          shapeMinX = shape.x;
          shapeMinY = shape.y;
          shapeMaxX = shape.x + (shape.width || 0);
          shapeMaxY = shape.y + (shape.height || 0);
          
          // Apply rotation if needed
          if (shape.rotation === 90) {
            shapeMinX = shape.x;
            shapeMinY = shape.y;
            shapeMaxX = shape.x + (shape.height || 0);
            shapeMaxY = shape.y + (shape.width || 0);
          }
      }
      
      // Update the overall bounds
      minX = Math.min(minX, shapeMinX);
      minY = Math.min(minY, shapeMinY);
      maxX = Math.max(maxX, shapeMaxX);
      maxY = Math.max(maxY, shapeMaxY);
    } catch (error) {
      console.error("Error calculating bounds for shape:", shape, error);
    }
  });
  
  // Ensure we have valid bounds
  if (minX === Infinity || minY === Infinity || maxX === -Infinity || maxY === -Infinity) {
    console.warn("Invalid bounds calculated:", { minX, minY, maxX, maxY });
    return null;
  }
  
  const bounds = {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY
  };
  
  console.log("Calculated bounds:", bounds);
  return bounds;
};

// Add this function to your component
const ensureSelectionBoundsUpdated = (selectedItems) => {
  if (!selectedItems || selectedItems.length === 0) {
    // Clear selection bounds if no items are selected
    setSelectionBounds(null);
    return;
  }
  
  // Calculate and set the selection bounds
  const bounds = calculateSelectionBounds(selectedItems);
  
  console.log("Updating selection bounds:", bounds);
  
  // Only update if bounds are valid
  if (bounds && bounds.width > 0 && bounds.height > 0) {
    setSelectionBounds(bounds);
  } else {
    console.warn("Invalid bounds calculated:", bounds);
  }
};

// Update your useEffect to watch for changes in selectedShapes
useEffect(() => {
  // When selectedShapes changes, update the selection bounds
  if (isMultiSelect && selectedShapes.length > 0) {
    // Use the function directly with selectedShapes
    const bounds = calculateSelectionBounds(selectedShapes);
    if (bounds) {
      setSelectionBounds(bounds);
    }
  } else if (!isMultiSelect || selectedShapes.length === 0) {
    setSelectionBounds(null);``
  }
}, [selectedShapes, isMultiSelect]);

  // Helper function to check if a shape is inside the selection rectangle
const isShapeInSelection = (shape, rect) => {
  // Skip locked shapes
  if (shape.locked) return false;
  
  // Get shape bounds based on shape type
  let shapeBounds;
  
  try {
    switch (shape.type) {
      case 'circle':
        shapeBounds = {
          x: shape.x - shape.radius,
          y: shape.y - shape.radius,
          width: shape.radius * 2,
          height: shape.radius * 2
        };
        break;
      case 'line':
        const points = shape.points || [0, 0, 0, 0];
        const minX = Math.min(points[0], points[2]);
        const maxX = Math.max(points[0], points[2]);
        const minY = Math.min(points[1], points[3]);
        const maxY = Math.max(points[1], points[3]);
        
        shapeBounds = {
          x: minX,
          y: minY,
          width: maxX - minX || 1, // Ensure non-zero width
          height: maxY - minY || 1  // Ensure non-zero height
        };
        break;
      case 'pillar':
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width || 1,
          height: shape.height || 1
        };
        break;
      case 'text':
        // For text, create a reasonable bounding box
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: (shape.text?.length || 1) * (shape.fontSize || 12) * 0.6,
          height: (shape.fontSize || 12) * 1.2
        };
        break;
      default:
        // For rectangles and other shapes with x, y, width, height
        shapeBounds = {
          x: shape.x,
          y: shape.y,
          width: shape.width || 1,
          height: shape.height || 1
        };
        
        // Apply rotation if needed
        if (shape.rotation === 90) {
          // For 90-degree rotated shapes, swap width and height
          shapeBounds = {
            x: shape.x,
            y: shape.y,
            width: shape.height || 1,
            height: shape.width || 1
          };
        }
    }
    
    // Check if shape bounds are inside or intersect with selection rectangle
    // For a shape to be selected, it must be at least partially inside the selection rectangle
    return (
      rect.x <= shapeBounds.x + shapeBounds.width &&
      rect.x + rect.width >= shapeBounds.x &&
      rect.y <= shapeBounds.y + shapeBounds.height &&
      rect.y + rect.height >= shapeBounds.y
    );
  } catch (error) {
    console.error("Error in isShapeInSelection for shape:", shape, error);
    return false;
  }
};

// Add this function to your component
const forceUpdateSelectionBounds = () => {
  if (selectedShapes.length > 0) {
    const bounds = calculateSelectionBounds(selectedShapes);
    console.log("Force updating selection bounds:", bounds);
    setSelectionBounds(bounds);
    
    // Force a redraw
    if (stageRef.current) {
      stageRef.current.batchDraw();
    }
  }
};

// Add this function to your component
const selectEntireGroup = (shape) => {
  if (!shape.groupId) return;
  
  // Find all shapes in this group
  const groupShapes = shapes.filter(s => s.groupId === shape.groupId);
  
  // Select all shapes in the group
  setSelectedShapes(groupShapes);
  setIsMultiSelect(true);
  
  // Calculate and set the selection bounds
  const bounds = calculateSelectionBounds(groupShapes);
  setSelectionBounds(bounds);
  
  // Also set the clicked shape as the primary selected shape
  onShapeSelect(shape);
};
const handleMouseUp = (e) => {
  // Get the stage
  const stage = e.target?.getStage();
  
  // PRIORITY CASE: Handle marquee selection completion
  if (isSelecting && selectionRect) {
    // Reset selection mode flag
    setIsSelectionMode(false);
    setIsSelecting(false);
    
    // Only process selection if the rectangle has some minimum size
    // This prevents accidental selections when clicking
    if (selectionRect.width > 3 || selectionRect.height > 3) {
      console.log("Processing selection with rect:", selectionRect);
      
      // Find shapes that are inside the selection rectangle
      const selectedItems = shapes.filter(shape => {
        const isInside = isShapeInSelection(shape, selectionRect);
        console.log(`Shape ${shape.id} (${shape.type}) inside selection: ${isInside}`);
        return isInside;
      });
      
      console.log("Selected items:", selectedItems.length);
      
      if (selectedItems.length > 0) {
        // If shift was held, add to existing selection
        if (isMultiSelect && selectedShapes.length > 0) {
          // Combine existing selection with new selection, avoiding duplicates
          const existingIds = selectedShapes.map(s => s.id);
          const newItems = selectedItems.filter(s => !existingIds.includes(s.id));
          const combinedSelection = [...selectedShapes, ...newItems];
          
          console.log("Combined selection:", combinedSelection.length);
          setSelectedShapes(combinedSelection);
          
          // Calculate and set the combined selection bounds
          const bounds = calculateSelectionBounds(combinedSelection);
          setSelectionBounds(bounds);
        } else {
          // New selection
          console.log("New selection:", selectedItems.length);
          setSelectedShapes(selectedItems);
          
          // Calculate and set the selection bounds
          const bounds = calculateSelectionBounds(selectedItems);
          setSelectionBounds(bounds);
        }
        
        // If only one shape is selected, use the regular selection mechanism
        if (selectedItems.length === 1 && !isMultiSelect) {
          console.log("Single shape selected, using regular selection");
          onShapeSelect(selectedItems[0]);
          setSelectedShapes([]);
          setIsMultiSelect(false);
          setSelectionBounds(null);
        } else if (selectedItems.length > 0) {
          // For multiple selection, clear the single selection
          console.log("Multiple shapes selected");
          onShapeSelect(null);
          setIsMultiSelect(true);
        }
      } else {
        console.log("No shapes selected");
        // If no shapes were selected and not adding to selection (no shift key)
        if (!isMultiSelect) {
          // Clear any existing selection
          setSelectedShapes([]);
          setIsMultiSelect(false);
          setSelectionBounds(null);
          onShapeSelect(null);
        }
      }
    } else {
      console.log("Selection too small, treating as click");
      // If the selection rectangle is too small, treat it as a click
      // Clear selection if not holding shift
      if (!isMultiSelect) {
        setSelectedShapes([]);
        setIsMultiSelect(false);
        setSelectionBounds(null);
        onShapeSelect(null);
      }
    }
    
    // Clear selection rectangle
    setSelectionRect(null);
    
    // Force a redraw to ensure visual feedback
    if (stage) stage.batchDraw();
    return;
  }
  
  // Reset selection mode flag
  setIsSelectionMode(false);
  
  // Handle drawing completion
  if (!isDrawing) return;
  setIsDrawing(false);

  if (selectedTool === 'pencil' && points.length > 2) {
    const newShape = {
      type: 'pencil',
      points: points,
      stroke: '#000',
      strokeWidth: 2,
      id: Date.now(),
    };
    onAddShape([...shapes, newShape]);
    setPoints([]);
  } else if (currentShape) {
    onAddShape([...shapes, currentShape]);
    setCurrentShape(null);
  }
};

  // Add this function to your component
const handleDragMove = (e, shape) => {
  // Skip if shape is locked
  if (shape.locked) return;
  
  // If we're dragging a group
  if (isDraggingGroup && shape.groupId === draggedGroupId) {
    // Calculate new position based on mouse position and offset
    const newX = e.evt.clientX - groupDragOffset.x;
    const newY = e.evt.clientY - groupDragOffset.y;
    
    // Calculate the delta from the original position
    let dx, dy;
    
    if (shape.type === 'line') {
      dx = newX - shape.points[0];
      dy = newY - shape.points[1];
    } else if (shape.type === 'pillar') {
      dx = newX - (shape.x + shape.width/2);
      dy = newY - (shape.y + shape.height/2);
    } else {
      dx = newX - shape.x;
      dy = newY - shape.y;
    }
    
    // Update all shapes in the group with the same delta
    const updatedShapes = shapes.map(s => {
      if (s.groupId === shape.groupId) {
        if (s.type === 'line') {
          return {
            ...s,
            points: [
              s.points[0] + dx,
              s.points[1] + dy,
              s.points[2] + dx,
              s.points[3] + dy
            ]
          };
        } else if (s.type === 'pillar') {
          return {
            ...s,
            x: s.x + dx,
            y: s.y + dy
          };
        } else {
          return {
            ...s,
            x: s.x + dx,
            y: s.y + dy
          };
        }
      }
      return s;
    });
    
    // Update shapes
    onAddShape(updatedShapes);
    
    // Update the dragged shape's position to match the mouse
    if (shape.type === 'line') {
      e.target.points([newX, newY, shape.points[2] + dx, shape.points[3] + dy]);
    } else if (shape.type === 'pillar') {
      e.target.position({ x: newX, y: newY });
    } else {
      e.target.position({ x: newX, y: newY });
    }
  }
};

// Add this function to your component
const updateRadialMenuPosition = (shape) => {
  if (!shape || !showRadialMenu) return;
  
  let menuX, menuY;
  
  switch (shape.type) {
    case 'circle':
      menuX = shape.x;
      menuY = shape.y;
      break;
    case 'line':
      const points = shape.points;
      menuX = (points[0] + points[2]) / 2;
      menuY = (points[1] + points[3]) / 2;
      break;
    case 'pillar':
      menuX = shape.x + shape.width / 2;
      menuY = shape.y + shape.height / 2;
      break;
    default:
      menuX = shape.x + (shape.width || 0) / 2;
      menuY = shape.y + (shape.height || 0) / 2;
  }
  
  setRadialMenuPosition({ x: menuX, y: menuY });
  
  // Force immediate redraw
  if (stageRef.current) {
    stageRef.current.batchDraw();
  }
};
const handleDragEnd = (e, shape) => {
   setIsDragging(false);
  // Reset group dragging state
  setIsDraggingGroup(false);
  setDraggedGroupId(null);
  // If the shape is locked or in a locked group, revert to original position
  const isGroupLocked = shape.groupId && shapes.some(s => s.groupId === shape.groupId && s.locked);
  if (shape.locked || isGroupLocked) {
    if (shape.type === 'pillar') {
      e.target.position({
        x: shape.x + shape.width/2,
        y: shape.y + shape.height/2
      });
    } else if (shape.type === 'line') {
      e.target.position({
        x: shape.points[0],
        y: shape.points[1]
      });
    } else {
      e.target.position({
        x: shape.x,
        y: shape.y
      });
    }
    return;
  }
  
  // Get the new position from Konva
  const newKonvaX = e.target.x();
  const newKonvaY = e.target.y();
  
  // Calculate the delta based on the shape type
  let dx, dy;
  
  if (shape.type === 'pillar') {
    // For pillars, calculate delta from center to center
    dx = newKonvaX - (shape.x + shape.width/2);
    dy = newKonvaY - (shape.y + shape.height/2);
  } else if (shape.type === 'line') {
    // For lines, calculate delta from first point
    dx = newKonvaX - shape.points[0];
    dy = newKonvaY - shape.points[1];
  } else {
    // For other shapes, calculate delta from top-left
    dx = newKonvaX - shape.x;
    dy = newKonvaY - shape.y;
  }
  
  // Handle group dragging
  if (shape.groupId && isDraggingGroup) {
    // Update all shapes in the group with the final delta
    const updatedShapes = shapes.map(s => {
      if (s.groupId === shape.groupId) {
        if (s.type === 'line') {
          return {
            ...s,
            points: [
              s.points[0] + dx,
              s.points[1] + dy,
              s.points[2] + dx,
              s.points[3] + dy
            ]
          };
        } else if (s.type === 'pillar') {
          return {
            ...s,
            x: s.x + dx,
            y: s.y + dy
          };
        } else {
          return {
            ...s,
            x: s.x + dx,
            y: s.y + dy
          };
        }
      }
      return s;
    });
    
    // Update shapes
    onAddShape(updatedShapes);
    
    // Update selected shape if this is the currently selected one
    if (selectedShape && selectedShape.groupId === shape.groupId) {
      const updatedShape = updatedShapes.find(s => s.id === selectedShape.id);
      onShapeSelect(updatedShape);
      
      // Update radial menu position
      if (showRadialMenu) {
        updateRadialMenuPosition(updatedShape);
      }
    }
    
    // Update multi-selection if applicable
    if (isMultiSelect && selectedShapes.some(s => s.groupId === shape.groupId)) {
      const updatedSelectedShapes = selectedShapes.map(s => {
        return updatedShapes.find(us => us.id === s.id) || s;
      });
      
      setSelectedShapes(updatedSelectedShapes);
      const bounds = calculateSelectionBounds(updatedSelectedShapes);
      setSelectionBounds(bounds);
    }
  } else {
    // Handle individual shape dragging
    let newShape;
    
    if (shape.type === 'line') {
      newShape = {
        ...shape,
        points: [
          shape.points[0] + dx,
          shape.points[1] + dy,
          shape.points[2] + dx,
          shape.points[3] + dy
        ]
      };
    } else {
      newShape = {
        ...shape,
        x: shape.x + dx,
        y: shape.y + dy
      };
    }
    
    // Check for collisions if it's a rack
    if (shape.type === 'rack' && checkCollision(newShape, shapes)) {
      // Revert to original position
      e.target.position({
        x: shape.x,
        y: shape.y
      });
      
      // Show collision warning
      alert("Cannot move rack here - it overlaps with another element.");
      return;
    }
    
    // Special handling for doors and windows
    if (shape.type === 'door' || shape.type === 'window' || shape.type === 'sliding-door') {
      // Calculate center position
      let centerX, centerY;
      
      if (shape.rotation === 90) {
        centerX = shape.x + shape.height/2 + dx;
        centerY = shape.y + shape.width/2 + dy;
      } else {
        centerX = shape.x + shape.width/2 + dx;
        centerY = shape.y + shape.height/2 + dy;
      }
      
      // Get original element properties
      const originalElement = {
        width: shape.rotation === 90 ? shape.height : shape.width,
        height: shape.rotation === 90 ? shape.width : shape.height
      };
      
      // Find wall to snap to
      const snappedPos = findWallToSnapTo({ x: centerX, y: centerY }, originalElement);
      
      // Update the shape with the snapped position and properties
      const updatedShapes = shapes.map(s => {
        if (s.id === shape.id) {
          return {
            ...s,
            ...snappedPos.elementProps,
            x: snappedPos.position.x,
            y: snappedPos.position.y
          };
        }
        return s;
      });
      
      onAddShape(updatedShapes);
      
      // Update selected shape if this is the currently selected one
      if (selectedShape && selectedShape.id === shape.id) {
        const updatedShape = updatedShapes.find(s => s.id === shape.id);
        onShapeSelect(updatedShape);
        
        // Update radial menu position
        if (showRadialMenu) {
          updateRadialMenuPosition(updatedShape);
        }
      }
    } else {
      // For other shapes, just update the position
      const updatedShapes = shapes.map(s => {
        if (s.id === shape.id) {
          if (s.type === 'line') {
            return {
              ...s,
              points: [
                s.points[0] + dx,
                s.points[1] + dy,
                s.points[2] + dx,
                s.points[3] + dy
              ]
            };
          } else {
            return {
              ...s,
              x: s.x + dx,
              y: s.y + dy
            };
          }
        }
        return s;
      });
      
      onAddShape(updatedShapes);
      
      // Update selected shape if this is the currently selected one
      if (selectedShape && selectedShape.id === shape.id) {
        const updatedShape = updatedShapes.find(s => s.id === shape.id);
        onShapeSelect(updatedShape);
        
        // Update radial menu position
        if (showRadialMenu) {
          updateRadialMenuPosition(updatedShape);
        }
      }
    }
  }
  
  // Reset group dragging state
  setIsDraggingGroup(false);
  setDraggedGroupId(null);
};
  
 // Calculate grid bounds based on zoom and position
const gridBounds = {
  startX: -stagePosition.x / zoomLevel,
  startY: -stagePosition.y / zoomLevel,
  endX: (stageSize.width - stagePosition.x) / zoomLevel,
  endY: (stageSize.height - stagePosition.y) / zoomLevel
};

// Round to nearest grid size to avoid too many lines
const startX = Math.floor(gridBounds.startX / gridSize) * gridSize;
const startY = Math.floor(gridBounds.startY / gridSize) * gridSize;
const endX = Math.ceil(gridBounds.endX / gridSize) * gridSize;
const endY = Math.ceil(gridBounds.endY / gridSize) * gridSize;

// Vertical lines
for (let i = startX; i <= endX; i += gridSize) {
  gridLines.push(
    <Line
      key={`v-${i}`}
      points={[i, startY, i, endY]}
      stroke="#ddd"
      strokeWidth={1 / zoomLevel}
    />
  );
}

// Horizontal lines
for (let i = startY; i <= endY; i += gridSize) {
  gridLines.push(
    <Line
      key={`h-${i}`}
      points={[startX, i, endX, i]}
      stroke="#ddd"
      strokeWidth={1 / zoomLevel}
    />
  );
}
  // Calculate scale bar dimensions for the current unit
  const calculateScaleBarWidth = () => {
    const currentUnit = units[unit] || units.meters;
    const pixelsPerMeter = 1 / scale;
    const pixelsPerUnit = pixelsPerMeter * currentUnit.toMeters;
    
    // Determine a nice round number for the scale bar
    let unitValue;
    if (pixelsPerUnit > 200) {
      unitValue = 0.1; // Show 0.1 unit if 1 unit is too large
    } else if (pixelsPerUnit > 100) {
      unitValue = 0.2; // Show 0.2 unit
    } else if (pixelsPerUnit > 50) {
      unitValue = 0.5; // Show 0.5 unit
    } else {
      unitValue = 1; // Show 1 unit
    }
    
    return {
      width: pixelsPerUnit * unitValue / zoomLevel,
      label: `${unitValue} ${currentUnit.abbr}`
    };
  };

  const scaleBar = calculateScaleBarWidth();

  // Render element preview when dragging
  const renderDragElementPreview = () => {
  if (!isDraggingElement || !dragElement) return null;
  
  // Render different shapes based on element type
  if (dragElement.isCircle) {
    return (
      <Circle
        x={dragPreviewPos.x + dragElement.width / 2}
        y={dragPreviewPos.y + dragElement.height / 2}
        radius={dragElement.width / 2}
        fill={dragElement.fill}
        stroke={dragElement.stroke}
        strokeWidth={dragElement.strokeWidth / zoomLevel}
        opacity={0.7}
        perfectDrawEnabled={false}
        listening={false}
      />
    );
  } else {
    return (
      <Rect
        x={dragPreviewPos.x}
        y={dragPreviewPos.y}
        width={dragElement.width}
        height={dragElement.height}
        fill={dragElement.fill}
        stroke={dragElement.stroke}
        strokeWidth={dragElement.strokeWidth / zoomLevel}
        strokeDasharray={dragElement.dash}
        opacity={0.7}
        perfectDrawEnabled={false}
        listening={false}
      />
    );
  }
};

  // Handle stage drag
  const handleStageDragStart = () => {
    // Disable stage dragging when:
    // 1. A tool is selected
    // 2. We're in selection mode
    // 3. We're actively selecting
    if (selectedTool || isSelectionMode || isSelecting) {
      return false;
    }
    return true;
  };

  // Update handleStageClick to clear multi-selection
    const handleStageClick = (e) => {
      // Only deselect if clicking on the stage itself (not on a shape),
      // and no drawing tool is active, and not in the middle of a selection
      if (e.target === e.target.getStage() && !selectedTool && !isSelecting) {
        console.log("Clearing selection from stage click");
        onShapeSelect(null);
        setShowRadialMenu(false);
        setContextMenu({ ...contextMenu, visible: false });
        setSelectedShapes([]);
        setIsMultiSelect(false);
        setSelectionBounds(null);
        
        // Force a redraw
        if (stageRef.current) {
          stageRef.current.batchDraw();
        }
      }
    };

    
const updateGroupPosition = (groupId, x, y) => {
  setGroups((prevGroups) =>
    prevGroups.map((g) =>
      g.id === groupId ? { ...g, x, y } : g
    )
  );
};


// Add this function to handle right-click on the stage when shapes are multi-selected
const handleMultiSelectContextMenu = (e) => {
  if (isMultiSelect && selectedShapes.length > 0) {
    e.evt.preventDefault();
    
    // Get position for context menu
    const stage = e.target.getStage();
    const pos = stage.getPointerPosition();
    
    // Show context menu at mouse position
    setContextMenu({
      visible: true,
      x: pos.x,
      y: pos.y,
      targetShape: null, // No single target shape
      isMultiSelect: true // Flag to indicate multi-selection context menu
    });
  }
};
  return (
  <div 
  className="canvas-container" 
  ref={containerRef}
  onDragOver={handleDragOver}
  onDrop={handleDrop}
>
    <Stage
          width={stageSize.width}
          height={stageSize.height}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={handleStageClick}
          onContextMenu={handleMultiSelectContextMenu} // Add this handler
          ref={stageRef}
          draggable={!selectedTool && !isSelecting}
          onDragStart={handleStageDragStart}
          onDragEnd={() => {
            if (stageRef.current) {
              setStagePosition(stageRef.current.position());
            }
          }}
        >
      <Layer>
        {/* Grid Layer */}
        {gridLines}
      </Layer>
      <Layer>
        
        {/* Existing Shapes */}
        {shapes.map(renderShape)}

          {/* Group outlines for locked groups */}
        {renderGroupOutlines()}
        
        {/* Duplicate Controls - only show for selected shape that is not locked*/}
      {selectedShape && !selectedShape.locked && !isRightClickSelection && !isDragging && (
      <DuplicateControls 
        shape={selectedShape} 
        onDuplicate={handleDuplicate}
        zoomLevel={zoomLevel}
      />
    )}
        
        {/* Dimensions */}
        {showDimensions && shapes.map(renderDimensions)}
        
        {/* Currently Drawing Shape */}
        {isDrawing && selectedTool === 'pencil' && (
          <Line
            points={points}
            stroke="#000"
            strokeWidth={2}
            tension={0.5}
            lineCap="round"
            lineJoin="round"
          />
        )}
        
        {/* Currently Drawing Line with Measurement */}
        {isDrawing && selectedTool === 'line' && currentShape && (
          <React.Fragment>
            <Line
              points={currentShape.points}
              stroke="red"
              strokeWidth={2}
            />
            {showDimensions && (
              <Text
                x={(currentShape.points[0] + currentShape.points[2]) / 2}
                y={(currentShape.points[1] + currentShape.points[3]) / 2 - 20 / zoomLevel}
                text={formatDimension(distance(
                  currentShape.points[0], 
                  currentShape.points[1], 
                  currentShape.points[2], 
                  currentShape.points[3]
                ))}
                fontSize={14 / zoomLevel}
                fill="red"
                align="center"
              />
            )}
          </React.Fragment>
        )}
        
        {/* Other currently drawing shapes */}
        {currentShape && selectedTool !== 'line' && renderShape(currentShape)}
        
        {/* Element being dragged */}
        {renderDragElementPreview()}

         {/* Selection Rectangle */}
       {isSelecting && selectionRect && (
        <Rect
          x={selectionRect.x}
          y={selectionRect.y}
          width={selectionRect.width}
          height={selectionRect.height}
          fill="rgba(0, 161, 255, 0.2)" // More visible fill
          stroke="rgb(0, 161, 255)"
          strokeWidth={2 / zoomLevel} // Thicker stroke
          dash={[5 / zoomLevel, 5 / zoomLevel]}
          perfectDrawEnabled={false}
          listening={false}
        />
      )}

     
{/* Enhanced Selection Outline - ALWAYS render if we have selection bounds */}
{selectionBounds && selectedShapes.length > 0 && (
  <>
    {/* Only show orange selection outline if the selected shapes aren't all part of the same group */}
    {!selectedShapes.every(shape => shape.groupId && 
        selectedShapes.every(s => s.groupId === shape.groupId)) && (
      <Rect
        x={selectionBounds.x - 4 / zoomLevel}
        y={selectionBounds.y - 4 / zoomLevel}
        width={selectionBounds.width + 8 / zoomLevel}
        height={selectionBounds.height + 8 / zoomLevel}
        stroke="#ff9800" // Orange color
        strokeWidth={2 / zoomLevel}
        fill="rgba(255, 152, 0, 0.05)" // Very light fill for better visibility
        perfectDrawEnabled={false}
        listening={true}
        draggable={true}
        onContextMenu={(e) => {
          e.evt.preventDefault();
          e.cancelBubble = true;
          
          // Get position for context menu
          const stage = e.target.getStage();
          const pos = stage.getPointerPosition();
          
          // Show context menu at mouse position
          setContextMenu({
            visible: true,
            x: pos.x,
            y: pos.y,
            targetShape: null,
            isMultiSelect: true
          });
        }}
        onDragStart={(e) => {
          // Store initial position
          const initialPos = { x: e.target.x(), y: e.target.y() };
          setDragStartPosition(initialPos);
        }}
        onDragEnd={(e) => {
          // Calculate offset from initial position
          const offsetX = e.target.x() - dragStartPosition.x;
          const offsetY = e.target.y() - dragStartPosition.y;
          
          // Move all selected shapes by this offset
          const updatedShapes = shapes.map(s => {
            if (selectedShapes.some(selected => selected.id === s.id) && !s.locked) {
              // Move based on shape type
              if (s.type === 'line') {
                return {
                  ...s,
                  points: [
                    s.points[0] + offsetX,
                    s.points[1] + offsetY,
                    s.points[2] + offsetX,
                    s.points[3] + offsetY
                  ]
                };
              } else {
                return {
                  ...s,
                  x: s.x + offsetX,
                  y: s.y + offsetY
                };
              }
            }
            return s;
          });
          
          // Update shapes
          onAddShape(updatedShapes);
          
          // Update selected shapes with new positions
          const updatedSelectedShapes = selectedShapes.map(shape => {
            const updatedShape = updatedShapes.find(s => s.id === shape.id);
            return updatedShape || shape;
          });
          
          // Update state
          setSelectedShapes(updatedSelectedShapes);
          
          // Force recalculation of bounds
          setTimeout(() => {
            ensureSelectionBoundsUpdated(updatedSelectedShapes);
          }, 0);
        }}
      />
    )}
    
    {/* Only show corner handles if not all selected shapes are part of the same group */}
    {!selectedShapes.every(shape => shape.groupId && 
        selectedShapes.every(s => s.groupId === shape.groupId)) && (
      [
        { x: selectionBounds.x - 4 / zoomLevel, y: selectionBounds.y - 4 / zoomLevel },
        { x: selectionBounds.x + selectionBounds.width + 4 / zoomLevel, y: selectionBounds.y - 4 / zoomLevel },
        { x: selectionBounds.x - 4 / zoomLevel, y: selectionBounds.y + selectionBounds.height + 4 / zoomLevel },
        { x: selectionBounds.x + selectionBounds.width + 4 / zoomLevel, y: selectionBounds.y + selectionBounds.height + 4 / zoomLevel }
      ].map((point, i) => (
        <Rect
          key={`handle-${i}`}
          x={point.x - 4 / zoomLevel}
          y={point.y - 4 / zoomLevel}
          width={8 / zoomLevel}
          height={8 / zoomLevel}
          fill="#ff9800"
          stroke="#fff"
          strokeWidth={1 / zoomLevel}
          perfectDrawEnabled={false}
          listening={false}
        />
      ))
    )}
  </>
)}
        
        {/* Multi-selection indicators */}
        {isMultiSelect && selectedShapes.length > 0 && selectedShapes.map(shape => {

          if (shape.groupId) return null;
          // Determine bounding box based on shape type
          let x, y, width, height;
          
          switch (shape.type) {
            case 'circle':
              x = shape.x - shape.radius;
              y = shape.y - shape.radius;
              width = shape.radius * 2;
              height = shape.radius * 2;
              break;
            case 'line':
              const points = shape.points;
              const minX = Math.min(points[0], points[2]);
              const maxX = Math.max(points[0], points[2]);
              const minY = Math.min(points[1], points[3]);
              const maxY = Math.max(points[1], points[3]);
              
              x = minX;
              y = minY;
              width = maxX - minX;
              height = maxY - minY;
              break;
            case 'pillar':
              x = shape.x;
              y = shape.y;
              width = shape.width;
              height = shape.height;
              break;
            default:
              x = shape.x;
              y = shape.y;
              width = shape.width;
              height = shape.height;
              
              if (shape.rotation === 90) {
                width = shape.height;
                height = shape.width;
              }
          }
          // Draw selection indicator
          return (
            <Rect
              key={`selection-${shape.id}`}
              x={x - 2 / zoomLevel}
              y={y - 2 / zoomLevel}
              width={width + 4 / zoomLevel}
              height={height + 4 / zoomLevel}
              // stroke="#3498db"
              strokeWidth={2 / zoomLevel}
              dash={[5 / zoomLevel, 5 / zoomLevel]}
              fill="transparent"
            />
          );
        })}
      
      
{/* Radial Menu */}
{selectedShape && !selectedShape.locked && !isRightClickSelection && !isDragging && showRadialMenu && (
  <RadialMenu
    x={radialMenuPosition.x}
    y={radialMenuPosition.y}
    isOpen={radialMenuOpen}
    onToggle={toggleRadialMenu}
    onAction={handleRadialMenuAction}
    zoomLevel={zoomLevel}
    selectedShape={selectedShape}
  />
)}
     </Layer> 
    </Stage>
    
    {/* Scale indicator */}
    <div className="scale-indicator" style={{ display: showDimensions ? 'flex' : 'none' }}>
      <div className="scale-bar">
        <div 
          className="scale-segment" 
          style={{ width: `${scaleBar.width}px` }}
        ></div>
      </div>
      <div className="scale-label">{scaleBar.label}</div>
    </div>

{/* Context Menu */}
{contextMenu.visible && (
  <div 
    className="context-menu"
    style={{
      position: 'absolute',
      top: `${contextMenu.y}px`,
      left: `${contextMenu.x}px`,
      background: '#fff',
      border: '1px solid #ccc',
      borderRadius: '4px',
      boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
      zIndex: 1000
    }}
    onClick={(e) => e.stopPropagation()}
  >
    <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
      {contextMenu.isMultiSelect ? (
        // Multi-selection context menu options
        <>
          <li 
            style={{ 
              padding: '5px 9px', 
              cursor: 'pointer',
              transition: 'background-color 0.2s',
              borderBottom: '1px solid #eee'
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0f0f0'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            onClick={() => {
              // Delete selected shapes
              const updatedShapes = shapes.filter(shape => 
                !selectedShapes.some(selected => selected.id === shape.id) || shape.locked
              );
              
              onAddShape(updatedShapes);
              setSelectedShapes([]);
              setIsMultiSelect(false);
              setSelectionBounds(null);
              setContextMenu({ ...contextMenu, visible: false });
            }}
          >
            Delete Selected
          </li>
          <li 
            style={{ 
              padding: '5px 9px', 
              cursor: 'pointer',
              transition: 'background-color 0.2s',
              borderBottom: '1px solid #eee'
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0f0f0'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            onClick={() => {
              // Duplicate selected shapes
              const duplicatesToAdd = [];
              
              selectedShapes.forEach(shape => {
                if (!shape.locked) {
                  let duplicatedShape;
                  
                  if (shape.type === 'line') {
                    duplicatedShape = {
                      ...shape,
                      id: Date.now() + Math.random(),
                      points: [
                        shape.points[0] + 20,
                        shape.points[1] + 20,
                        shape.points[2] + 20,
                        shape.points[3] + 20
                      ]
                    };
                  } else {
                    duplicatedShape = {
                      ...shape,
                      id: Date.now() + Math.random(),
                      x: shape.x + 20,
                      y: shape.y + 20
                    };
                  }
                  
                  // Skip collision check for non-rack items
                  if (shape.type !== 'rack' || !checkCollision(duplicatedShape, [...shapes])) {
                    duplicatesToAdd.push(duplicatedShape);
                  }
                }
              });
              
              if (duplicatesToAdd.length > 0) {
                onAddShape([...shapes, ...duplicatesToAdd]);
                
                // Select the new duplicates
                setSelectedShapes(duplicatesToAdd);

                 // Update selection bounds
                 const bounds = calculateSelectionBounds(duplicatesToAdd);
                 setSelectionBounds(bounds);
              }
              
              setContextMenu({ ...contextMenu, visible: false });
            }}
          >
            Duplicate Selected
          </li>
          {/* Add Group option for multi-selection */}
          {selectedShapes.length >= 2 && (
            <li 
              style={{ 
                padding: '5px 9px', 
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0f0f0'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              onClick={() => {
                createGroup();
                setContextMenu({ ...contextMenu, visible: false });
              }}
            >
              Group Elements
            </li>
          )}
        </>
      ) : (
        // Single shape context menu options
        <>
          <li 
            style={{ 
              padding: '5px 9px', 
              cursor: 'pointer',
              transition: 'background-color 0.2s'
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0f0f0'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            onClick={() => {
              // Toggle lock status
              if (contextMenu.targetShape) {
                const isCurrentlyLocked = contextMenu.targetShape.locked;

                // Check if the shape is part of a group
                const groupId = contextMenu.targetShape.groupId;
                
               const updatedShapes = shapes.map(s => {
                // If the shape is part of a group and we're operating on a group member,
                // apply the lock/unlock to all shapes in the group
                if (groupId && s.groupId === groupId) {
                  return {
                    ...s,
                    locked: !isCurrentlyLocked
                  };
                } 
                // Otherwise, just update the individual shape
                else if (s.id === contextMenu.targetShape.id) {
                  return {
                    ...s,
                    locked: !s.locked
                  };
                }
                return s;
              });
                
                // Hide context menu
                setContextMenu({ ...contextMenu, visible: false });
                
                // Update shapes array
                onAddShape(updatedShapes);
                
                // Update the selected shape if it's the one being locked/unlocked
                if (selectedShape && selectedShape.id === contextMenu.targetShape.id) {
                  const updatedShape = updatedShapes.find(s => s.id === contextMenu.targetShape.id);
                  
                  // If we're unlocking a shape, reset right-click flag and show UI elements
                  if (isCurrentlyLocked && !groupId) {
                    // Reset the right-click selection flag to ensure duplicate arrows appear
                    setIsRightClickSelection(false);
                    
                    // Calculate position based on shape type
                    let menuX, menuY;
                    
                    switch (updatedShape.type) {
                      case 'circle':
                        menuX = updatedShape.x;
                        menuY = updatedShape.y;
                        break;
                      case 'line':
                        const points = updatedShape.points;
                        menuX = (points[0] + points[2]) / 2;
                        menuY = (points[1] + points[3]) / 2;
                        break;
                      case 'pillar':
                        menuX = updatedShape.x + updatedShape.width / 2;
                        menuY = updatedShape.y + updatedShape.height / 2;
                        break;
                      default:
                        menuX = updatedShape.x + updatedShape.width / 2;
                        menuY = updatedShape.y + updatedShape.height / 2;
                    }
                    
                    // Small timeout to ensure the context menu is fully closed first
                    setTimeout(() => {
                      // Update the selected shape
                      onShapeSelect(updatedShape);
                      
                      // Show radial menu
                      setRadialMenuPosition({ x: menuX, y: menuY });
                      setShowRadialMenu(true);
                      setRadialMenuOpen(true);
                      
                      // Force a redraw to ensure both elements appear
                      if (stageRef.current) {
                        stageRef.current.batchDraw();
                      }
                    }, 10);
                  } else {
                    // If locking, just update the selected shape
                    onShapeSelect(updatedShape);
                    // Hide radial menu
                    setShowRadialMenu(false);
                  }
                }
              }
            }}
          >
            {contextMenu.targetShape && contextMenu.targetShape.locked ? 'Unlock' : 'Lock'}
          </li>
          
          {/* Add Ungroup option for grouped shapes */}
          {contextMenu.targetShape && contextMenu.targetShape.groupId && (
            <li 
              style={{ 
                padding: '5px 9px', 
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0f0f0'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              onClick={() => {
                // Ungroup the shapes
                const groupId = contextMenu.targetShape.groupId;
                
                // Update shapes to remove the groupId
                const updatedShapes = shapes.map(s => {
                  if (s.groupId === groupId) {
                    const { groupId, ...rest } = s;
                    return rest;
                  }
                  return s;
                });
                
                // Remove the group
                setGroups(groups.filter(g => g.id !== groupId));
                
                // Update shapes
                onAddShape(updatedShapes);
                
                // Close context menu
                setContextMenu({ ...contextMenu, visible: false });
              }}
            >
              Ungroup Elements
            </li>
          )}
        </>
      )}
    </ul>
  </div>
)}
  </div>
);
};

export default Canvas;

