// import React from 'react';
// import { Group, Rect, Text } from 'react-konva';

// const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
//   // Calculate button size and positions based on shape dimensions and zoom level
//   const buttonSize = 20 / zoomLevel;
//   const buttonOffset = 10 / zoomLevel;
  
//   // Get shape dimensions
//   let width, height, x, y;
  
//   if (shape.type === 'circle') {
//     width = shape.radius * 2;
//     height = shape.radius * 2;
//     x = shape.x - shape.radius;
//     y = shape.y - shape.radius;
//   } else if (shape.type === 'line') {
//     const points = shape.points;
//     const minX = Math.min(points[0], points[2]);
//     const maxX = Math.max(points[0], points[2]);
//     const minY = Math.min(points[1], points[3]);
//     const maxY = Math.max(points[1], points[3]);
//     width = maxX - minX;
//     height = maxY - minY;
//     x = minX;
//     y = minY;
//   } else {
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   }
  
//   // Apply rotation if needed
//   const rotation = shape.rotation || 0;
  
//   // Button positions
//   const buttons = [
//     {
//       direction: 'up',
//       x: x + width / 2 - buttonSize / 2,
//       y: y - buttonSize - buttonOffset,
//       label: '↑'
//     },
//     {
//       direction: 'right',
//       x: x + width + buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '→'
//     },
//     {
//       direction: 'down',
//       x: x + width / 2 - buttonSize / 2,
//       y: y + height + buttonOffset,
//       label: '↓'
//     },
//     {
//       direction: 'left',
//       x: x - buttonSize - buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '←'
//     }
//   ];
  
//   const handleClick = (direction, e) => {
//     e.cancelBubble = true; // Stop event propagation
    
//     // Calculate offset based on direction
//     let offsetX = 0;
//     let offsetY = 0;
//     const offsetAmount = Math.max(width, height) * 1.1; // Offset by 110% of the largest dimension
    
//     switch (direction) {
//       case 'up':
//         offsetY = -offsetAmount;
//         break;
//       case 'right':
//         offsetX = offsetAmount;
//         break;
//       case 'down':
//         offsetY = offsetAmount;
//         break;
//       case 'left':
//         offsetX = -offsetAmount;
//         break;
//       default:
//         break;
//     }
    
//     onDuplicate(shape, offsetX, offsetY);
//   };
  
//   return (
//     <Group>
//       {buttons.map((button) => (
//         <Group 
//           key={button.direction}
//           x={button.x}
//           y={button.y}
//           onClick={(e) => handleClick(button.direction, e)}
//           onTap={(e) => handleClick(button.direction, e)}
//         >
//           <Rect
//             width={buttonSize}
//             height={buttonSize}
//             fill="#4a90e2"
//             cornerRadius={4 / zoomLevel}
//             shadowColor="black"
//             shadowBlur={3 / zoomLevel}
//             shadowOpacity={0.3}
//             shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
//           />
//           <Text
//             text={button.label}
//             width={buttonSize}
//             height={buttonSize}
//             align="center"
//             verticalAlign="middle"
//             fill="white"
//             fontSize={12 / zoomLevel}
//           />
//         </Group>
//       ))}
//     </Group>
//   );
// };

// export default DuplicateControls;



import React, { useState } from 'react';
import { Group, Rect, Text, Line, Circle } from 'react-konva';

const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragDirection, setDragDirection] = useState(null);
  const [dragStartPoint, setDragStartPoint] = useState({ x: 0, y: 0 });
  const [dragCurrentPoint, setDragCurrentPoint] = useState({ x: 0, y: 0 });
  
  // Calculate button size and positions based on shape dimensions and zoom level
  const buttonSize = 20 / zoomLevel;
  const buttonOffset = 10 / zoomLevel;
  
  // Get shape dimensions
  let width, height, x, y;
  
  if (shape.type === 'circle') {
    width = shape.radius * 2;
    height = shape.radius * 2;
    x = shape.x - shape.radius;
    y = shape.y - shape.radius;
  } else if (shape.type === 'line') {
    const points = shape.points;
    const minX = Math.min(points[0], points[2]);
    const maxX = Math.max(points[0], points[2]);
    const minY = Math.min(points[1], points[3]);
    const maxY = Math.max(points[1], points[3]);
    width = maxX - minX;
    height = maxY - minY;
    x = minX;
    y = minY;
  } else if (shape.type === 'pillar') {
    width = shape.width;
    height = shape.height;
    x = shape.x;
    y = shape.y;
  } else {
    width = shape.width;
    height = shape.height;
    x = shape.x;
    y = shape.y;
  }
  
  // Apply rotation if needed
  const rotation = shape.rotation || 0;
  
  // Button positions
  const buttons = [
    {
      direction: 'up',
      x: x + width / 2 - buttonSize / 2,
      y: y - buttonSize - buttonOffset,
      label: '↑'
    },
    {
      direction: 'right',
      x: x + width + buttonOffset,
      y: y + height / 2 - buttonSize / 2,
      label: '→'
    },
    {
      direction: 'down',
      x: x + width / 2 - buttonSize / 2,
      y: y + height + buttonOffset,
      label: '↓'
    },
    {
      direction: 'left',
      x: x - buttonSize - buttonOffset,
      y: y + height / 2 - buttonSize / 2,
      label: '←'
    }
  ];
  
  const handleDragStart = (direction, e) => {
    e.cancelBubble = true; // Stop event propagation
    setIsDragging(true);
    setDragDirection(direction);
    setDragStartPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
    setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
  };
  
  const handleDragMove = (e) => {
    if (!isDragging) return;
    setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
  };
  
  const handleDragEnd = (e) => {
    if (!isDragging) return;
    
    // Calculate distance and direction
    const endPoint = { x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y };
    
    // Calculate the distance based on direction
    let distance = 0;
    let spacing = 0;
    
    switch (dragDirection) {
      case 'up':
      case 'down':
        distance = Math.abs(endPoint.y - dragStartPoint.y) / zoomLevel;
        spacing = height * 1.1; // 10% spacing between elements
        break;
      case 'left':
      case 'right':
        distance = Math.abs(endPoint.x - dragStartPoint.x) / zoomLevel;
        spacing = width * 1.1; // 10% spacing between elements
        break;
      default:
        break;
    }
    
    // Calculate how many copies can fit in this distance
    const copies = Math.max(1, Math.floor(distance / spacing));
    
    // Create copies
    if (copies > 0) {
      const duplicates = [];
      
      for (let i = 1; i <= copies; i++) {
        let offsetX = 0;
        let offsetY = 0;
        
        switch (dragDirection) {
          case 'up':
            offsetY = -spacing * i;
            break;
          case 'right':
            offsetX = spacing * i;
            break;
          case 'down':
            offsetY = spacing * i;
            break;
          case 'left':
            offsetX = -spacing * i;
            break;
          default:
            break;
        }
        
        duplicates.push({
          shape,
          offsetX,
          offsetY
        });
      }
      
      // Call onDuplicate with all copies
      onDuplicate(duplicates);
    }
    
    // Reset state
    setIsDragging(false);
    setDragDirection(null);
  };
  
  // Render preview of duplicates while dragging
  const renderDuplicatePreviews = () => {
    if (!isDragging) return null;
    
    // Calculate distance and direction
    let distance = 0;
    let spacing = 0;
    
    switch (dragDirection) {
      case 'up':
      case 'down':
        distance = Math.abs(dragCurrentPoint.y - dragStartPoint.y) / zoomLevel;
        spacing = height * 1.1; // 10% spacing between elements
        break;
      case 'left':
      case 'right':
        distance = Math.abs(dragCurrentPoint.x - dragStartPoint.x) / zoomLevel;
        spacing = width * 1.1; // 10% spacing between elements
        break;
      default:
        break;
    }
    
    // Calculate how many copies can fit in this distance
    const copies = Math.max(1, Math.floor(distance / spacing));
    
    // Create preview elements
    const previews = [];
    
    for (let i = 1; i <= copies; i++) {
      let offsetX = 0;
      let offsetY = 0;
      
      switch (dragDirection) {
        case 'up':
          offsetY = -spacing * i;
          break;
        case 'right':
          offsetX = spacing * i;
          break;
        case 'down':
          offsetY = spacing * i;
          break;
        case 'left':
          offsetX = -spacing * i;
          break;
        default:
          break;
      }
      
      // Add preview based on shape type
      if (shape.type === 'circle') {
        previews.push(
          <Circle
            key={`preview-${i}`}
            x={shape.x + offsetX}
            y={shape.y + offsetY}
            radius={shape.radius}
            fill={shape.fill}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            opacity={0.5}
          />
        );
      } else if (shape.type === 'line') {
        const points = shape.points.map((p, idx) => {
          if (idx % 2 === 0) return p + offsetX;
          return p + offsetY;
        });
        
        previews.push(
          <Line
            key={`preview-${i}`}
            points={points}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            opacity={0.5}
          />
        );
      } else {
        previews.push(
          <Rect
            key={`preview-${i}`}
            x={shape.x + offsetX}
            y={shape.y + offsetY}
            width={shape.width}
            height={shape.height}
            fill={shape.fill}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            rotation={shape.rotation || 0}
            opacity={0.5}
          />
        );
      }
    }
    
    return previews;
  };
  
  // Render drag line
  const renderDragLine = () => {
    if (!isDragging) return null;
    
    return (
      <Line
        points={[dragStartPoint.x, dragStartPoint.y, dragCurrentPoint.x, dragCurrentPoint.y]}
        stroke="#3498db"
        strokeWidth={2 / zoomLevel}
        dash={[5 / zoomLevel, 5 / zoomLevel]}
      />
    );
  };
  
  return (
    <Group>
      {/* Duplicate buttons */}
      {buttons.map((button) => (
        <Group 
          key={button.direction}
          x={button.x}
          y={button.y}
          draggable
          onDragStart={(e) => handleDragStart(button.direction, e)}
          onDragMove={handleDragMove}
          onDragEnd={handleDragEnd}
        >
          <Rect
            width={buttonSize}
            height={buttonSize}
            fill="#4a90e2"
            cornerRadius={4 / zoomLevel}
            shadowColor="black"
            shadowBlur={3 / zoomLevel}
            shadowOpacity={0.3}
            shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
          />
          <Text
            text={button.label}
            width={buttonSize}
            height={buttonSize}
            align="center"
            verticalAlign="middle"
            fill="white"
            fontSize={12 / zoomLevel}
          />
        </Group>
      ))}
      
      {/* Drag line */}
      {renderDragLine()}
      
      {/* Duplicate previews */}
      {renderDuplicatePreviews()}
    </Group>
  );
};

export default DuplicateControls;