
// import * as React from 'react';
// import {
//   Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
//   Paper, Chip, Avatar, Stack, IconButton, Menu, MenuItem, TablePagination, Typography
// } from '@mui/material';
// import MoreVertIcon from '@mui/icons-material/MoreVert';

// type Row = {
//   enquiryId: string;
//   customer_name: string;
//   actions: string;
//   created_date: string;
//   email_id: string;
//   reference_no: string;
//   product_group: string;
//     billing_address: string;
//     status: 'Active' | 'Inactive' | 'Pending';
//     view_ga: string;
//     view_bom: string;
//     update: string;
// };

// const data: Row[] = [];

// export default function UsersTableBasic() {
//   const [page, setPage] = React.useState(0);
//   const [rowsPerPage, setRowsPerPage] = React.useState(5);
//   const [menuRow, setMenuRow] = React.useState<Row | null>(null);
//   const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

//   const openMenu = (e: React.MouseEvent<HTMLButtonElement>, row: Row) => {
//     setAnchorEl(e.currentTarget);
//     setMenuRow(row);
//   };
//   const closeMenu = () => {
//     setAnchorEl(null);
//     setMenuRow(null);
//   };

//   return (
//     <Paper sx={{ width: '100%' }}>
//       <TableContainer sx={{ maxHeight: 440 }}>
//         <Table stickyHeader size="small" aria-label="users table">
//           <TableHead>
//             <TableRow>
//               <TableCell>Enquiry ID</TableCell>
//               <TableCell>Customer Name</TableCell>
//               <TableCell>Actions</TableCell>
//               <TableCell>Created Date</TableCell>
//               <TableCell>Email ID</TableCell>
//               <TableCell align="right">Reference No</TableCell>
//               <TableCell>Product Group</TableCell>
//               <TableCell>Billing Address</TableCell>
//               <TableCell>Status</TableCell>
//               <TableCell>View GA</TableCell>
//               <TableCell>View BOM</TableCell>
//               <TableCell>Update</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((r) => (
//               <TableRow key={r.id} hover>
//                 <TableCell>
//                   <Stack direction="row" spacing={1} alignItems="center">
//                     <Avatar src={r.avatarUrl} sx={{ width: 28, height: 28 }} />
//                     <Box>
//                       <Typography variant="body2" fontWeight={600}>{r.name}</Typography>
//                       <Typography variant="caption" color="text.secondary">{r.email}</Typography>
//                     </Box>
//                   </Stack>
//                 </TableCell>
//                 <TableCell>{r.role}</TableCell>
//                 <TableCell>
//                   <Chip
//                     size="small"
//                     label={r.status}
//                     color={r.status === 'Active' ? 'success' : r.status === 'Pending' ? 'warning' : 'default'}
//                   />
//                 </TableCell>
//                 <TableCell>{new Date(r.joinedAt).toLocaleDateString()}</TableCell>
//                 <TableCell align="right">
//                   <IconButton size="small" onClick={(e) => openMenu(e, r)}>
//                     <MoreVertIcon fontSize="small" />
//                   </IconButton>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>
//       <TablePagination
//         component="div"
//         count={data.length}
//         page={page}
//         onPageChange={(_, p) => setPage(p)}
//         rowsPerPage={rowsPerPage}
//         onRowsPerPageChange={(e) => {
//           setRowsPerPage(parseInt(e.target.value, 10));
//           setPage(0);
//         }}
//         rowsPerPageOptions={[5, 10, 25]}
//       />
//       <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={closeMenu}>
//         <MenuItem onClick={() => { console.log('Edit', menuRow?.id); closeMenu(); }}>Edit</MenuItem>
//         <MenuItem onClick={() => { console.log('Delete', menuRow?.id); closeMenu(); }} sx={{ color: 'error.main' }}>
//           Delete
//         </MenuItem>
//       </Menu>
//     </Paper>
//   );
// }
