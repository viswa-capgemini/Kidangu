
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Stack,
  Typography,
  Button,
  Divider,
  Paper,
  Chip,
  IconButton,
  Pagination,
  TextField,
  MenuItem,
  Grid,
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import type { GridColDef } from '@mui/x-data-grid';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import IosShareIcon from '@mui/icons-material/IosShare';

/* ---------------- Types, helpers, and mocks ---------------- */
interface Enquiry {
  id: string;
  customerName: string;
  actions: string;
  createdDate: string;
  email: string;
  referenceNo: string;
  productGroup: string;
  billingAddress: string;
}

interface RevisionRow {
  enquiryId: string;
  customerName: string;
  actions: string;
  createdDate: string;
  email: string;
  referenceNo: string;
  productGroup: string;
  billingAddress: string;
  status?: string;
}

const labelStyle = { variant: 'caption' as const, sx: { color: 'text.secondary' } };
const valueStyle = { variant: 'body2' as const, sx: { fontWeight: 400 } };

const DetailItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <Stack spacing={0.5}>
    <Typography {...labelStyle}>{label}</Typography>
    <Typography {...valueStyle}>{value}</Typography>
  </Stack>
);

const mockEnquiry: Enquiry = {
  id: 'ENQ-A987MYCM',
  customerName: 'Coca cola',
  actions: 'Multi layer warehouse configuration',
  createdDate: '2025-04-01',
  email: 'Cocacola@gmail.com',
  referenceNo: 'GDCC1',
  productGroup: 'SPR',
  billingAddress: 'Chennai',
};

const mockRevisions: RevisionRow[] = [
  { enquiryId: 'ENG-AB9MYCM', customerName: 'Coca cola', actions: 'Multi layer warehouse configuration', createdDate: '2025-04-01', email: 'Cocacola@gmail.com', referenceNo: 'GDCC1', productGroup: 'SPR', billingAddress: 'Chennai', status: 'N/A' },
  { enquiryId: 'ENG-GB9MYCM', customerName: 'Pepsi',     actions: 'Multi layer warehouse configuration', createdDate: '2025-04-01', email: 'Cocacola@gmail.com', referenceNo: '123456', productGroup: 'SPR, Cantilever', billingAddress: 'Chennai', status: 'N/A' },
  { enquiryId: 'ENG-UB9MYCM', customerName: 'Pepsi',     actions: 'Multi layer warehouse configuration', createdDate: '2025-04-01', email: 'pepsi@gmail.com',     referenceNo: 'GC1',   productGroup: 'Mezzanine',       billingAddress: 'Chennai', status: 'N/A' },
  { enquiryId: 'ENG-TB9MYCM', customerName: 'Coca cola', actions: 'Multi layer warehouse configuration', createdDate: '2025-04-01', email: 'Cocacola@gmail.com', referenceNo: 'GDH1',  productGroup: 'SPR, Cantilever', billingAddress: 'Chennai', status: 'N/A' },
  { enquiryId: 'ENG-LB9MYCM', customerName: 'Pepsi',     actions: 'Multi layer warehouse configuration', createdDate: '2025-04-01', email: 'pepsi@gmail.com',     referenceNo: 'GEC1',  productGroup: 'SPR',             billingAddress: 'Chennai', status: 'N/A' },
];

/* ---------------- Component ---------------- */
const EnquiryDetails: React.FC = () => {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();

  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [page, setPage] = React.useState(1);
  const totalRows = 120;
  const totalPages = Math.ceil(totalRows / rowsPerPage);

  const handleExport = () => {
    // Stub: no CSV as requested; wire to PDF or backend when ready.
    console.log('Export clicked (no CSV)');
  };

  const handleRowsPerPageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = parseInt(e.target.value, 10);
    setRowsPerPage(v);
    setPage(1);
  };

  const displayedEnquiry = React.useMemo(
    () => ({ ...mockEnquiry, id: id ?? mockEnquiry.id }),
    [id]
  );

  // Expand to 120 rows for pagination demo and ensure unique ids
  const allRows: RevisionRow[] = React.useMemo(() => {
    const out: RevisionRow[] = [];
    for (let i = 0; i < totalRows; i++) {
      const base = mockRevisions[i % mockRevisions.length];
      out.push({
        ...base,
        enquiryId: `${base.enquiryId}-${String(i + 1).padStart(3, '0')}`,
      });
    }
    return out;
  }, [totalRows]);

  // Current page slice
  const startIndex = (page - 1) * rowsPerPage;
  const endIndex = Math.min(startIndex + rowsPerPage, totalRows);
  const pageRows = allRows.slice(startIndex, endIndex);

  // Handlers
  const handleViewGA = (row: RevisionRow) => navigate(`/ga/${encodeURIComponent(row.enquiryId)}`);
  const handleViewBOM = (row: RevisionRow) => navigate(`/bom/${encodeURIComponent(row.enquiryId)}`);

  // Data Grid columns (kept same order/labels)
  const columns: GridColDef[] = [
    {
      field: "enquiryId",
      headerName: "Enquiry ID",
      minWidth: 150,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "0.85rem", fontWeight: 500 }}>
          {params.value as string}
        </Typography>
      ),
    },
    { field: "customerName", headerName: "Customer Name", minWidth: 120 },
    {
      field: "actions",
      headerName: "Actions",
      minWidth: 140,
      renderCell: (p) => (
        <Typography
          variant="body2"
          sx={{ whiteSpace: "normal", lineHeight: 1.25 }}
        >
          {p.value}
        </Typography>
      ),
    },
    { field: "createdDate", headerName: "Created Date", minWidth: 120 },
    { field: "email", headerName: "Email ID", minWidth: 160 },
    { field: "referenceNo", headerName: "Reference No", minWidth: 110 },
    { field: "productGroup", headerName: "Product Group", minWidth: 130 },
    { field: "billingAddress", headerName: "Billing Address", minWidth: 110 },
    {
      field: "status",
      headerName: "Status",
      minWidth: 100,
      align: "center",
      headerAlign: "center",
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <Chip
          label={(params.value as string) ?? "N/A"}
          size="small"
          color="secondary"
          variant="outlined"
        />
      ),
    },
    {
      field: "ga",
      headerName: "View GA",
      minWidth: 90,
      align: "center",
      headerAlign: "center",
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <IconButton
          size="small"
          color="primary"
          aria-label="view-ga"
          onClick={() => handleViewGA(params.row as RevisionRow)}
        >
          <VisibilityOutlinedIcon />
        </IconButton>
      ),
    },
    {
      field: "bom",
      headerName: "View BOM",
      minWidth: 90,
      align: "center",
      headerAlign: "center",
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <IconButton
          size="small"
          color="primary"
          aria-label="view-bom"
          onClick={() => handleViewBOM(params.row as RevisionRow)}
        >
          <VisibilityOutlinedIcon />
        </IconButton>
      ),
    },
  ];

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
        <Typography variant="h5" sx={{ color: '#810055'}}>
          Enquiry Details
        </Typography>
        <Button
          variant="contained"
          startIcon={<IosShareIcon />}
          onClick={handleExport}
          sx={{ borderRadius: 5, px: 2, py: 0.5, bgcolor: '#810055' }}
        >
          Export
        </Button>
      </Stack>

      {/* Details Grid */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(4, 1fr)' }, gap: 3, mb: 2 }}>
        <Box>
          <DetailItem label="Enquiry ID" value={displayedEnquiry.id} />
        </Box>
        <Box>
          <DetailItem label="Customer Name" value={mockEnquiry.customerName} />
        </Box>
        <Box>
          <DetailItem label="Actions" value={mockEnquiry.actions} />
        </Box>
        <Box>
          <DetailItem label="Created Date" value={mockEnquiry.createdDate} />
        </Box>

        <Box>
          <DetailItem label="Email ID" value={mockEnquiry.email} />
        </Box>
        <Box>
          <DetailItem label="Reference No" value={mockEnquiry.referenceNo} />
        </Box>
        <Box>
          <DetailItem label="Product Group" value={mockEnquiry.productGroup} />
        </Box>
        <Box>
          <DetailItem label="Billing Address" value={mockEnquiry.billingAddress} />
        </Box>
      </Box>

      {/* Action Buttons */}
      <Stack direction="row" spacing={1.5} mb={3}>
        <Button
          variant="contained"
          startIcon={<KeyboardBackspaceIcon />}
          sx={{ borderRadius: 5, bgcolor: 'white', color: '#810055', borderColor: '#810055', border: '1px solid #810055'}}
          onClick={() => navigate(-1)}
        >
          Back
        </Button>
        <Button
          variant="contained"
          startIcon={<CompareArrowsIcon />}
          sx={{ borderRadius: 5, bgcolor: 'white', color: '#810055', border: '1px solid #810055'}}
          onClick={() => navigate('/pg-comparison')}
        >
          Product Group Comparison
        </Button>
        <Button
          variant="outlined"
          startIcon={<PlayArrowRoundedIcon />}
          sx={{ borderRadius: 5, bgcolor: 'white', color: '#810055', borderColor: '#810055', }}
        >
          Start Design
        </Button>
      </Stack>

      {/* Revisions */}
      <Typography variant="h4" sx={{ color: '#810055', fontWeight: 500, mb: 1.5 }}>
        Revisions
      </Typography>

      <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
        <DataGrid
          autoHeight
          rows={pageRows}
          columns={columns}
          getRowId={(row) => row.enquiryId}
          density="compact"
          hideFooter
        //   disableColumnMenu
          disableRowSelectionOnClick
          sx={{
            '& .even-row': { backgroundColor: '#FAF7FB' },
          }}
          getRowClassName={(params) =>
            params.indexRelativeToCurrentPage % 2 === 1 ? 'even-row' : ''
          }
        />

        <Divider />

        {/* Bottom controls */}
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          alignItems="center"
          justifyContent="space-between"
          sx={{ p: 1.5 }}
          spacing={1.5}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography variant="caption">Items per page</Typography>
            <TextField
              value={rowsPerPage}
              onChange={handleRowsPerPageChange}
              select
              size="small"
              sx={{ width: 70 }}
            >
              {[5, 10, 20].map((n) => (
                <MenuItem key={n} value={n}>
                  {n}
                </MenuItem>
              ))}
            </TextField>
            <Typography variant="caption" sx={{ color: 'text.secondary' }}>
              Showing {startIndex + 1}–{endIndex} of {totalRows} results
            </Typography>
          </Stack>

          <Pagination
            count={totalPages}
            page={page}
            onChange={(_, p) => setPage(p)}
            shape="rounded"
            size="small"
            showFirstButton
            showLastButton
          />
        </Stack>
      </Paper>
    </Box>
  );
};

export default EnquiryDetails;
