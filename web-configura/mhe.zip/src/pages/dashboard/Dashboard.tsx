import React, {useState} from 'react'
import EnquiryList from '../enquiry-list/EnquiryList'

const Dashboard = () => {
  return (
    <div>
      <EnquiryList/>
    </div>
  )
}

export default Dashboard
