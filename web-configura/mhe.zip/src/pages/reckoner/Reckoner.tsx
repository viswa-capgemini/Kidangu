import React from 'react'

const Reckoner = () => {
  return (
    <div>
      <h1> Reckoner Page</h1>
    </div>
  )
}

export default Reckoner
