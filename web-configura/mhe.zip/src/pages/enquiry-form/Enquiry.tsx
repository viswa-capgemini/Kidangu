import React from 'react'

const Enquiry = () => {
  return (
    <div>
      <h1 data-testid="" className='text-godrej-purple text-4xl'>Enquiry Form</h1>
    </div>
  )
}

export default Enquiry
