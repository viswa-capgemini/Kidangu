import "./App.css";
import Body from "./components/body/Body";
import Header from "./components/header/Header";
import Joyride, { type Placement, type Step } from "react-joyride";
import { useState } from "react";
import { useLocation } from "react-router";

function App() {
  const [runTour, setRunTour] = useState(true);
  const [tour, setTour] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const location = useLocation();
  const hideHeaderPaths = ["/configuration-layout"];

  const shouldHideHeader = hideHeaderPaths.includes(location.pathname);
  // if (location.pathname.includes(hideHeaderPaths)) {
  //   return <Body isSidebarOpen={true} />;
  // }

  const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);

  const steps: Step[] = [
    {
      target: '[data-testid="main-header"]',
      content: "This is a key feature in the header!",
      disableBeacon: true,
      placement: "bottom" as Placement,
    },
    {
      target: ".left-side-panel",
      content: "You can select different options from here.",
      disableBeacon: true,
      placement: "right" as Placement,
    },
    {
      target: ".user",
      content: "You can the user profile here.",
      disableBeacon: true,
      placement: "right" as Placement,
    },
    {
      target: ".create-project",
      content: "You can create new project from here.",
      disableBeacon: true,
      placement: "right" as Placement,
    },
  ];

  const handleJoyrideCallback = (data: any) => {
    console.log("Joyride callback data:", data);
    const { status, type, action } = data;
    // const finishedStatuses: string[] = ["finished", "skipped"];

    if (action === "close" || action === "skip" || status === "finished") {
      setRunTour(false);
      setTour(false);
    }
  }

  const tooltipStyles = {
    options: {
      zIndex: 10000,
    },
    buttonClose: {
      backgroundColor: "#810055",
      color: "white",
      border: "2px solid white",
      padding: "5px",
      margin: "5px",
      borderRadius: "5px",
    },
    buttonNext: {
      backgroundColor: "#810055",
      color: "white",
      border: "2px solid white",
      borderRadius: "5px",
    },
    buttonBack: {
      backgroundColor: "#810055",
      color: "white",
      border: "2px solid white",
      borderRadius: "5px",
    },
    buttonSkip: {
      backgroundColor: "#810055",
      color: "white",
      border: "2px solid white",
      borderRadius: "5px",
    },
  };

  return (
    <div className="flex flex-col h-screen">
      {tour && (
        <Joyride
          steps={steps}
          run={runTour}
          continuous={true}
          showSkipButton={true}
          showProgress={true}
          callback={handleJoyrideCallback}
          styles={tooltipStyles}
        />
      )}
      
      {!shouldHideHeader && <Header setTour={setTour} tour={tour} setRunTour={setRunTour} onHamburgerClick={toggleSidebar}/>}
      <Body isSidebarOpen={isSidebarOpen}/>
    </div>
  );
}

export default App;
