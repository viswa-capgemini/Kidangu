
// theme.ts
import { createTheme } from '@mui/material/styles';

export const theme = createTheme({
  
  typography: {
    body2: {
      fontWeight: 400, // globally lighter for body2
    },
  },

  palette: {
    primary: {
      main: '#810055',
      contrastText: '#ffffff',
    },
  },

  components: {
    // Checkbox: brand color across states
    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: '#810055',                       // unchecked icon
          '&.Mui-checked': { color: '#810055' },  // checked icon
          '&.MuiCheckbox-indeterminate': { color: '#810055' },
          '&:hover': {
            backgroundColor: 'rgba(129, 0, 85, 0.08)',
          },
        },
      },
    },

    // Outlined input & label (used by TextField and Autocomplete)
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          // outline/border
          '& .MuiOutlinedInput-notchedOutline': {
            borderColor: '#810055',
          },
          '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: '#810055',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: '#810055',
          },
        },
        input: {
          color: '#810055',      // input text
          caretColor: '#810055', // caret color
        },
      },
    },

    MuiInputLabel: {
      styleOverrides: {
        root: {
          color: '#810055',
        },
        outlined: {
          '&.Mui-focused': { color: '#810055' }, // focused label color
        },
      },
    },

    // Buttons
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          backgroundColor: '#810055',
          color: '#ffffff',
          '&:hover': { backgroundColor: '#6c0048' },
        },
        outlined: {
          color: '#810055',
          borderColor: '#810055',
          '&:hover': {
            backgroundColor: '#810055',
            color: '#fff',
            borderColor: '#810055',
          },
        },
      },
    },
  },
});
