export function slugify(label: string): string {
  return label.toLowerCase().replace(/\s+/g, '-');
}