import React from 'react'

 type CardProps = {

  title: string;
  description: string;
};

const Card: React.FC<CardProps> = ({ title, description }) => {
  return (
    <div data-testid="cardContainer" className="p-4 bg-white shadow-md w-64">
      <h3 data-testid="cardTitle" className='text-godrej-purple text-1xl'>{title}</h3>
      {/* <p>{description}</p> */}
    </div>
  );
};

export default Card;

