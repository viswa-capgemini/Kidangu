import React from "react";

type ButtonProps = {
  id?: string;
  label: string;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  iconClass?: string;
  className?: string;
};

const Button: React.FC<ButtonProps> = ({ id, label, onClick, type = "button", iconClass, className }) => {
  return (
    <button
      data-testid={id}
      type={type}
      onClick={onClick}
      disabled={false}
      className={className}
    >
    <span className={`icon ${iconClass} text-xl`}></span>
    <span className="text-md font-small">{label}</span>
    </button>
  );
};

export default Button;
