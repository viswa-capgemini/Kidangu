import React, { useState, useEffect, useRef } from "react";
import {
  ArrowPathIcon,
  PencilIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";
import { Navigate, useNavigate } from "react-router-dom";
import dynamoDBClient from "../../aws-config";
import { Link } from "react-router-dom";
import { ScanCommand } from "@aws-sdk/client-dynamodb";
import { DeleteItemCommand } from "@aws-sdk/client-dynamodb";
import CreateRule from "./CreateRule";

// Define interfaces for state objects
interface ValidationState {
  knowDepth: boolean;
  rackDepth: number;
  palletDepth: number;
  frontClear: number;
  rearClear: number;
  editLimits: boolean;
  minDepth: number;
  maxDepth: number;
  validationResult: boolean;
  computedDepth: number;
  isValid: boolean;
}

interface CalculateState {
  warehouseClearHeight: number;
  palletHeight: number;
  mheWorkingHeight: number;
  mheMFH: number;
  mheBasis: "WorkingHeight" | "MFH";
  topClearance: number;
  pitch: number;
  unitType: "single" | "double";
  singleFrameDepth: number;
  doubleFrameDepth1: number;
  doubleFrameDepth2: number;
  rowConnector: number;
  lastLoadingLevel: number | null;
  rackHeight: number | null;
  computedDepth: number | null;
  hdr: number | null;
  depthBreakdown?: string;
  messages: string[];
  status: string;
}

// Define interface for rule objects
interface Rule {
  id: string;
  name?: string;
  description?: string;
  type?: string;
  message?: string;
  severity?: string;
  expression?: string;
  active?: boolean;
  [key: string]: any; // For other dynamic properties
}

// Define interface for expanded rows tracking
interface ExpandedRows {
  [key: string]: boolean;
}

// Function to normalize DynamoDB response data
const normalizeDynamoDBItem = (item: any): Rule => {
  const normalized: any = {};

  if (!item) return {} as Rule;

  Object.keys(item).forEach((key) => {
    // Extract the value based on DynamoDB type
    if (item[key].S !== undefined) {
      normalized[key] = item[key].S;
    } else if (item[key].N !== undefined) {
      normalized[key] = Number(item[key].N);
    } else if (item[key].BOOL !== undefined) {
      normalized[key] = item[key].BOOL;
    } else if (item[key].L !== undefined) {
      normalized[key] = item[key].L.map((i: any) => normalizeDynamoDBItem(i));
    } else if (item[key].M !== undefined) {
      normalized[key] = normalizeDynamoDBItem(item[key].M);
    } else {
      normalized[key] = item[key]; // Fallback
    }
  });

  return normalized as Rule;
};

const RulePolicy: React.FC = () => {
  // Basic state
  const [selected, setSelected] = useState<boolean>(false);
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);
  const [expandedRows, setExpandedRows] = useState<ExpandedRows>({});
  const [rules, setRules] = useState<Rule[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const navigate = useNavigate();
  const [copied, setCopied] = useState<boolean>(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [showToast, setShowToast] = useState<boolean>(false);
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"calculate" | "validate">(
    "calculate"
  );
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  //for modal
  const [isModalMaximized, setIsModalMaximized] = useState(false);
  const [modalSize, setModalSize] = useState({ width: "80%", height: "80vh" });
  const resizingRef = useRef(false);
  const startPositionRef = useRef({ x: 0, y: 0 });
  const modalSizeRef = useRef({ width: 0, height: 0 });

  const [modalPosition, setModalPosition] = useState({ top: 100, left: 100 });
  const modalPositionRef = useRef({ top: 100, left: 100 });
  const isDraggingRef = useRef(false);

  useEffect(() => {
    // Initial calculation when component mounts
    computeRackHeight();
  }, []);

  // Run calculation when tab changes to 'calculate'
  useEffect(() => {
    if (activeTab === "calculate") {
      computeRackHeight();
    } else if (activeTab === "validate") {
      validateDepth();
    }
  }, [activeTab]);

  // Search and pagination
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const rulesPerPage: number = 10;

  // Validation state
  const [validationState, setValidationState] = useState<ValidationState>({
    knowDepth: false,
    rackDepth: 1000,
    palletDepth: 1000,
    frontClear: 0,
    rearClear: 75,
    editLimits: true,
    minDepth: 164,
    maxDepth: 1223,
    validationResult: false,
    computedDepth: 0,
    isValid: false,
  });

  // Calculate state
  const [calculateState, setCalculateState] = useState<CalculateState>({
    warehouseClearHeight: 8000,
    palletHeight: 1200,
    mheWorkingHeight: 6200,
    mheMFH: 6500,
    mheBasis: "WorkingHeight",
    topClearance: 300,
    pitch: 100,
    unitType: "single",
    singleFrameDepth: 1100,
    doubleFrameDepth1: 1100,
    doubleFrameDepth2: 1100,
    rowConnector: 200,
    // Outputs
    lastLoadingLevel: null,
    rackHeight: null,
    computedDepth: null,
    hdr: null,
    messages: [],
    status: "Ready",
  });

  // Destructure validation state for easier access
  const {
    knowDepth,
    rackDepth,
    palletDepth,
    frontClear,
    rearClear,
    editLimits,
    minDepth,
    maxDepth,
    validationResult,
    computedDepth,
    isValid,
  } = validationState;

  // Helper function to update a single field in validation state
  const updateValidationState = (
    field: keyof ValidationState,
    value: any
  ): void => {
    setValidationState((prev) => {
      const newState = {
        ...prev,
        [field]: value,
      };

      // Schedule validation to run after state update
      setTimeout(() => validateDepth(newState), 0);

      return newState;
    });
  };

  // Helper function to update a single field in calculate state
  const updateCalculateState = (
    field: keyof CalculateState,
    value: any
  ): void => {
    setCalculateState((prev) => {
      const newState = {
        ...prev,
        [field]: value,
      };

      // Schedule calculation to run after state update
      setTimeout(() => computeRackHeight(newState), 0);

      return newState;
    });
  };

  // Toggle accordion for a specific rule
  const toggleAccordion = (id: string): void => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Validate depth function
  const validateDepth = (state = validationState): void => {
    // Use the provided state or current state
    const {
      knowDepth,
      rackDepth,
      palletDepth,
      frontClear,
      rearClear,
      minDepth,
      maxDepth,
    } = state;

    // Ensure all inputs are valid numbers
    const rackDepthNum = parseFloat(rackDepth.toString()) || 0;
    const palletDepthNum = parseFloat(palletDepth.toString()) || 0;
    const frontClearNum = parseFloat(frontClear.toString()) || 0;
    const rearClearNum = parseFloat(rearClear.toString()) || 0;

    const depth = knowDepth
      ? rackDepthNum
      : palletDepthNum + frontClearNum + rearClearNum;

    // Ensure minDepth and maxDepth are numbers
    const min = parseFloat(minDepth.toString()) || 0;
    const max = parseFloat(maxDepth.toString()) || 0;

    const valid = depth >= min && depth <= max;

    setValidationState((prev) => ({
      ...prev,
      computedDepth: depth,
      isValid: valid,
      validationResult: true,
    }));

    // Optional: Debug log
    console.log("Computed Depth:", depth, "Min Depth:", min, "Max Depth:", max);
  };
  // Compute rack height and related values
  const computeRackHeight = (state = calculateState): void => {
    // Use the provided state or current state
    const {
      warehouseClearHeight,
      palletHeight,
      mheWorkingHeight,
      mheMFH,
      mheBasis,
      topClearance,
      unitType,
      singleFrameDepth,
      doubleFrameDepth1,
      doubleFrameDepth2,
      rowConnector,
    } = state;

    // LLL components
    const civil = warehouseClearHeight - 200 - palletHeight;
    const mheSelected = (mheBasis === "MFH" ? mheMFH : mheWorkingHeight) - 200;
    const lll = Math.max(0, Math.min(civil, mheSelected));

    // Rack height
    const rackHeight = lll + topClearance;

    // Depth
    let depth = 0;
    let depthBreakdown = "";
    if (unitType === "single") {
      depth = singleFrameDepth;
      depthBreakdown = `single: ${depth}mm`;
    } else {
      depth = doubleFrameDepth1 + doubleFrameDepth2 + rowConnector;
      depthBreakdown = `double: ${doubleFrameDepth1} + ${doubleFrameDepth2} + ${rowConnector} = ${depth}mm`;
    }

    const hdr = depth > 0 ? +(lll / depth).toFixed(2) : null;

    // Evaluate rules
    const messages: string[] = [];
    let status = "OK";

    // Example rule: HDR must be ≤ 6
    if (hdr && hdr > 6) {
      messages.push(
        `Height:Depth ratio (${hdr}) exceeds 6. Consider stability components.`
      );
      status = "Warnings";
    }

    setCalculateState((prev) => ({
      ...prev,
      lastLoadingLevel: Math.round(lll),
      rackHeight: Math.round(rackHeight),
      computedDepth: Math.round(depth),
      depthBreakdown,
      hdr,
      messages,
      status,
    }));
  };

  // Handle radio button selection
  const handleSelectRule = (ruleId: string): void => {
    setSelectedRuleId(ruleId);
    setSelected(true);
  };

  // Function to open modal
  const openCalculateValidateModal = (): void => {
    setModalOpen(true);
    setDropdownOpen(false);
  };

  // Fetch rules from DynamoDB
  async function fetchRulesFromDynamoDB(): Promise<Rule[]> {
    const params = {
      TableName: "RulesTable",
    };

    try {
      const command = new ScanCommand(params);
      const data = await dynamoDBClient.send(command);

      // Normalize the DynamoDB response data
      const normalizedRules = (data.Items || []).map((item) =>
        normalizeDynamoDBItem(item)
      );
      console.log("Normalized rules:", normalizedRules);

      return normalizedRules;
    } catch (error) {
      console.error("Error fetching rules from DynamoDB:", error);
      alert("Failed to fetch rules. Please try again later.");
      return [];
    }
  }

  // Load rules when component mounts
  useEffect(() => {
    async function loadRules(): Promise<void> {
      try {
        setIsLoading(true);
        const rulesFromDB = await fetchRulesFromDynamoDB();
        console.log("rulesFromDB", rulesFromDB);
        if (rulesFromDB.length > 0) {
          setRules(rulesFromDB);
        }
      } catch (error) {
        console.error("Error loading rules:", error);
      } finally {
        setIsLoading(false);
      }
    }

    loadRules();
  }, []);

  // Compute rack height when component mounts
  useEffect(() => {
    computeRackHeight();
  }, []);

  // Function to delete rule from DynamoDB
  async function deleteRuleFromDynamoDB(id: string): Promise<boolean> {
    const params = {
      TableName: "RulesTable",
      Key: {
        id: { S: id },
      },
    };

    try {
      const command = new DeleteItemCommand(params);
      await dynamoDBClient.send(command);
      console.log("Rule deleted from DynamoDB successfully");
      return true;
    } catch (error) {
      console.error("Error deleting rule from DynamoDB:", error);
      return false;
    }
  }

  // handleDeleteRule function
  async function handleDeleteRule(id: string): Promise<void> {
    setPendingDeleteId(id);
    setShowToast(true);
  }

  async function confirmDelete(): Promise<void> {
    if (!pendingDeleteId) return;

    try {
      setIsDeleting(true);
      const success = await deleteRuleFromDynamoDB(pendingDeleteId);

      if (success) {
        setRules((prevRules) =>
          prevRules.filter((rule) => rule.id !== pendingDeleteId)
        );
        if (selectedRuleId === pendingDeleteId) {
          setSelectedRuleId(null);
          setSelected(false);
        }
      } else {
        // Optional: show another toast or fallback alert
        alert("Failed to delete rule from database.");
      }
    } catch (error) {
      console.error("Error in handleDeleteRule:", error);
    } finally {
      setIsDeleting(false);
      setShowToast(false);
      setPendingDeleteId(null);
    }
  }

  function cancelDelete(): void {
    setShowToast(false);
    setPendingDeleteId(null);
  }

  // Function to handle edit rule
  const handleEditRule = (id: string): void => {
    navigate(`/createrule?id=${id}`);
  };

  // Function to prepare rule data for JSON display (excluding id)
  const prepareRuleForDisplay = (rule: Rule): Omit<Rule, "id"> => {
    // Create a copy of the rule object
    const displayRule = { ...rule } as Partial<Rule>;

    // Remove the id field
    delete displayRule.id;

    return displayRule as Omit<Rule, "id">;
  };

  const handleRefresh = async (): Promise<void> => {
    try {
      setIsLoading(true);
      const rulesFromDB = await fetchRulesFromDynamoDB();
      if (rulesFromDB.length > 0) {
        setRules(rulesFromDB);
      }
    } catch (error) {
      console.error("Error refreshing rules:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async (jsonText: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(jsonText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  const calculateAndValidate = (): void => {
    if (!selectedRuleId) return;

    const selectedRule = rules.find((rule) => rule.id === selectedRuleId);

    if (!selectedRule) return;

    if (activeTab === "calculate") {
      // Logic for calculation
      computeRackHeight();
      console.log(`Calculating rule: ${selectedRule.name}`);
    } else {
      // Logic for validation
      validateDepth();
      console.log(`Validating rule: ${selectedRule.name}`);
    }
  };

  // Filter rules based on search term
  const filteredRules = rules
    .filter(
      (rule) =>
        selectedType === "all" ||
        rule.type?.toLowerCase() === selectedType.toLowerCase()
    )
    .filter(
      (rule) =>
        rule.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.message?.toLowerCase().includes(searchTerm.toLowerCase())
    );

  // Get current rules for pagination
  const indexOfLastRule = currentPage * rulesPerPage;
  const indexOfFirstRule = indexOfLastRule - rulesPerPage;
  const currentRules = filteredRules.slice(indexOfFirstRule, indexOfLastRule);

  // Change page
  const paginate = (pageNumber: number): void => setCurrentPage(pageNumber);

  // Calculate total pages
  const totalPages = Math.ceil(filteredRules.length / rulesPerPage);

  // Get status chip class based on status
  const getStatusChipClass = (status: string): string => {
    switch (status) {
      case "Warnings":
        return "bg-[#FFF4E5] text-[#FFA814]";
      case "Errors":
        return "bg-[#FFEBEE] text-[#E1142E]";
      default:
        return "bg-[#E8F5E9] text-[#33C037]";
    }
  };
  return (
    <div className="flex min-h-screen">
      <div className="flex-1 p-4">
        <div className="flex items-center justify-between gap-4 p-2">
          <header className="text-left">
            <h1 className="font-sans text-[48px] leading-[58px] text-[#810055] mb-4">
              Rules
            </h1>
          </header>
          <div className="flex gap-4">
            <button onClick={handleRefresh} className="flex items-center">
              <ArrowPathIcon
                className={`h-10 w-8 text-[#810055] mr-2 ${
                  isLoading ? "animate-spin" : ""
                }`}
              />
            </button>

            {/* Actions dropdown */}
            <div
              className="dropdown-container relative inline-block"
              ref={dropdownRef}
            >
              <button
                disabled={!selected}
                onClick={() => selected && setDropdownOpen(!dropdownOpen)}
                className={`inline-flex justify-center gap-x-1.5 font-medium rounded-full text-sm px-7 py-2.5 me-2 mb-2 transition-colors duration-300 ${
                  selected
                    ? "bg-[#810055] text-[#FFFFFF] hover:bg-[#990066] focus:ring-4 focus:ring-[#d48ac0]"
                    : "bg-[#F1F1ED] text-[#707070] cursor-not-allowed"
                }`}
              >
                Actions
                <svg
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                  className="-mr-1 size-5 text-[#FFFFFF]"
                >
                  <path
                    d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z"
                    clipRule="evenodd"
                    fillRule="evenodd"
                  />
                </svg>
              </button>

              {dropdownOpen && (
                <div className="absolute right-0 z-20 mt-2 w-56 origin-top-right rounded-md bg-white p-0 shadow-lg outline outline-1 outline-black/5">
                  <div className="py-1">
                    <button
                      className="block w-full text-left px-4 py-2 text-sm text-[#333333] hover:bg-[#F9F2F6] focus:outline-none"
                      onClick={openCalculateValidateModal}
                    >
                      Calculate & Validate
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Create rule button */}
            <button
              type="button"
              onClick={() => navigate("/CreateRule")}
              className="px-4 py-2 rounded-full opacity-100 transition-colors duration-300 ease-in-out bg-[#810055] text-white hover:bg-[#990066] focus:outline-none focus:ring-4 focus:ring-[#d48ac0] font-sans font-semibold text-[14px] text-center me-2 mb-2"
            >
              Create Rule
            </button>
          </div>
        </div>
        <div className="flex items-center pb-4 gap-6">
          {/* Search bar */}
          <div className="relative w-full max-w-md">
            <input
              type="search"
              id="default-search"
              value={searchTerm}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSearchTerm(e.target.value)
              }
              className="block w-full px-4 py-2 text-sm text-[#333333] border border-[#707070] rounded-lg bg-[#F1F1ED] focus:ring-[#00B5D6] focus:outline-none"
              placeholder="Search"
              required
            />
          </div>

          {/* Filter Dropdown */}
          <div className="flex flex-col mb-4">
            <h3 className="text-[14px] leading-[24px] font-semibold text-[#333333] mb-1">
              Filter by Rule Type
            </h3>
            <select
              className="rounded-md bg-[#F1F1ED] px-6 py-2 text-sm border border-[#707070] font-semibold text-[#333333] shadow hover:bg-[#F9F2F6]"
              value={selectedType}
              onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                setSelectedType(e.target.value)
              }
            >
              <option value="all">All Types</option>
              <option value="validation">Validation</option>
              <option value="calculation">Calculation</option>
            </select>
          </div>

          {/* Pagination */}
          <div className="ml-auto flex items-center justify-between border-t border-[#707070] bg-white px-4 py-3 sm:px-6">
            {/* Pagination content */}
            <div className="flex flex-1 justify-between sm:hidden">
              <a
                href="#"
                className="inline-flex items-center rounded-md border border-[#707070] bg-white px-4 py-2 text-sm font sm:justify-between"
              >
                Previous
              </a>
              <a
                href="#"
                className="inline-flex items-center rounded-md border border-[#707070] bg-white px-4 py-2 text-sm font sm:justify-between"
              >
                Next
              </a>
            </div>
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
              <div>
                <nav
                  aria-label="Pagination"
                  className="isolate inline-flex -space-x-px rounded-md shadow"
                >
                  {/* Pagination buttons */}
                  <a
                    href="#"
                    className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 inset-ring inset-ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                  >
                    <span className="sr-only">Previous</span>
                    <svg
                      viewBox="0 0 20 20"
                      fill="currentColor"
                      data-slot="icon"
                      aria-hidden="true"
                      className="size-5"
                    >
                      <path
                        d="M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z"
                        clipRule="evenodd"
                        fillRule="evenodd"
                      />
                    </svg>
                  </a>
                  <a
                    href="#"
                    aria-current="page"
                    className="relative z-10 inline-flex items-center bg-[#810055]-600 px-4 py-2 text-sm font-semibold text-black focus:z-20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                  >
                    1
                  </a>
                  {/* More pagination buttons */}
                  <a
                    href="#"
                    className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 inset-ring inset-ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                  >
                    <span className="sr-only">Next</span>
                    <svg
                      viewBox="0 0 20 20"
                      fill="currentColor"
                      data-slot="icon"
                      aria-hidden="true"
                      className="size-5"
                    >
                      <path
                        d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z"
                        clipRule="evenodd"
                        fillRule="evenodd"
                      />
                    </svg>
                  </a>
                </nav>
              </div>
            </div>
          </div>
        </div>

        {/* Delete confirmation toast */}
        {showToast && (
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-md p-6 text-[#707070] bg-white rounded-xl shadow-sm z-50">
            <div className="flex">
              <div className="inline-flex items-center justify-center shrink-0 w-10 h-10 text-[#810055] bg-[#f5e1f0] rounded-lg">
                <button
                  onClick={() => {
                    setShowToast(false);
                    setPendingDeleteId(null);
                  }}
                  className="inline-flex items-center justify-center w-10 h-10 text-[#810055] bg-[#f5e1f0] rounded-lg"
                  aria-label="Close"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 18 20">
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 6l6 6m0-6l-6 6"
                    />
                  </svg>
                </button>
              </div>

              <div className="ms-4 text-base font-normal">
                <span className="mb-2 text-base font-semibold text-[#333333] block">
                  Delete rule?
                </span>
                <div className="mb-4 text-base font-normal">
                  Are you sure you want to delete this rule?
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  <button
                    onClick={confirmDelete}
                    className="px-4 py-2 text-sm font-medium text-white bg-[#810055] rounded-lg hover:bg-[#990066]"
                  >
                    OK
                  </button>
                  <button
                    onClick={cancelDelete}
                    className="px-4 py-2 text-sm font-medium text-[#333333] bg-white border border-[#707070] rounded-lg hover:bg-[#F1F1ED]"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Calculate & Validate Modal */}
        {modalOpen && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ backgroundColor: "#00000080" }}
          >
            <div
              ref={modalRef}
              className={`bg-white rounded-lg shadow-xl overflow-hidden transition-all duration-300 ${
                isModalMaximized ? "fixed inset-2" : "relative"
              }`}
              style={{
                width: isModalMaximized ? "calc(100% - 16px)" : modalSize.width,
                height: isModalMaximized
                  ? "calc(100% - 16px)"
                  : modalSize.height,
                resize: isModalMaximized ? "none" : "both",
                overflow: "auto",
                minWidth: "300px",
                minHeight: "200px",
                display: "flex",
                flexDirection: "column",
              }}
            >
              {/* Modal Header */}
              <div
                className="flex justify-between items-center p-2 border-b bg-gray-50 cursor-move flex-shrink-0"
                onMouseDown={(e) => {
                  if (!isModalMaximized && e.target === e.currentTarget) {
                    isDraggingRef.current = true;
                    startPositionRef.current = { x: e.clientX, y: e.clientY };
                  }
                }}
              >
                <h3 className="text-xl font-semibold text-[#810055] pl-2">
                  Calculate And Validate
                </h3>
                <div className="flex items-center">
                  {/* Maximize/Restore button */}
                  <button
                    onClick={() => setIsModalMaximized(!isModalMaximized)}
                    className="text-gray-400 hover:text-gray-600 focus:outline-none mx-1"
                    title={isModalMaximized ? "Restore" : "Maximize"}
                  >
                    {isModalMaximized ? (
                      <svg
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"
                        />
                      </svg>
                    ) : (
                      <svg
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5"
                        />
                      </svg>
                    )}
                  </button>

                  {/* Close button */}
                  <button
                    onClick={() => setModalOpen(false)}
                    className="text-gray-400 hover:text-gray-600 focus:outline-none mx-1"
                    title="Close"
                  >
                    <svg
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="border-b border-gray-200 flex-shrink-0">
                <div className="flex">
                  <button
                    onClick={() => setActiveTab("calculate")}
                    className={`py-3 px-6 font-medium text-sm ${
                      activeTab === "calculate"
                        ? "border-b-2 border-[#810055] text-[#810055]"
                        : "text-gray-500 hover:text-gray-700"
                    }`}
                  >
                    Calculate
                  </button>
                  <button
                    onClick={() => setActiveTab("validate")}
                    className={`py-3 px-6 font-medium text-sm ${
                      activeTab === "validate"
                        ? "border-b-2 border-[#810055] text-[#810055]"
                        : "text-gray-500 hover:text-gray-700"
                    }`}
                  >
                    Validate
                  </button>
                </div>
              </div>

              {/* Modal Content */}
              <div className="flex-grow overflow-auto p-3">
                {activeTab === "calculate" ? (
                  /* Calculate Tab Content - Side by Side Layout */
                  <div className="h-full">
                    <p className="text-sm text-gray-600 mb-4">
                      Calculate rack height and dimensions based on warehouse
                      parameters.
                    </p>

                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Left Column - Inputs */}
                      <div className="bg-gray-50 p-2 rounded-lg lg:w-3/5">
                        <h3 className="font-sans font-semibold text-sm text-[#810055] mb-2">
                          Input Parameters
                        </h3>

                        {/* Basic Inputs */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-1 mb-4">
                          <div>
                            <label className="block font-sans text-sm font-medium text-gray-700 mb-1">
                              Warehouse clear height (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.warehouseClearHeight}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "warehouseClearHeight",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            />
                          </div>
                          <div>
                            <label className="block font-sans text-sm font-medium text-gray-700 mb-1">
                              Pallet height (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.palletHeight}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "palletHeight",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            />
                          </div>
                          {/* MHE Heights */}
                          <div>
                            <label className="block font-sans text-gray-700 text-sm font-medium mb-1">
                              MHE working height (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.mheWorkingHeight}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "mheWorkingHeight",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            />
                          </div>
                          <div>
                            <label className="block font-sans text-gray-700 text-sm font-medium mb-1">
                              MHE MFH (max fork height) (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.mheMFH}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "mheMFH",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            />
                          </div>
                        </div>

                        {/* MHE Basis */}
                        <div className="mb-4">
                          <label className="block font-sans text-gray-700 text-sm font-medium mb-1">
                            MHE basis
                          </label>
                          <div className="flex gap-4">
                            <label className="flex items-center text-sm">
                              <input
                                type="radio"
                                name="mheBasis"
                                value="WorkingHeight"
                                checked={
                                  calculateState.mheBasis === "WorkingHeight"
                                }
                                onChange={() =>
                                  updateCalculateState(
                                    "mheBasis",
                                    "WorkingHeight"
                                  )
                                }
                                className="mr-2 accent-godrej-purple"
                              />
                              <span>Working height</span>
                            </label>
                            <label className="flex items-center text-sm">
                              <input
                                type="radio"
                                name="mheBasis"
                                value="MFH"
                                checked={calculateState.mheBasis === "MFH"}
                                onChange={() =>
                                  updateCalculateState("mheBasis", "MFH")
                                }
                                className="mr-2"
                              />
                              <span>MFH (Max Fork Height)</span>
                            </label>
                          </div>
                        </div>

                        {/* Clearance and Pitch */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                          {/* Top Clearance */}
                          <div className="flex items-center">
                            <label className="w-[100px] text-sm font-medium text-gray-700">
                              Top clearance (mm)
                            </label>
                            <select
                              value={calculateState.topClearance}
                              onChange={(
                                e: React.ChangeEvent<HTMLSelectElement>
                              ) =>
                                updateCalculateState(
                                  "topClearance",
                                  parseFloat(e.target.value)
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            >
                              <option value="250">250 mm</option>
                              <option value="300">300 mm</option>
                            </select>
                          </div>

                          {/* Beam Pitch */}
                          <div className="flex items-center gap-4">
                            <label className="w-[100px] text-sm font-medium text-gray-700">
                              Beam pitch (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.pitch}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "pitch",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              min="25"
                              step="25"
                              className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                            />
                          </div>
                        </div>

                        {/* Unit Type */}
                        <div className="mb-4">
                          <label className="block text-gray-700 text-sm font-medium mb-1">
                            Unit type
                          </label>
                          <div className="flex gap-4">
                            <label className="flex items-center">
                              <input
                                type="radio"
                                name="unitType"
                                value="single"
                                checked={calculateState.unitType === "single"}
                                onChange={() =>
                                  updateCalculateState("unitType", "single")
                                }
                                className="mr-2 accent-godrej-purple"
                              />
                              <span className="font-sans text-sm">
                                Single-sided
                              </span>
                            </label>
                            <label className="flex items-center">
                              <input
                                type="radio"
                                name="unitType"
                                value="double"
                                checked={calculateState.unitType === "double"}
                                onChange={() =>
                                  updateCalculateState("unitType", "double")
                                }
                                className="mr-2"
                              />
                              <span className="font-sans text-sm">
                                Double-sided
                              </span>
                            </label>
                          </div>
                        </div>

                        {/* Frame Depth */}
                        {calculateState.unitType === "single" ? (
                          <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-medium mb-1">
                              Single frame overall depth (mm)
                            </label>
                            <input
                              type="number"
                              value={calculateState.singleFrameDepth}
                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) =>
                                updateCalculateState(
                                  "singleFrameDepth",
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-[100px] p-2 border border-gray-300 rounded"
                            />
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                            {/* Double frame A depth */}
                            <div>
                              <label className="w-[100px] text-sm font-medium text- #333333 mb-1">
                                Double frame A depth (mm)
                              </label>
                              <input
                                type="number"
                                value={calculateState.doubleFrameDepth1}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) =>
                                  updateCalculateState(
                                    "doubleFrameDepth1",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                              />
                            </div>

                            {/* Double frame B depth */}
                            <div>
                              <label className="w-[100px] text-sm font-medium text- #333333 mb-1">
                                Double frame B depth (mm)
                              </label>
                              <input
                                type="number"
                                value={calculateState.doubleFrameDepth2}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) =>
                                  updateCalculateState(
                                    "doubleFrameDepth2",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                              />
                            </div>

                            {/* Row connector length */}
                            <div>
                              <label className="w-[100px] text-sm font-medium text- #333333 mb-1">
                                Row connector length (mm)
                              </label>
                              <input
                                type="number"
                                value={calculateState.rowConnector}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) =>
                                  updateCalculateState(
                                    "rowConnector",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                className="w-[100px] p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#810055]"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Right Column - Results */}
                      <div className="lg:w-2/5">
                        {/* Results */}
                        <div className="bg-white p-2 rounded-lg border border-gray-300 h-full">
                          <h3 className="font-sans font-semibold text-sm text-[#810055] mb-4">
                            Calculation Results
                          </h3>

                          <div className="flex items-center mb-4">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusChipClass(
                                calculateState.status
                              )}`}
                            >
                              {calculateState.status}
                            </span>
                          </div>

                          <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text- #333333">
                                  Last loading level (from floor)
                                </p>
                                <p className="text-lg font-semibold">
                                  {calculateState.lastLoadingLevel || "—"}{" "}
                                  <span className="text-xs text-gray-500">
                                    mm
                                  </span>
                                </p>
                              </div>
                              <div>
                                <p className="text-sm text- #333333">
                                  Rack height
                                </p>
                                <p className="text-lg font-semibold">
                                  {calculateState.rackHeight || "—"}{" "}
                                  <span className="text-xs text-gray-500">
                                    mm
                                  </span>
                                </p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text- #333333">
                                  Computed depth
                                </p>
                                <p className="text-lg font-semibold">
                                  {calculateState.computedDepth || "—"}{" "}
                                  <span className="text-xs text-gray-500">
                                    mm
                                  </span>
                                </p>
                                <p className="text-xs text- #333333">
                                  {calculateState.depthBreakdown || "—"}
                                </p>
                              </div>
                              <div>
                                <p className="text-sm text- #333333">
                                  Height : Depth ratio
                                </p>
                                <p className="text-lg font-semibold">
                                  {calculateState.hdr || "—"}
                                </p>
                              </div>
                            </div>

                            {calculateState.messages.length > 0 && (
                              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                                <h4 className="font-medium text-gray-700 mb-2">
                                  Messages:
                                </h4>
                                <ul className="list-disc pl-5 text-sm text- #333333">
                                  {calculateState.messages.map(
                                    (message, index) => (
                                      <li key={index}>{message}</li>
                                    )
                                  )}
                                </ul>
                              </div>
                            )}
                          </div>

                          <div className="mt-6 text-xs text- #333333 bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-medium mb-2">Assumptions:</h4>
                            <ul className="list-disc pl-5">
                              <li>
                                Last loading level (LLL) = min(warehouse clear
                                height − 200 − pallet height, selected MHE
                                height − 200).
                              </li>
                              <li>
                                Rack height = LLL + top clearance (250 or 300
                                mm).
                              </li>
                              <li>
                                For Height:Depth ratio, height = LLL (per
                                guideline), depth depends on unit type.
                              </li>
                              <li>
                                Height:Depth ratio should be ≤ 6. If it exceeds,
                                stability components are recommended.
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Validate Tab Content - Side by Side Layout */
                  <div className="h-full">
                    <p className="text-sm text- #333333 mb-4">
                      Validate rack depth against the rule:{" "}
                      <strong>500 mm ≤ Depth ≤ 1500 mm</strong>.
                    </p>

                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Left Column - Inputs */}
                      <div className="bg-gray-50 p-4 rounded-lg lg:w-3/5">
                        <h3 className="font-sans text-sm text-[#810055] mb-2">
                          Input Parameters
                        </h3>

                        {/* Depth Input Mode */}
                        <div className="flex items-center gap-2 mb-4">
                          <input
                            type="checkbox"
                            id="knowDepth"
                            checked={knowDepth}
                            onChange={() =>
                              updateValidationState("knowDepth", !knowDepth)
                            }
                            style={{ accentColor: "#810055" }}
                            className="scale-110  "
                          />
                          <label
                            htmlFor="knowDepth"
                            className="text-sm font-medium"
                          >
                            I know the Rack Depth (enter directly)
                          </label>
                        </div>

                        {/* Depth Inputs */}
                        {knowDepth ? (
                          <div className="space-y-4">
                            <div>
                              <label className="block text- #333333">
                                Rack Depth (mm)
                              </label>
                              <input
                                type="number"
                                value={rackDepth}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) => {
                                  const value = e.target.value;
                                  if (value.length <= 6) {
                                    updateValidationState(
                                      "rackDepth",
                                      parseFloat(value) || 0
                                    );
                                  }
                                }}
                                className="w-[100px] p-2 border border-gray-300 rounded"
                              />
                            </div>
                            <div>
                              <label className="block text- #333333">
                                Adjust via slider
                              </label>
                              <input
                                type="range"
                                min="300"
                                max="2000"
                                value={rackDepth}
                                onChange={(e) =>
                                  updateValidationState(
                                    "rackDepth",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                style={{
                                  background: `linear-gradient(to right, #810055 ${
                                    ((rackDepth - 300) / (2000 - 300)) * 100
                                  }%, #fff ${
                                    ((rackDepth - 300) / (2000 - 300)) * 100
                                  }%)`,
                                }}
                                className="w-full appearance-none h-2 rounded-full 
                                  [&::-webkit-slider-thumb]:appearance-none 
                                  [&::-webkit-slider-thumb]:h-4 
                                  [&::-webkit-slider-thumb]:w-4 
                                  [&::-webkit-slider-thumb]:bg-[#810055] 
                                  [&::-webkit-slider-thumb]:rounded-full 
                                  [&::-webkit-slider-thumb]:cursor-pointer"
                              />

                              <div className="flex justify-between text-xs text-gray-500">
                                <span>300 mm</span>
                                <span>2000 mm</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex gap-13 items-end">
                              <label className="block text-gray-700 text-sm mb-1">
                                Pallet Depth (mm)
                              </label>
                              <input
                                type="number"
                                value={palletDepth}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) => {
                                  const value = e.target.value;
                                  if (value.length <= 6) {
                                    updateValidationState(
                                      "palletDepth",
                                      parseFloat(value) || 0
                                    );
                                  }
                                }}
                                className="w-[100px] p-2 border border-gray-300 rounded"
                              />
                            </div>
                            <div className="flex gap-7 items-end">
                              <label className="block text-gray-700 text-sm mb-1">
                                Front Clearance (mm)
                              </label>
                              <input
                                type="number"
                                value={frontClear}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) =>
                                  updateValidationState(
                                    "frontClear",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                className="w-[100px] p-2 border border-gray-300 rounded"
                              />
                            </div>
                            <div className="flex gap-4 items-end">
                              <label className="block text-gray-700">
                                Rear Clearance (mm)
                              </label>
                              <input
                                type="number"
                                value={rearClear}
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) =>
                                  updateValidationState(
                                    "rearClear",
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                className="w-[100px] p-2 border border-gray-300 rounded"
                              />
                            </div>
                            <p className="text-xs text-gray-500">
                              Computed:{" "}
                              <em>
                                Rack Depth = Pallet depth + Front clearance +
                                Rear clearance
                              </em>
                            </p>
                          </div>
                        )}
                        {/* Advanced Validation Limits */}
                        <div className="mt-6">
                          <label className="flex items-center gap-1">
                            <input
                              type="checkbox"
                              checked={editLimits}
                              onChange={() =>
                                updateValidationState("editLimits", !editLimits)
                              }
                              style={{ accentColor: "#810055" }}
                              className="scale-110"
                            />
                            <span className="text-sm font-medium">
                              Advanced: Edit allowed depth limits
                            </span>
                          </label>

                          {editLimits && (
                            <div className="grid grid-cols-2 gap-4 mt-4">
                              <div>
                                <label className="block text-gray-700">
                                  Min allowed depth (mm)
                                </label>
                                <input
                                  type="number"
                                  value={minDepth}
                                  onChange={(
                                    e: React.ChangeEvent<HTMLInputElement>
                                  ) =>
                                    updateValidationState(
                                      "minDepth",
                                      parseFloat(e.target.value) || 0
                                    )
                                  }
                                  className="w-[100px] p-2 border border-gray-300 rounded"
                                />
                              </div>
                              <div>
                                <label className="block text-gray-700">
                                  Max allowed depth (mm)
                                </label>
                                <input
                                  type="number"
                                  value={maxDepth}
                                  onChange={(
                                    e: React.ChangeEvent<HTMLInputElement>
                                  ) =>
                                    updateValidationState(
                                      "maxDepth",
                                      parseFloat(e.target.value) || 0
                                    )
                                  }
                                  className="w-[100px] p-2 border border-gray-300 rounded"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right Column - Results with Enhanced Visualization */}
                      <div className="lg:w-2/5">
                        <div className="bg-white p-2 rounded-lg border border-gray-300 h-full">
                          <h3 className="font-semibold text-[#810055] mb-1">
                            Validation Results
                          </h3>
                          <div>
                            <div className="space-y-2 ">
                              <div className="bg-gray-50">
                                <p className="text-sm text- #333333">
                                  Computed/Entered Rack Depth
                                </p>
                                <p className="text-lg font-semibold">
                                  {computedDepth}{" "}
                                  <span className="text-xs text- #333333">
                                    mm
                                  </span>
                                </p>
                                <p className="text-xs text- #333333">
                                  {knowDepth
                                    ? "Entered directly"
                                    : `Pallet ${palletDepth} mm + Front ${frontClear} mm + Rear ${rearClear} mm`}
                                </p>
                              </div>

                              {/* Enhanced depth visualization band */}
                              <div>
                                <div className="relative h-3 mb-1 ">
                                  {/* Background band */}
                                  <div className="absolute inset-0 bg-gray-100 border border-gray-300 rounded-lg"></div>

                                  {/* Valid range band */}
                                  <div
                                    className="absolute top-0 bottom-0 bg-[rgba(32,201,151,.25)] border border-[rgba(32,201,151,.35)] rounded-lg"
                                    style={{
                                      left: `${Math.max(
                                        0,
                                        ((minDepth - 300) / (2000 - 300)) * 100
                                      )}%`,
                                      right: `${Math.max(
                                        0,
                                        100 -
                                          ((maxDepth - 300) / (2000 - 300)) *
                                            100
                                      )}%`,
                                    }}
                                  ></div>

                                  {/* Current value thumb */}
                                  <div
                                    className="absolute top-[-1px] bottom-[-1px] w-2 bg-[#4db6ff]"
                                    style={{
                                      left: `${Math.max(
                                        0,
                                        Math.min(
                                          100,
                                          ((computedDepth - 300) /
                                            (2000 - 300)) *
                                            100
                                        )
                                      )}%`,
                                      transform: "translateX(-50%)",
                                      boxShadow:
                                        "0 0 0 2px rgba(77,182,255,.25)",
                                      borderRadius: "1px",
                                    }}
                                  ></div>
                                </div>

                                <div className="text-xs text- #333333 mt-1">
                                  Scale: 300 mm → 2000 mm
                                </div>
                              </div>
                            </div>

                            <div className="bg-gray-50 rounded-lg">
                              <p className="text-sm text- #333333">
                                Validation
                              </p>
                              <div className="mt-2">
                                <span
                                  className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                                    computedDepth < minDepth ||
                                    computedDepth > maxDepth
                                      ? "bg-[rgba(255,107,107,.12)] text-[#ff9b9b] border border-[ #E1142E]"
                                      : "bg-[rgba(32,201,151,.12)] text-[#33C037] border border-[#33C037]"
                                  }`}
                                >
                                  {computedDepth < minDepth
                                    ? "FAIL: Too shallow"
                                    : computedDepth > maxDepth
                                    ? "FAIL: Too deep"
                                    : "PASS"}
                                </span>
                              </div>

                              <p className="text-sm text- #333333 ">
                                {computedDepth < minDepth
                                  ? `Depth is ${
                                      minDepth - computedDepth
                                    } mm below minimum (${minDepth} mm).`
                                  : computedDepth > maxDepth
                                  ? `Depth exceeds maximum by ${
                                      computedDepth - maxDepth
                                    } mm (max ${maxDepth} mm).`
                                  : `Within allowed band ${minDepth} mm to ${maxDepth} mm.`}
                              </p>
                            </div>

                            {!isValid && (
                              <div className="bg-gray-50 rounded-lg">
                                <h4 className="font-medium text-gray-700 mb-2">
                                  Recommendation:
                                </h4>
                                <p className="text-sm text-gray-600">
                                  {computedDepth < minDepth
                                    ? `Increase depth by at least ${
                                        minDepth - computedDepth
                                      } mm to meet the minimum allowed limit.`
                                    : `Reduce depth by at least ${
                                        computedDepth - maxDepth
                                      } mm to meet the maximum allowed limit.`}
                                </p>
                              </div>
                            )}
                          </div>

                          <div className="mt-6 text-xs text- #333333 bg-gray-50  rounded-lg">
                            <h4 className="font-medium mb-2">Design Rule:</h4>
                            <p>
                              Depth is validated between{" "}
                              <strong>min. {minDepth} mm</strong> and{" "}
                              <strong>max. {maxDepth} mm</strong>.
                            </p>
                            <p className="mt-2">
                              When "Compute" mode is used,{" "}
                              <em>
                                Rack Depth = Pallet depth + Front clearance +
                                Rear clearance
                              </em>
                              .
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Rules table */}
        <div className="relative overflow-x-auto">
          <table className="table-auto w-full text-sm text-left text-[#707070]">
            <thead className="text-[12px] font-semibold text-[#333333] uppercase bg-[#F1F1ED]">
              <tr>
                <th scope="col" className="px-6 py-3"></th>
                <th scope="col" className="px-6 py-3">
                  Rule name
                </th>
                <th scope="col" className="px-6 py-3">
                  Rule Type
                </th>
                <th scope="col" className="px-6 py-3">
                  Severity
                </th>
                <th scope="col" className="px-6 py-3">
                  Description
                </th>
                <th scope="col" className="px-6 py-3">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td
                    colSpan={6}
                    className="px-6 py-4 text-center text-[#333333]"
                  >
                    Loading rules...
                  </td>
                </tr>
              ) : filteredRules.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    className="px-6 py-4 text-center text-[#333333]"
                  >
                    No rules found
                  </td>
                </tr>
              ) : (
                filteredRules.map((rule) => (
                  <React.Fragment key={rule.id}>
                    <tr
                      className={`border-b border-[#F1F1ED] ${
                        selectedRuleId === rule.id ? "bg-[#F9F2F6]" : "bg-white"
                      }`}
                    >
                      <td scope="col" className="px-6 py-3">
                        <input
                          id={`radio-${rule.id}`}
                          type="radio"
                          name="selected-rule"
                          checked={selectedRuleId === rule.id}
                          onChange={() => handleSelectRule(rule.id)}
                          className="w-4 h-4 accent-godrej-purple bg-[#F1F1ED] border-[#707070] focus:ring-[#00B5D6]"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <button
                            onClick={() => toggleAccordion(rule.id)}
                            className="mr-2"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              strokeWidth={1.5}
                              stroke="#810055"
                              className="w-6 h-6 text-[#810055]"
                            >
                              {expandedRows[rule.id] ? (
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  d="M15 12H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                                />
                              ) : (
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                                />
                              )}
                            </svg>
                          </button>
                          <span className="text-[#333333]">{rule.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-[#333333]">{rule.type}</td>
                      <td className="px-6 py-4">
                        {rule.type === "validation" && (
                          <span
                            className={`px-2 py-1 text-xs rounded-full font-medium ${
                              rule.severity === "warning"
                                ? "bg-[#FFF4E5] text-[#FFA814]"
                                : "bg-[#F1F1ED] text-[#707070]"
                            }`}
                          >
                            {rule.severity || "info"}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-[#333333]">
                        {rule.description || rule.message || "-"}
                      </td>

                      {/* Actions Column */}
                      <td className="px-6 py-4 flex gap-4 items-center">
                        <button
                          onClick={() => handleEditRule(rule.id)}
                          className="group"
                          title="Edit"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={1.5}
                            stroke="#810055"
                            className="w-5 h-5 text-[#810055] group-hover:text-[#6c0048]"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDeleteRule(rule.id)}
                          className="text-[#FF4D4F] hover:text-red-600"
                          title="Delete"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={1.5}
                            stroke="#810055"
                            className="w-6 h-6"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                            />
                          </svg>
                        </button>
                      </td>
                    </tr>

                    {/* Expanded Row */}
                    {expandedRows[rule.id] && (
                      <tr className="bg-[#F1F1ED]">
                        <td colSpan={6} className="px-6 py-4">
                          <div className="bg-white p-4 rounded-md border border-[#F1F1ED] shadow-sm">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-[14px] font-semibold text-[#333333] mb-2">
                                  Rule Details:
                                </h4>
                                <pre className="text-[13px] text-[#707070] bg-[#F1F1ED] p-3 rounded overflow-auto max-h-60">
                                  {JSON.stringify(
                                    prepareRuleForDisplay(rule),
                                    null,
                                    2
                                  )}
                                </pre>
                              </div>

                              <div className="flex gap-4 ml-4">
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleCopy(
                                      JSON.stringify(
                                        prepareRuleForDisplay(rule),
                                        null,
                                        2
                                      )
                                    )
                                  }
                                  className="px-4 py-2 text-sm font-medium text-white bg-[#707070] rounded hover:bg-green-600 focus:outline-none focus:bg-green-600 focus:ring-2 focus:ring-green-300"
                                >
                                  Copy JSON
                                </button>

                                {copied && (
                                  <div
                                    id="toast-success"
                                    className="fixed bottom-4 right-4 flex items-center w-full max-w-xs p-4 mb-4 text-gray-500 bg-white rounded-lg shadow-sm"
                                    role="alert"
                                  >
                                    <div className="inline-flex items-center justify-center shrink-0 w-8 h-8 text-green-500 bg-green-100 rounded-lg">
                                      <svg
                                        className="w-5 h-5"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                      >
                                        <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                                      </svg>
                                    </div>
                                    <div className="ms-3 text-sm font-normal">
                                      Copied successfully!
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => setCopied(false)}
                                      className="ms-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex items-center justify-center h-8 w-8"
                                      aria-label="Close"
                                    >
                                      <svg
                                        className="w-3 h-3"
                                        fill="none"
                                        viewBox="0 0 14 14"
                                      >
                                        <path
                                          stroke="currentColor"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          strokeWidth="2"
                                          d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                                        />
                                      </svg>
                                    </button>
                                  </div>
                                )}

                                <button
                                  type="button"
                                  onClick={() =>
                                    console.log("Validate clicked for", rule.id)
                                  }
                                  className="px-4 py-2 text-sm font-medium text-white bg-[#707070] rounded hover:bg-godrej-purple focus:outline-none focus: bg-godrej-purple focus:ring-2 focus:ring-godrej-purple"
                                >
                                  Edit JSON
                                </button>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
        {/* Show loading or empty state if needed */}

        {isLoading && (
          <div className="flex justify-center my-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#00B5D6]"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RulePolicy;
