import React from 'react'
import { Link } from 'react-router'

const PageNotFound = () => {
  return (
    <div data-testid="pageNotFoundContainer" className='flex flex-col gap-2'>
        <h1 data-testid="pageNotFoundHeader">404 - Page Not Found</h1>
        <Link to="/">Go to Home</Link>
        <a href="/">Home from Anchor</a>
    </div>
  )
}

export default PageNotFound
