import React, { useRef, useState } from "react";

const CodeInput = () => {
  const length = 6; // Define the number of input boxes
  const [values, setValues] = useState<string[]>(Array(length).fill(""));
  const inputsRef = useRef<Array<HTMLInputElement | null>>([]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;

    const newValues = [...values];
    newValues[index] = value;
    setValues(newValues);

    // Move to next input automatically
    if (value && index < length - 1) {
      inputsRef.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Backspace" && !values[index] && index > 0) {
      const newValues = [...values];
      newValues[index - 1] = "";
      setValues(newValues);
      inputsRef.current[index - 1]?.focus();
    }
  };

  return (
    <div className="flex">
      {values.map((val, index) => (
        <input
          data-testid={`codeInput-${index}`}
          key={index}
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={val}
          onChange={(e) => handleChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          ref={(el) => (inputsRef.current[index] = el)}
          className={`w-13 h-12 text-center text-lg font-medium border outline-none transition-all ${
            val ? "border-gray-400" : "border-gray-300"
          } focus:border-godrej-grey-500 focus:ring-2 focus:ring-godrej-grey`}
        />
      ))}
    </div>
  );
};

export default CodeInput;