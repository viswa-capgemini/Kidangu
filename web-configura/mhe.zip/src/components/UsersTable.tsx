
import * as React from 'react';
import {
  DataGrid,
  type GridColDef,
  type GridRenderCellParams,
  GridPagination,
  GridFooterContainer,
  useGridApiContext,
  useGridSelector,
  gridPageSelector,
  gridPageSizeSelector,
  gridRowCountSelector,
} from '@mui/x-data-grid';
import {
  Box,
  Chip,
  IconButton,
  Tooltip,
  Stack,
  Typography,
  Link as MuiLink,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';

// ---- Types ----
export type UserRow = {
  enquiryId: string;
  customer_name: string;
  actions: string;            // Description shown in “Actions” column (from screenshot)
  created_date: string;       // e.g., "2025-04-01" or ISO string
  email_id: string;
  reference_no: string;
  product_group: string;      // e.g., "SPR, Cantilever"
  billing_address: string;
  status?: 'Active' | 'Inactive' | 'Pending'; // optional to allow "N/A" look
  view_ga: string;            // "ICON" means available; "N/A" means not available
  view_bom: string;           // same as above
  update: string;             // "ICON" to show edit/delete buttons
};

// ---- Sample data (replace with API data) ----
const rows: UserRow[] = [
  {
    enquiryId: 'ENG-A89N7YCM',
    customer_name: 'Coca cola',
    actions: 'Multi layer warehouse configuration',
    created_date: '2025-04-01',
    email_id: 'cocacola@gmail.com',
    reference_no: 'GDCC1',
    product_group: 'SPR',
    billing_address: 'Chennai',
    status: 'Pending',
    view_ga: 'N/A',
    view_bom: 'N/A',
    update: 'ICON',
  },
  {
    enquiryId: 'ENG-Q987MYCM',
    customer_name: 'Pepsi',
    actions: 'Multi layer warehouse configuration',
    created_date: '2025-04-01',
    email_id: 'cocacola@gmail.com',
    reference_no: '123456',
    product_group: 'SPR, Cantilever',
    billing_address: 'Chennai',
    status: undefined, // will render "N/A"
    view_ga: 'N/A',
    view_bom: 'N/A',
    update: 'ICON',
  },
];

// ---- Helpers ----
const formatToYYYYMMDD = (value: string) => {
  // Accepts either "YYYY-MM-DD" or ISO date strings and returns "YYYY-MM-DD"
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
};

const statusChip = (status?: UserRow['status']) => {
  if (!status) return <Typography variant="body2" color="text.secondary">N/A</Typography>;
  const color =
    status === 'Active' ? 'success' :
    status === 'Pending' ? 'warning' : 'default';
  return <Chip size="small" label={status} color={color} variant="filled" />;
};

// ---- Custom footer for “Showing X–Y of N results” ----
function CustomFooter() {
  const apiRef = useGridApiContext();
  const page = useGridSelector(apiRef, gridPageSelector);
  const pageSize = useGridSelector(apiRef, gridPageSizeSelector);
  const rowCount = useGridSelector(apiRef, gridRowCountSelector);

  const from = rowCount === 0 ? 0 : page * pageSize + 1;
  const to = Math.min(rowCount, (page + 1) * pageSize);

  return (
    <GridFooterContainer sx={{ px: 2 }}>
      <Box sx={{ fontSize: 12, color: 'text.secondary' }}>
        {`Showing ${from}-${to} of ${rowCount} results`}
      </Box>
      <Box sx={{ flex: 1 }} />
      <GridPagination
        // Change label "Rows per page" -> "Items per page"
        labelRowsPerPage="Items per page"
      />
    </GridFooterContainer>
  );
}

// columns will be created inside component

// ---- Component ----
export default function UsersTable() {
  const [paginationModel, setPaginationModel] = React.useState({ page: 0, pageSize: 10 });
  const navigate = useNavigate();

  const columns: GridColDef<UserRow>[] = [
    {
      field: 'enquiryId',
      headerName: 'Enquiry ID',
      flex: 1,
      minWidth: 160,
      renderCell: (params: GridRenderCellParams<UserRow, string>) => (
        <Tooltip title="Open enquiry">
          <Typography
            variant="body2"
            fontWeight={600}
            color="#810055"
            sx={{ cursor: 'pointer' }}
            onClick={() => navigate(`/enquiry-details/${encodeURIComponent(String(params.value))}`)}
          >
            {params.value}
          </Typography>
        </Tooltip>
      ),
    },
    {
      field: 'customer_name',
      headerName: 'Customer Name',
      flex: 1,
      minWidth: 130,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      flex: 1.4,
      minWidth: 180,
      renderCell: (p) => (
        <Typography variant="body2" sx={{ whiteSpace: 'normal', lineHeight: 1.25 }}>
          {p.value}
        </Typography>
      ),
    },
    {
      field: 'email_id',
      headerName: 'Email ID',
      flex: 1.2,
      minWidth: 170,
      renderCell: (p) => (
        <MuiLink href={`mailto:${p.value}`} underline="hover" sx={{color: "black"}}>
          {p.value}
        </MuiLink>
      ),
    },
    {
      field: 'reference_no',
      headerName: 'Reference No',
      flex: 0.9,
      minWidth: 120,
    },
    {
      field: 'product_group',
      headerName: 'Product Group',
      flex: 1.2,
      minWidth: 170,
    },
    {
      field: 'billing_address',
      headerName: 'Billing Address',
      flex: 1,
      minWidth: 140,
    },
    {
      field: 'status',
      headerName: 'Status',
      flex: 0.8,
      minWidth: 100,
      renderCell: (p: GridRenderCellParams<UserRow, UserRow['status']>) => statusChip(p.value),
      sortable: true,
    },
    {
      field: 'view_ga',
      headerName: 'View GA',
      flex: 0.6,
      minWidth: 90,
      align: 'center',
      headerAlign: 'center',
      sortable: false,
      filterable: false,
      renderCell: (p) =>
        p.value === 'N/A' ? (
          <Typography variant="body2" color="text.secondary">N/A</Typography>
        ) : (
          <Tooltip title="View GA">
            <IconButton size="small" onClick={() => console.log('View GA', p.row.enquiryId)}>
              <VisibilityOutlinedIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        ),
    },
    {
      field: 'view_bom',
      headerName: 'View BOM',
      flex: 0.7,
      minWidth: 100,
      align: 'center',
      headerAlign: 'center',
      sortable: false,
      filterable: false,
      renderCell: (p) =>
        p.value === 'N/A' ? (
          <Typography variant="body2" color="text.secondary">N/A</Typography>
        ) : (
          <Tooltip title="View BOM">
            <IconButton size="small" onClick={() => console.log('View BOM', p.row.enquiryId)}>
              <VisibilityOutlinedIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        ),
    },
    {
      field: 'update',
      headerName: 'Update',
      width: 110,
      align: 'center',
      headerAlign: 'center',
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      renderCell: (p) => (
        <Stack direction="row" spacing={0.5} justifyContent="center">
          <Tooltip title="Edit">
            <IconButton
              size="small"
              onClick={() => console.log('Edit', p.row.enquiryId)}
            >
              <EditOutlinedIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton
              size="small"
              color="error"
              onClick={() => console.log('Delete', p.row.enquiryId)}
            >
              <DeleteOutlineOutlinedIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Stack>
      ),
    },
  ];

  // If you’re doing server-side pagination, set this to API total.
  // For the screenshot look, you can set 120.
  const totalRowCount = 120; // rows.length for client-side; replace with API total for server-side.

  return (
    <Box
      sx={{
        height: 520,
        width: '100%',
        '& .MuiDataGrid-columnHeaders': {
          position: 'sticky',
          top: 0,
          zIndex: 1,
        },
      }}
      className="p-2"
    >
      <DataGrid<UserRow>
        rows={rows}
        columns={columns}
        getRowId={(r) => r.enquiryId}
        disableRowSelectionOnClick
        checkboxSelection={false}
        // Pagination
        paginationModel={paginationModel}
        onPaginationModelChange={setPaginationModel}
        pageSizeOptions={[10, 25, 50]}
        rowCount={totalRowCount}
        // Turn this to 'server' if you load pages from API
        paginationMode="client"
        // Sorting (optional)
        initialState={{
          sorting: { sortModel: [{ field: 'enquiryId', sort: 'asc' }] },
        }}
        // Custom footer for "Showing X–Y of N results"
        slots={{
          footer: CustomFooter,
        }}
        // Tone & minor visuals
        sx={{
          '& .MuiDataGrid-cell': { alignItems: 'center' },
          '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 600 },
        }}
      />
    </Box>
  );
}
