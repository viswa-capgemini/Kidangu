import axios from 'axios';
 
const API_BASE_URL = 'https://5yzuz4kl73.execute-api.eu-north-1.amazonaws.com/prod/api';
const S3_BUCKET_NAME = 'my-dxf-bucket';
 
// Create an axios instance with proper configuration
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 10 seconds timeout
});
 
// Add request interceptor for debugging
apiClient.interceptors.request.use(request => {
  console.log('Starting API Request:', request.url);
  return request;
});
 
// Add response interceptor for debugging
apiClient.interceptors.response.use(
  response => {
    console.log('API Response Success:', response.config.url);
    return response;
  },
  error => {
    console.error('API Response Error:', error.config?.url, error.message);
    return Promise.reject(error);
  }
);
 
// Define interface for upload metadata
interface UploadMetadata {
  product_id: string;
  name: string;
  pg_name: string[];
  category: string[];
  comp_type: string[];
  uploaded_date: string;
  last_revised: string;
  s3_bucket_url: string;
  file_size: number;
  file_type: string;
}
 
// Define interface for S3 upload result
interface S3UploadResult {
  success: boolean;
  url?: string;
  key?: string;
  error?: string;
}
 
/**
 * Upload a file to S3 via backend presigned URL
 */
export const uploadFileToS3 = async (file: File, fileName: string): Promise<S3UploadResult> => {
  try {
    console.log(`Requesting presigned URL for ${fileName}...`, {
      endpoint: `${API_BASE_URL}/products/presigned-url`,
      fileType: file.type || 'model/gltf-binary',
      fileSize: file.size
    });
   
    // Step 1: Get a presigned URL from your backend
    const response = await axios.post(`${API_BASE_URL}/products/presigned-url`, {
      fileName,
      fileType: file.type || 'model/gltf-binary',
      fileSize: file.size
    }).catch(error => {
      console.error('Error getting presigned URL:', error.message);
      if (error.response) {
        console.error('Response data:', error.response.data);
        console.error('Response status:', error.response.status);
      }
      throw error;
    });
 
    console.log('Presigned URL response:', response.data);
   
    const { presignedUrl, key } = response.data;
   
    if (!presignedUrl || !key) {
      console.error('Missing presignedUrl or key in response:', response.data);
      return {
        success: false,
        error: 'Invalid response from server'
      };
    }
   
    console.log(`Received presigned URL: ${presignedUrl.substring(0, 100)}...`);
    console.log(`S3 key: ${key}`);
 
    // Create form data for upload
    const formData = new FormData();
    formData.append('file', file);
    formData.append('key', key);
   
    console.log('Uploading file to backend proxy:', {
      endpoint: `${API_BASE_URL}/products/upload`,
      fileSize: file.size,
      key: key
    });
   
    // Upload via our backend proxy
    const uploadResponse = await axios.post(`${API_BASE_URL}/products/upload`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round((progressEvent.loaded * 100) / (progressEvent.total || progressEvent.loaded));
        console.log(`Upload progress: ${percentCompleted}%`);
      }
    }).catch(error => {
      console.error('Error uploading file:', error.message);
      if (error.response) {
        console.error('Response data:', error.response.data);
        console.error('Response status:', error.response.status);
      }
      throw error;
    });
 
    console.log('Upload completed successfully:', uploadResponse.data);
   
    // Construct the S3 URL
    const url = `https://${S3_BUCKET_NAME}.s3.amazonaws.com/${key}`;
   
    // Return the S3 URL and key
    return {
      success: true,
      url,
      key
    };
  } catch (error) {
    console.error('Error uploading to S3:', error);
   
    // Provide more detailed error information
    let errorMessage = 'Failed to upload file to S3';
    if (axios.isAxiosError(error)) {
      if (error.response) {
        errorMessage = `Server error: ${error.response.status} - ${JSON.stringify(error.response.data)}`;
      } else if (error.request) {
        errorMessage = 'No response received from server';
      } else {
        errorMessage = `Error: ${error.message}`;
      }
    }
   
    return {
      success: false,
      error: errorMessage
    };
  }
};
 
/**
 * Save product metadata to the backend
 */
export const saveProductMetadata = async (metadata: UploadMetadata): Promise<{ success: boolean; error?: string }> => {
  try {
    console.log('Saving product metadata:', metadata);
   
    const response = await axios.post(`${API_BASE_URL}/products`, metadata);
   
    console.log('Metadata saved successfully:', response.data);
   
    return {
      success: true
    };
  } catch (error) {
    console.error('Error saving metadata:', error);
   
    let errorMessage = 'Failed to save product metadata';
    if (axios.isAxiosError(error)) {
      if (error.response) {
        errorMessage = `Server error: ${error.response.status} - ${JSON.stringify(error.response.data)}`;
      } else if (error.request) {
        errorMessage = 'No response received from server';
      } else {
        errorMessage = `Error: ${error.message}`;
      }
    }
   
    return {
      success: false,
      error: errorMessage
    };
  }
};
 
/**
 * Fetch all products from the backend
 */
export const fetchProducts = async (): Promise<{ success: boolean; products?: any[]; error?: string }> => {
  try {
    const response = await axios.get('https://5yzuz4kl73.execute-api.eu-north-1.amazonaws.com/prod/api/products');
    return {
      success: true,
      products: response.data.products
    };
  } catch (error) {
    console.error('Error fetching products:', error);
   
    let errorMessage = 'Failed to fetch products';
    if (axios.isAxiosError(error)) {
      if (error.response) {
        errorMessage = `Server error: ${error.response.status} - ${JSON.stringify(error.response.data)}`;
      } else if (error.request) {
        errorMessage = 'No response received from server';
      } else {
        errorMessage = `Error: ${error.message}`;
      }
    }
   
    return {
      success: false,
      error: errorMessage
    };
  }
};
 
/**
 * Delete a product by ID
 */
export const deleteProduct = async (productId: string): Promise<{ success: boolean; error?: string }> => {
  try {
    const response = await axios.delete(`${API_BASE_URL}/products/${productId}`);
    return {
      success: true
    };
  } catch (error) {
    console.error('Error deleting product:', error);
   
    let errorMessage = 'Failed to delete product';
    if (axios.isAxiosError(error)) {
      if (error.response) {
        errorMessage = `Server error: ${error.response.status} - ${JSON.stringify(error.response.data)}`;
      }
    }
   
    return {
      success: false,
      error: errorMessage
    };
  }
};
 
 
/**
 * Test S3 connection and upload
 */
export const testS3Connection = async (): Promise<{ success: boolean; message: string }> => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/test-s3`);
    return {
      success: true,
      message: 'S3 connection successful'
    };
  } catch (error) {
    console.error('Error testing S3 connection:', error);
    return {
      success: false,
      message: 'S3 connection failed'
    };
  }
};