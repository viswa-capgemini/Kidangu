
// MultiSelect.tsx
import * as React from 'react';
import { Autocomplete, TextField, type SxProps, type Theme } from '@mui/material';

type Option = { value: string; label: string };

export const MultiSelect: React.FC<{
  label: string;
  options: Option[];
  value: string[];
  onChange: (value: string[]) => void;
  sx?: SxProps<Theme>;
}> = ({ label, options, value, onChange, sx }) => {
  return (
    <Autocomplete
      multiple
      options={options}
      getOptionLabel={(o) => o.label}
      value={options.filter((o) => value.includes(o.value))}
      onChange={(_, newVal) => onChange(newVal.map((v) => v.value))}
      sx={{ minWidth: 220, ...sx }} // <-- forward sx to Autocomplete
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          size="small"
          variant="outlined"
          color="primary" // <-- ensures focus uses theme.palette.primary
        />
      )}
    />
  );
};
