import React, { useEffect, useState, Suspense, useRef } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { 
  Environment, 
  OrbitControls, 
  Html, 
  useGLTF, 
  Center, 
  PerspectiveCamera,
  useProgress,
  Stats
} from '@react-three/drei';
import * as THREE from 'three';

// Loading indicator component
function LoadingIndicator() {
  const { progress } = useProgress();
  return (
    <Html center>
      <div style={{ 
        color: 'white', 
        background: 'rgba(0,0,0,0.7)', 
        padding: '12px 16px', 
        borderRadius: '4px',
        textAlign: 'center' 
      }}>
        Loading: {progress.toFixed(0)}%
      </div>
    </Html>
  );
}

// Debug component to show axes and grid
function DebugHelpers() {
  return (
    <>
      <axesHelper args={[5]} />
      <gridHelper args={[10, 10]} />
    </>
  );
}

// Camera controller to automatically fit the model
function CameraController({ modelRef }) {
  const { camera, scene } = useThree();
  
  useEffect(() => {
    if (modelRef.current) {
      // Create a bounding box for the model
      const box = new THREE.Box3().setFromObject(modelRef.current);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      
      // Get the max dimension of the model
      const maxDim = Math.max(size.x, size.y, size.z);
      const fov = camera.fov * (Math.PI / 180);
      let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
      
      // Set a minimum distance
      cameraZ = Math.max(cameraZ * 1.5, 2);
      
      // Update camera position and look at center of model
      camera.position.set(center.x, center.y, center.z + cameraZ);
      camera.lookAt(center);
      camera.updateProjectionMatrix();
      
      console.log('Camera positioned at:', camera.position);
      console.log('Looking at center:', center);
      console.log('Model size:', size);
    }
  }, [camera, modelRef, scene]);
  
  return null;
}

// Model component with error handling
function Model({ url }) {
  const modelRef = useRef();
  const [error, setError] = useState(null);
  
  useEffect(() => {
    console.log('Loading model from URL:', url);
  }, [url]);
  
  try {
    const { scene } = useGLTF(url);
    
    useEffect(() => {
      if (scene) {
        console.log('Model loaded successfully:', scene);
      }
    }, [scene]);
    
    return (
      <Center ref={modelRef}>
        <primitive object={scene} />
        <CameraController modelRef={modelRef} />
      </Center>
    );
  } catch (err) {
    console.error('Error loading GLB model:', err);
    setError(err.message);
    return (
      <Html center>
        <div style={{ color: 'red', background: 'rgba(0,0,0,0.7)', padding: '10px' }}>
          Error loading model: {error || 'Unknown error'}
        </div>
      </Html>
    );
  }
}

// Simple test object to verify rendering
function TestObject() {
  return (
    <mesh position={[0, 0, 0]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="hotpink" />
    </mesh>
  );
}

const ThreeScene = ({ url }) => {
  const [showDebug, setShowDebug] = useState(false);
  const [showTestObject, setShowTestObject] = useState(false);
  
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'd') setShowDebug(prev => !prev);
      if (e.key === 't') setShowTestObject(prev => !prev);
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);
  
  useEffect(() => {
    console.log('ThreeScene mounted with URL:', url);
    return () => {
      console.log('ThreeScene unmounting, cleaning up');
      try {
        useGLTF.clear(url);
      } catch (e) {
        console.error('Failed to clear GLTF cache:', e);
      }
    };
  }, [url]);

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      {/* Debug controls */}
      {showDebug && (
        <div style={{ 
          position: 'absolute', 
          top: 10, 
          left: 10, 
          background: 'rgba(0,0,0,0.7)', 
          color: 'white',
          padding: '5px',
          fontSize: '12px',
          zIndex: 1000
        }}>
          Debug Mode (Press 'D' to toggle)
          <br />
          Press 'T' to show test object
        </div>
      )}
      
      <Canvas
        style={{ width: '100%', height: '100%' }}
        camera={{ position: [0, 0, 5], fov: 50 }}
        gl={{ antialias: true }}
        shadows
      >
        {/* Lighting */}
        <ambientLight intensity={0.5} />
        <directionalLight 
          position={[5, 5, 5]} 
          intensity={1} 
          castShadow 
          shadow-mapSize-width={1024} 
          shadow-mapSize-height={1024}
        />
        <directionalLight position={[-5, 5, 5]} intensity={0.5} />
        <pointLight position={[0, 5, 0]} intensity={0.5} />
        
        {/* Debug helpers */}
        {showDebug && <DebugHelpers />}
        {showTestObject && <TestObject />}
        
        {/* Model */}
        <Suspense fallback={<LoadingIndicator />}>
          <Model url={url} />
          <Environment preset="warehouse" background={false} />
        </Suspense>
        
        {/* Controls */}
        <OrbitControls 
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          minDistance={1}
          maxDistance={20}
        />
        
        {/* Debug stats */}
        {showDebug && <Stats />}
      </Canvas>
      
      {/* Instructions */}
      <div style={{ 
        position: 'absolute', 
        bottom: 10, 
        left: 10, 
        background: 'rgba(0,0,0,0.5)', 
        color: 'white',
        padding: '5px',
        fontSize: '12px',
        borderRadius: '4px'
      }}>
        Click and drag to rotate • Scroll to zoom
      </div>
    </div>
  );
};

export default ThreeScene;