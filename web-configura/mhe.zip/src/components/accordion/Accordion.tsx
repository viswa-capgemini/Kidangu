import React, { useState } from "react";
import { useDynamicHeight } from "../../hooks/useDynamicHeight";

type AccordionProps = {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
};

const Accordion: React.FC<AccordionProps> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const { contentRef, style } = useDynamicHeight(isOpen);

  return (
    <div className="border-t border-gray-600">
      {/* Header */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer"
      >
        <h3 className="text-sm font-semibold">{title}</h3>
                <span>
          {isOpen ? (
            <span
              className="icon-[ic--sharp-expand-less] w-6 h-6"
              style={{ color: "#810055" }}
            />
          ) : (
            <span
              className="icon-[ic--sharp-expand-more] w-6 h-6"
              style={{ color: "#810055"}}
            />
          )}
        </span>
      </div>

      {/* Content */}
      <div ref={contentRef} style={style}>
        <div className="p-2 bg-gray-50">{children}</div>
      </div>
    </div>
  );
};

export default Accordion;