import { useState, useRef, useEffect } from "react";

/**
 * Hook to handle dynamic height transitions for expand/collapse sections.
 * @param isOpen - Boolean to control open/close state.
 * @param duration - Transition duration in ms (default: 300).
 */
export const useDynamicHeight = (isOpen: boolean, duration: number = 300) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState("0px");

  useEffect(() => {
    if (contentRef.current) {
      setHeight(isOpen ? `${contentRef.current.scrollHeight}px` : "0px");
    }
  }, [isOpen]);

  const style: React.CSSProperties = {
    height,
    transition: `height ${duration}ms ease`,
    overflow: "hidden",
  };

  return { contentRef, style };
};