
import React from 'react';
import { Link } from 'react-router-dom';

const NotAuthorized: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md rounded-xl bg-white shadow p-6 text-center">
        <h1 className="text-2xl font-semibold text-gray-800">Not authorized</h1>
        <p className="mt-2 text-gray-600">You don’t have permission to view this page.</p>
        <Link to="/login" className="inline-block mt-4 rounded bg-blue-600 text-white px-4 py-2 text-sm hover:bg-blue-700">
          Go to Login
        </Link>
      </div>
    </div>
  );
};

export default NotAuthorized;
