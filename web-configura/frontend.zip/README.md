# Frontend - DXF Metadata Extractor

React application for viewing and extracting metadata from DXF files.

## Features

- 📁 Drag & drop DXF file upload
- 📐 Canvas-based DXF rendering
- 🎨 Layer visibility controls
- 🔍 Pan and zoom tools
- 📊 File metadata display
- 🎯 Entity type statistics

## Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be available at `http://localhost:5173`

## Technology Stack

- **React 18** - UI framework
- **Vite** - Build tool & dev server
- **Tailwind CSS v4** - Styling
- **Canvas API** - DXF rendering

## Project Structure

```
src/
├── components/
│   ├── Canvas/          # DXF rendering canvas
│   ├── FileUpload/      # Drag & drop upload
│   ├── Header/          # App header
│   ├── LayerPanel/      # Layer list & controls
│   ├── MetadataPanel/   # File info display
│   └── Toolbar/         # Tool selection
├── context/
│   └── DxfContext.jsx   # Global state management
├── services/
│   └── api.js           # Backend API calls
├── utils/
│   └── canvasRenderer.js # Canvas drawing utilities
├── App.jsx
├── index.css
└── main.jsx
```

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `V` | Select tool |
| `H` | Pan tool |
| `+` | Zoom in |
| `-` | Zoom out |
| `0` | Fit to view |
| `Scroll` | Zoom in/out |
| `Drag` | Pan canvas |
