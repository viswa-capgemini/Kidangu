import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    FileBox,
    Upload,
    X,
    ChevronRight,
    Database,
    Download
} from 'lucide-react';
import { resetDxfState } from '../../store/slices/dxfSlice';
import { generateSVG, downloadFile } from '../../utils/exportUtils';

const Header = () => {
    const dispatch = useDispatch();
    const { data: dxfData, visibleLayers } = useSelector((state) => state.dxf);
    const { theme } = useSelector((state) => state.ui);

    const handleExport = () => {
        if (!dxfData) return;
        const visibleLayersSet = new Set(visibleLayers);
        const svgContent = generateSVG(dxfData, visibleLayersSet, theme);
        if (svgContent) {
            downloadFile(svgContent, `${dxfData.metadata.filename}.svg`, 'image/svg+xml');
        }
    };

    return (
        <header className="h-16 px-6 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between glass z-30">
            <div className="flex items-center gap-4">
                {/* Branding */}
                <div className="flex items-center gap-2">
                    <div className="bg-brand w-8 h-8 rounded-lg flex items-center justify-center text-white shadow-lg shadow-brand/20">
                        <Database size={20} />
                    </div>
                    <h1 className="font-bold text-lg tracking-tight bg-gradient-to-r from-brand to-indigo-500 bg-clip-text text-transparent">
                        DXF Extractor
                    </h1>
                </div>

                {/* Breadcrumbs or File Status */}
                {dxfData && (
                    <div className="flex items-center gap-2 text-sm text-secondary px-4 border-l border-zinc-200 dark:border-zinc-800 h-8 ml-2">
                        <ChevronRight size={14} />
                        <span className="font-medium truncate max-w-[200px]">{dxfData.metadata.filename}</span>
                        <span className="text-[10px] bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded uppercase font-bold tracking-widest leading-none">
                            {dxfData.metadata.dxf_version}
                        </span>
                    </div>
                )}
            </div>

            <div className="flex items-center gap-3">
                {dxfData ? (
                    <>
                        <button
                            onClick={() => dispatch(resetDxfState())}
                            className="flex items-center justify-center w-8 h-8 rounded-full text-secondary hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                            title="Close File"
                        >
                            <X size={18} />
                        </button>
                        <button
                            onClick={handleExport}
                            className="bg-brand hover:bg-brand-hover text-white px-4 py-2 rounded-xl text-sm font-bold shadow-lg shadow-brand/20 transition-all active:scale-95 flex items-center gap-2"
                        >
                            <Download size={16} />
                            Export
                        </button>
                    </>
                ) : (
                    <div className="flex items-center gap-2 text-xs font-bold text-secondary uppercase tracking-widest">
                        Rayon Prototype v1.0
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;
