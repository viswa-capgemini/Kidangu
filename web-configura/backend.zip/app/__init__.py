"""
DXF Metadata Extractor API
"""
