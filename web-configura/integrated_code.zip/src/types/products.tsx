export interface Product {
  id: string;
  name: string;
  image?: string;
}

export interface TreeNode {
  id: string;
  label: string;
  children?: TreeNode[]; // Optional for nested nodes
}
