
// src/types.ts
export type Enquiry = {
  id: string;
  customerName: string;
  actions: string;
  createdDate: string; // ISO or yyyy-mm-dd
  email: string;
  referenceNo: string;
  productGroup: string;
  billingAddress: string;
};

export type RevisionRow = {
  enquiryId: string;
  customerName: string;
  actions: string;
  createdDate: string;
  email: string;
  referenceNo: string;
  productGroup: string;
  billingAddress: string;
  status: string;
};
