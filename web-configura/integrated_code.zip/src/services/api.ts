export interface MheRow {
  id?: number;
  name: string;
  picking_aisle_width_mm?: number;
  pallet_to_pallet_width_mm?: number;
  cross_aisle_width_mm?: number;
  end_aisle_width_mm?: number;
  capacity_kg?: number;
  max_loading_height_mm?: number;
  overall_height_lowered_mm?: number;
  straddle_outer_to_outer_mm?: number;
  straddle_height_mm?: number;
}

export interface MheApiResponse {
  mhe: MheRow[]
}
 
export const fetchMhe = async (): Promise<MheApiResponse> => {
  const res = await fetch("/mhe_data.json"); 
  return res.json();
};
 
export const upsertMhe = async (data: MheRow): Promise<MheRow> => {
  const res = await fetch("mhe_data.json", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return res.json();
};