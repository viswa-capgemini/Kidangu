import React, { useContext } from "react";
import CollapseIcon from "../../assets/images/Component 186 – 3.svg";
import PropertiesSection from "./LayoutRightPanel/PropertyTabs";
import ExpandIcon from "../../assets/images/Component 191 – 3.svg";
import ConfigurationSummary from "./LayoutRightPanel/ConfigurationSummary";
import BOMTable from "./LayoutRightPanel/BOM";
import MHETable from "./LayoutRightPanel/MHETable";
import Button from "../../components/button/Button";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import UserMenu from "../../components/user-menu/UserMenu";
// import ExportWithSubOptions from "./LayoutRightPanel/ExportButton";
// import ExportPanel from "./LayoutRightPanel/ExportButton";
import ExportButton from "./LayoutRightPanel/ExportButton";

interface LayoutRightPanelProps {
  selectedNodeId?: string | null;
  onClose: () => void;
}

const LayoutRightPanel: React.FC<LayoutRightPanelProps> = ({
  selectedNodeId,
  onClose,
}) => {
  const [isOpen, setIsOpen] = React.useState(true);
  const [openExport, setOpenExport] = React.useState(false);

  // ⬇️ Pull user + logout from AuthContext, and navigation
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div>
      <div
        data-testid="rightPanelToggle"
        className={`sticky top-0 z-10 flex justify-between relative ${
          isOpen
            ? "flex justify-between w-full h-[48px] items-center bg-white"
            : "flex justify-start m-1"
        } `}
      >
        <button
          data-testid="rightPanelToggleBtn"
          onClick={() => setIsOpen(!isOpen)}
          className={`border border-gray-100 px-3 ${
            isOpen ? "h-full" : "py-2"
          } rounded p-1 hover:bg-gray-300`}
        >
          {isOpen ? (
            // <img src={ExpandIcon} alt="Collapse" className="w-6 h-6" />
            <div className="flex items-center">
              <span className="icon-[icon-park-outline--expand-left]"></span>
            </div>
          ) : (
            // <img src={CollapseIcon} alt="Expand" className="w-6 h-6" />
            <span className="icon-[icon-park-outline--expand-right]"></span>
          )}
        </button>
        {/* <button>
          {isOpen && <span
            data-testid="rightPanel-user-icon"
            className="icon-[qlementine-icons--user-24]"
            style={{ marginRight: "12px" }}
          ></span>}
        </button> */}

        {/* <Button
          className="btn-primary-32 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
          onClick={() => setOpenExport(!openExport)}
        /> */}
        <ExportButton />

        {/* ✅ Render popover/panel when open */}
        {/* {openExport && <ExportPanel />} */}

        {/* <ExportWithSubOptions /> */}

        {/* User menu trigger on the right side of the sticky header */}
        {isOpen && (
          <div className="pr-3">
            <UserMenu
              userName={user?.name ?? "Guest"}
              onLogout={handleLogout}
              align="right"
              testId="rightPanel-user-menu"
              // Reuse your icon style as a custom trigger
              trigger={
                <div className="flex items-center gap-2">
                  <span
                    data-testid="rightPanel-user-icon"
                    className="icon-[qlementine-icons--user-24] text-xl"
                    style={{ marginRight: "4px" }}
                  />
                  {/* <span className="text-sm">{user?.name ?? "Guest"}</span> */}
                  {/* <span className="icon-[iconamoon--arrow-down-2-light] text-base" /> */}
                </div>
              }
            />
          </div>
        )}
      </div>

      {/* Right panel content */}
      {isOpen && (
        <div
          data-testid="rightPanelContainer"
          className="bg-gray-100 border-l mr-0 border-gray-300 overflow-y-auto w-[250px] h-screen scrollbar-hide"
        >
          <PropertiesSection />
          <ConfigurationSummary />
          <BOMTable />
          <MHETable />
        </div>
      )}
    </div>
  );
};

export default LayoutRightPanel;