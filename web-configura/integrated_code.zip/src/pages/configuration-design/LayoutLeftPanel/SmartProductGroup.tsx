import { useState } from "react";
import { smartProductGroups } from "../../../constants/constants";
import Accordion from "../../../components/accordion/Accordion";

const SmartProductGroup: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    // <div className="border-t border-gray-600">
    //   {/* Accordion Header */}
    //   <div
    //     onClick={() => setIsOpen(!isOpen)}
    //     className="flex justify-between items-center p-2 bg-godrej-lite-purple text-godrej-purple cursor-pointer"
    //   >
    //     <h3 className="text-sm font-semibold">Smart Product Group</h3>
    //     <span>
    //       {isOpen ? (
    //         <span
    //           className="icon-[ic--sharp-expand-less] w-6 h-6"
    //           style={{ color: "#810055" }}
    //         />
    //       ) : (
    //         <span
    //           className="icon-[ic--sharp-expand-more] w-6 h-6"
    //           style={{ color: "#810055" }}
    //         />
    //       )}
    //     </span>
    //   </div>

    //   {/* Accordion Content */}
    //   <div
    //     className={`transition-all duration-300 ${
    //       isOpen
    //         ? "max-h-48 overflow-y-auto scrollbar-hide"
    //         : "max-h-0 overflow-hidden"
    //     }`}
    //   >
    //     <div className="p-2 bg-gray-50 grid grid-cols-2 gap-3 items-center">
    //       {smartProductGroups.map((group, index) => (
    //         <button
    //           key={index}
    //           className="bg-gray-100 shadow-md rounded-md p-1 text-[12px] text-gray-600 text-center transition w-16 h-12 break-words whitespace-normal"
    //         >
    //           {group}
    //         </button>
    //       ))}
    //     </div>
    //   </div>
    // </div>
    <Accordion title="Smart Product Group" defaultOpen={false}>
      <div className="p-2 bg-gray-50 grid grid-cols-2 gap-3 items-center">
        {smartProductGroups.map((group, index) => (
          <button
            key={index}
            className="bg-gray-100 shadow-md rounded-md p-1 text-[12px] text-gray-600 text-center transition w-16 h-12 break-words whitespace-normal"
          >
            {group}
          </button>
        ))}
      </div>
    </Accordion>
  );
};

export default SmartProductGroup;
