import { type Product } from "../../../types/products";

type Props = { product: Product; selectedProduct: string | null };

const ProductGroupItem: React.FC<Props> = ({ product, selectedProduct }) => {
  const isSelected = selectedProduct === product.name;

  return (
    <div
      data-testid="productGroupItemContainer"
      className={`flex items-center gap-2 border-gray-100 p-2 cursor-pointer rounded ${
        isSelected ? "bg-gray-200" : "hover:bg-godrej-lite-purple"
      }`}
    >
      <li
        data-testid="productGroupItemList"
        className="flex px-1 items-center cursor-pointer rounded"
        onClick={() => console.log(`Selected: ${product.name}`)}
      >
        <span
          className={` ${isSelected ? "text-black" : "text-black"}  text-[12px] text-gray-600`}
        >
          {product.name}
        </span>
      </li>
    </div>
  );
};

export default ProductGroupItem;
