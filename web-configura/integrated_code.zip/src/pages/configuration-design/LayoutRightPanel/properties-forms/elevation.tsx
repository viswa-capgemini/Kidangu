import React, { useState } from "react";
import FloatingOrderQuantity from "../../../../components/custom-inputs/FloatingOrderQunatity";
import FloatingLabelInputFields from "../../../../components/custom-inputs/FloatingLabelInputFields";

const Elevation = () => {
  const [arrangement, setArrangement] = useState("Single Row");
  const [orientation, setOrientation] = useState("Horizontal");
  const [sameHeight, setSameHeight] = useState<boolean>(true);
  const [rackColumns, setRackColumns] = useState<number>(2);
  const [levels, setLevels] = useState<number>(3);
  const [pallets, setPallets] = useState<number>(4);

  return (
    <div className="space-y-3 w-full">
      {/* Arrangement */}
      {/* <div className="flex flex-wrap items-center gap-4 w-full">
        <span className="font-semibold">Arrangement</span>
        <label>
          <input type="radio" name="arrangement" /> Single Row
        </label>
        <label>
          <input type="radio" name="arrangement" /> Multi Row
        </label>
        <FloatingOrderQuantity
          maxVal={10}
          width="w-[90px]"
          label="No. of rows"
        />
      </div> */}

      {/* Orientation */}
      {/* <div className="flex flex-wrap items-center gap-4 w-full">
        <span className="font-semibold">Orientation</span>
        <label>
          <input type="radio" name="orientation" /> Horizontal
        </label>
        <label>
          <input type="radio" name="orientation" /> Vertical
        </label>
      </div> */}

      {/* <div className="grid grid-cols-2 gap-4">
        <FloatingOrderQuantity
          maxVal={100}
          width="w-[110px]"
          label="No. of rack columns"
        />
        <FloatingOrderQuantity
          maxVal={500}
          width="w-[110px]"
          label="No. of add ons"
        />
        <FloatingOrderQuantity
          maxVal={2000}
          width="w-[110px]"
          label="No. of Pallet"
        />
      </div> */}

      <div>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label htmlFor="id" className="text-[12px] text-gray-600">
            Id
          </label>
          <input
            type="text"
            id="id"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label htmlFor="PG name" className="text-[12px] text-gray-600">
            Product Group
          </label>
          <input
            type="text"
            id="PG name"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">
            Configuration Name
          </label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">Version Number</label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">Last updated Date</label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>

        <div>
          <label className="text-[12px] text-gray-600">Arrangement</label>
          <div className="flex space-x-4">
            {["Single Row", "Multi Row"].map((option) => (
              <label
                key={option}
                className="flex flex-wrap items-center space-x-2"
              >
                <input
                  type="radio"
                  name="arrangement"
                  value={option}
                  checked={arrangement === option}
                  onChange={() => setArrangement(option)}
                  className={`text-[12px] text-gray-600`}
                />
                <span className={`text-[12px] text-gray-600`}>{option}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="text-[12px] text-gray-600">Orientation</label>
          <div className="flex space-x-4">
            {["Horizontal", "Verticle"].map((option) => (
              <label
                key={option}
                className="flex flex-wrap items-center space-x-2"
              >
                <input
                  type="radio"
                  name="orientation"
                  value={option}
                  checked={orientation === option}
                  onChange={() => setOrientation(option)}
                  className={`text-[12px] text-gray-600`}
                />
                <span className={`text-[12px] text-gray-600`}>{option}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Checkbox */}
        <label className="flex items-center mt-2 space-x-2 text-[12px] text-gray-600">
          <input
            type="checkbox"
            checked={sameHeight}
            onChange={(e) => setSameHeight(e.target.checked)}
            className="h-4 w-4 border-gray-300 rounded focus:ring-blue-500"
          />
          <span>Same height levels</span>
        </label>
      </div>

      {/* Dropdown */}
      <div className="grid grid-cols-2 gap-2 items-center">
        <label className="mb-1 text-[12px] text-gray-600">
          No. of rack columns
        </label>

        <select
          value={rackColumns}
          onChange={(e) => setRackColumns(Number(e.target.value))}
          className="bg-gray-200 rounded w-full h-6 mt-1 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
        >
          {[1, 2, 3, 4, 5].map((num) => (
            <option key={num} value={num}>
              {num}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-2 items-center">
        <label className="mb-1 text-[12px] text-gray-600">
          Number of Levels
        </label>

        <select
          value={levels}
          onChange={(e) => setLevels(Number(e.target.value))}
          className="bg-gray-200 rounded w-full h-6 mt-1 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
        >
          {[1, 2, 3, 4, 5].map((num) => (
            <option key={num} value={num}>
              {num}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-2 items-center">
        <label className="mb-1 text-[12px] text-gray-600">
          Number of Pallets
        </label>

        <select
          value={pallets}
          onChange={(e) => setPallets(Number(e.target.value))}
          className="bg-gray-200 rounded w-full h-6 mt-1 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
        >
          {[1, 2, 3, 4, 5].map((num) => (
            <option key={num} value={num}>
              {num}
            </option>
          ))}
        </select>
      </div>
      <span className="grid grid-cols-2 gap-2 items-center">
        <label className="text-[12px] text-gray-600">Load per level</label>
        <input
          type="text"
          className="bg-gray-200 rounded w-full h-6 mt-1 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
        />
      </span>
      <span className="grid grid-cols-2 gap-2 items-center">
        <label className="text-[12px] text-gray-600">Level to level(mm)</label>
        <input
          type="text"
          className="bg-gray-200 rounded w-full h-6 mt-1 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
        />
      </span>
    </div>
  );
};

export default Elevation;
