import React, { useState } from "react";
import FloattingOrderQuantity from "../../../../components/custom-inputs/FloatingOrderQunatity";

const SKU = () => {
  const [arrangement, setArrangement] = useState("Single Row");
  const [orientation, setOrientation] = useState("Horizontal");
  return (
    <div>
      {/* <FloattingOrderQuantity maxVal={100} width="w-[120px]" label="Pallets" /> */}
      <div>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label htmlFor="id" className="text-[12px] text-gray-600">
            Id
          </label>
          <input
            type="text"
            id="id"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label htmlFor="PG name" className="text-[12px] text-gray-600">
            Product Group
          </label>
          <input
            type="text"
            id="PG name"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">
            Configuration Name
          </label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">Version Number</label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>
        <span className="grid grid-cols-2 gap-2 items-center">
          <label className="text-[12px] text-gray-600">Last updated Date</label>
          <input
            type="text"
            className="bg-gray-200 rounded w-full h-6 mt-2 px-2 text-xs border border-transparent hover:border-gray-500 focus:border-blue-500 outline-none"
          />
        </span>

        <div>
          <label className="text-[12px] text-gray-600">Arrangement</label>
          <div className="flex space-x-4">
            {["Single Row", "Multi Row"].map((option) => (
              <label key={option} className="flex flex-wrap items-center space-x-2">
                <input
                  type="radio"
                  name="arrangement"
                  value={option}
                  checked={arrangement === option}
                  onChange={() => setArrangement(option)}
                  className={`text-[12px] text-gray-600`}
                />
                <span className={`text-[12px] text-gray-600`}>{option}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="text-[12px] text-gray-600">Orientation</label>
          <div className="flex space-x-4">
            {["Horizontal", "Verticle"].map((option) => (
              <label key={option} className="flex flex-wrap items-center space-x-2">
                <input
                  type="radio"
                  name="orientation"
                  value={option}
                  checked={orientation === option}
                  onChange={() => setOrientation(option)}
                  className={`text-[12px] text-gray-600`}
                />
                <span className={`text-[12px] text-gray-600`}>{option}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SKU;
