
import React, { useState } from "react";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import ListItemText from "@mui/material/ListItemText";
import ListItemIcon from "@mui/material/ListItemIcon";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

export default function ExportButton() {
  // Root menu state
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const rootOpen = Boolean(anchorEl);

  // Submenu state (anchored to the clicked parent MenuItem)
  const [submenuAnchorEl, setSubmenuAnchorEl] = useState<HTMLElement | null>(null);
  const submenuOpen = Boolean(submenuAnchorEl);

  // Which submenu is active (so you can have multiple submenus if you like)
  const [activeSubmenu, setActiveSubmenu] = useState<null | "drawings" | "exportOptions">(null);

  const openRoot = (e: React.MouseEvent<HTMLButtonElement>) => setAnchorEl(e.currentTarget);
  const closeRoot = () => {
    setAnchorEl(null);
    setSubmenuAnchorEl(null);
    setActiveSubmenu(null);
  };

  // Open submenu when a particular MenuItem is clicked
  const openSubmenu = (
    e: React.MouseEvent<HTMLElement>,
    submenuKey: "drawings" | "exportOptions"
  ) => {
    setSubmenuAnchorEl(e.currentTarget as HTMLElement);
    setActiveSubmenu(submenuKey);
  };

  const closeSubmenu = () => {
    setSubmenuAnchorEl(null);
    setActiveSubmenu(null);
  };

  // Example click handlers for leaf items
  const handleAction = (label: string) => {
    // Put your real logic here (download/export/etc.)
    console.log("Clicked:", label);
    // Close everything
    closeRoot();
  };

  return (
    <Box sx={{ p: 4, display: "grid", gap: 2 }}>
      {/* <Typography variant="h5">Menu with Click-to-open Submenu</Typography> */}

      <Button
        id="export-button"
        className={`!bg-godrej-purple !text-white !rounded-full`}
        variant="contained"
        onClick={openRoot}
        aria-controls={rootOpen ? "root-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={rootOpen ? "true" : undefined}
      >
        <span className="icon icon-[ix--export] text-xl"></span>Export
      </Button>

      {/* Root menu */}
      <Menu
        id="root-menu"
        anchorEl={anchorEl}
        open={rootOpen}
        onClose={closeRoot}
        slotProps={{
          list: { "aria-labelledby": "export-button" },
        }}
      >
        {/* Regular item */}
        <MenuItem onClick={() => handleAction("Image")}>Image</MenuItem>

        {/* Another regular item */}
        <MenuItem onClick={() => handleAction("PDF")}>PDF</MenuItem>

        {/* Item that opens a submenu (Drawings) */}
        <MenuItem
          onClick={(e) => openSubmenu(e, "drawings")}
          aria-haspopup="menu"
          aria-expanded={submenuOpen && activeSubmenu === "drawings" ? "true" : undefined}
          aria-controls={submenuOpen && activeSubmenu === "drawings" ? "submenu-drawings" : undefined}
        >
          <ListItemText>Drawings</ListItemText>
          <ListItemIcon sx={{ ml: 1 }}>
            <ChevronRightIcon fontSize="small" />
          </ListItemIcon>
        </MenuItem>

        {/* Item that opens another submenu (Export Options) */}
        <MenuItem
          onClick={(e) => openSubmenu(e, "exportOptions")}
          aria-haspopup="menu"
          aria-expanded={
            submenuOpen && activeSubmenu === "exportOptions" ? "true" : undefined
          }
          aria-controls={
            submenuOpen && activeSubmenu === "exportOptions" ? "submenu-export" : undefined
          }
        >
          <ListItemText>More Export Options</ListItemText>
          <ListItemIcon sx={{ ml: 1 }}>
            <ChevronRightIcon fontSize="small" />
          </ListItemIcon>
        </MenuItem>

        {/* Submenu: conditionally render based on which parent was clicked */}
        <Menu
          id={
            activeSubmenu === "drawings"
              ? "submenu-drawings"
              : activeSubmenu === "exportOptions"
              ? "submenu-export"
              : "submenu"
          }
          anchorEl={submenuAnchorEl}
          open={submenuOpen}
          onClose={closeSubmenu}
          // Position submenu to the right of the parent item
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "left" }}
          // Optional: close submenu when mouse leaves
          MenuListProps={{
            onMouseLeave: closeSubmenu,
          }}
        >
          {activeSubmenu === "drawings" ? (
            <>
              <MenuItem onClick={() => handleAction("DWG")}>DWG</MenuItem>
              <MenuItem onClick={() => handleAction("DXF")}>DXF</MenuItem>
              <MenuItem onClick={() => handleAction("SVG")}>SVG</MenuItem>
            </>
          ) : activeSubmenu === "exportOptions" ? (
            <>
              <MenuItem onClick={() => handleAction("High Quality")}>High Quality</MenuItem>
              <MenuItem onClick={() => handleAction("Small Size")}>Small Size</MenuItem>
              <MenuItem onClick={() => handleAction("Custom Settings")}>Custom Settings</MenuItem>
            </>
          ) : null}
        </Menu>
      </Menu>
    </Box>
  );
}