import React, { useState } from "react";
import { ThemeProvider } from '@mui/material/styles';
import { theme } from "../../theme";
import {Box, FormControl, MenuItem, Paper, Select, TextField, Typography, FormControlLabel, Checkbox,InputLabel} from "@mui/material";
import Button from "../../components/button/Button";
import CompareTable from "./CompareTable";
import MhePage from "../mhe-details/MhePage";


const PGComparison = () => {
  const options = [
        "Selectivity",
        "Storage Density",
        "Custom storage Application",
        "Cost",
        "Pallet Density",
        "Productivity",
        "Material Movement",

    ];
    const checkboxRow1 = options.slice(0, 4);
    const checkboxRow2 = options.slice(4)
    const [showTable, setShowTable] = useState<boolean>(false)

    const handleCompare = () => {
        setShowTable(true);
    }


  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ p: 3, minHeight: "100vh" }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                <h1 data-testid="enquiryListHeader" className="text-godrej-purple text-4xl mt-0">Compare Product Group</h1>
                 <Button id="enquiryListExportButton" className="btn-primary-32 flex items-center" label="Export" />
            </Box> 
            <Box sx={{ display: "flex", gap: 2 }}>
                <FormControl sx={{ m: 1, minWidth: 140 }}  size="small">
                  <InputLabel>SKU</InputLabel>
                  <Select label="Box">
                    <MenuItem value="Box">Box</MenuItem>
                    <MenuItem value="Bin">Bin</MenuItem>
                    <MenuItem value="Gunny Bag">Gunny Bag</MenuItem>
                    <MenuItem value="Drum">Drum</MenuItem>
                  </Select>
                </FormControl>                
                  {checkboxRow1.map((label) => (
                      <FormControlLabel
                  control={<Checkbox size="small" defaultChecked />}
                  label={label}
                />
                  )
                )
                }
            </Box>
            <Box sx={{ mb: 3,m: 1, mt:3, display: "flex", gap: 2}}>
              <FormControl sx={{marginRight: 1}} size="small" >
                <TextField
                    label="Volume (MT)"
                    variant="outlined"
                    size="small"
                    type="text"
                    placeholder="Width"
                    sx = {{maxWidth : 140}}
                    defaultValue="5000"
                  />                        
              </FormControl>
                {checkboxRow2.map((label) => (
                  <FormControlLabel
              control={<Checkbox size="small" defaultChecked />}
              label={label}
            />
              )
            )
            }
            </Box>
            <Box sx={{ ml: 5, mt:3, display: "flex", gap: 14}}>
              <Box>
                <Typography variant="h5" sx={{ color: '#810055', fontWeight: 500}}>
                  Product Group1
                </Typography>
                <FormControl sx={{ m:1, mt:2, width:'180px'}}  size="small">
                  <InputLabel >Rack Type</InputLabel>
                  <Select label="Rack Type" autoWidth>
                    <MenuItem value="Shuttle Pallet">Shuttle Pallet</MenuItem>
                    <MenuItem value="Double Deep Pallet">Double Deep Pallet</MenuItem>
                    <MenuItem value="Mobile Pallet">Mobile Pallet</MenuItem>
                    <MenuItem value="Pushback">Pushback</MenuItem>
                     <MenuItem value="Selective Pallet">Selective Pallet</MenuItem>
                  </Select>
                </FormControl>
              </Box>
                
                <Typography variant="h4" sx={{ color: '#810055', fontWeight: 400 }} paddingTop={6}>
                        Vs
                </Typography>
                <Box>
                  <Typography variant="h5" sx={{ color: '#810055', fontWeight: 500 }}>
                  Product Group2
                </Typography>
                <FormControl sx={{ m:1, mt:2, width:'180px'}}  size="small">
                <InputLabel>Rack Type</InputLabel>
                  <Select  label="Rack Type" autoWidth>
                    <MenuItem value="Shuttle Pallet">Shuttle Pallet</MenuItem>
                    <MenuItem value="Double Deep Pallet">Double Deep Pallet</MenuItem>
                    <MenuItem value="Mobile Pallet">Mobile Pallet</MenuItem>
                    <MenuItem value="Pushback">Pushback</MenuItem>
                     <MenuItem value="Selective Pallet">Selective Pallet</MenuItem>
                  </Select>
                </FormControl>
                </Box>               
            </Box> 
            <Box  sx={{ ml: 3, mt:3}}>
              <Button id="enquiryListExportButton" className="btn-primary-32 flex items-center" label="Compare" onClick={handleCompare} />  
            </Box>
            <Box>
               {showTable && <CompareTable /> }
            </Box>
        </Box>
      </ThemeProvider>
  )
}

export default PGComparison
