import * as React from "react";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { Box, Grid, Typography } from "@mui/material";
 
const columns: GridColDef<(typeof rows)[number]>[] = [
  {
    field: "label",
    headerName: "",
    flex: 1.2,
    headerAlign: "center",
    align: "left",

  },
  {
    field: "shuttle",
    headerName: "Shuttle Pallet Racking",     
    headerAlign: "center",
    align: "left",
    width:400
   
  },
  {
    field: "driveIn",
    headerName: "Drive-In Pallet Racking",
    flex: 1.5,
    headerAlign: "center",
    align: "left",
  },
];
 
const rows = [
  { id: 1, label: "SKU (Box)", shuttle: "Good for Box", driveIn: "Good for drum" },
  { id: 2, label: "Selectivity", shuttle: "Excellent", driveIn: "Fair" },
  { id: 3, label: "Storage Density", shuttle: "Fair", driveIn: "Excellent" },
  { id: 4, label: "Volume", shuttle: "Low", driveIn: "High" },
  {
    id: 5,
    label: "Common storage application",
    shuttle: "Palletized products requiring low density and high selectivity",
    driveIn: "Large quantities of uniform products",
  },
  { id: 6, label: "Pallet density", shuttle: "Low", driveIn: "Medium" },
  { id: 7, label: "Productivity", shuttle: "Excellent", driveIn: "Medium" },
  { id: 8, label: "Material Movement", shuttle: "First In, First Out", driveIn: "First In, First Out" },
  { id: 9, label: "Cost", shuttle: "Low", driveIn: "Medium" },
];
 
export default function CompareTable() {
  return (
    <Grid sx={{ height: 520, maxWidth: 1000, paddingTop:"15px"}}>
      <DataGrid
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        disableColumnFilter
        disableColumnMenu
        disableColumnSorting
        autoHeight
        hideFooter
      
        sx={{
          border: "2px solid #ccc",
            wordBreak:"break-word",
          "& .MuiDataGrid-cell": {
            borderRight: "1px solid #ccc",
            borderBottom: "1px solid #ccc",
          },
 
          "& .MuiDataGrid-columnHeaders": {
            borderBottom: "2px solid #ccc",
            
          },
 
          "& .MuiDataGrid-columnHeader": {
            borderRight: "1px solid #ccc",
            fontWeight: "bold",
          },
 
          "& .MuiDataGrid-row:last-child .MuiDataGrid-cell": {
            borderBottom: "none",
          },
 
          "& .MuiDataGrid-columnHeader:last-child, & .MuiDataGrid-cell:last-child": {
            borderRight: "none",
          },
        }}
      /> 
      </Grid>
  );
}