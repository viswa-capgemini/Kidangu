import React from "react";
import Card from "../../components/card/Card";
import ImportCard from "./import-layout/OverlayImport";
import TemplateCard from "./overlay-templates/Template";
import PredefinedStart from "./predefined-start/PredefinedStart";

const OverlayCardItems = () => {
  // const cardsData = [
  //   { id: 1, title: 'Templates', description: 'Description for Card 1' },
  //   { id: 2, title: 'Import Layout', description: 'Description for Card 2' },
  //   { id: 3, title: 'Product Group', description: 'Description for Card 3' },
  //   { id: 2, title: 'Components', description: 'Description for Card 2' },
  //   { id: 3, title: 'Smart Product Group', description: 'Description for Card 3' },
  // ];

  return (
    <div>
      <div
        data-testid="select-product-container"
        className=" text-godrej-purple text-3xl"
      >
        <p data-testid="select-product-title">
          Select Product group, warehouse
        </p>
      </div>


      <div className="mt-4 p-4 grid grid-cols-1 md:grid-cols-3 gap-10 flex-1 min-h-0 items-stretch overflow-auto">
        <TemplateCard />
        <ImportCard />
        <PredefinedStart />
      </div>
    </div>
  );
};

export default OverlayCardItems;
