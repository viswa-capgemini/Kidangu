// src/features/template/Template.tsx
import React from "react";
import { useNavigate } from "react-router-dom";
import Card from "../../../components/card/Card";
import SecondaryModal from "../secondary-modal/SecondaryModal";
import Modal from "../../../components/modal/Modal";
// import ConfigurationLayout from "../../configuration-design/ConfigurationLayout"; // still available if you re-enable local rendering

const Template: React.FC = () => {
  const navigate = useNavigate();

  // Keeping state in case you later switch back to inline rendering
  const [showConfigurationLayout, setShowConfigurationLayout] = React.useState(false);
  const [showSecondaryModal, setShowSecondaryModal] = React.useState(false);

  const openModal = () => setShowSecondaryModal(true);
  const closeModal = () => setShowSecondaryModal(false);

  const handleConfigurationLayout = () => {
    // setShowConfigurationLayout(!showConfigurationLayout);
    navigate("/configuration-layout");
  };

  return (
    <>
      <Card
        data-testid="templateContainer"
        widthClassName="w-full" // responsive width; matches your previous 400px cap
        heightClassName="h-full" // auto height on small screens; 320px on md+
        className="flex flex-col p-2 bg-white shadow-md" // keep your original surface styling here
      >
        <h3 data-testid="templateHeader" className="text-godrej-purple text-xl">
          Template
        </h3>

        <div
          data-testid="templateWarehouseContainer"
          className="flex flex-row justify-between items-center mt-4 mb-4 bg-gray-100"
        >
          <button
            data-testid="templateWarehouseBtn"
            // onClick={handleConfigurationLayout}
            onClick={openModal}
          >
            <select
              data-testid="templateSelect"
              className="border border-gray-300"
            >
              <option value="template1">FLat</option>
              <option value="template2">Roof</option>
              <option value="template3">Inclined</option>
            </select>

            <span className="p-2 text-godrej-purple">New Warehouse</span>
          </button>
        </div>

        {/* If you want to render inline instead of navigating, re-enable this: */}
        {/* {showConfigurationLayout && <ConfigurationLayout />} */}

        <div className="flex flex-row justify-start items-center p-2 gap-2">
          <span
            data-testid="warehouse100*200"
            className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center"
          >
            <img src="images/overlay-template.png" alt="warehouse" />
          </span>
          <span data-testid="warehouse100*200-Header">
            Flat Warehouse 100m x 200m
          </span>
        </div>

        <div className="flex flex-row justify-start items-center p-2 gap-2">
          <span
            data-testid="warehouse150*200"
            className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center"
          >
            <img src="images/overlay-template.png" alt="warehouse" />
          </span>
          <span data-testid="warehouse150*200-Header">
            Roof Warehouse 150m x 200m
          </span>
        </div>

        <div className="flex flex-row justify-start items-center p-2 gap-2">
          <span
            data-testid="warehouse100*100"
            className="w-27 h-10 bg-gray-100 border border-black-100 mr-10px flex justify-center items-center"
          >
            <img src="images/overlay-template.png" alt="warehouse" />
          </span>
          <span data-testid="warehouse100*100-Header" className="text-sm">
            Inclined Warehouse 100m x 100m
          </span>
        </div>
      </Card>

      {/* Modal with two cards */}
      <Modal
        open={showSecondaryModal}
        onClose={closeModal}
        data-testid="newWarehouseModal"
        widthClassName="w-[60%]" // adjust as needed
        heightClassName="h-[60%]" // ensures it never exceeds viewport
      >
        <SecondaryModal />
      </Modal>
    </>
  );
};

export default Template;
