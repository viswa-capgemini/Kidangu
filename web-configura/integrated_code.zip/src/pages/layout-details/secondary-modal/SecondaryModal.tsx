// src/features/template/NewWarehouseModalContent.tsx
import React, {useState} from "react";
import Card from "../../../components/card/Card";
import { useNavigate } from "react-router-dom";

const SecondaryModal: React.FC = () => {
    const [sku, setSku] = useState("Box");
    const navigate = useNavigate();

  const handleDesign = () => {
    // Logic to start the design process
    navigate('/layout-design');
    console.log("Starting design process...");
  }
  return (
    <div className="h-full flex flex-col min-h-0">
      {/* Header */}
      <h2 className="text-godrej-purple text-2xl">New Warehouse</h2>

      {/* Cards grid */}
      <div
        className="
          mt-4 grid grid-cols-1 md:grid-cols-2 gap-6
          flex-1 min-h-0 items-stretch
        "
      >
        {/* Card 1: Select Template */}
        <Card
          data-testid="newWarehouseCard-template"
          widthClassName="w-full"
          heightClassName="h-full"
          className="flex flex-col min-h-0 p-4 bg-white shadow-md"
        >
          <h3 className="text-godrej-purple text-xl">SKU</h3>

          {/* Scrollable inner */}
          {/* <div className="mt-3 overflow-y-auto min-h-0 space-y-3">
            {[
              { name: "Flat Warehouse 100m x 200m", img: "images/overlay-template.png" },
              { name: "Roof Warehouse 150m x 200m", img: "images/overlay-template.png" },
              { name: "Inclined Warehouse 100m x 100m", img: "images/overlay-template.png" },
            ].map((w, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <span className="w-24 h-14 bg-gray-100 border border-gray-300 flex justify-center items-center">
                  <img src={w.img} alt="warehouse" className="max-h-full" />
                </span>
                <span className="text-sm">{w.name}</span>
              </div>
            ))}
          </div> */}

          {/* Footer pinned */}
          {/* <div className="mt-auto pt-4">
            <button className="w-full h-[40px] rounded-full bg-godrej-purple text-white hover:opacity-90 transition">
              Use Selected Template
            </button>
          </div> */}
                  {/* SKU */}
        <div className="border border-gray-300 rounded-md h-[48px] flex items-center px-3">
          <select
            data-testid="skuSelect"
            value={sku}
            onChange={(e) => setSku(e.target.value)}
            className="w-full outline-none bg-transparent"
            aria-label="SKU"
          >
            <option>Box</option>
            <option>Crate</option>
            <option>Carton</option>
            <option>Pallet</option>
          </select>
        </div>
        </Card>

        {/* Card 2: Basic Setup / Dimensions */}
        <Card
          data-testid="newWarehouseCard-setup"
          widthClassName="w-full"
          heightClassName="h-full"
          className="flex flex-col min-h-0 p-4 bg-white shadow-md"
        >
          <h3 className="text-godrej-purple text-xl">MHE Options</h3>

          {/* Scrollable form */}
          <div className="mt-3 overflow-y-auto min-h-0 space-y-4">
            <fieldset className="border border-gray-300 rounded-md p-3">
              <legend className="px-1 text-sm text-gray-700">Dimension</legend>
              <div className="grid grid-cols-3 gap-3">
                <input
                  className="border border-gray-300 rounded-md h-[40px] px-3 outline-none"
                  placeholder="Length (m)"
                />
                <input
                  className="border border-gray-300 rounded-md h-[40px] px-3 outline-none"
                  placeholder="Width (m)"
                />
                <input
                  className="border border-gray-300 rounded-md h-[40px] px-3 outline-none"
                  placeholder="Height (m)"
                />
              </div>
            </fieldset>

            <div className="border border-gray-300 rounded-md h-[48px] flex items-center px-3">
              <select className="w-full outline-none bg-transparent">
                <option>Shuttle Pallet</option>
                <option>Selective Pallet</option>
                <option>Drive-In</option>
                <option>Push Back</option>
              </select>
            </div>

            <div className="border border-gray-300 rounded-md h-[48px] flex items-center px-3">
              <select className="w-full outline-none bg-transparent">
                <option>Forklift</option>
                <option>Reach Truck</option>
                <option>Stacker</option>
                <option>Pallet Jack</option>
              </select>
            </div>

            {/* <fieldset className="border border-gray-300 rounded-md p-3">
              <legend className="px-1 text-sm text-gray-700">
                Smart Product Group
              </legend>
              <div className="grid grid-cols-2 gap-y-2">
                {[
                  "Men's Room",
                  "Women's Room",
                  "Office",
                  "Reception",
                  "Conference",
                  "Show Room",
                ].map((label) => (
                  <label key={label} className="inline-flex items-center gap-2">
                    <input type="checkbox" className="accent-godrej-purple" />
                    <span className="text-sm">{label}</span>
                  </label>
                ))}
              </div>
            </fieldset> */}
          </div>
        </Card>
      </div>
      <div className="flex justify-end mt-4">
      <button className="w-[120px] h-[40px] top-4 rounded-full bg-godrej-purple text-white hover:opacity-90 transition"
        onClick={handleDesign}
      >
        Start Design
      </button>
      </div>
    </div>
  );
};

export default SecondaryModal;
