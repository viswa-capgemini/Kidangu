import React, { useMemo, useState } from 'react';
import {
  AppBar,
  Box,
  Toolbar,
  Typography,
  IconButton,
  Container,
  Tabs,
  Tab,
  Stack,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
} from '@mui/material';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import DownloadIcon from '@mui/icons-material/Download';
import UserOnboardStepper from "../../components/User/UserOnboardStepper";
import UsersList from "../../components/User/UserList";

type Role = 'Designer' | 'Viewer' | 'Admin';
type Product = 'SPR' | 'Shelving' | 'Mobistack' | 'Mezzanine';
type SubProduct = 'Components';
type WeightOption = 'With Weight' | 'Without weight';
type PriceOption = 'INR' | 'USD' | 'Both';
type OutputOption = 'BOM' | 'Drawing pdf' | 'Drawing dwg' | 'Tech spec' | '3D' | 'Assembly dwg';
type BomType = 'Excel' | 'pdf' | 'Assembly level';
type StandardType = 'GFA' | 'Std1' | 'Std2' | 'All';

interface Access {
  products: Product[];
  subProducts: SubProduct[];
  weight: '' | WeightOption;
  price: '' | PriceOption;
  outputs: OutputOption[];
  bomType: BomType[];
  standardType: '' | StandardType;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: '' | Role;
  access: Access;
}

// Custom Notification Component
interface NotificationDialogProps {
  open: boolean;
  message: string;
  onClose: () => void;
}

const NotificationDialog: React.FC<NotificationDialogProps> = ({ open, message, onClose }) => {
  return (
    <Dialog 
      open={open} 
      onClose={onClose}
      PaperProps={{
        sx: {
          borderRadius: '8px',
          maxWidth: '400px',
          width: '100%'
        }
      }}
    >
      <DialogTitle sx={{ 
        color: '#810055', 
        fontWeight: 500,
        pb: 1
      }}>
        Validation Error
      </DialogTitle>
      <DialogContent>
        <Alert severity="error" sx={{ mb: 2 }}>
          {message}
        </Alert>
      </DialogContent>
      <DialogActions sx={{ p: 2, pt: 0 }}>
        <Button 
          onClick={onClose} 
          sx={{ 
            backgroundColor: '#810055',
            color: 'white',
            px: 3,
            '&:hover': {
              backgroundColor: '#6a0046',
            }
          }}
        >
          OK
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const LS_KEY = 'admin-config-prototype-users';

const readUsersFromLS = (): User[] => {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? (JSON.parse(raw) as User[]) : [];
  } catch {
    return [];
  }
};

const writeUsersToLS = (users: User[]) => {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(users));
  } catch {
    
  }
};

export default function UserManagement() {
  const [tab, setTab] = useState<number>(0);
  const [users, setUsers] = useState<User[]>(() => readUsersFromLS());
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  // Add state for notification
  const [notification, setNotification] = useState({
    open: false,
    message: ''
  });

  const handleTabChange = (_e: React.SyntheticEvent, value: number) => setTab(value);

  const upsertUser = (user: User, isValid: boolean, errorMessage?: string) => {
    // If validation failed in the UserOnboardStepper
    if (!isValid) {
      setNotification({
        open: true,
        message: errorMessage || 'Please check your form for errors'
      });
      return;
    }

    // If validation passed, proceed with saving the user
    setUsers(prev => {
      const idx = prev.findIndex(u => u.id === user.id);
      const next = [...prev];
      if (idx >= 0) next[idx] = user;
      else next.push(user);
      writeUsersToLS(next);
      return next;
    });
    setEditingUser(null);
    setTab(1);
  };

  const closeNotification = () => {
    setNotification({
      open: false,
      message: ''
    });
  };

  const deleteUser = (id: string) => {
    setUsers(prev => {
      const next = prev.filter(u => u.id !== id);
      writeUsersToLS(next);
      return next;
    });
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(users, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'users-config.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const headerRight = useMemo(
    () => (
      <Stack direction="row" spacing={1}>
        <Button 
          variant="outlined" 
          startIcon={<DownloadIcon />} 
          onClick={exportJson} 
          sx={{
            color: '#810055',
            borderColor: '#810055',
            '&:hover': {
              borderColor: '#6a0046',
              backgroundColor: 'rgba(129, 0, 85, 0.04)',
            }
          }}
        >
          Export JSON
        </Button>
      </Stack>
    ),
    []
  );

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* <AppBar position="static" sx={{ 
        backgroundColor: 'white',  
        boxShadow: 1  
      }}> */}
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1, color: '#810055' }}>
            Role Configuration
          </Typography>
          {headerRight}
        </Toolbar>
      {/* </AppBar> */}
      <Container maxWidth="lg" sx={{ py: 3 }}>
        <Tabs
          value={tab}
          onChange={handleTabChange}
          aria-label="admin tabs"
          sx={{
            mb: 3,
            '& .MuiTab-root': { color: 'rgba(0, 0, 0, 0.6)' },
            '& .Mui-selected': { color: '#810055 !important' },
            '& .MuiTabs-indicator': { backgroundColor: '#810055' },
          }}
        >
          <Tab
            icon={<PersonAddAltIcon sx={{ color: tab === 0 ? '#810055' : 'rgba(0, 0, 0, 0.6)' }} />}
            iconPosition="start"
            label={editingUser ? 'Edit User' : 'Onboard User'}
          />
          <Tab
            label="Users"
          />
        </Tabs>
        {tab === 0 && (
          <UserOnboardStepper onSubmit={upsertUser} initialUser={editingUser ?? undefined} />
        )}
        {tab === 1 && (
          <UsersList
            users={users}
            onDelete={deleteUser}
            onEdit={(u) => {
              setEditingUser(u);
              setTab(0);
            }}
          />
        )}
        
        {/* Custom Notification Dialog */}
        <NotificationDialog 
          open={notification.open}
          message={notification.message}
          onClose={closeNotification}
        />
      </Container>
    </Box>
  );
}