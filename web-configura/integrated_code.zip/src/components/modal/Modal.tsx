
// src/components/modal/Modal.tsx
import React, { useEffect, useRef } from "react";

type ModalProps = {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  widthClassName?: string;   // e.g., "w-[65%]"
  heightClassName?: string;  // e.g., "h-[65%]"
  ['data-testid']?: string;
};

const Modal: React.FC<ModalProps> = ({
  open,
  onClose,
  children,
  widthClassName = "w-[55%]",
  heightClassName = "h-[55%]",
  ...rest
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  // backdrop click close
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === containerRef.current) onClose();
  };

  return (
    <div
      {...rest}
      ref={containerRef}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
      onMouseDown={handleBackdropClick}
      aria-modal="true"
      role="dialog"
    >
      <div
        className={`bg-white border rounded-md border-gray-300 shadow-lg p-6 ${widthClassName} ${heightClassName} flex flex-col min-h-0`}
      >
        {/* Close button */}
        <button
          aria-label="Close modal"
          className="absolute top-3 right-3 text-2xl"
          onClick={onClose}
        >
          <span className="icon-[carbon--close-outline]"></span>
        </button>

        {/* Body must be shrinkable/scrollable */}
        <div className="flex-1 min-h-0 overflow-hidden">
          {children}
        </div>
      </div>
    </div>
   );
};

export default Modal;