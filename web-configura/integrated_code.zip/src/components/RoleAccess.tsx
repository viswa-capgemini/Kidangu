
// src/app/roleAccess.ts
import type { Role } from '../types/auth';

export const roleAccessBySlug: Record<string, Role[]> = {
  // Shared pages
  'enquiry-form': ['dealer', 'admin'],
  'enquiry-list': ['dealer', 'admin'],
  'layout-details': ['dealer', 'admin'],
  'previews': ['dealer', 'admin'],

  // Dealer-centric
  'configuration-layout': ['dealer'],
  'layout-design': ['dealer'],

  // Admin-only
  'master-inventory': ['admin'],
  'product-upload': ['admin'],
  'rules': ['admin'],
  'createrule': ['admin'],
};
