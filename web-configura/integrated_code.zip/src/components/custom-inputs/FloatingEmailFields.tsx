
import React, { useState } from "react";

type FloatEmailProps = {
  type: string;
  id: string;
  label: string;
  value: string;
  placeholder: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
  disabled?: boolean;
  helperText?: string;    // optional helper shown when focused
  errorText?: string;     // optional override error text
};

const FloatingEmailFields: React.FC<FloatEmailProps> = ({
  type = "",
  id,
  label,
  value,
  placeholder,
  onChange,
  className = "",
  disabled = false,
  helperText = "",
  errorText = "Please enter a valid email address.",
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [touched, setTouched] = useState(false);

  // Email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValidEmail =
    value.trim() === "" || emailRegex.test(value.trim());

  const showError = touched && !isValidEmail && value.trim() !== "";
  const isFilled = Boolean(value && value.trim().length > 0);

  return (
    <div
      data-testid="floatingEmailContainer"
      className="flex flex-col gap-4 p-4 justify-center items-center w-[320px] font-inter"
    >
      <div
        data-testid="floatingEmailWrapper"
        className="relative w-full"
      >
        <input
          data-testid="floatingEmailInput"
          type={type}
          id={id}
          value={value}
          placeholder=""
          onChange={(e) => {
            onChange(e);
          }}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setTouched(true);
          }}
          disabled={disabled}
          className={`peer block w-full rounded-md px-3 pt-[22px] pb-[8px] text-[15px] text-black outline-none transition-all border
            ${showError ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-godrej-grey"}
            ${disabled ? "bg-gray-100 cursor-not-allowed text-gray-400" : ""}
            ${className}
          `}
        />

        <label
          data-testid="floatingEmailLabel"
          htmlFor={id}
          className={`absolute left-3 px-1 transition-all duration-200 ease-in-out
            ${isFilled || isFocused
              ? "top-[6px] translate-y-0 text-[13px] text-godrej-grey"
              : "top-1/2 -translate-y-1/2 text-[15px] text-gray-400"}
            peer-focus:top-[6px] peer-focus:translate-y-0 peer-focus:text-[13px] peer-focus:text-godrej-grey
          `}
        >
          {label}
        </label>

        {/* Error Text */}
        {showError && (
          <p
            data-testid="floatingEmailError"
            className="text-red-500 text-[13px] mt-1 transition-all duration-200 ease-in-out"
          >
            {errorText}
          </p>
        )}
      </div>

    </div>
  );
};

export default FloatingEmailFields;

