import React, { useState } from "react";
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/solid";

interface CollapsibleWrapperProps {
  children: React.ReactNode;
  width?: string;
}

const CollapsibleWrapper: React.FC<CollapsibleWrapperProps> = ({
  children,
  width = "w-[220px]",
}) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div>
      {isOpen ? (
        // Expanded Panel
        <div
          data-testid="collapsiblePanelOpen"
          className={`relative ${
            isOpen ? width : "w-12"
          } bg-gray-100 shadow-lg transition-all duration-300`}
          style={{ height: "calc(100vh - 60px)" }} // Adjust for header height
        >
          {/* Header with Toggle Icon */}
          <div className="flex justify-end items-center w-full p-2 bg-gray-200">
            <button
              data-testid="collapsibleToggleBtn"
              onClick={() => setIsOpen(!isOpen)}
              className="bg-white border rounded shadow p-1 hover:bg-gray-100"
            >
              {isOpen ? (
                <ChevronLeftIcon className="h-5 w-5 text-gray-700" />
              ) : (
                <ChevronRightIcon className="h-5 w-5 text-gray-700" />
              )}
            </button>
          </div>

          {/* Panel Content */}
          {isOpen && <div data-testid="collapsibleChildrenContainer" className="overflow-y-auto">{children}</div>}
        </div>
      ) : (
        // Collapsed State: Only Icon (fixed position)
        <button
          data-testid="collapsiblePanelClosed"
          onClick={() => setIsOpen(true)}
          className="fixed top-[75px] left-16 bg-white border rounded shadow p-2 hover:bg-gray-100 z-50"
        >
          <ChevronRightIcon className="h-5 w-5 text-gray-700" />
        </button>
      )}
    </div>
  );
};

export default CollapsibleWrapper;
