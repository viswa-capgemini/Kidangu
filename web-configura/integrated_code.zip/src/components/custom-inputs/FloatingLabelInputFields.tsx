import { Label } from '@headlessui/react'
import React, {useState} from 'react'

type FloatingLabelInputFieldsProps = {
  label?: string
  width?: string
}

const FloatingLabelInputFields: React.FC<FloatingLabelInputFieldsProps> = ({
  label,
  width,
}) => {

  const [value, setValue] = useState('');
  const [focused, setFocused] = useState(false);

  return (
    <div>
      <div data-testid="floatingInputFieldContainer" className='relative'>

        <input
          data-testid="floatingInputField"
          type='text'
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className={`peer w-full h-10 border rounded px-1 py-1 text-sm`}
        />
        <label
          data-testid="floatingInputFieldLabel"
          className={`${value.length > 0 ? "peer-focus:text-[12px]": "top-[6px]"} absolute left-2 text-[8px] px-1 peer-focus:text-[6px] peer-focus:top-[1px]`}
        >{label}</label>
      </div>
    </div>
  )
}

export default FloatingLabelInputFields;
