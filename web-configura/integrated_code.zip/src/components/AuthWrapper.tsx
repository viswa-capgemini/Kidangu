import React from 'react';
import { useAuth } from '../context/AuthContext';
import App from '../App';
import Login from '../features/login-signup/Login';

const AuthWrapper: React.FC = () => {
  const { user } = useAuth();

  // If user exists, render the main App. Otherwise show Login page.
  return user ? <App /> : <Login />;
};

export default AuthWrapper;
