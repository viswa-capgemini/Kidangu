
const ElementsPanel = ({ onElementDragStart }) => {
  // Define the elements that can be dragged onto the canvas
  const elements = {
    openings: [
      {
        type: 'door',
        name: 'Door',
        width: 80,
        height: 10,
        fill: '#fff',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings'
      },
      {
        type: 'window',
        name: 'Window',
        width: 60,
        height: 8,
        fill: '#d4f1f9',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings'
      },
      {
        type: 'sliding-door',
        name: 'Sliding Door',
        width: 100,
        height: 10,
        fill: '#fff',
        stroke: '#000',
        strokeWidth: 2,
        category: 'openings',
        dash: [10, 5]
      }
    ],
    structure: [
      {
        type: 'wall',
        name: 'Wall',
        width: 100,
        height: 10,
        fill: '#888',
        stroke: '#000',
        strokeWidth: 1,
        category: 'structure'
      },
      {
        type: 'pillar',
        name: 'pillar',
        width: 30,
        height: 30,
        fill: '#888',
        stroke: '#000',
        strokeWidth: 1,
        category: 'structure',
        isCircle: true
      }
    ],
    furniture: [
      {
        type: 'bed',
        name: '',
        width: 120,
        height: 200,
        fill: '#f9d4d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'sofa',
        name: 'MobileShelving',
        width: 180,
        height: 80,
        fill: '#d4d4f9',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'table',
        name: 'Cantilever',
        width: 100,
        height: 60,
        fill: '#d4f9d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'chair',
        name: 'DDPR',
        width: 40,
        height: 40,
        fill: '#f9f9d4',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      },
      {
        type: 'rack',
        name: 'SPR',
        width: 60,
        height: 20,
        fill: '#d4e6f9',
        stroke: '#000',
        strokeWidth: 1,
        category: 'furniture'
      }
    ]
  };


const handleDragStart = (e, element) => {
    // Set data for drag operation
    e.dataTransfer.setData('application/json', JSON.stringify(element));
    
    // Set effectAllowed to move to indicate this is a move operation
    e.dataTransfer.effectAllowed = 'move';
    
    // Create a custom drag image that follows the cursor
    const dragPreview = document.createElement('div');
    dragPreview.style.width = `${element.width / 3}px`;
    dragPreview.style.height = `${element.height / 3}px`;
    dragPreview.style.backgroundColor = element.fill || '#ccc';
    dragPreview.style.border = `1px solid ${element.stroke || '#000'}`;
    dragPreview.style.opacity = '0.7';
    dragPreview.style.position = 'absolute';
    dragPreview.style.top = '-1000px';
    dragPreview.style.left = '-1000px';
    document.body.appendChild(dragPreview);
    
    // Set the drag image with an offset to position it under the cursor
    e.dataTransfer.setDragImage(dragPreview, element.width / 6, element.height / 6);
    
    // Clean up the drag image after a short delay
    setTimeout(() => {
      document.body.removeChild(dragPreview);
    }, 100);
    
    // Notify parent component
    onElementDragStart(element);
  };

  const renderElementItem = (element) => {
    return (
      <div 
        key={element.type} 
        className="element-item"
        draggable="true"
        onDragStart={(e) => handleDragStart(e, element)}
        style={{ cursor: 'grab' }} // Set cursor to grab to indicate draggable
      >
        <div className="element-icon">
          {element.isCircle ? (
            <svg width="40" height="40">
              <circle cx="20" cy="20" r="15" fill={element.fill} stroke={element.stroke} strokeWidth={element.strokeWidth} />
            </svg>
          ) : (
            <svg width="40" height="40">
              <rect 
                x={(40 - Math.min(40, element.width / 3)) / 2} 
                y={(40 - Math.min(40, element.height / 3)) / 2} 
                width={Math.min(40, element.width / 3)} 
                height={Math.min(40, element.height / 3)} 
                fill={element.fill} 
                stroke={element.stroke} 
                strokeWidth={element.strokeWidth}
                strokeDasharray={element.dash ? element.dash.join(' ') : 'none'}
              />
            </svg>
          )}
        </div>
        <div className="element-name">{element.name}</div>
      </div>
    );
  };

  return (
    <div className="elements-panel">
      <h2 className="elements-title">Elements</h2>
      
      <div className="elements-section">
        <h3 className="elements-section-title">Openings</h3>
        <div className="elements-grid">
          {elements.openings.map(renderElementItem)}
        </div>
      </div>
      
      <div className="elements-section">
        <h3 className="elements-section-title">Structure</h3>
        <div className="elements-grid">
          {elements.structure.map(renderElementItem)}
        </div>
      </div>
      
      <div className="elements-section">
        <h3 className="elements-section-title">Product Group</h3>
        <div className="elements-grid">
          {elements.furniture.map(renderElementItem)}
        </div>
      </div>
    </div>
  );
};

export default ElementsPanel;