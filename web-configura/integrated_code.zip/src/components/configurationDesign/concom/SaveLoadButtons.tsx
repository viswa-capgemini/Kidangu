// src/components/configuration-design/SaveLoadButtons.jsx
import React from 'react';

const SaveLoadButtons = ({ onSave, onLoad }) => {
  // Reference for file input
  const fileInputRef = React.useRef(null);

  // Trigger file input click when Load button is clicked
  const handleLoadClick = () => {
    fileInputRef.current.click();
  };

  // Handle file selection
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      onLoad(file);
    }
    // Reset file input so the same file can be selected again
    e.target.value = null;
  };

  return (
    <div className="save-load-buttons">
      <button 
        className="save-button"
        onClick={onSave}
        title="Save Layout"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
          <polyline points="17 21 17 13 7 13 7 21"></polyline>
          <polyline points="7 3 7 8 15 8"></polyline>
        </svg>
        Save Layout
      </button>
      
      <button 
        className="load-button"
        onClick={handleLoadClick}
        title="Load Layout"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
          <polyline points="7 10 12 15 17 10"></polyline>
          <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
        Load Layout
      </button>
      
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        accept=".json"
        onChange={handleFileChange}
      />
    </div>
  );
};

export default SaveLoadButtons;