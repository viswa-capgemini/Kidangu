// import React, { useRef, useEffect, useState } from 'react';
// import * as THREE from 'three';
// import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// const isWebGLAvailable = () => {
//   try {
//     const canvas = document.createElement('canvas');
//     return !!(window.WebGLRenderingContext && 
//       (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
//   } catch (e) {
//     return false;
//   }
// };

// const ThreeJsView = ({ shapes, scale, unit }) => {
//   const containerRef = useRef(null);
//   const [isLoading, setIsLoading] = useState(true);
//   const [webGLSupported, setWebGLSupported] = useState(true);
//   const [error, setError] = useState(null);

//   // Units configuration with conversion factors
//   const units = {
//     meters: { toMeters: 1, abbr: 'm' },
//     centimeters: { toMeters: 0.01, abbr: 'cm' },
//     feet: { toMeters: 0.3048, abbr: 'ft' },
//     inches: { toMeters: 0.0254, abbr: 'in' },
//     yards: { toMeters: 0.9144, abbr: 'yd' }
//   };

//   // Get the current unit configuration
//   const currentUnit = units[unit] || units.meters;

//   useEffect(() => {
//     console.log("ThreeJsView mounted");
    
//     // Check WebGL support
//     if (!isWebGLAvailable()) {
//       console.error("WebGL is not supported in this browser");
//       setWebGLSupported(false);
//       setIsLoading(false);
//       return;
//     }
    
//     // Short delay to ensure the component is fully mounted
//     const timer = setTimeout(() => {
//       if (!containerRef.current) {
//         console.error("Container ref is still null after delay");
//         setError("Failed to initialize 3D view - container not found");
//         setIsLoading(false);
//         return;
//       }
      
//       try {
//         // Create scene
//         const scene = new THREE.Scene();
//         scene.background = new THREE.Color(0x6495ed); // Distinctive blue
        
//         // Create camera
//         const camera = new THREE.PerspectiveCamera(
//           75,
//           containerRef.current.clientWidth / containerRef.current.clientHeight,
//           0.1,
//           1000
//         );
//         camera.position.set(0, 5, 10);
        
//         // Create renderer
//         const renderer = new THREE.WebGLRenderer({ antialias: true });
//         renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
//         containerRef.current.appendChild(renderer.domElement);
        
//         // Add orbit controls
//         const controls = new OrbitControls(camera, renderer.domElement);
//         controls.enableDamping = true;
        
//         // Create a grid helper with appropriate size based on unit
//         const gridSize = 20; // Size in meters
//         const gridDivisions = 20;
//         const gridHelper = new THREE.GridHelper(gridSize, gridDivisions);
//         scene.add(gridHelper);
        
//         // Add a label to show the current unit
//         const createUnitLabel = () => {
//           // Create a canvas for the texture
//           const canvas = document.createElement('canvas');
//           const context = canvas.getContext('2d');
//           canvas.width = 256;
//           canvas.height = 64;
          
//           // Draw text on the canvas
//           context.fillStyle = 'white';
//           context.font = 'Bold 24px Arial';
//           context.fillText(`Grid: 1 square = 1 ${currentUnit.abbr}`, 10, 40);
          
//           // Create texture from canvas
//           const texture = new THREE.CanvasTexture(canvas);
//           texture.needsUpdate = true;
          
//           // Create a sprite material with the texture
//           const material = new THREE.SpriteMaterial({ map: texture });
          
//           // Create a sprite with the material
//           const sprite = new THREE.Sprite(material);
//           sprite.position.set(10, 0.5, 10);
//           sprite.scale.set(5, 1.25, 1);
          
//           return sprite;
//         };
        
//         const unitLabel = createUnitLabel();
//         scene.add(unitLabel);
        
//         // Convert 2D shapes to 3D
//         const convert2DShapesTo3D = () => {
//           shapes.forEach(shape => {
//             // Convert all measurements to meters for 3D
//             const metersToUnit = 1 / currentUnit.toMeters;
            
//             switch(shape.type) {
//               case 'wall':
//               case 'rectangle': {
//                 const width = Math.abs(shape.width) * scale;
//                 const length = Math.abs(shape.height) * scale;
//                 const height = 2.5; // Default wall height in meters
                
//                 const geometry = new THREE.BoxGeometry(width, height, length);
//                 const material = new THREE.MeshStandardMaterial({ 
//                   color: shape.fill || 0xcccccc,
//                   roughness: 0.7
//                 });
                
//                 const mesh = new THREE.Mesh(geometry, material);
                
//                 // Position the mesh
//                 mesh.position.set(
//                   shape.x * scale + width/2, 
//                   height/2, 
//                   shape.y * scale + length/2
//                 );
                
//                 if (shape.rotation) {
//                   mesh.rotation.y = shape.rotation * Math.PI / 180;
//                 }
                
//                 scene.add(mesh);
//                 break;
//               }
              
//               case 'line': {
//                 const points = shape.points;
//                 const x1 = points[0] * scale;
//                 const z1 = points[1] * scale;
//                 const x2 = points[2] * scale;
//                 const z2 = points[3] * scale;
                
//                 const lineLength = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(z2-z1, 2));
//                 const lineGeometry = new THREE.BoxGeometry(lineLength, 2.5, 0.1);
//                 const lineMaterial = new THREE.MeshStandardMaterial({ color: 0xcccccc });
//                 const line = new THREE.Mesh(lineGeometry, lineMaterial);
                
//                 // Position and rotate
//                 line.position.set((x1+x2)/2, 1.25, (z1+z2)/2);
//                 line.rotation.y = Math.atan2(z2-z1, x2-x1);
                
//                 scene.add(line);
//                 break;
//               }
              
//               // Add cases for other shape types
//             }
//           });
//         };
        
//         // Convert shapes to 3D
//         convert2DShapesTo3D();
        
//         // Add ambient light
//         const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
//         scene.add(ambientLight);
        
//         // Add directional light
//         const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
//         directionalLight.position.set(10, 20, 10);
//         scene.add(directionalLight);
        
//         // Animation loop
//         const animate = () => {
//           requestAnimationFrame(animate);
//           controls.update();
//           renderer.render(scene, camera);
//         };
//         animate();
        
//         setIsLoading(false);
//         console.log("Three.js initialized successfully");
        
//         // Handle resize
//         const handleResize = () => {
//           if (!containerRef.current) return;
          
//           camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
//           camera.updateProjectionMatrix();
//           renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
//         };
//         window.addEventListener('resize', handleResize);
        
//         // Cleanup
//         return () => {
//           window.removeEventListener('resize', handleResize);
//           if (containerRef.current && renderer.domElement) {
//             containerRef.current.removeChild(renderer.domElement);
//           }
//           scene.clear();
//         };
//       } catch (err) {
//         console.error("Error initializing Three.js:", err);
//         setError(`Failed to initialize 3D view: ${err.message}`);
//         setIsLoading(false);
//       }
//     }, 100);
    
//     return () => clearTimeout(timer);
//   }, [shapes, scale, unit, currentUnit.abbr, currentUnit.toMeters]);

//   if (!webGLSupported) {
//     return (
//       <div className="webgl-error" style={{ padding: '20px', textAlign: 'center' }}>
//         <h3>WebGL Not Supported</h3>
//         <p>Your browser or device does not support WebGL, which is required for 3D view.</p>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="three-js-error" style={{ padding: '20px', textAlign: 'center' }}>
//         <h3>Error</h3>
//         <p>{error}</p>
//       </div>
//     );
//   }

//   return (
//     <div className="three-js-view" style={{ width: '100%', height: '100%', position: 'relative' }}>
//       <div ref={containerRef} style={{ width: '100%', height: '100%' }}></div>
//       {isLoading && (
//         <div style={{ 
//           position: 'absolute', 
//           top: '50%', 
//           left: '50%', 
//           transform: 'translate(-50%, -50%)',
//           background: 'rgba(255,255,255,0.8)',
//           padding: '20px',
//           borderRadius: '5px'
//         }}>
//           Loading 3D View...
//         </div>
//       )}
//       <div className="unit-indicator" style={{ 
//         position: 'absolute', 
//         bottom: '20px', 
//         left: '20px',
//         background: 'rgba(255,255,255,0.7)',
//         padding: '8px 12px',
//         borderRadius: '4px',
//         fontSize: '14px'
//       }}>
//         Unit: {currentUnit.abbr}
//       </div>
//     </div>
//   );
// };

// export default ThreeJsView;


import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const isWebGLAvailable = () => {
  try {
    const canvas = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && 
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
  } catch (e) {
    return false;
  }
};

const ThreeJsView = ({ shapes, scale, unit }) => {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);
  const [webGLSupported, setWebGLSupported] = useState(true);
  const [error, setError] = useState(null);

  // Units configuration with conversion factors
  const units = {
    meters: { toMeters: 1, abbr: 'm' },
    centimeters: { toMeters: 0.01, abbr: 'cm' },
    feet: { toMeters: 0.3048, abbr: 'ft' },
    inches: { toMeters: 0.0254, abbr: 'in' },
    yards: { toMeters: 0.9144, abbr: 'yd' }
  };

  // Get the current unit configuration
  const currentUnit = units[unit] || units.meters;

  // Helper function to convert 2D coordinates to 3D
  const convert2DTo3D = (x, y) => {
    return {
      x: x * scale,
      y: 0, // Default to ground level
      z: y * scale
    };
  };

  useEffect(() => {
    console.log("ThreeJsView mounted with:", {
      shapes: shapes.length,
      shapeTypes: [...new Set(shapes.map(s => s.type))],
      scale,
      unit
    });
    
    // Check WebGL support
    if (!isWebGLAvailable()) {
      console.error("WebGL is not supported in this browser");
      setWebGLSupported(false);
      setIsLoading(false);
      return;
    }
    
    // Short delay to ensure the component is fully mounted
    const timer = setTimeout(() => {
      if (!containerRef.current) {
        console.error("Container ref is still null after delay");
        setError("Failed to initialize 3D view - container not found");
        setIsLoading(false);
        return;
      }
      
      try {
        // Create scene
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xf0f0f0); // Light gray background
        sceneRef.current = scene;
        
        // Create camera
        const camera = new THREE.PerspectiveCamera(
          75,
          containerRef.current.clientWidth / containerRef.current.clientHeight,
          0.1,
          1000
        );
        camera.position.set(0, 5, 10);
        
        // Create renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        containerRef.current.appendChild(renderer.domElement);
        rendererRef.current = renderer;
        
        // Add orbit controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.screenSpacePanning = false;
        controls.minDistance = 1;
        controls.maxDistance = 50;
        controls.maxPolarAngle = Math.PI / 2; // Limit to not go below ground
        
        // Create a grid helper with appropriate size based on unit
        const gridSize = 20; // Size in meters
        const gridDivisions = 20;
        const gridHelper = new THREE.GridHelper(gridSize, gridDivisions);
        scene.add(gridHelper);
        
        // Add a label to show the current unit
        const createUnitLabel = () => {
          // Create a canvas for the texture
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          canvas.width = 256;
          canvas.height = 64;
          
          // Draw text on the canvas
          context.fillStyle = 'white';
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.fillStyle = 'black';
          context.font = 'Bold 24px Arial';
          context.fillText(`Grid: 1 square = 1 ${currentUnit.abbr}`, 10, 40);
          
          // Create texture from canvas
          const texture = new THREE.CanvasTexture(canvas);
          texture.needsUpdate = true;
          
          // Create a sprite material with the texture
          const material = new THREE.SpriteMaterial({ map: texture });
          
          // Create a sprite with the material
          const sprite = new THREE.Sprite(material);
          sprite.position.set(10, 0.5, 10);
          sprite.scale.set(5, 1.25, 1);
          
          return sprite;
        };
        
        const unitLabel = createUnitLabel();
        scene.add(unitLabel);
        
        // Add floor plane
        const floorGeometry = new THREE.PlaneGeometry(gridSize, gridSize);
        const floorMaterial = new THREE.MeshStandardMaterial({ 
          color: 0xffffff,
          roughness: 0.8,
          metalness: 0.2,
          side: THREE.DoubleSide
        });
        const floor = new THREE.Mesh(floorGeometry, floorMaterial);
        floor.rotation.x = -Math.PI / 2;
        floor.receiveShadow = true;
        scene.add(floor);
        
        // Convert 2D shapes to 3D
        const convert2DShapesTo3D = () => {
          console.log("Converting shapes to 3D:", shapes.length, "shapes");
          
          shapes.forEach(shape => {
            try {
              // Log shape for debugging
              console.log("Processing shape:", shape.type, shape);
              
              switch(shape.type) {
                case 'wall':
                case 'rectangle': {
                  const width = Math.abs(shape.width) * scale;
                  const length = Math.abs(shape.height) * scale;
                  const height = 2.5; // Default wall height in meters
                  
                  const geometry = new THREE.BoxGeometry(width, height, length);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0xcccccc,
                    roughness: 0.7
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale + width/2, 
                    height/2, 
                    shape.y * scale + length/2
                  );
                  
                  if (shape.rotation) {
                    mesh.rotation.y = shape.rotation * Math.PI / 180;
                  }
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'line': {
                  const points = shape.points;
                  const x1 = points[0] * scale;
                  const z1 = points[1] * scale;
                  const x2 = points[2] * scale;
                  const z2 = points[3] * scale;
                  
                  const lineLength = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(z2-z1, 2));
                  const lineGeometry = new THREE.BoxGeometry(lineLength, 2.5, 0.1);
                  const lineMaterial = new THREE.MeshStandardMaterial({ 
                    color: shape.stroke || 0xcccccc 
                  });
                  const line = new THREE.Mesh(lineGeometry, lineMaterial);
                  line.castShadow = true;
                  line.receiveShadow = true;
                  
                  // Position and rotate
                  line.position.set((x1+x2)/2, 1.25, (z1+z2)/2);
                  line.rotation.y = Math.atan2(z2-z1, x2-x1);
                  
                  scene.add(line);
                  break;
                }
                
                case 'door':
                case 'window':
                case 'sliding-door': {
                  // Handle openings
                  const width = Math.abs(shape.width) * scale;
                  const length = Math.abs(shape.height) * scale;
                  const height = shape.type === 'door' || shape.type === 'sliding-door' ? 2.0 : 1.2;
                  const yPos = shape.type === 'window' ? 1.0 : height/2;
                  
                  const geometry = new THREE.BoxGeometry(width, height, length);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.type === 'window' ? 0xadd8e6 : 0x8b4513,
                    transparent: shape.type === 'window',
                    opacity: shape.type === 'window' ? 0.7 : 1.0
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale + width/2, 
                    yPos, 
                    shape.y * scale + length/2
                  );
                  
                  if (shape.rotation) {
                    mesh.rotation.y = shape.rotation * Math.PI / 180;
                  }
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'rack': {
                  // Handle racks (auto-populated elements)
                  const width = Math.abs(shape.width) * scale;
                  const length = Math.abs(shape.height) * scale;
                  const height = 1.5; // Default rack height
                  
                  const geometry = new THREE.BoxGeometry(width, height, length);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0x22c55e,
                    roughness: 0.7
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale + width/2, 
                    height/2, 
                    shape.y * scale + length/2
                  );
                  
                  if (shape.rotation) {
                    mesh.rotation.y = shape.rotation * Math.PI / 180;
                  }
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'bed':
                case 'sofa':
                case 'table':
                case 'chair': {
                  // Handle furniture
                  const width = Math.abs(shape.width) * scale;
                  const length = Math.abs(shape.height) * scale;
                  const height = shape.type === 'table' ? 0.75 : 
                                shape.type === 'chair' ? 0.5 : 
                                shape.type === 'sofa' ? 0.8 : 0.5;
                  
                  const geometry = new THREE.BoxGeometry(width, height, length);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0xdddddd,
                    roughness: 0.5
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale + width/2, 
                    height/2, 
                    shape.y * scale + length/2
                  );
                  
                  if (shape.rotation) {
                    mesh.rotation.y = shape.rotation * Math.PI / 180;
                  }
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'pillar': {
                  // Handle pillars (circular columns)
                  const radius = Math.abs(shape.width) * scale / 2;
                  const height = 3.0; // Default pillar height
                  
                  const geometry = new THREE.CylinderGeometry(radius, radius, height, 32);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0x888888,
                    roughness: 0.7
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale + radius, 
                    height/2, 
                    shape.y * scale + radius
                  );
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'circle': {
                  // Handle circles
                  const radius = shape.radius * scale;
                  const height = 0.1; // Thin disc
                  
                  const geometry = new THREE.CylinderGeometry(radius, radius, height, 32);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0xcccccc,
                    roughness: 0.7
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  mesh.castShadow = true;
                  mesh.receiveShadow = true;
                  
                  // Position the mesh
                  mesh.position.set(
                    shape.x * scale, 
                    height/2, 
                    shape.y * scale
                  );
                  
                  scene.add(mesh);
                  break;
                }
                
                case 'text': {
                  // Handle text (create a floating label)
                  const canvas = document.createElement('canvas');
                  const context = canvas.getContext('2d');
                  canvas.width = 256;
                  canvas.height = 64;
                  
                  context.fillStyle = 'white';
                  context.fillRect(0, 0, canvas.width, canvas.height);
                  context.fillStyle = 'black';
                  context.font = 'Bold 24px Arial';
                  context.fillText(shape.text || "", 10, 40);
                  
                  const texture = new THREE.CanvasTexture(canvas);
                  const material = new THREE.SpriteMaterial({ map: texture });
                  const sprite = new THREE.Sprite(material);
                  
                  sprite.position.set(
                    shape.x * scale, 
                    1.5, // Float above ground
                    shape.y * scale
                  );
                  
                  sprite.scale.set(2, 0.5, 1);
                  scene.add(sprite);
                  break;
                }
                
                case 'aisle': {
                  // Handle aisles (special floor marking)
                  const width = Math.abs(shape.width) * scale;
                  const length = Math.abs(shape.height) * scale;
                  
                  const geometry = new THREE.PlaneGeometry(width, length);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: shape.fill || 0xcccccc,
                    transparent: true,
                    opacity: 0.7,
                    side: THREE.DoubleSide
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  
                  // Position the mesh (slightly above floor to prevent z-fighting)
                  mesh.position.set(
                    shape.x * scale + width/2, 
                    0.01, // Just above floor
                    shape.y * scale + length/2
                  );
                  
                  // Rotate to lay flat
                  mesh.rotation.x = -Math.PI / 2;
                  
                  if (shape.rotation) {
                    mesh.rotation.z = shape.rotation * Math.PI / 180;
                  }
                  
                  scene.add(mesh);
                  
                  // Add aisle label
                  if (shape.label) {
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');
                    canvas.width = 256;
                    canvas.height = 64;
                    
                    context.fillStyle = 'white';
                    context.fillRect(0, 0, canvas.width, canvas.height);
                    context.fillStyle = 'black';
                    context.font = 'Bold 24px Arial';
                    context.fillText(shape.label, 10, 40);
                    
                    const texture = new THREE.CanvasTexture(canvas);
                    const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
                    const sprite = new THREE.Sprite(spriteMaterial);
                    
                    sprite.position.set(
                      shape.x * scale + width/2, 
                      0.1, // Just above the aisle
                      shape.y * scale + length/2
                    );
                    
                    sprite.scale.set(width/2, width/8, 1);
                    scene.add(sprite);
                  }
                  break;
                }
                
                case 'pencil': {
                  // Handle pencil (freehand drawing)
                  if (shape.points && shape.points.length >= 4) {
                    const points = [];
                    
                    // Convert points to THREE.Vector3 for the line
                    for (let i = 0; i < shape.points.length; i += 2) {
                      if (i + 1 < shape.points.length) {
                        points.push(new THREE.Vector3(
                          shape.points[i] * scale,
                          0.1, // Slightly above ground
                          shape.points[i + 1] * scale
                        ));
                      }
                    }
                    
                    const geometry = new THREE.BufferGeometry().setFromPoints(points);
                    const material = new THREE.LineBasicMaterial({ 
                      color: shape.stroke || 0x000000,
                      linewidth: shape.strokeWidth || 2
                    });
                    
                    const line = new THREE.Line(geometry, material);
                    scene.add(line);
                  }
                  break;
                }
                
                default: {
                  // Fallback representation for unhandled types
                  console.warn(`Unhandled shape type in 3D view: ${shape.type}`, shape);
                  
                  const size = 0.5;
                  const geometry = new THREE.SphereGeometry(size, 16, 16);
                  const material = new THREE.MeshStandardMaterial({ 
                    color: 0xff0000, // Red for unhandled types
                    wireframe: true
                  });
                  
                  const mesh = new THREE.Mesh(geometry, material);
                  
                  // Position at shape location
                  let posX = shape.x * scale;
                  let posZ = shape.y * scale;
                  
                  // If shape has width/height, position at center
                  if (shape.width !== undefined && shape.height !== undefined) {
                    posX += (shape.width * scale) / 2;
                    posZ += (shape.height * scale) / 2;
                  }
                  
                  mesh.position.set(posX, size, posZ);
                  scene.add(mesh);
                  break;
                }
              }
            } catch (err) {
              console.error(`Error converting shape to 3D: ${shape.type}`, err, shape);
            }
          });
        };
        
        // Add ambient light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);
        
        // Add directional light with shadows
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 20, 10);
        directionalLight.castShadow = true;
        
        // Configure shadow properties
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -20;
        directionalLight.shadow.camera.right = 20;
        directionalLight.shadow.camera.top = 20;
        directionalLight.shadow.camera.bottom = -20;
        
        scene.add(directionalLight);
        
        // Add a hemisphere light for more natural lighting
        const hemisphereLight = new THREE.HemisphereLight(0xddeeff, 0x202020, 0.5);
        scene.add(hemisphereLight);
        
        // Convert shapes to 3D
        convert2DShapesTo3D();
        
        // Animation loop
        const animate = () => {
          requestAnimationFrame(animate);
          controls.update();
          renderer.render(scene, camera);
        };
        animate();
        
        setIsLoading(false);
        console.log("Three.js initialized successfully");
        
        // Handle resize
        const handleResize = () => {
          if (!containerRef.current) return;
          
          camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
        };
        window.addEventListener('resize', handleResize);
        
        // Cleanup
        return () => {
          window.removeEventListener('resize', handleResize);
          if (containerRef.current && renderer.domElement) {
            containerRef.current.removeChild(renderer.domElement);
          }
          
          // Dispose of geometries and materials to prevent memory leaks
          scene.traverse((object) => {
            if (object.geometry) {
              object.geometry.dispose();
            }
            
            if (object.material) {
              if (Array.isArray(object.material)) {
                object.material.forEach(material => material.dispose());
              } else {
                object.material.dispose();
              }
            }
          });
          
          scene.clear();
          renderer.dispose();
        };
      } catch (err) {
        console.error("Error initializing Three.js:", err);
        setError(`Failed to initialize 3D view: ${err.message}`);
        setIsLoading(false);
      }
    }, 100);
    
    return () => clearTimeout(timer);
  }, [shapes, scale, unit, currentUnit.abbr, currentUnit.toMeters]);

  // Effect to update the scene when shapes change
  useEffect(() => {
    if (!sceneRef.current || !rendererRef.current) return;
    
    const scene = sceneRef.current;
    
    // Clear existing objects (except lights, grid, etc.)
    const objectsToRemove = [];
    scene.traverse((object) => {
      // Keep lights, grid, and floor
      if (object instanceof THREE.Light || 
          object instanceof THREE.GridHelper || 
          object instanceof THREE.Sprite ||
          (object instanceof THREE.Mesh && object.geometry instanceof THREE.PlaneGeometry)) {
        return;
      }
      
      if (object !== scene) {
        objectsToRemove.push(object);
      }
    });
    
    objectsToRemove.forEach(object => {
      scene.remove(object);
      
      // Dispose of geometries and materials
      if (object.geometry) {
        object.geometry.dispose();
      }
      
      if (object.material) {
        if (Array.isArray(object.material)) {
          object.material.forEach(material => material.dispose());
        } else {
          object.material.dispose();
        }
      }
    });
    
    // Convert 2D shapes to 3D
    const convert2DShapesTo3D = () => {
      console.log("Updating 3D view with:", shapes.length, "shapes");
      
      shapes.forEach(shape => {
        try {
          // Log shape for debugging
          console.log("Processing shape:", shape.type, shape);
          
          switch(shape.type) {
            case 'wall':
            case 'rectangle': {
              const width = Math.abs(shape.width) * scale;
              const length = Math.abs(shape.height) * scale;
              const height = 2.5; // Default wall height in meters
              
              const geometry = new THREE.BoxGeometry(width, height, length);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0xcccccc,
                roughness: 0.7
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale + width/2, 
                height/2, 
                shape.y * scale + length/2
              );
              
              if (shape.rotation) {
                mesh.rotation.y = shape.rotation * Math.PI / 180;
              }
              
              scene.add(mesh);
              break;
            }
            
            case 'line': {
              const points = shape.points;
              const x1 = points[0] * scale;
              const z1 = points[1] * scale;
              const x2 = points[2] * scale;
              const z2 = points[3] * scale;
              
              const lineLength = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(z2-z1, 2));
              const lineGeometry = new THREE.BoxGeometry(lineLength, 2.5, 0.1);
              const lineMaterial = new THREE.MeshStandardMaterial({ 
                color: shape.stroke || 0xcccccc 
              });
              const line = new THREE.Mesh(lineGeometry, lineMaterial);
              line.castShadow = true;
              line.receiveShadow = true;
              
              // Position and rotate
              line.position.set((x1+x2)/2, 1.25, (z1+z2)/2);
              line.rotation.y = Math.atan2(z2-z1, x2-x1);
              
              scene.add(line);
              break;
            }
            
            case 'door':
            case 'window':
            case 'sliding-door': {
              // Handle openings
              const width = Math.abs(shape.width) * scale;
              const length = Math.abs(shape.height) * scale;
              const height = shape.type === 'door' || shape.type === 'sliding-door' ? 2.0 : 1.2;
              const yPos = shape.type === 'window' ? 1.0 : height/2;
              
              const geometry = new THREE.BoxGeometry(width, height, length);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.type === 'window' ? 0xadd8e6 : 0x8b4513,
                transparent: shape.type === 'window',
                opacity: shape.type === 'window' ? 0.7 : 1.0
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale + width/2, 
                yPos, 
                shape.y * scale + length/2
              );
              
              if (shape.rotation) {
                mesh.rotation.y = shape.rotation * Math.PI / 180;
              }
              
              scene.add(mesh);
              break;
            }
            
            case 'rack': {
              // Handle racks (auto-populated elements)
              const width = Math.abs(shape.width) * scale;
              const length = Math.abs(shape.height) * scale;
              const height = 1.5; // Default rack height
              
              const geometry = new THREE.BoxGeometry(width, height, length);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0x22c55e,
                roughness: 0.7
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale + width/2, 
                height/2, 
                shape.y * scale + length/2
              );
              
              if (shape.rotation) {
                mesh.rotation.y = shape.rotation * Math.PI / 180;
              }
              
              scene.add(mesh);
              break;
            }
            
            case 'bed':
            case 'sofa':
            case 'table':
            case 'chair': {
              // Handle furniture
              const width = Math.abs(shape.width) * scale;
              const length = Math.abs(shape.height) * scale;
              const height = shape.type === 'table' ? 0.75 : 
                            shape.type === 'chair' ? 0.5 : 
                            shape.type === 'sofa' ? 0.8 : 0.5;
              
              const geometry = new THREE.BoxGeometry(width, height, length);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0xdddddd,
                roughness: 0.5
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale + width/2, 
                height/2, 
                shape.y * scale + length/2
              );
              
              if (shape.rotation) {
                mesh.rotation.y = shape.rotation * Math.PI / 180;
              }
              
              scene.add(mesh);
              break;
            }
            
            case 'pillar': {
              // Handle pillars (circular columns)
              const radius = Math.abs(shape.width) * scale / 2;
              const height = 3.0; // Default pillar height
              
              const geometry = new THREE.CylinderGeometry(radius, radius, height, 32);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0x888888,
                roughness: 0.7
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale + radius, 
                height/2, 
                shape.y * scale + radius
              );
              
              scene.add(mesh);
              break;
            }
            
            case 'circle': {
              // Handle circles
              const radius = shape.radius * scale;
              const height = 0.1; // Thin disc
              
              const geometry = new THREE.CylinderGeometry(radius, radius, height, 32);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0xcccccc,
                roughness: 0.7
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              
              // Position the mesh
              mesh.position.set(
                shape.x * scale, 
                height/2, 
                shape.y * scale
              );
              
              scene.add(mesh);
              break;
            }
            
            case 'text': {
              // Handle text (create a floating label)
              const canvas = document.createElement('canvas');
              const context = canvas.getContext('2d');
              canvas.width = 256;
              canvas.height = 64;
              
              context.fillStyle = 'white';
              context.fillRect(0, 0, canvas.width, canvas.height);
              context.fillStyle = 'black';
              context.font = 'Bold 24px Arial';
              context.fillText(shape.text || "", 10, 40);
              
              const texture = new THREE.CanvasTexture(canvas);
              const material = new THREE.SpriteMaterial({ map: texture });
              const sprite = new THREE.Sprite(material);
              
              sprite.position.set(
                shape.x * scale, 
                1.5, // Float above ground
                shape.y * scale
              );
              
              sprite.scale.set(2, 0.5, 1);
              scene.add(sprite);
              break;
            }
            
            case 'aisle': {
              // Handle aisles (special floor marking)
              const width = Math.abs(shape.width) * scale;
              const length = Math.abs(shape.height) * scale;
              
              const geometry = new THREE.PlaneGeometry(width, length);
              const material = new THREE.MeshStandardMaterial({ 
                color: shape.fill || 0xcccccc,
                transparent: true,
                opacity: 0.7,
                side: THREE.DoubleSide
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              
              // Position the mesh (slightly above floor to prevent z-fighting)
              mesh.position.set(
                shape.x * scale + width/2, 
                0.01, // Just above floor
                shape.y * scale + length/2
              );
              
              // Rotate to lay flat
              mesh.rotation.x = -Math.PI / 2;
              
              if (shape.rotation) {
                mesh.rotation.z = shape.rotation * Math.PI / 180;
              }
              
              scene.add(mesh);
              
              // Add aisle label
              if (shape.label) {
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.width = 256;
                canvas.height = 64;
                
                context.fillStyle = 'white';
                context.fillRect(0, 0, canvas.width, canvas.height);
                context.fillStyle = 'black';
                context.font = 'Bold 24px Arial';
                context.fillText(shape.label, 10, 40);
                
                const texture = new THREE.CanvasTexture(canvas);
                const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
                const sprite = new THREE.Sprite(spriteMaterial);
                
                sprite.position.set(
                  shape.x * scale + width/2, 
                  0.1, // Just above the aisle
                  shape.y * scale + length/2
                );
                
                sprite.scale.set(width/2, width/8, 1);
                scene.add(sprite);
              }
              break;
            }
            
            case 'pencil': {
              // Handle pencil (freehand drawing)
              if (shape.points && shape.points.length >= 4) {
                const points = [];
                
                // Convert points to THREE.Vector3 for the line
                for (let i = 0; i < shape.points.length; i += 2) {
                  if (i + 1 < shape.points.length) {
                    points.push(new THREE.Vector3(
                      shape.points[i] * scale,
                      0.1, // Slightly above ground
                      shape.points[i + 1] * scale
                    ));
                  }
                }
                
                const geometry = new THREE.BufferGeometry().setFromPoints(points);
                const material = new THREE.LineBasicMaterial({ 
                  color: shape.stroke || 0x000000,
                  linewidth: shape.strokeWidth || 2
                });
                
                const line = new THREE.Line(geometry, material);
                scene.add(line);
              }
              break;
            }
            
            default: {
              // Fallback representation for unhandled types
              console.warn(`Unhandled shape type in 3D view: ${shape.type}`, shape);
              
              const size = 0.5;
              const geometry = new THREE.SphereGeometry(size, 16, 16);
              const material = new THREE.MeshStandardMaterial({ 
                color: 0xff0000, // Red for unhandled types
                wireframe: true
              });
              
              const mesh = new THREE.Mesh(geometry, material);
              
              // Position at shape location
              let posX = shape.x * scale;
              let posZ = shape.y * scale;
              
              // If shape has width/height, position at center
              if (shape.width !== undefined && shape.height !== undefined) {
                posX += (shape.width * scale) / 2;
                posZ += (shape.height * scale) / 2;
              }
              
              mesh.position.set(posX, size, posZ);
              scene.add(mesh);
              break;
            }
          }
        } catch (err) {
          console.error(`Error converting shape to 3D: ${shape.type}`, err, shape);
        }
      });
    };
    
    // Convert shapes to 3D
    convert2DShapesTo3D();
    
  }, [shapes, scale]);

  if (!webGLSupported) {
    return (
      <div className="webgl-error" style={{ padding: '20px', textAlign: 'center' }}>
        <h3>WebGL Not Supported</h3>
        <p>Your browser or device does not support WebGL, which is required for 3D view.</p>
        <p>Please try using a different browser or device that supports WebGL.</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="three-js-error" style={{ padding: '20px', textAlign: 'center' }}>
        <h3>Error</h3>
        <p>{error}</p>
        <p>Please try refreshing the page or contact support if the issue persists.</p>
      </div>
    );
  }

  return (
    <div className="three-js-view" style={{ width: '100%', height: '100%', position: 'relative' }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%' }}></div>
      {isLoading && (
        <div style={{ 
          position: 'absolute', 
          top: '50%', 
          left: '50%', 
          transform: 'translate(-50%, -50%)',
          background: 'rgba(255,255,255,0.8)',
          padding: '20px',
          borderRadius: '5px',
          boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ marginBottom: '10px' }}>Loading 3D View...</div>
            <div style={{ width: '50px', height: '50px', border: '5px solid #f3f3f3', borderTop: '5px solid #3498db', borderRadius: '50%', margin: '0 auto', animation: 'spin 1s linear infinite' }}></div>
            <style>{`
              @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
              }
            `}</style>
          </div>
        </div>
      )}
      <div className="unit-indicator" style={{ 
        position: 'absolute', 
        bottom: '20px', 
        left: '20px',
        background: 'rgba(255,255,255,0.7)',
        padding: '8px 12px',
        borderRadius: '4px',
        fontSize: '14px',
        boxShadow: '0 1px 4px rgba(0,0,0,0.1)'
      }}>
        Unit: {currentUnit.abbr}
      </div>
      <div className="controls-help" style={{ 
        position: 'absolute', 
        top: '20px', 
        right: '20px',
        background: 'rgba(255,255,255,0.7)',
        padding: '8px 12px',
        borderRadius: '4px',
        fontSize: '12px',
        boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        maxWidth: '200px'
      }}>
        <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>3D Controls:</div>
        <div>• Left click + drag: Rotate</div>
        <div>• Right click + drag: Pan</div>
        <div>• Scroll: Zoom</div>
      </div>
    </div>
  );
};

export default ThreeJsView;