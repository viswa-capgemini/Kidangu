

// import React, { useState, useRef } from 'react';

// interface TopBarProps {
//   selectedTool: string | null;
//   onToolSelect: (toolId: string | null) => void;
//   onUndo?: () => void;
//   onRedo?: () => void;
//   canUndo: boolean;
//   canRedo: boolean;
//   showDimensions: boolean;
//   onToggleDimensions: () => void;
//   scale: number;
//   onScaleChange: (metersPerPixel: number) => void;
//   unit: 'meters' | 'centimeters' | 'feet' | 'inches' | 'yards';
//   onUnitChange: (unit: TopBarProps['unit']) => void;
//   zoomLevel: number;
//   onZoomIn: () => void;
//   onZoomOut: () => void;
//   onResetZoom: () => void;
//   viewMode: '2D' | '3D';
//   onToggleViewMode: () => void;
//   showAutoPopulate?: boolean;
//   onToggleAutoPopulate?: () => void;
//   onSaveLayout?: () => void;
//   onLoadLayout?: (file: File) => void;
//   isPanMode?: boolean;
//   onTogglePanMode?: () => void;
// }

// const TopBar: React.FC<TopBarProps> = ({ 
//   selectedTool, 
//   onToolSelect, 
//   onUndo, 
//   onRedo, 
//   canUndo, 
//   canRedo,
//   showDimensions,
//   onToggleDimensions,
//   scale,
//   onScaleChange,
//   unit,
//   onUnitChange,
//   zoomLevel,
//   onZoomIn,
//   onZoomOut,
//   onResetZoom,
//   viewMode,
//   onToggleViewMode,
//   showAutoPopulate,
//   onToggleAutoPopulate,
//   onSaveLayout,
//   onLoadLayout,
//   isPanMode = false,
//   onTogglePanMode
// }) => {
//   const [showScaleInput, setShowScaleInput] = useState(false);
//   const fileInputRef = useRef<HTMLInputElement>(null);

//   const tools = [
//     { id: 'line', name: 'Line', icon: 'M3,3 L21,21' },
//     { id: 'rectangle', name: 'Rectangle', icon: 'M4,4 H20 V20 H4 Z' },
//     { id: 'circle', name: 'Circle', icon: 'M12,12 m-8,0 a8,8 0 1,0 16,0 a8,8 0 1,0 -16,0' },
//     { id: 'pencil', name: 'Pencil', icon: 'M3,17.25 L3,21 L6.75,21 L17.81,9.94 L14.06,6.19 L3,17.25 Z M20.71,7.04 C21.1,6.65 21.1,6.02 20.71,5.63 L18.37,3.29 C17.98,2.9 17.35,2.9 16.96,3.29 L15.13,5.12 L18.88,8.87 L20.71,7.04 Z' },
//     { id: 'text', name: 'Text', icon: 'M5,3 H19 V7 H16 V19 H8 V7 H5 V3 Z' }
//   ];

//   // Units configuration with conversion factors (relative to meters)
//   const units = [
//     { id: 'meters', label: 'Meters', abbr: 'm', toMeters: 1 },
//     { id: 'centimeters', label: 'Centimeters', abbr: 'cm', toMeters: 0.01 },
//     { id: 'feet', label: 'Feet', abbr: 'ft', toMeters: 0.3048 },
//     { id: 'inches', label: 'Inches', abbr: 'in', toMeters: 0.0254 },
//     { id: 'yards', label: 'Yards', abbr: 'yd', toMeters: 0.9144 }
//   ];
  
//   // Find the current unit object
//   const currentUnit = units.find(u => u.id === unit) || units[0];

//   const handleScaleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const value = parseFloat(e.target.value);
//     if (!isNaN(value) && value > 0) {
//       // Convert the input scale (in current unit per pixel) to meters per pixel
//       const metersPerPixel = value * currentUnit.toMeters;
//       onScaleChange(metersPerPixel);
//     }
//   };

//   // Calculate display value for the current unit
//   const displayScale = scale / currentUnit.toMeters;
  
//   // Calculate pixels per unit for display
//   const pixelsPerUnit = 1 / displayScale;

//   // Handle file selection for loading layout
//   const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const file = e.target.files?.[0];
//     if (file && onLoadLayout) {
//       onLoadLayout(file);
//     }
//     // Reset file input so the same file can be selected again
//     if (e.target) {
//       e.target.value = '';
//     }
//   };

//   // Handle AutoPopulate toggle - turn off pan mode if needed
//   const handleToggleAutoPopulate = () => {
//     // If pan mode is active and we're turning on AutoPopulate, turn off pan mode first
//     if (isPanMode && !showAutoPopulate && onTogglePanMode) {
//       onTogglePanMode();
//     }
    
//     // Then toggle AutoPopulate
//     if (onToggleAutoPopulate) {
//       onToggleAutoPopulate();
//     }
//   };

//   return (
//     <div className="top-bar">
//       <div className="tool-group">
//         {tools.map((tool) => (
//           <button
//             key={tool.id}
//             className={`tool-icon ${selectedTool === tool.id ? 'selected' : ''}`}
//             onClick={() => onToolSelect(tool.id)}
//             title={tool.name}
//             disabled={viewMode === '3D' || isPanMode || showAutoPopulate} // Disable drawing tools in 3D mode, pan mode, or when AutoPopulate is active
//           >
//             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//               <path d={tool.icon} />
//             </svg>
//           </button>
//         ))}
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className="tool-icon" 
//           onClick={onUndo} 
//           disabled={!canUndo || viewMode === '3D' || isPanMode || showAutoPopulate} // Disable in 3D mode, pan mode, or when AutoPopulate is active
//           title="Undo"
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M3,10 C3,10 7,5 12,5 C17,5 21,10 21,10" />
//             <path d="M3,10 L8,10 L8,5" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onRedo} 
//           disabled={!canRedo || viewMode === '3D' || isPanMode || showAutoPopulate} // Disable in 3D mode, pan mode, or when AutoPopulate is active
//           title="Redo"
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M21,10 C21,10 17,5 12,5 C7,5 3,10 3,10" />
//             <path d="M21,10 L16,10 L16,5" />
//           </svg>
//         </button>
//       </div>

//       <div className="divider"></div>

//       {/* Save/Load buttons */}
//       {onSaveLayout && onLoadLayout && (
//         <>
//           <div className="tool-group">
//             <button 
//               className="tool-icon" 
//               onClick={onSaveLayout}
//               title="Save Layout"
//             >
//               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                 <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
//                 <polyline points="17 21 17 13 7 13 7 21"></polyline>
//                 <polyline points="7 3 7 8 15 8"></polyline>
//               </svg>
//             </button>
//             <button 
//               className="tool-icon" 
//               onClick={() => fileInputRef.current?.click()}
//               title="Load Layout"
//             >
//               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                 <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
//                 <polyline points="7 10 12 15 17 10"></polyline>
//                 <line x1="12" y1="15" x2="12" y2="3"></line>
//               </svg>
//             </button>
//             {/* Hidden file input */}
//             <input
//               type="file"
//               ref={fileInputRef}
//               style={{ display: 'none' }}
//               accept=".json"
//               onChange={handleFileChange}
//             />
//           </div>
//           <div className="divider"></div>
//         </>
//       )}

//       {/* Pan Mode Toggle - disabled when AutoPopulate is active */}
//       {onTogglePanMode && viewMode === '2D' && (
//         <>
//           <div className="tool-group">
//             <button
//               className={`tool-icon ${isPanMode ? 'selected' : ''}`}
//               onClick={onTogglePanMode}
//               title={isPanMode ? "Exit Pan Mode" : "Enter Pan Mode"}
//               disabled={viewMode === '3D' || showAutoPopulate} // Disable in 3D mode or when AutoPopulate is active
//             >
//               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                 <path d="M13,11 L22,11 M13,11 L13,2 M11,13 L2,13 M11,13 L11,22 M13,13 L22,22 M13,13 L22,13 M11,11 L2,2 M11,11 L2,11" />
//                 <circle cx="12" cy="12" r="3" />
//               </svg>
//             </button>
//             {isPanMode && !showAutoPopulate && (
//               <div className="pan-mode-indicator">
//                 Pan Mode
//               </div>
//             )}
//           </div>
//           <div className="divider"></div>
//         </>
//       )}

//       <div className="tool-group">
//         <button 
//           className={`tool-icon ${showDimensions ? 'selected' : ''}`} 
//           onClick={onToggleDimensions}
//           title="Toggle Dimensions"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M3,6 H21" />
//             <path d="M3,6 L3,3" />
//             <path d="M21,6 L21,3" />
//             <path d="M12,3 L12,21" />
//             <path d="M12,21 L9,21" />
//             <path d="M12,21 L15,21" />
//           </svg>
//         </button>
        
//         <div className="scale-control">
//           <button 
//             className="tool-icon" 
//             onClick={() => setShowScaleInput(!showScaleInput)}
//             title="Scale Settings"
//           >
//             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//               <path d="M3,6 H21" />
//               <path d="M3,12 H21" />
//               <path d="M3,18 H21" />
//             </svg>
//           </button>
          
//           {showScaleInput && (
//             <div className="scale-popup">
//               <label>
//                 Unit:
//                 <select 
//                   value={unit} 
//                   onChange={(e) => onUnitChange(e.target.value as TopBarProps['unit'])}
//                   className="unit-select"
//                 >
//                   {units.map(u => (
//                     <option key={u.id} value={u.id}>{u.label}</option>
//                   ))}
//                 </select>
//               </label>
//               <label>
//                 Scale ({currentUnit.abbr}):
//                 <input
//                   type="number"
//                   value={displayScale.toFixed(6)}
//                   onChange={handleScaleChange}
//                   step={currentUnit.id === 'meters' ? 0.001 : 0.01}
//                   min={currentUnit.id === 'meters' ? 0.001 : 0.01}
//                   max={currentUnit.id === 'meters' ? 0.1 : 10}
//                 />
//               </label>
//               <div className="scale-info">
//                 1 {currentUnit.abbr} = {Math.round(pixelsPerUnit)} pixels
//               </div>
//               <div className="scale-info">
//                 100 pixels = {(100 * scale / currentUnit.toMeters).toFixed(2)} {currentUnit.abbr}
//               </div>
//             </div>
//           )}
//         </div>
//       </div>

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className="tool-icon" 
//           onClick={onZoomIn}
//           title="Zoom In"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <line x1="12" y1="8" x2="12" y2="16" />
//             <line x1="8" y1="12" x2="16" y2="12" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onZoomOut}
//           title="Zoom Out"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <line x1="8" y1="12" x2="16" y2="12" />
//           </svg>
//         </button>
//         <button 
//           className="tool-icon" 
//           onClick={onResetZoom}
//           title="Reset Zoom"
//           disabled={viewMode === '3D'} // Disable in 3D mode
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <circle cx="12" cy="12" r="10" />
//             <path d="M8,12 L16,12" />
//             <path d="M12,8 L12,16" />
//           </svg>
//         </button>
//         {viewMode === '2D' && (
//           <div className="zoom-level">
//             {Math.round(zoomLevel * 100)}%
//           </div>
//         )}
//       </div>

//       {/* Auto-Populate button */}
//       {onToggleAutoPopulate && (
//         <>
//           <div className="divider"></div>
//           <div className="tool-group">  
//             <button
//               onClick={handleToggleAutoPopulate}
//               title={showAutoPopulate ? "Hide Auto‑Populate" : "Show Auto‑Populate"}
//               className={`tool-icon ${showAutoPopulate ? "selected" : ""}`}
//               disabled={viewMode === '3D'} // Disable in 3D mode
//             >
//               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"> 
//                 <rect x="3" y="4" width="6" height="16" rx="1" />
//                 <rect x="15" y="4" width="6" height="16" rx="1" />
//                 <line x1="9" y1="8" x2="15" y2="8" />
//                 <line x1="9" y1="12" x2="15" y2="12" />
//                 <line x1="9" y1="16" x2="15" y2="16" />
//                 <circle cx="12" cy="20" r="2" />
//                 <path d="M12 18v-1M12 22v-1M10 20h-1M14 20h-1" />
//               </svg>
//             </button>
//             {showAutoPopulate && (
//               <div className="auto-populate-indicator">
//                 Auto-Populate
//               </div>
//             )}
//           </div>
//         </>
//       )}

//       <div className="divider"></div>

//       <div className="tool-group">
//         <button 
//           className={`tool-icon ${viewMode === '3D' ? 'selected' : ''}`} 
//           onClick={onToggleViewMode}
//           title={viewMode === '2D' ? 'Switch to 3D View' : 'Switch to 2D View'}
//         >
//           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M12,2 L22,8 L12,14 L2,8 Z" />
//             <path d="M12,14 L12,22" />
//             <path d="M22,8 L22,16 L12,22 L2,16 L2,8" />
//           </svg>
//         </button>
//         <div className="view-mode-label">
//           {viewMode} View
//         </div>
//       </div>
//     </div>
//   );
// };

// export default TopBar;


import React, { useState, useRef } from 'react';

interface TopBarProps {
  selectedTool: string | null;
  onToolSelect: (toolId: string | null) => void;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo: boolean;
  canRedo: boolean;
  showDimensions: boolean;
  onToggleDimensions: () => void;
  scale: number;
  onScaleChange: (metersPerPixel: number) => void;
  unit: 'meters' | 'centimeters' | 'feet' | 'inches' | 'yards';
  onUnitChange: (unit: TopBarProps['unit']) => void;
  zoomLevel: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetZoom: () => void;
  viewMode: '2D' | '3D';
  onToggleViewMode: () => void;
  showAutoPopulate?: boolean;
  onToggleAutoPopulate?: () => void;
  onSaveLayout?: () => void;
  onLoadLayout?: (file: File) => void;
  isPanMode?: boolean;
  onTogglePanMode?: () => void;
  snapAngle: number; // New prop for snap angle
  onSnapAngleChange: (angle: number) => void; // New prop for handling snap angle change
}

const TopBar: React.FC<TopBarProps> = ({ 
  selectedTool, 
  onToolSelect, 
  onUndo, 
  onRedo, 
  canUndo, 
  canRedo,
  showDimensions,
  onToggleDimensions,
  scale,
  onScaleChange,
  unit,
  onUnitChange,
  zoomLevel,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  viewMode,
  onToggleViewMode,
  showAutoPopulate,
  onToggleAutoPopulate,
  onSaveLayout,
  onLoadLayout,
  isPanMode = false,
  onTogglePanMode,
  snapAngle = 45, // Default to 45 degrees
  onSnapAngleChange
}) => {
  const [showScaleInput, setShowScaleInput] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const tools = [
    { id: 'line', name: 'Line', icon: 'M3,3 L21,21' },
    { id: 'rectangle', name: 'Rectangle', icon: 'M4,4 H20 V20 H4 Z' },
    { id: 'circle', name: 'Circle', icon: 'M12,12 m-8,0 a8,8 0 1,0 16,0 a8,8 0 1,0 -16,0' },
    { id: 'pencil', name: 'Pencil', icon: 'M3,17.25 L3,21 L6.75,21 L17.81,9.94 L14.06,6.19 L3,17.25 Z M20.71,7.04 C21.1,6.65 21.1,6.02 20.71,5.63 L18.37,3.29 C17.98,2.9 17.35,2.9 16.96,3.29 L15.13,5.12 L18.88,8.87 L20.71,7.04 Z' },
    { id: 'text', name: 'Text', icon: 'M5,3 H19 V7 H16 V19 H8 V7 H5 V3 Z' }
  ];

  // Units configuration with conversion factors (relative to meters)
  const units = [
    { id: 'meters', label: 'Meters', abbr: 'm', toMeters: 1 },
    { id: 'centimeters', label: 'Centimeters', abbr: 'cm', toMeters: 0.01 },
    { id: 'feet', label: 'Feet', abbr: 'ft', toMeters: 0.3048 },
    { id: 'inches', label: 'Inches', abbr: 'in', toMeters: 0.0254 },
    { id: 'yards', label: 'Yards', abbr: 'yd', toMeters: 0.9144 }
  ];
  
  // Find the current unit object
  const currentUnit = units.find(u => u.id === unit) || units[0];

  const handleScaleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value > 0) {
      // Convert the input scale (in current unit per pixel) to meters per pixel
      const metersPerPixel = value * currentUnit.toMeters;
      onScaleChange(metersPerPixel);
    }
  };

  // Calculate display value for the current unit
  const displayScale = scale / currentUnit.toMeters;
  
  // Calculate pixels per unit for display
  const pixelsPerUnit = 1 / displayScale;

  // Handle file selection for loading layout
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onLoadLayout) {
      onLoadLayout(file);
    }
    // Reset file input so the same file can be selected again
    if (e.target) {
      e.target.value = '';
    }
  };

  // Handle AutoPopulate toggle - turn off pan mode if needed
  const handleToggleAutoPopulate = () => {
    // If pan mode is active and we're turning on AutoPopulate, turn off pan mode first
    if (isPanMode && !showAutoPopulate && onTogglePanMode) {
      onTogglePanMode();
    }
    
    // Then toggle AutoPopulate
    if (onToggleAutoPopulate) {
      onToggleAutoPopulate();
    }
  };

  // Handle snap angle toggle
  const handleToggleSnapAngle = () => {
    // Toggle between 1 and 45 degrees
    const newAngle = snapAngle === 45 ? 1 : 45;
    onSnapAngleChange(newAngle);
  };

  return (
    <div className="top-bar">
      <div className="tool-group">
        {tools.map((tool) => (
          <button
            key={tool.id}
            className={`tool-icon ${selectedTool === tool.id ? 'selected' : ''}`}
            onClick={() => onToolSelect(tool.id)}
            title={tool.name}
            disabled={viewMode === '3D' || isPanMode || showAutoPopulate} // Disable drawing tools in 3D mode, pan mode, or when AutoPopulate is active
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d={tool.icon} />
            </svg>
          </button>
        ))}
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className="tool-icon" 
          onClick={onUndo} 
          disabled={!canUndo || viewMode === '3D' || isPanMode || showAutoPopulate} // Disable in 3D mode, pan mode, or when AutoPopulate is active
          title="Undo"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3,10 C3,10 7,5 12,5 C17,5 21,10 21,10" />
            <path d="M3,10 L8,10 L8,5" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onRedo} 
          disabled={!canRedo || viewMode === '3D' || isPanMode || showAutoPopulate} // Disable in 3D mode, pan mode, or when AutoPopulate is active
          title="Redo"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21,10 C21,10 17,5 12,5 C7,5 3,10 3,10" />
            <path d="M21,10 L16,10 L16,5" />
          </svg>
        </button>
      </div>

      <div className="divider"></div>

      {/* Save/Load buttons */}
      {onSaveLayout && onLoadLayout && (
        <>
          <div className="tool-group">
            <button 
              className="tool-icon" 
              onClick={onSaveLayout}
              title="Save Layout"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                <polyline points="7 3 7 8 15 8"></polyline>
              </svg>
            </button>
            <button 
              className="tool-icon" 
              onClick={() => fileInputRef.current?.click()}
              title="Load Layout"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
            </button>
            {/* Hidden file input */}
            <input
              type="file"
              ref={fileInputRef}
              style={{ display: 'none' }}
              accept=".json"
              onChange={handleFileChange}
            />
          </div>
          <div className="divider"></div>
        </>
      )}

      {/* Pan Mode Toggle - disabled when AutoPopulate is active */}
      {onTogglePanMode && viewMode === '2D' && (
        <>
          <div className="tool-group">
            <button
              className={`tool-icon ${isPanMode ? 'selected' : ''}`}
              onClick={onTogglePanMode}
              title={isPanMode ? "Exit Pan Mode" : "Enter Pan Mode"}
              disabled={viewMode === '3D' || showAutoPopulate} // Disable in 3D mode or when AutoPopulate is active
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M13,11 L22,11 M13,11 L13,2 M11,13 L2,13 M11,13 L11,22 M13,13 L22,22 M13,13 L22,13 M11,11 L2,2 M11,11 L2,11" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            </button>
            {isPanMode && !showAutoPopulate && (
              <div className="pan-mode-indicator">
                Pan Mode
              </div>
            )}
          </div>
          <div className="divider"></div>
        </>
      )}

      {/* Snap Angle Toggle */}
      <div className="tool-group">
        <button
          className={`tool-icon ${snapAngle === 1 ? 'selected' : ''}`}
          onClick={handleToggleSnapAngle}
          title={`Angle Snap: ${snapAngle}°`}
          disabled={viewMode === '3D' || isPanMode || showAutoPopulate} // Disable in 3D mode, pan mode, or when AutoPopulate is active
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {snapAngle === 45 ? (
              // 45-degree angle icon
              <>
                <path d="M4,20 L20,4" />
                <path d="M4,20 L4,14" />
                <path d="M4,20 L10,20" />
                <text x="14" y="10" fontSize="8" fill="currentColor">45°</text>
              </>
            ) : (
              // 1-degree angle icon (more precise)
              <>
                <path d="M4,19 L20,16" />
                <path d="M4,19 L4,14" />
                <path d="M4,19 L9,19" />
                <text x="14" y="14" fontSize="8" fill="currentColor">1°</text>
              </>
            )}
          </svg>
        </button>
        <div className="snap-angle-indicator">
          {snapAngle}° Snap
        </div>
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className={`tool-icon ${showDimensions ? 'selected' : ''}`} 
          onClick={onToggleDimensions}
          title="Toggle Dimensions"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3,6 H21" />
            <path d="M3,6 L3,3" />
            <path d="M21,6 L21,3" />
            <path d="M12,3 L12,21" />
            <path d="M12,21 L9,21" />
            <path d="M12,21 L15,21" />
          </svg>
        </button>
        
        <div className="scale-control">
          <button 
            className="tool-icon" 
            onClick={() => setShowScaleInput(!showScaleInput)}
            title="Scale Settings"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3,6 H21" />
              <path d="M3,12 H21" />
              <path d="M3,18 H21" />
            </svg>
          </button>
          
          {showScaleInput && (
            <div className="scale-popup">
              <label>
                Unit:
                <select 
                  value={unit} 
                  onChange={(e) => onUnitChange(e.target.value as TopBarProps['unit'])}
                  className="unit-select"
                >
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.label}</option>
                  ))}
                </select>
              </label>
              <label>
                Scale ({currentUnit.abbr}):
                <input
                  type="number"
                  value={displayScale.toFixed(6)}
                  onChange={handleScaleChange}
                  step={currentUnit.id === 'meters' ? 0.001 : 0.01}
                  min={currentUnit.id === 'meters' ? 0.001 : 0.01}
                  max={currentUnit.id === 'meters' ? 0.1 : 10}
                />
              </label>
              <div className="scale-info">
                1 {currentUnit.abbr} = {Math.round(pixelsPerUnit)} pixels
              </div>
              <div className="scale-info">
                100 pixels = {(100 * scale / currentUnit.toMeters).toFixed(2)} {currentUnit.abbr}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className="tool-icon" 
          onClick={onZoomIn}
          title="Zoom In"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="16" />
            <line x1="8" y1="12" x2="16" y2="12" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onZoomOut}
          title="Zoom Out"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="8" y1="12" x2="16" y2="12" />
          </svg>
        </button>
        <button 
          className="tool-icon" 
          onClick={onResetZoom}
          title="Reset Zoom"
          disabled={viewMode === '3D'} // Disable in 3D mode
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <path d="M8,12 L16,12" />
            <path d="M12,8 L12,16" />
          </svg>
        </button>
        {viewMode === '2D' && (
          <div className="zoom-level">
            {Math.round(zoomLevel * 100)}%
          </div>
        )}
      </div>

      {/* Auto-Populate button */}
      {onToggleAutoPopulate && (
        <>
          <div className="divider"></div>
          <div className="tool-group">  
            <button
              onClick={handleToggleAutoPopulate}
              title={showAutoPopulate ? "Hide Auto‑Populate" : "Show Auto‑Populate"}
              className={`tool-icon ${showAutoPopulate ? "selected" : ""}`}
              disabled={viewMode === '3D'} // Disable in 3D mode
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"> 
                <rect x="3" y="4" width="6" height="16" rx="1" />
                <rect x="15" y="4" width="6" height="16" rx="1" />
                <line x1="9" y1="8" x2="15" y2="8" />
                <line x1="9" y1="12" x2="15" y2="12" />
                <line x1="9" y1="16" x2="15" y2="16" />
                <circle cx="12" cy="20" r="2" />
                <path d="M12 18v-1M12 22v-1M10 20h-1M14 20h-1" />
              </svg>
            </button>
            {showAutoPopulate && (
              <div className="auto-populate-indicator">
                Auto-Populate
              </div>
            )}
          </div>
        </>
      )}

      <div className="divider"></div>

      <div className="tool-group">
        <button 
          className={`tool-icon ${viewMode === '3D' ? 'selected' : ''}`} 
          onClick={onToggleViewMode}
          title={viewMode === '2D' ? 'Switch to 3D View' : 'Switch to 2D View'}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12,2 L22,8 L12,14 L2,8 Z" />
            <path d="M12,14 L12,22" />
            <path d="M22,8 L22,16 L12,22 L2,16 L2,8" />
          </svg>
        </button>
        <div className="view-mode-label">
          {viewMode} View
        </div>
      </div>
    </div>
  );
};

export default TopBar;