// import React from 'react';

// const DimensionSettings = ({ showDimensions, scale, onToggleDimensions, onScaleChange }) => {
//   const handleScaleChange = (e) => {
//     const newScale = parseFloat(e.target.value);
//     if (!isNaN(newScale) && newScale > 0) {
//       onScaleChange(newScale);
//     }
//   };

//   return (
//     <div className="dimension-settings">
//       <h3 className="settings-title">Dimensions</h3>
      
//       <div className="setting-row">
//         <label className="setting-label">
//           <input
//             type="checkbox"
//             checked={showDimensions}
//             onChange={onToggleDimensions}
//           />
//           Show Dimensions
//         </label>
//       </div>
      
//       <div className="setting-row">
//         <label className="setting-label">
//           Scale (meters/pixel):
//           <input
//             type="number"
//             value={scale}
//             onChange={handleScaleChange}
//             step="0.001"
//             min="0.001"
//             max="0.1"
//             className="scale-input"
//           />
//         </label>
//       </div>
      
//       <div className="setting-info">
//         1 meter = {Math.round(1 / scale)} pixels
//       </div>
//     </div>
//   );
// };

// export default DimensionSettings;

import React, { useState } from 'react';

const DimensionSettings = ({ showDimensions, scale, onToggleDimensions, onScaleChange, unit, onUnitChange }) => {
  // Units configuration with conversion factors (relative to meters)
  const units = [
    { id: 'meters', label: 'Meters', abbr: 'm', toMeters: 1 },
    { id: 'centimeters', label: 'Centimeters', abbr: 'cm', toMeters: 0.01 },
    { id: 'feet', label: 'Feet', abbr: 'ft', toMeters: 0.3048 },
    { id: 'inches', label: 'Inches', abbr: 'in', toMeters: 0.0254 },
    { id: 'yards', label: 'Yards', abbr: 'yd', toMeters: 0.9144 }
  ];
  
  // Find the current unit object
  const currentUnit = units.find(u => u.id === unit) || units[0];
  
  const handleScaleChange = (e) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value > 0) {
      // Convert the input scale (in current unit per pixel) to meters per pixel
      const metersPerPixel = value * currentUnit.toMeters;
      onScaleChange(metersPerPixel);
    }
  };
  
  const handleUnitChange = (e) => {
    const newUnitId = e.target.value;
    onUnitChange(newUnitId);
  };
  
  // Calculate display value for the current unit
  const displayScale = scale / currentUnit.toMeters;
  
  // Calculate pixels per unit for display
  const pixelsPerUnit = 1 / displayScale;

  return (
    <div className="dimension-settings">
      <h3 className="settings-title">Dimensions</h3>
      
      <div className="setting-row">
        <label className="setting-label">
          <input
            type="checkbox"
            checked={showDimensions}
            onChange={onToggleDimensions}
          />
          Show Dimensions
        </label>
      </div>
      
      <div className="setting-row">
        <label className="setting-label">
          Unit:
          <select 
            value={unit} 
            onChange={handleUnitChange}
            className="unit-select"
          >
            {units.map(u => (
              <option key={u.id} value={u.id}>{u.label}</option>
            ))}
          </select>
        </label>
      </div>
      
      <div className="setting-row">
        <label className="setting-label">
          Scale ({currentUnit.label}):
          <input
            type="number"
            value={displayScale.toFixed(6)}
            onChange={handleScaleChange}
            step={currentUnit.id === 'meters' ? 0.001 : 0.01}
            min={currentUnit.id === 'meters' ? 0.001 : 0.01}
            max={currentUnit.id === 'meters' ? 0.1 : 10}
            className="scale-input"
          />
        </label>
      </div>
      
      <div className="setting-info">
        1 {currentUnit.abbr} = {Math.round(pixelsPerUnit)} pixels
      </div>
      
      <div className="setting-info">
        100 pixels = {(100 * scale / currentUnit.toMeters).toFixed(2)} {currentUnit.abbr}
      </div>
    </div>
  );
};

export default DimensionSettings;