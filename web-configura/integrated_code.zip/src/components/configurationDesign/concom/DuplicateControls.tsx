

// import React, { useState } from 'react';
// import { Group, Rect, Text, Line, Circle } from 'react-konva';

// const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
//   const [isDragging, setIsDragging] = useState(false);
//   const [dragDirection, setDragDirection] = useState(null);
//   const [dragStartPoint, setDragStartPoint] = useState({ x: 0, y: 0 });
//   const [dragCurrentPoint, setDragCurrentPoint] = useState({ x: 0, y: 0 });
  
//   // Calculate button size and positions based on shape dimensions and zoom level
//   const buttonSize = 20 / zoomLevel;
//   const buttonOffset = 10 / zoomLevel;
  
//   // Get shape dimensions - account for transformations
//   let width, height, x, y;
  
//   if (shape.type === 'circle') {
//     // For circles, use the actual radius which may have been transformed
//     width = shape.radius * 2;
//     height = shape.radius * 2;
//     x = shape.x - shape.radius;
//     y = shape.y - shape.radius;
//   } else if (shape.type === 'line') {
//     const points = shape.points;
//     const minX = Math.min(points[0], points[2]);
//     const maxX = Math.max(points[0], points[2]);
//     const minY = Math.min(points[1], points[3]);
//     const maxY = Math.max(points[1], points[3]);
//     width = maxX - minX;
//     height = maxY - minY;
//     x = minX;
//     y = minY;
//   } else if (shape.type === 'pillar') {
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   } else {
//     // For rectangles and other shapes, use the actual width/height
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   }
  
//   // Apply rotation if needed
//   const rotation = shape.rotation || 0;
  
//   // Button positions - now with 8 directions
//   const buttons = [
//     // Cardinal directions (N, E, S, W)
//     {
//       direction: 'n',
//       x: x + width / 2 - buttonSize / 2,
//       y: y - buttonSize - buttonOffset,
//       label: '↑'
//     },
//     {
//       direction: 'e',
//       x: x + width + buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '→'
//     },
//     {
//       direction: 's',
//       x: x + width / 2 - buttonSize / 2,
//       y: y + height + buttonOffset,
//       label: '↓'
//     },
//     {
//       direction: 'w',
//       x: x - buttonSize - buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '←'
//     },
//     // Diagonal directions (NE, SE, SW, NW)
//     {
//       direction: 'ne',
//       x: x + width + buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↗'
//     },
//     {
//       direction: 'se',
//       x: x + width + buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↘'
//     },
//     {
//       direction: 'sw',
//       x: x - buttonSize - buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↙'
//     },
//     {
//       direction: 'nw',
//       x: x - buttonSize - buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↖'
//     }
//   ];
  
//   const handleDragStart = (direction, e) => {
//     e.cancelBubble = true; // Stop event propagation
//     setIsDragging(true);
//     setDragDirection(direction);
//     setDragStartPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   const handleDragMove = (e) => {
//     if (!isDragging) return;
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   // Constants for warehouse layout
//   const ITEMS_PER_ROW = 2; // Number of items per row in vertical layout
//   const AISLE_GAP = 1; // Gap multiplier for aisles (in terms of spacingY)
  
//   const handleDragEnd = (e) => {
//     if (!isDragging || !dragDirection) return;
    
//     // Calculate distance and direction
//     const endPoint = { x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y };
    
//     // Calculate the distance based on direction
//     const dx = (endPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (endPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create copies
//     if (copiesX > 0 || copiesY > 0) {
//       const duplicates = [];
      
//       // Helper function to add a duplicate with specific offsets
//       const addDuplicate = (offsetX, offsetY) => {
//         // Skip the original position (0,0)
//         if (offsetX === 0 && offsetY === 0) return;
        
//         // Create a deep copy of the shape to ensure all properties are duplicated
//         const shapeCopy = JSON.parse(JSON.stringify(shape));
        
//         duplicates.push({
//           shape: shapeCopy,
//           offsetX,
//           offsetY
//         });
//       };
      
//       // Determine direction signs
//       const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//       const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
      
//       // For cardinal directions (N, E, S, W)
//       if (dragDirection === 'n' || dragDirection === 's') {
//         // Duplicate vertically with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
//       } else if (dragDirection === 'e' || dragDirection === 'w') {
//         // Duplicate horizontally only
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
//       } else {
//         // For diagonal directions (NE, SE, SW, NW)
//         // Horizontal row
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
        
//         // Vertical column with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
        
//         // Diagonal grid with warehouse layout
//         for (let x = 1; x <= copiesX; x++) {
//           for (let i = 0; i < copiesY; i++) {
//             // Calculate row and position within row
//             const row = Math.floor(i / ITEMS_PER_ROW);
//             const posInRow = i % ITEMS_PER_ROW;
            
//             // Calculate Y position with aisles
//             const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
            
//             // Add the duplicate
//             addDuplicate(signX * spacingX * x, yPos);
//           }
//         }
//       }
      
//       // Call onDuplicate with all copies
//       if (duplicates.length > 0) {
//         onDuplicate(duplicates);
//       }
//     }
    
//     // Reset state
//     setIsDragging(false);
//     setDragDirection(null);
//   };
  
//   // Render preview of duplicates while dragging
//   const renderDuplicatePreviews = () => {
//     if (!isDragging || !dragDirection) return null;
    
//     // Calculate the distance based on direction
//     const dx = (dragCurrentPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (dragCurrentPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create preview elements
//     const previews = [];
    
//     // Determine direction signs
//     const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//     const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
    
//     // Helper function to add a preview at specific offsets
//     const addPreview = (offsetX, offsetY, index) => {
//       // Skip the original position (0,0)
//       if (offsetX === 0 && offsetY === 0) return;
      
//       // Add preview based on shape type
//       if (shape.type === 'circle') {
//         previews.push(
//           <Circle
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             radius={shape.radius}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else if (shape.type === 'line') {
//         const points = shape.points.map((p, idx) => {
//           if (idx % 2 === 0) return p + offsetX;
//           return p + offsetY;
//         });
        
//         previews.push(
//           <Line
//             key={`preview-${index}`}
//             points={points}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else {
//         previews.push(
//           <Rect
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             rotation={shape.rotation || 0}
//             opacity={0.5}
//           />
//         );
//       }
//     };
    
//     // Generate previews based on direction
//     let previewIndex = 0;
    
//     // For cardinal directions (N, E, S, W)
//     if (dragDirection === 'n' || dragDirection === 's') {
//       // Preview vertically with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
//     } else if (dragDirection === 'e' || dragDirection === 'w') {
//       // Preview horizontally only
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
//     } else {
//       // For diagonal directions (NE, SE, SW, NW), preview in a grid pattern
//       // Horizontal row
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
      
//       // Vertical column with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
      
//       // Diagonal grid with warehouse layout
//       for (let x = 1; x <= copiesX; x++) {
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the preview
//           addPreview(signX * spacingX * x, yPos, previewIndex++);
//         }
//       }
//     }
    
//     // Add aisle indicators (optional)
//     if ((dragDirection === 'n' || dragDirection === 's' || 
//          dragDirection === 'ne' || dragDirection === 'se' || 
//          dragDirection === 'sw' || dragDirection === 'nw') && copiesY > ITEMS_PER_ROW) {
      
//       const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
      
//       for (let row = 0; row < rows - 1; row++) {
//         // Calculate Y position of the aisle
//         const aisleY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
//                                row * spacingY * AISLE_GAP);
        
//         // Add aisle indicator
//         previews.push(
//           <Rect
//             key={`aisle-${row}`}
//             x={shape.x - spacingX / 2}
//             y={shape.y + aisleY}
//             width={copiesX > 0 ? (copiesX + 1) * spacingX : spacingX * 2}
//             height={spacingY * AISLE_GAP}
//             fill="rgba(200, 200, 200, 0.2)"
//             stroke="rgba(150, 150, 150, 0.5)"
//             strokeWidth={1 / zoomLevel}
//             opacity={0.3}
//             dash={[5 / zoomLevel, 5 / zoomLevel]}
//           />
//         );
//       }
//     }
    
//     return previews;
//   };
  
//   // Render drag line
//   const renderDragLine = () => {
//     if (!isDragging) return null;
    
//     return (
//       <Line
//         points={[dragStartPoint.x, dragStartPoint.y, dragCurrentPoint.x, dragCurrentPoint.y]}
//         stroke="#3498db"
//         strokeWidth={2 / zoomLevel}
//         dash={[5 / zoomLevel, 5 / zoomLevel]}
//       />
//     );
//   };
  
//   return (
//     <Group>
//       {/* Duplicate buttons */}
//       {buttons.map((button) => (
//         <Group 
//           key={button.direction}
//           x={button.x}
//           y={button.y}
//           draggable
//           onDragStart={(e) => handleDragStart(button.direction, e)}
//           onDragMove={handleDragMove}
//           onDragEnd={handleDragEnd}
//         >
//           <Rect
//             width={buttonSize}
//             height={buttonSize}
//             fill="#4a90e2"
//             cornerRadius={4 / zoomLevel}
//             shadowColor="black"
//             shadowBlur={3 / zoomLevel}
//             shadowOpacity={0.3}
//             shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
//           />
//           <Text
//             text={button.label}
//             width={buttonSize}
//             height={buttonSize}
//             align="center"
//             verticalAlign="middle"
//             fill="white"
//             fontSize={12 / zoomLevel}
//           />
//         </Group>
//       ))}
      
//       {/* Drag line */}
//       {renderDragLine()}
      
//       {/* Duplicate previews */}
//       {renderDuplicatePreviews()}
//     </Group>
//   );
// };

// export default DuplicateControls;



// import React, { useState } from 'react';
// import { Group, Rect, Text, Line, Circle } from 'react-konva';

// const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
//   const [isDragging, setIsDragging] = useState(false);
//   const [dragDirection, setDragDirection] = useState(null);
//   const [dragStartPoint, setDragStartPoint] = useState({ x: 0, y: 0 });
//   const [dragCurrentPoint, setDragCurrentPoint] = useState({ x: 0, y: 0 });
  
//   // Calculate button size and positions based on shape dimensions and zoom level
//   const buttonSize = 20 / zoomLevel;
//   const buttonOffset = 10 / zoomLevel;
  
//   // Get shape dimensions - account for transformations
//   let width, height, x, y;
  
//   if (shape.type === 'circle') {
//     // For circles, use the actual radius which may have been transformed
//     width = shape.radius * 2;
//     height = shape.radius * 2;
//     x = shape.x - shape.radius;
//     y = shape.y - shape.radius;
//   } else if (shape.type === 'line') {
//     const points = shape.points;
//     const minX = Math.min(points[0], points[2]);
//     const maxX = Math.max(points[0], points[2]);
//     const minY = Math.min(points[1], points[3]);
//     const maxY = Math.max(points[1], points[3]);
//     width = maxX - minX;
//     height = maxY - minY;
//     x = minX;
//     y = minY;
//   } else if (shape.type === 'pillar') {
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   } else {
//     // For rectangles and other shapes, use the actual width/height
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   }
  
//   // Apply rotation if needed
//   const rotation = shape.rotation || 0;
  
//   // Button positions - now with 8 directions
//   const buttons = [
//     // Cardinal directions (N, E, S, W)
//     {
//       direction: 'n',
//       x: x + width / 2 - buttonSize / 2,
//       y: y - buttonSize - buttonOffset,
//       label: '↑'
//     },
//     {
//       direction: 'e',
//       x: x + width + buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '→'
//     },
//     {
//       direction: 's',
//       x: x + width / 2 - buttonSize / 2,
//       y: y + height + buttonOffset,
//       label: '↓'
//     },
//     {
//       direction: 'w',
//       x: x - buttonSize - buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '←'
//     },
//     // Diagonal directions (NE, SE, SW, NW)
//     {
//       direction: 'ne',
//       x: x + width + buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↗'
//     },
//     {
//       direction: 'se',
//       x: x + width + buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↘'
//     },
//     {
//       direction: 'sw',
//       x: x - buttonSize - buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↙'
//     },
//     {
//       direction: 'nw',
//       x: x - buttonSize - buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↖'
//     }
//   ];
  
//   const handleDragStart = (direction, e) => {
//     e.cancelBubble = true; // Stop event propagation
//     setIsDragging(true);
//     setDragDirection(direction);
//     setDragStartPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   const handleDragMove = (e) => {
//     if (!isDragging) return;
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   // Constants for warehouse layout
//   const ITEMS_PER_ROW = 2; // Number of items per row in vertical layout
//   const AISLE_GAP = 2; // Gap multiplier for aisles (in terms of spacingY)
  
//   const handleDragEnd = (e) => {
//     if (!isDragging || !dragDirection) return;
    
//     // Calculate distance and direction
//     const endPoint = { x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y };
    
//     // Calculate the distance based on direction
//     const dx = (endPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (endPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create copies
//     if (copiesX > 0 || copiesY > 0) {
//       const duplicates = [];
      
//       // Helper function to add a duplicate with specific offsets
//       const addDuplicate = (offsetX, offsetY) => {
//         // Skip the original position (0,0)
//         if (offsetX === 0 && offsetY === 0) return;
        
//         // Create a deep copy of the shape to ensure all properties are duplicated
//         const shapeCopy = JSON.parse(JSON.stringify(shape));
        
//         duplicates.push({
//           shape: shapeCopy,
//           offsetX,
//           offsetY
//         });
//       };
      
//       // Determine direction signs
//       const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//       const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
      
//       // For cardinal directions (N, E, S, W)
//       if (dragDirection === 'n' || dragDirection === 's') {
//         // Duplicate vertically with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
//       } else if (dragDirection === 'e' || dragDirection === 'w') {
//         // Duplicate horizontally only
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
//       } else {
//         // For diagonal directions (NE, SE, SW, NW)
//         // Horizontal row
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
        
//         // Vertical column with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
        
//         // Diagonal grid with warehouse layout
//         for (let x = 1; x <= copiesX; x++) {
//           for (let i = 0; i < copiesY; i++) {
//             // Calculate row and position within row
//             const row = Math.floor(i / ITEMS_PER_ROW);
//             const posInRow = i % ITEMS_PER_ROW;
            
//             // Calculate Y position with aisles
//             const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
            
//             // Add the duplicate
//             addDuplicate(signX * spacingX * x, yPos);
//           }
//         }
//       }
      
//       // Call onDuplicate with all copies
//       if (duplicates.length > 0) {
//         onDuplicate(duplicates);
//       }
//     }
    
//     // Reset state
//     setIsDragging(false);
//     setDragDirection(null);
//   };
  
//   // Render preview of duplicates while dragging
//   const renderDuplicatePreviews = () => {
//     if (!isDragging || !dragDirection) return null;
    
//     // Calculate the distance based on direction
//     const dx = (dragCurrentPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (dragCurrentPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create preview elements
//     const previews = [];
    
//     // Determine direction signs
//     const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//     const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
    
//     // Helper function to add a preview at specific offsets
//     const addPreview = (offsetX, offsetY, index) => {
//       // Skip the original position (0,0)
//       if (offsetX === 0 && offsetY === 0) return;
      
//       // Add preview based on shape type
//       if (shape.type === 'circle') {
//         previews.push(
//           <Circle
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             radius={shape.radius}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else if (shape.type === 'line') {
//         const points = shape.points.map((p, idx) => {
//           if (idx % 2 === 0) return p + offsetX;
//           return p + offsetY;
//         });
        
//         previews.push(
//           <Line
//             key={`preview-${index}`}
//             points={points}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else {
//         previews.push(
//           <Rect
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             rotation={shape.rotation || 0}
//             opacity={0.5}
//           />
//         );
//       }
//     };
    
//     // Generate previews based on direction
//     let previewIndex = 0;
    
//     // For cardinal directions (N, E, S, W)
//     if (dragDirection === 'n' || dragDirection === 's') {
//       // Preview vertically with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
//     } else if (dragDirection === 'e' || dragDirection === 'w') {
//       // Preview horizontally only
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
//     } else {
//       // For diagonal directions (NE, SE, SW, NW), preview in a grid pattern
//       // Horizontal row
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
      
//       // Vertical column with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
      
//       // Diagonal grid with warehouse layout
//       for (let x = 1; x <= copiesX; x++) {
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the preview
//           addPreview(signX * spacingX * x, yPos, previewIndex++);
//         }
//       }
//     }
    
//     // Add aisle indicators with enhanced visibility
//     if ((dragDirection === 'n' || dragDirection === 's' || 
//          dragDirection === 'ne' || dragDirection === 'se' || 
//          dragDirection === 'sw' || dragDirection === 'nw') && copiesY > ITEMS_PER_ROW) {
      
//       const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
      
//       for (let row = 0; row < rows - 1; row++) {
//         // Calculate Y position of the aisle
//         const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
//                                    row * spacingY * AISLE_GAP);
//         const aisleHeight = spacingY * AISLE_GAP;
        
//         // Calculate width of the aisle
//         const aisleWidth = copiesX > 0 ? (copiesX + 1) * spacingX : spacingX * 3;
        
//         // Add aisle indicator with enhanced visibility
//         previews.push(
//           <Rect
//             key={`aisle-${row}`}
//             x={shape.x - spacingX}
//             y={shape.y + aisleStartY}
//             width={aisleWidth}
//             height={aisleHeight}
//             fill="rgba(70, 130, 180, 0.3)" // Steel blue with transparency
//             stroke="rgba(70, 130, 180, 0.7)" // Darker steel blue for border
//             strokeWidth={2 / zoomLevel}
//             opacity={0.7}
//           />
//         );
        
//         // Add "WALKING PATH" text label for better visibility
//         previews.push(
//           <Text
//             key={`aisle-text-${row}`}
//             x={shape.x}
//             y={shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel}
//             text="WALKING PATH"
//             fontSize={16 / zoomLevel}
//             fill="#000"
//             width={aisleWidth - spacingX}
//             align="center"
//             opacity={0.8}
//           />
//         );
        
//         // Add directional arrows in the aisle
//         const arrowCount = Math.max(1, Math.floor(aisleWidth / (spacingX * 2)));
//         for (let i = 0; i < arrowCount; i++) {
//           const arrowX = shape.x + (i * aisleWidth / arrowCount) - spacingX / 2;
          
//           previews.push(
//             <Line
//               key={`aisle-arrow-${row}-${i}`}
//               points={[
//                 arrowX, shape.y + aisleStartY + aisleHeight / 2,
//                 arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2
//               ]}
//               stroke="#000"
//               strokeWidth={2 / zoomLevel}
//               opacity={0.8}
//             />
//           );
          
//           // Arrow head
//           previews.push(
//             <Line
//               key={`aisle-arrowhead-${row}-${i}`}
//               points={[
//                 arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel,
//                 arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2,
//                 arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 + 10 / zoomLevel
//               ]}
//               stroke="#000"
//               strokeWidth={2 / zoomLevel}
//               opacity={0.8}
//               closed={false}
//             />
//           );
//         }
//       }
//     }
    
//     return previews;
//   };
  
//   // Render drag line
//   const renderDragLine = () => {
//     if (!isDragging) return null;
    
//     return (
//       <Line
//         points={[dragStartPoint.x, dragStartPoint.y, dragCurrentPoint.x, dragCurrentPoint.y]}
//         stroke="#3498db"
//         strokeWidth={2 / zoomLevel}
//         dash={[5 / zoomLevel, 5 / zoomLevel]}
//       />
//     );
//   };
  
//   return (
//     <Group>
//       {/* Duplicate buttons */}
//       {buttons.map((button) => (
//         <Group 
//           key={button.direction}
//           x={button.x}
//           y={button.y}
//           draggable
//           onDragStart={(e) => handleDragStart(button.direction, e)}
//           onDragMove={handleDragMove}
//           onDragEnd={handleDragEnd}
//         >
//           <Rect
//             width={buttonSize}
//             height={buttonSize}
//             fill="#4a90e2"
//             cornerRadius={4 / zoomLevel}
//             shadowColor="black"
//             shadowBlur={3 / zoomLevel}
//             shadowOpacity={0.3}
//             shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
//           />
//           <Text
//             text={button.label}
//             width={buttonSize}
//             height={buttonSize}
//             align="center"
//             verticalAlign="middle"
//             fill="white"
//             fontSize={12 / zoomLevel}
//           />
//         </Group>
//       ))}
      
//       {/* Drag line */}
//       {renderDragLine()}
      
//       {/* Duplicate previews */}
//       {renderDuplicatePreviews()}
//     </Group>
//   );
// };

// export default DuplicateControls;





// import React, { useState } from 'react';
// import { Group, Rect, Text, Line, Circle } from 'react-konva';

// const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
//   const [isDragging, setIsDragging] = useState(false);
//   const [dragDirection, setDragDirection] = useState(null);
//   const [dragStartPoint, setDragStartPoint] = useState({ x: 0, y: 0 });
//   const [dragCurrentPoint, setDragCurrentPoint] = useState({ x: 0, y: 0 });
  
//   // Calculate button size and positions based on shape dimensions and zoom level
//   const buttonSize = 20 / zoomLevel;
//   const buttonOffset = 10 / zoomLevel;
  
//   // Get shape dimensions - account for transformations
//   let width, height, x, y;
  
//   if (shape.type === 'circle') {
//     // For circles, use the actual radius which may have been transformed
//     width = shape.radius * 2;
//     height = shape.radius * 2;
//     x = shape.x - shape.radius;
//     y = shape.y - shape.radius;
//   } else if (shape.type === 'line') {
//     const points = shape.points;
//     const minX = Math.min(points[0], points[2]);
//     const maxX = Math.max(points[0], points[2]);
//     const minY = Math.min(points[1], points[3]);
//     const maxY = Math.max(points[1], points[3]);
//     width = maxX - minX;
//     height = maxY - minY;
//     x = minX;
//     y = minY;
//   } else if (shape.type === 'pillar') {
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   } else {
//     // For rectangles and other shapes, use the actual width/height
//     width = shape.width;
//     height = shape.height;
//     x = shape.x;
//     y = shape.y;
//   }
  
//   // Apply rotation if needed
//   const rotation = shape.rotation || 0;
  
//   // Button positions - now with 8 directions
//   const buttons = [
//     // Cardinal directions (N, E, S, W)
//     {
//       direction: 'n',
//       x: x + width / 2 - buttonSize / 2,
//       y: y - buttonSize - buttonOffset,
//       label: '↑'
//     },
//     {
//       direction: 'e',
//       x: x + width + buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '→'
//     },
//     {
//       direction: 's',
//       x: x + width / 2 - buttonSize / 2,
//       y: y + height + buttonOffset,
//       label: '↓'
//     },
//     {
//       direction: 'w',
//       x: x - buttonSize - buttonOffset,
//       y: y + height / 2 - buttonSize / 2,
//       label: '←'
//     },
//     // Diagonal directions (NE, SE, SW, NW)
//     {
//       direction: 'ne',
//       x: x + width + buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↗'
//     },
//     {
//       direction: 'se',
//       x: x + width + buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↘'
//     },
//     {
//       direction: 'sw',
//       x: x - buttonSize - buttonOffset,
//       y: y + height + buttonOffset,
//       label: '↙'
//     },
//     {
//       direction: 'nw',
//       x: x - buttonSize - buttonOffset,
//       y: y - buttonSize - buttonOffset,
//       label: '↖'
//     }
//   ];
  
//   const handleDragStart = (direction, e) => {
//     e.cancelBubble = true; // Stop event propagation
//     setIsDragging(true);
//     setDragDirection(direction);
//     setDragStartPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   const handleDragMove = (e) => {
//     if (!isDragging) return;
//     setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
//   };
  
//   // Constants for warehouse layout
//   const ITEMS_PER_ROW = 2; // Number of items per row in vertical layout
//   const AISLE_GAP = 2; // Gap multiplier for aisles (in terms of spacingY)
  
//   const handleDragEnd = (e) => {
//     if (!isDragging || !dragDirection) return;
    
//     // Calculate distance and direction
//     const endPoint = { x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y };
    
//     // Calculate the distance based on direction
//     const dx = (endPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (endPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create copies
//     if (copiesX > 0 || copiesY > 0) {
//       const duplicates = [];
//       const aisles = []; // Array to store aisle shapes
      
//       // Helper function to add a duplicate with specific offsets
//       const addDuplicate = (offsetX, offsetY) => {
//         // Skip the original position (0,0)
//         if (offsetX === 0 && offsetY === 0) return;
        
//         // Create a deep copy of the shape to ensure all properties are duplicated
//         const shapeCopy = JSON.parse(JSON.stringify(shape));
        
//         duplicates.push({
//           shape: shapeCopy,
//           offsetX,
//           offsetY
//         });
//       };
      
//       // Determine direction signs
//       const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//       const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
      
//       // For cardinal directions (N, E, S, W)
//       if (dragDirection === 'n' || dragDirection === 's') {
//         // Duplicate vertically with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
        
//         // Create aisle shapes for vertical layout
//         const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
//         for (let row = 0; row < rows - 1; row++) {
//           // Calculate Y position of the aisle
//           const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
//                                      row * spacingY * AISLE_GAP);
//           const aisleHeight = spacingY * AISLE_GAP;
          
//           // Calculate width of the aisle
//           const aisleWidth = spacingX * 3; // Make aisle wider than a single element
          
//           // Create aisle shape
//           aisles.push({
//             type: 'aisle',
//             x: shape.x - spacingX,
//             y: shape.y + aisleStartY,
//             width: aisleWidth,
//             height: aisleHeight,
//             fill: 'rgba(70, 130, 180, 0.3)', // Steel blue with transparency
//             stroke: 'rgba(70, 130, 180, 0.7)', // Darker steel blue for border
//             strokeWidth: 2,
//             id: Date.now() + Math.random(),
//             label: 'WALKING PATH'
//           });
//         }
//       } else if (dragDirection === 'e' || dragDirection === 'w') {
//         // Duplicate horizontally only
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
//       } else {
//         // For diagonal directions (NE, SE, SW, NW)
//         // Horizontal row
//         for (let x = 1; x <= copiesX; x++) {
//           addDuplicate(signX * spacingX * x, 0);
//         }
        
//         // Vertical column with warehouse layout
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the duplicate
//           addDuplicate(0, yPos);
//         }
        
//         // Create aisle shapes for vertical component of diagonal layout
//         const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
//         for (let row = 0; row < rows - 1; row++) {
//           // Calculate Y position of the aisle
//           const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
//                                      row * spacingY * AISLE_GAP);
//           const aisleHeight = spacingY * AISLE_GAP;
          
//           // Calculate width of the aisle - extend across all horizontal copies
//           const aisleWidth = (copiesX + 1) * spacingX;
          
//           // Create aisle shape
//           aisles.push({
//             type: 'aisle',
//             x: shape.x - spacingX,
//             y: shape.y + aisleStartY,
//             width: aisleWidth,
//             height: aisleHeight,
//             fill: 'rgba(70, 130, 180, 0.3)', // Steel blue with transparency
//             stroke: 'rgba(70, 130, 180, 0.7)', // Darker steel blue for border
//             strokeWidth: 2,
//             id: Date.now() + Math.random(),
//             label: 'WALKING PATH'
//           });
//         }
        
//         // Diagonal grid with warehouse layout
//         for (let x = 1; x <= copiesX; x++) {
//           for (let i = 0; i < copiesY; i++) {
//             // Calculate row and position within row
//             const row = Math.floor(i / ITEMS_PER_ROW);
//             const posInRow = i % ITEMS_PER_ROW;
            
//             // Calculate Y position with aisles
//             const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
            
//             // Add the duplicate
//             addDuplicate(signX * spacingX * x, yPos);
//           }
//         }
//       }
      
//       // Call onDuplicate with all copies and aisles
//       if (duplicates.length > 0 || aisles.length > 0) {
//         // Convert aisles to the same format as duplicates
//         const aisleShapes = aisles.map(aisle => ({
//           shape: aisle,
//           offsetX: 0,
//           offsetY: 0
//         }));
        
//         // Combine duplicates and aisles
//         onDuplicate([...duplicates, ...aisleShapes]);
//       }
//     }
    
//     // Reset state
//     setIsDragging(false);
//     setDragDirection(null);
//   };
  
//   // Render preview of duplicates while dragging
//   const renderDuplicatePreviews = () => {
//     if (!isDragging || !dragDirection) return null;
    
//     // Calculate the distance based on direction
//     const dx = (dragCurrentPoint.x - dragStartPoint.x) / zoomLevel;
//     const dy = (dragCurrentPoint.y - dragStartPoint.y) / zoomLevel;
    
//     // Calculate spacing between elements (10% extra space)
//     const spacingX = width * 1.1;
//     const spacingY = height * 1.1;
    
//     // Calculate how many copies can fit in each direction
//     let copiesX = 0;
//     let copiesY = 0;
    
//     // Determine copies based on direction
//     switch (dragDirection) {
//       case 'n':
//       case 's':
//         // For vertical directions, calculate total distance including aisles
//         // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
//         const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
//         break;
//       case 'e':
//       case 'w':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         break;
//       case 'ne':
//       case 'se':
//       case 'sw':
//       case 'nw':
//         copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
//         // For diagonal with vertical component, use warehouse layout
//         const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
//         copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
//         break;
//       default:
//         break;
//     }
    
//     // Create preview elements
//     const previews = [];
    
//     // Determine direction signs
//     const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
//     const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
    
//     // Helper function to add a preview at specific offsets
//     const addPreview = (offsetX, offsetY, index) => {
//       // Skip the original position (0,0)
//       if (offsetX === 0 && offsetY === 0) return;
      
//       // Add preview based on shape type
//       if (shape.type === 'circle') {
//         previews.push(
//           <Circle
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             radius={shape.radius}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else if (shape.type === 'line') {
//         const points = shape.points.map((p, idx) => {
//           if (idx % 2 === 0) return p + offsetX;
//           return p + offsetY;
//         });
        
//         previews.push(
//           <Line
//             key={`preview-${index}`}
//             points={points}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             opacity={0.5}
//           />
//         );
//       } else {
//         previews.push(
//           <Rect
//             key={`preview-${index}`}
//             x={shape.x + offsetX}
//             y={shape.y + offsetY}
//             width={shape.width}
//             height={shape.height}
//             fill={shape.fill}
//             stroke={shape.stroke}
//             strokeWidth={shape.strokeWidth}
//             rotation={shape.rotation || 0}
//             opacity={0.5}
//           />
//         );
//       }
//     };
    
//     // Generate previews based on direction
//     let previewIndex = 0;
    
//     // For cardinal directions (N, E, S, W)
//     if (dragDirection === 'n' || dragDirection === 's') {
//       // Preview vertically with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
//     } else if (dragDirection === 'e' || dragDirection === 'w') {
//       // Preview horizontally only
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
//     } else {
//       // For diagonal directions (NE, SE, SW, NW), preview in a grid pattern
//       // Horizontal row
//       for (let x = 1; x <= copiesX; x++) {
//         addPreview(signX * spacingX * x, 0, previewIndex++);
//       }
      
//       // Vertical column with warehouse layout
//       for (let i = 0; i < copiesY; i++) {
//         // Calculate row and position within row
//         const row = Math.floor(i / ITEMS_PER_ROW);
//         const posInRow = i % ITEMS_PER_ROW;
        
//         // Calculate Y position with aisles
//         const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
//         // Add the preview
//         addPreview(0, yPos, previewIndex++);
//       }
      
//       // Diagonal grid with warehouse layout
//       for (let x = 1; x <= copiesX; x++) {
//         for (let i = 0; i < copiesY; i++) {
//           // Calculate row and position within row
//           const row = Math.floor(i / ITEMS_PER_ROW);
//           const posInRow = i % ITEMS_PER_ROW;
          
//           // Calculate Y position with aisles
//           const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
//           // Add the preview
//           addPreview(signX * spacingX * x, yPos, previewIndex++);
//         }
//       }
//     }
    
//     // Add aisle indicators with enhanced visibility
//     if ((dragDirection === 'n' || dragDirection === 's' || 
//          dragDirection === 'ne' || dragDirection === 'se' || 
//          dragDirection === 'sw' || dragDirection === 'nw') && copiesY > ITEMS_PER_ROW) {
      
//       const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
      
//       for (let row = 0; row < rows - 1; row++) {
//         // Calculate Y position of the aisle
//         const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
//                                    row * spacingY * AISLE_GAP);
//         const aisleHeight = spacingY * AISLE_GAP;
        
//         // Calculate width of the aisle
//         const aisleWidth = copiesX > 0 ? (copiesX + 1) * spacingX : spacingX * 3;
        
//         // Add aisle indicator with enhanced visibility
//         previews.push(
//           <Rect
//             key={`aisle-${row}`}
//             x={shape.x - spacingX}
//             y={shape.y + aisleStartY}
//             width={aisleWidth}
//             height={aisleHeight}
//             fill="rgba(70, 130, 180, 0.3)" // Steel blue with transparency
//             stroke="rgba(70, 130, 180, 0.7)" // Darker steel blue for border
//             strokeWidth={2 / zoomLevel}
//             opacity={0.7}
//           />
//         );
        
//         // Add "WALKING PATH" text label for better visibility
//         previews.push(
//           <Text
//             key={`aisle-text-${row}`}
//             x={shape.x}
//             y={shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel}
//             text="WALKING PATH"
//             fontSize={16 / zoomLevel}
//             fill="#000"
//             width={aisleWidth - spacingX}
//             align="center"
//             opacity={0.8}
//           />
//         );
        
//         // Add directional arrows in the aisle
//         const arrowCount = Math.max(1, Math.floor(aisleWidth / (spacingX * 2)));
//         for (let i = 0; i < arrowCount; i++) {
//           const arrowX = shape.x + (i * aisleWidth / arrowCount) - spacingX / 2;
          
//           previews.push(
//             <Line
//               key={`aisle-arrow-${row}-${i}`}
//               points={[
//                 arrowX, shape.y + aisleStartY + aisleHeight / 2,
//                 arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2
//               ]}
//               stroke="#000"
//               strokeWidth={2 / zoomLevel}
//               opacity={0.8}
//             />
//           );
          
//           // Arrow head
//           previews.push(
//             <Line
//               key={`aisle-arrowhead-${row}-${i}`}
//               points={[
//                 arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel,
//                 arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2,
//                 arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 + 10 / zoomLevel
//               ]}
//               stroke="#000"
//               strokeWidth={2 / zoomLevel}
//               opacity={0.8}
//               closed={false}
//             />
//           );
//         }
//       }
//     }
    
//     return previews;
//   };
  
//   // Render drag line
//   const renderDragLine = () => {
//     if (!isDragging) return null;
    
//     return (
//       <Line
//         points={[dragStartPoint.x, dragStartPoint.y, dragCurrentPoint.x, dragCurrentPoint.y]}
//         stroke="#3498db"
//         strokeWidth={2 / zoomLevel}
//         dash={[5 / zoomLevel, 5 / zoomLevel]}
//       />
//     );
//   };
  
//   return (
//     <Group>
//       {/* Duplicate buttons */}
//       {buttons.map((button) => (
//         <Group 
//           key={button.direction}
//           x={button.x}
//           y={button.y}
//           draggable
//           onDragStart={(e) => handleDragStart(button.direction, e)}
//           onDragMove={handleDragMove}
//           onDragEnd={handleDragEnd}
//         >
//           <Rect
//             width={buttonSize}
//             height={buttonSize}
//             fill="#4a90e2"
//             cornerRadius={4 / zoomLevel}
//             shadowColor="black"
//             shadowBlur={3 / zoomLevel}
//             shadowOpacity={0.3}
//             shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
//           />
//           <Text
//             text={button.label}
//             width={buttonSize}
//             height={buttonSize}
//             align="center"
//             verticalAlign="middle"
//             fill="white"
//             fontSize={12 / zoomLevel}
//           />
//         </Group>
//       ))}
      
//       {/* Drag line */}
//       {renderDragLine()}
      
//       {/* Duplicate previews */}
//       {renderDuplicatePreviews()}
//     </Group>
//   );
// };

// export default DuplicateControls;


import React, { useState } from 'react';
import { Group, Rect, Text, Line, Circle } from 'react-konva';

const DuplicateControls = ({ shape, onDuplicate, zoomLevel }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragDirection, setDragDirection] = useState(null);
  const [dragStartPoint, setDragStartPoint] = useState({ x: 0, y: 0 });
  const [dragCurrentPoint, setDragCurrentPoint] = useState({ x: 0, y: 0 });
  
  // Calculate button size and positions based on shape dimensions and zoom level
  const buttonSize = 20 / zoomLevel;
  const buttonOffset = 10 / zoomLevel;
  
  // Get shape dimensions - account for transformations
  let width, height, x, y;
  
  if (shape.type === 'circle') {
    // For circles, use the actual radius which may have been transformed
    width = shape.radius * 2;
    height = shape.radius * 2;
    x = shape.x - shape.radius;
    y = shape.y - shape.radius;
  } else if (shape.type === 'line') {
    const points = shape.points;
    const minX = Math.min(points[0], points[2]);
    const maxX = Math.max(points[0], points[2]);
    const minY = Math.min(points[1], points[3]);
    const maxY = Math.max(points[1], points[3]);
    width = maxX - minX;
    height = maxY - minY;
    x = minX;
    y = minY;
  } else if (shape.type === 'pillar') {
    width = shape.width;
    height = shape.height;
    x = shape.x;
    y = shape.y;
  } else {
    // For rectangles and other shapes, use the actual width/height
    width = shape.width;
    height = shape.height;
    x = shape.x;
    y = shape.y;
  }
  
  // Apply rotation if needed
  const rotation = shape.rotation || 0;
  
  // Button positions - now with 8 directions
  const buttons = [
    // Cardinal directions (N, E, S, W)
    {
      direction: 'n',
      x: x + width / 2 - buttonSize / 2,
      y: y - buttonSize - buttonOffset,
      label: '↑'
    },
    {
      direction: 'e',
      x: x + width + buttonOffset,
      y: y + height / 2 - buttonSize / 2,
      label: '→'
    },
    {
      direction: 's',
      x: x + width / 2 - buttonSize / 2,
      y: y + height + buttonOffset,
      label: '↓'
    },
    {
      direction: 'w',
      x: x - buttonSize - buttonOffset,
      y: y + height / 2 - buttonSize / 2,
      label: '←'
    },
    // Diagonal directions (NE, SE, SW, NW)
    {
      direction: 'ne',
      x: x + width + buttonOffset,
      y: y - buttonSize - buttonOffset,
      label: '↗'
    },
    {
      direction: 'se',
      x: x + width + buttonOffset,
      y: y + height + buttonOffset,
      label: '↘'
    },
    {
      direction: 'sw',
      x: x - buttonSize - buttonOffset,
      y: y + height + buttonOffset,
      label: '↙'
    },
    {
      direction: 'nw',
      x: x - buttonSize - buttonOffset,
      y: y - buttonSize - buttonOffset,
      label: '↖'
    }
  ];
  
  const handleDragStart = (direction, e) => {
    e.cancelBubble = true; // Stop event propagation
    setIsDragging(true);
    setDragDirection(direction);
    setDragStartPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
    setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
  };
  
  const handleDragMove = (e) => {
    if (!isDragging) return;
    setDragCurrentPoint({ x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y });
  };
  
  // Constants for warehouse layout
  const ITEMS_PER_ROW = 2; // Number of items per row in vertical layout
  const AISLE_GAP = 2; // Gap multiplier for aisles (in terms of spacingY)
  
  const handleDragEnd = (e) => {
    if (!isDragging || !dragDirection) return;
    
    // Calculate distance and direction
    const endPoint = { x: e.target.getStage().getPointerPosition().x, y: e.target.getStage().getPointerPosition().y };
    
    // Calculate the distance based on direction
    const dx = (endPoint.x - dragStartPoint.x) / zoomLevel;
    const dy = (endPoint.y - dragStartPoint.y) / zoomLevel;
    
    // Calculate spacing between elements (10% extra space)
    const spacingX = width * 1.1;
    const spacingY = height * 1.1;
    
    // Calculate how many copies can fit in each direction
    let copiesX = 0;
    let copiesY = 0;
    
    // Determine copies based on direction
    switch (dragDirection) {
      case 'n':
      case 's':
        // For vertical directions, calculate total distance including aisles
        // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
        const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
        copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
        break;
      case 'e':
      case 'w':
        copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
        break;
      case 'ne':
      case 'se':
      case 'sw':
      case 'nw':
        copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
        // For diagonal with vertical component, use warehouse layout
        const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
        copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
        break;
      default:
        break;
    }
    
    // Create copies
    if (copiesX > 0 || copiesY > 0) {
      const duplicates = [];
      const aisles = []; // Array to store aisle shapes
      
      // Helper function to add a duplicate with specific offsets
      const addDuplicate = (offsetX, offsetY) => {
        // Skip the original position (0,0)
        if (offsetX === 0 && offsetY === 0) return;
        
        // Create a deep copy of the shape to ensure all properties are duplicated
        const shapeCopy = JSON.parse(JSON.stringify(shape));
        
        duplicates.push({
          shape: shapeCopy,
          offsetX,
          offsetY
        });
      };
      
      // Determine direction signs
      const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
      const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
      
      // For cardinal directions (N, E, S, W)
      if (dragDirection === 'n' || dragDirection === 's') {
        // Duplicate vertically with warehouse layout
        for (let i = 0; i < copiesY; i++) {
          // Calculate row and position within row
          const row = Math.floor(i / ITEMS_PER_ROW);
          const posInRow = i % ITEMS_PER_ROW;
          
          // Calculate Y position with aisles
          const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
          // Add the duplicate
          addDuplicate(0, yPos);
        }
        
        // Create aisle shapes for vertical layout
        const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
        for (let row = 0; row < rows - 1; row++) {
          // Calculate Y position of the aisle
          const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
                                     row * spacingY * AISLE_GAP);
          const aisleHeight = spacingY * AISLE_GAP;
          
          // Calculate width of the aisle - FIXED: Use the element width instead of arbitrary width
          const aisleWidth = width; // Just use the element width
          
          // Create aisle shape - FIXED: Properly align with the element
          aisles.push({
            type: 'aisle',
            x: shape.x, // Align with the element's x position
            y: shape.y + aisleStartY,
            width: aisleWidth,
            height: aisleHeight,
            fill: 'rgba(70, 130, 180, 0.3)', // Steel blue with transparency
            stroke: 'rgba(70, 130, 180, 0.7)', // Darker steel blue for border
            strokeWidth: 2,
            id: Date.now() + Math.random(),
            label: 'WALKING PATH'
          });
        }
      } else if (dragDirection === 'e' || dragDirection === 'w') {
        // Duplicate horizontally only
        for (let x = 1; x <= copiesX; x++) {
          addDuplicate(signX * spacingX * x, 0);
        }
      } else {
        // For diagonal directions (NE, SE, SW, NW)
        // Horizontal row
        for (let x = 1; x <= copiesX; x++) {
          addDuplicate(signX * spacingX * x, 0);
        }
        
        // Vertical column with warehouse layout
        for (let i = 0; i < copiesY; i++) {
          // Calculate row and position within row
          const row = Math.floor(i / ITEMS_PER_ROW);
          const posInRow = i % ITEMS_PER_ROW;
          
          // Calculate Y position with aisles
          const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
          // Add the duplicate
          addDuplicate(0, yPos);
        }
        
        // Create aisle shapes for vertical component of diagonal layout
        const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
        for (let row = 0; row < rows - 1; row++) {
          // Calculate Y position of the aisle
          const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
                                     row * spacingY * AISLE_GAP);
          const aisleHeight = spacingY * AISLE_GAP;
          
          // Calculate width of the aisle - FIXED: Calculate based on actual elements
          const aisleWidth = (copiesX + 1) * spacingX;
          
          // Create aisle shape - FIXED: Properly align with the elements
          aisles.push({
            type: 'aisle',
            x: shape.x, // Align with the element's x position
            y: shape.y + aisleStartY,
            width: aisleWidth,
            height: aisleHeight,
            fill: 'rgba(70, 130, 180, 0.3)', // Steel blue with transparency
            stroke: 'rgba(70, 130, 180, 0.7)', // Darker steel blue for border
            strokeWidth: 2,
            id: Date.now() + Math.random(),
            label: 'WALKING PATH'
          });
        }
        
        // Diagonal grid with warehouse layout
        for (let x = 1; x <= copiesX; x++) {
          for (let i = 0; i < copiesY; i++) {
            // Calculate row and position within row
            const row = Math.floor(i / ITEMS_PER_ROW);
            const posInRow = i % ITEMS_PER_ROW;
            
            // Calculate Y position with aisles
            const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
            
            // Add the duplicate
            addDuplicate(signX * spacingX * x, yPos);
          }
        }
      }
      
      // Call onDuplicate with all copies and aisles
      if (duplicates.length > 0 || aisles.length > 0) {
        // Convert aisles to the same format as duplicates
        const aisleShapes = aisles.map(aisle => ({
          shape: aisle,
          offsetX: 0,
          offsetY: 0
        }));
        
        // Combine duplicates and aisles
        onDuplicate([...duplicates, ...aisleShapes]);
      }
    }
    
    // Reset state
    setIsDragging(false);
    setDragDirection(null);
  };
  
  // Render preview of duplicates while dragging
  const renderDuplicatePreviews = () => {
    if (!isDragging || !dragDirection) return null;
    
    // Calculate the distance based on direction
    const dx = (dragCurrentPoint.x - dragStartPoint.x) / zoomLevel;
    const dy = (dragCurrentPoint.y - dragStartPoint.y) / zoomLevel;
    
    // Calculate spacing between elements (10% extra space)
    const spacingX = width * 1.1;
    const spacingY = height * 1.1;
    
    // Calculate how many copies can fit in each direction
    let copiesX = 0;
    let copiesY = 0;
    
    // Determine copies based on direction
    switch (dragDirection) {
      case 'n':
      case 's':
        // For vertical directions, calculate total distance including aisles
        // Every ITEMS_PER_ROW items, we add an extra AISLE_GAP * spacingY
        const totalSpacingY = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
        copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingY) * ITEMS_PER_ROW);
        break;
      case 'e':
      case 'w':
        copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
        break;
      case 'ne':
      case 'se':
      case 'sw':
      case 'nw':
        copiesX = Math.max(1, Math.floor(Math.abs(dx) / spacingX));
        // For diagonal with vertical component, use warehouse layout
        const totalSpacingYDiag = spacingY * (1 + AISLE_GAP / ITEMS_PER_ROW);
        copiesY = Math.max(1, Math.floor(Math.abs(dy) / totalSpacingYDiag) * ITEMS_PER_ROW);
        break;
      default:
        break;
    }
    
    // Create preview elements
    const previews = [];
    
    // Determine direction signs
    const signX = dragDirection.includes('e') ? 1 : dragDirection.includes('w') ? -1 : 0;
    const signY = dragDirection.includes('s') ? 1 : dragDirection.includes('n') ? -1 : 0;
    
    // Helper function to add a preview at specific offsets
    const addPreview = (offsetX, offsetY, index) => {
      // Skip the original position (0,0)
      if (offsetX === 0 && offsetY === 0) return;
      
      // Add preview based on shape type
      if (shape.type === 'circle') {
        previews.push(
          <Circle
            key={`preview-${index}`}
            x={shape.x + offsetX}
            y={shape.y + offsetY}
            radius={shape.radius}
            fill={shape.fill}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            opacity={0.5}
          />
        );
      } else if (shape.type === 'line') {
        const points = shape.points.map((p, idx) => {
          if (idx % 2 === 0) return p + offsetX;
          return p + offsetY;
        });
        
        previews.push(
          <Line
            key={`preview-${index}`}
            points={points}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            opacity={0.5}
          />
        );
      } else {
        previews.push(
          <Rect
            key={`preview-${index}`}
            x={shape.x + offsetX}
            y={shape.y + offsetY}
            width={shape.width}
            height={shape.height}
            fill={shape.fill}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            rotation={shape.rotation || 0}
            opacity={0.5}
          />
        );
      }
    };
    
    // Generate previews based on direction
    let previewIndex = 0;
    
    // For cardinal directions (N, E, S, W)
    if (dragDirection === 'n' || dragDirection === 's') {
      // Preview vertically with warehouse layout
      for (let i = 0; i < copiesY; i++) {
        // Calculate row and position within row
        const row = Math.floor(i / ITEMS_PER_ROW);
        const posInRow = i % ITEMS_PER_ROW;
        
        // Calculate Y position with aisles
        const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
        // Add the preview
        addPreview(0, yPos, previewIndex++);
      }
    } else if (dragDirection === 'e' || dragDirection === 'w') {
      // Preview horizontally only
      for (let x = 1; x <= copiesX; x++) {
        addPreview(signX * spacingX * x, 0, previewIndex++);
      }
    } else {
      // For diagonal directions (NE, SE, SW, NW), preview in a grid pattern
      // Horizontal row
      for (let x = 1; x <= copiesX; x++) {
        addPreview(signX * spacingX * x, 0, previewIndex++);
      }
      
      // Vertical column with warehouse layout
      for (let i = 0; i < copiesY; i++) {
        // Calculate row and position within row
        const row = Math.floor(i / ITEMS_PER_ROW);
        const posInRow = i % ITEMS_PER_ROW;
        
        // Calculate Y position with aisles
        const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
        
        // Add the preview
        addPreview(0, yPos, previewIndex++);
      }
      
      // Diagonal grid with warehouse layout
      for (let x = 1; x <= copiesX; x++) {
        for (let i = 0; i < copiesY; i++) {
          // Calculate row and position within row
          const row = Math.floor(i / ITEMS_PER_ROW);
          const posInRow = i % ITEMS_PER_ROW;
          
          // Calculate Y position with aisles
          const yPos = signY * ((row * spacingY * (ITEMS_PER_ROW + AISLE_GAP)) + (posInRow * spacingY));
          
          // Add the preview
          addPreview(signX * spacingX * x, yPos, previewIndex++);
        }
      }
    }
    
    // Add aisle indicators with enhanced visibility
    if ((dragDirection === 'n' || dragDirection === 's' || 
         dragDirection === 'ne' || dragDirection === 'se' || 
         dragDirection === 'sw' || dragDirection === 'nw') && copiesY > ITEMS_PER_ROW) {
      
      const rows = Math.ceil(copiesY / ITEMS_PER_ROW);
      
      for (let row = 0; row < rows - 1; row++) {
        // Calculate Y position of the aisle
        const aisleStartY = signY * ((row + 1) * spacingY * ITEMS_PER_ROW + 
                                   row * spacingY * AISLE_GAP);
        const aisleHeight = spacingY * AISLE_GAP;
        
        // FIXED: Calculate width based on the actual element width
        // For vertical directions, use the element width
        // For diagonal directions, calculate based on how many elements in the row
        const aisleWidth = (dragDirection === 'n' || dragDirection === 's') 
          ? width  // Just use the element width for vertical directions
          : (copiesX + 1) * spacingX; // Use calculated width for diagonal directions
        
        // FIXED: Properly align with the element
        previews.push(
          <Rect
            key={`aisle-${row}`}
            x={shape.x} // Align with the element's x position
            y={shape.y + aisleStartY}
            width={aisleWidth}
            height={aisleHeight}
            fill="rgba(70, 130, 180, 0.3)" // Steel blue with transparency
            stroke="rgba(70, 130, 180, 0.7)" // Darker steel blue for border
            strokeWidth={2 / zoomLevel}
            opacity={0.7}
          />
        );
        
        // Add "WALKING PATH" text label for better visibility
        previews.push(
          <Text
            key={`aisle-text-${row}`}
            x={shape.x + aisleWidth / 2 - 50} // Center the text
            y={shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel}
            text="WALKING PATH"
            fontSize={16 / zoomLevel}
            fill="#000"
            width={100}
            align="center"
            opacity={0.8}
          />
        );
        
        // Add directional arrows in the aisle
        const arrowCount = Math.max(1, Math.floor(aisleWidth / (spacingX * 2)));
        for (let i = 0; i < arrowCount; i++) {
          const arrowX = shape.x + (i * aisleWidth / arrowCount) + spacingX / 2;
          
          previews.push(
            <Line
              key={`aisle-arrow-${row}-${i}`}
              points={[
                arrowX, shape.y + aisleStartY + aisleHeight / 2,
                arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2
              ]}
              stroke="#000"
              strokeWidth={2 / zoomLevel}
              opacity={0.8}
            />
          );
          
          // Arrow head
          previews.push(
            <Line
              key={`aisle-arrowhead-${row}-${i}`}
              points={[
                arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 - 10 / zoomLevel,
                arrowX + spacingX / 2, shape.y + aisleStartY + aisleHeight / 2,
                arrowX + spacingX / 3, shape.y + aisleStartY + aisleHeight / 2 + 10 / zoomLevel
              ]}
              stroke="#000"
              strokeWidth={2 / zoomLevel}
              opacity={0.8}
              closed={false}
            />
          );
        }
      }
    }
    
    return previews;
  };
  
  // Render drag line
  const renderDragLine = () => {
    if (!isDragging) return null;
    
    return (
      <Line
        points={[dragStartPoint.x, dragStartPoint.y, dragCurrentPoint.x, dragCurrentPoint.y]}
        stroke="#3498db"
        strokeWidth={2 / zoomLevel}
        dash={[5 / zoomLevel, 5 / zoomLevel]}
      />
    );
  };
  
  return (
    <Group>
      {/* Duplicate buttons */}
      {buttons.map((button) => (
        <Group 
          key={button.direction}
          x={button.x}
          y={button.y}
          draggable
          onDragStart={(e) => handleDragStart(button.direction, e)}
          onDragMove={handleDragMove}
          onDragEnd={handleDragEnd}
        >
          <Rect
            width={buttonSize}
            height={buttonSize}
            fill="#4a90e2"
            cornerRadius={4 / zoomLevel}
            shadowColor="black"
            shadowBlur={3 / zoomLevel}
            shadowOpacity={0.3}
            shadowOffset={{ x: 1 / zoomLevel, y: 1 / zoomLevel }}
          />
          <Text
            text={button.label}
            width={buttonSize}
            height={buttonSize}
            align="center"
            verticalAlign="middle"
            fill="white"
            fontSize={12 / zoomLevel}
          />
        </Group>
      ))}
      
      {/* Drag line */}
      {renderDragLine()}
      
      {/* Duplicate previews */}
      {renderDuplicatePreviews()}
    </Group>
  );
};

export default DuplicateControls;