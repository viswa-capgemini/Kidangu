
// import React, { useState, useCallback, useRef, useEffect } from 'react';
// import Canvas from './concom/Canvas';
// import TopBar from './concom/TopBar';
// import ElementsPanel from './concom/ElementsPanel';
// import LayoutLeftPanel from './LayoutLeftPanel';
// import PropertiesPanel from './concom/PropertiesPanel';
// import ThreeJsView from './concom/ThreeJsView';
// // AutoPopulatePanel intentionally not imported here to keep the right sidebar empty when active
// import './Test.css';

// interface Shape {
//   id: string | number;
//   type: string;
//   x?: number;
//   y?: number;
//   width?: number;
//   height?: number;
//   points?: number[];
//   radius?: number;
//   stroke?: string;
//   strokeWidth?: number;
//   fill?: string;
//   rotation?: 0 | 90 | 180 | 270;
//   locked?: boolean;
//   groupId?: string;
//   dash?: number[];
//   sectionId?: string;
//   label?: string;
//   [key: string]: any; // For additional properties
// }

// interface RackSection {
//   id: string;
//   boundary: { x: number; y: number; width: number; height: number };
//   rackIds: string[];
// }

// function ConfigurationLayout() {
//   // Tool and shape state
//   const [selectedTool, setSelectedTool] = useState<string | null>(null);
//   const [shapes, setShapes] = useState<Shape[]>([]);
//   const [selectedShape, setSelectedShape] = useState<Shape | null>(null);
//   const [isDraggingElement, setIsDraggingElement] = useState<boolean>(false);
//   const [dragElement, setDragElement] = useState<any>(null);
  
//   // Multi-select and grouping state
//   const [isMultiSelectMode, setIsMultiSelectMode] = useState<boolean>(false);
//   const [selectedShapes, setSelectedShapes] = useState<Shape[]>([]);
//   const [groups, setGroups] = useState<any[]>([]);
  
//   // Radial menu state
//   const [showRadialMenu, setShowRadialMenu] = useState<boolean>(false);
  
//   // History state for undo/redo
//   const [history, setHistory] = useState<Shape[][]>([]);
//   const [historyIndex, setHistoryIndex] = useState<number>(-1);
  
//   // Dimension settings
//   const [showDimensions, setShowDimensions] = useState<boolean>(true);
//   const [scale, setScale] = useState<number>(0.01); // 1 pixel = 0.01 meters (1cm)
//   const [unit, setUnit] = useState<string>('meters'); // Default unit is meters
  
//   // Zoom settings
//   const [zoomLevel, setZoomLevel] = useState<number>(1);
  
//   // View mode (2D or 3D)
//   const [viewMode, setViewMode] = useState<'2D' | '3D'>('2D');
  
//   // Auto populate panel
//   const [showAutoPopulatePanel, setShowAutoPopulatePanel] = useState<boolean>(false);
//   const [autoPopulateMode, setAutoPopulateMode] = useState<'selection' | 'obstruction' | null>(null);
//   const stageRef = useRef<any>(null);
  
//   // Pan mode state
//   const [isPanMode, setIsPanMode] = useState<boolean>(false);
  
//   // Rack sections management
//   const [rackSections, setRackSections] = useState<RackSection[]>([]);
//   const [currentSectionId, setCurrentSectionId] = useState<string | null>(null);
//   const [rackSelectionRect, setRackSelectionRect] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
//   const [rackObstructions, setRackObstructions] = useState<{ id: string; x: number; y: number; width: number; height: number }[]>([]);

//   // Add CSS for drag and drop
//   useEffect(() => {
//     // Create a style element
//     const styleElement = document.createElement('style');
//     styleElement.textContent = `
//       .dragging {
//         cursor: grabbing !important;
//       }
      
//       .canvas-container {
//         position: relative;
//       }
      
//       .canvas-container.drag-over {
//         outline: 2px dashed #3498db;
//       }
      
//       .element-item {
//         cursor: grab;
//         user-select: none;
//         transition: transform 0.2s, box-shadow 0.2s;
//       }
      
//       .element-item:hover {
//         transform: translateY(-2px);
//         box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
//       }
      
//       .element-item:active {
//         cursor: grabbing;
//         transform: translateY(0);
//       }
      
//       .sidebar {
//         /* Remove transitions for now */
//       }
      
//       .auto-populate-panel {
//         /* Remove transitions for now */
//       }
//     `;
    
//     // Add the style element to the document head
//     document.head.appendChild(styleElement);
    
//     // Clean up function
//     return () => {
//       document.head.removeChild(styleElement);
//     };
//   }, []);

//   // Handle drag end events (including cancelled drags)
//   useEffect(() => {
//     const handleDragEnd = () => {
//       if (isDraggingElement) {
//         setIsDraggingElement(false);
//         setDragElement(null);
//         document.body.classList.remove('dragging');
//         document.body.style.cursor = '';
//       }
//     };
    
//     // Handle drag end events
//     document.addEventListener('dragend', handleDragEnd);
    
//     // Handle cases where drag is cancelled without firing dragend
//     const handleKeyDown = (e: KeyboardEvent) => {
//       if (e.key === 'Escape' && isDraggingElement) {
//         handleDragEnd();
//       }
//     };
    
//     document.addEventListener('keydown', handleKeyDown);
    
//     // Handle mouse up outside the window
//     const handleMouseUp = () => {
//       if (isDraggingElement) {
//         handleDragEnd();
//       }
//     };
    
//     window.addEventListener('mouseup', handleMouseUp);
    
//     return () => {
//       document.removeEventListener('dragend', handleDragEnd);
//       document.removeEventListener('keydown', handleKeyDown);
//       window.removeEventListener('mouseup', handleMouseUp);
//       document.body.classList.remove('dragging');
//       document.body.style.cursor = '';
//     };
//   }, [isDraggingElement]);

//   const handleToolSelect = (tool: string) => {
//     // If selecting the same tool, toggle it off
//     if (tool === selectedTool) {
//       setSelectedTool(null);
//     } else {
//       setSelectedTool(tool);
//       // Deselect shape when selecting a tool
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   };

//   const handleAddShape = useCallback((newShapes: Shape[]) => {
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleElementDragStart = (element: any) => {
//     setIsDraggingElement(true);
//     setDragElement(element);
//     setSelectedTool(null); // Deselect any active drawing tool
//     setSelectedShape(null); // Deselect any selected shape
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
    
//     // Add a class to the body to indicate dragging
//     document.body.classList.add('dragging');
    
//     // Set cursor style for the entire document during drag
//     document.body.style.cursor = 'grabbing';
//   };

//   const handleElementDrop = useCallback((element: any, position: {x: number, y: number}) => {
//     setIsDraggingElement(false);
//     setDragElement(null);
    
//     // Remove the dragging class
//     document.body.classList.remove('dragging');
    
//     // Reset cursor style
//     document.body.style.cursor = '';
    
//     // Create a new shape based on the dropped element
//     const newElement = {
//       ...element,
//       x: position.x,
//       y: position.y,
//       id: Date.now(),
//     };
    
//     // Add section ID to rack elements
//     if (element.type === 'rack' && currentSectionId) {
//       newElement.sectionId = currentSectionId;
//     }
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     setShapes([...shapes, newElement]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex, currentSectionId]);

//   const handleShapeSelect = useCallback((shape: Shape | null, isShiftKey?: boolean) => {
//     // Deselect tool when selecting a shape
//     setSelectedTool(null);
    
//     if (isShiftKey) {
//       // Enable multi-select mode
//       setIsMultiSelectMode(true);
      
//       if (shape) {
//         // Check if shape is already selected
//         const isAlreadySelected = selectedShapes.some(s => s.id === shape.id);
        
//         if (isAlreadySelected) {
//           // Remove from selection
//           setSelectedShapes(selectedShapes.filter(s => s.id !== shape.id));
//         } else {
//           // Add to selection
//           setSelectedShapes([...selectedShapes, shape]);
//         }
//       }
      
//       // Clear single selection
//       setSelectedShape(null);
//     } else {
//       // Single selection mode
//       setIsMultiSelectMode(false);
//       setSelectedShapes([]);
//       setSelectedShape(shape);
//     }
//   }, [selectedShapes]);

//   //handle pan mode toggle
//   const handleTogglePanMode = useCallback(() => {
//     setIsPanMode(prev => !prev);
//     // When entering pan mode, deselect any tools and shapes
//     if (!isPanMode) {
//       setSelectedTool(null);
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [isPanMode]);

//   // Group shapes function
//   const handleGroupShapes = useCallback((shapesToGroup: Shape[]) => {
//     if (shapesToGroup.length < 2) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Create a unique ID for the group
//     const groupId = `group_${Date.now()}`;
    
//     // Update shapes with the group ID
//     const updatedShapes = shapes.map(shape => 
//       shapesToGroup.some(s => s.id === shape.id) ? { ...shape, groupId } : shape
//     );
    
//     setShapes(updatedShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Clear selection
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
    
//     // Select one of the shapes in the group
//     if (shapesToGroup.length > 0) {
//       const updatedShape = updatedShapes.find(s => s.id === shapesToGroup[0].id);
//       if (updatedShape) {
//         setSelectedShape(updatedShape);
//       }
//     }
//   }, [shapes, history, historyIndex]);

//   // Ungroup shapes function
//   const handleUngroupShapes = useCallback((groupId: string) => {
//     if (!groupId) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Remove the group ID from all shapes in the group
//     const updatedShapes = shapes.map(shape => 
//       shape.groupId === groupId ? { ...shape, groupId: undefined } : shape
//     );
    
//     setShapes(updatedShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Clear selection
//     setSelectedShape(null);
//   }, [shapes, history, historyIndex]);

//   const handleUpdateGroups = useCallback((updatedGroups: any[]) => {
//     setGroups(updatedGroups);
//   }, []);

//   const handleUpdateShape = useCallback((updatedShape: Shape) => {
//     // Check if the shape should be deleted
//     if (updatedShape._delete) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Filter out the shape to be deleted
//       const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
      
//       // If it's a rack, also update the section
//       if (updatedShape.type === 'rack' && updatedShape.sectionId) {
//         const sectionId = updatedShape.sectionId;
//         const section = rackSections.find(s => s.id === sectionId);
        
//         if (section) {
//           const updatedSection = {
//             ...section,
//             rackIds: section.rackIds.filter(id => id !== updatedShape.id)
//           };
          
//           setRackSections(prev => 
//             prev.map(s => s.id === sectionId ? updatedSection : s)
//               .filter(s => s.rackIds.length > 0) // Remove empty sections
//           );
//         }
//       }
      
//       setShapes(newShapes);
//       setSelectedShape(null);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
//       return;
//     }
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Update the shape
//     const newShapes = shapes.map(shape => 
//       shape.id === updatedShape.id ? { ...updatedShape } : shape
//     );
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex, rackSections]);

//   const handleDuplicateShape = useCallback((duplicates: Shape | { shape: Shape, offsetX: number, offsetY: number }[]) => {
//     // If it's a single duplicate (for backward compatibility)
//     if (!Array.isArray(duplicates)) {
//       const originalShape = duplicates;
//       const offsetX = arguments[1] || 0;
//       const offsetY = arguments[2] || 0;
      
//       // Create a new shape based on the selected one with the specified offset
//       // Use a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...originalShape,
//         id: Date.now(),
//         x: originalShape.x + offsetX,
//         y: originalShape.y + offsetY
//       }));
      
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Add the duplicated shape to the shapes array
//       const newShapes = [...shapes, duplicatedShape];
//       setShapes(newShapes);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
      
//       // Select the new shape
//       setSelectedShape(duplicatedShape);
//       return;
//     }
    
//     // Handle multiple duplicates
//     if (duplicates.length === 0) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Create all duplicated shapes
//     const newShapes = [...shapes];
//     let lastShape = null;
    
//     duplicates.forEach(({ shape, offsetX, offsetY }) => {
//       // Create a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...shape,
//         id: Date.now() + Math.random(), // Ensure unique ID
//         x: shape.x + offsetX,
//         y: shape.y + offsetY
//       }));
      
//       newShapes.push(duplicatedShape);
//       lastShape = duplicatedShape;
//     });
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Select the last shape created
//     if (lastShape) {
//       setSelectedShape(lastShape);
//     }
//   }, [shapes, history, historyIndex]);

//   const handleUndo = useCallback(() => {
//     if (historyIndex > 0) {
//       setHistoryIndex(historyIndex - 1);
//       setShapes(history[historyIndex - 1]);
//       // Deselect shape when undoing
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [history, historyIndex]);

//   const handleRedo = useCallback(() => {
//     if (historyIndex < history.length - 1) {
//       setHistoryIndex(historyIndex + 1);
//       setShapes(history[historyIndex + 1]);
//       // Deselect shape when redoing
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [history, historyIndex]);

//   const handleToggleDimensions = useCallback(() => {
//     setShowDimensions(!showDimensions);
//   }, [showDimensions]);

//   const handleScaleChange = useCallback((newScale: number) => {
//     setScale(newScale);
//   }, []);

//   const handleUnitChange = useCallback((newUnit: string) => {
//     setUnit(newUnit);
//   }, []);

//   const handleZoomIn = useCallback(() => {
//     setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
//   }, []);

//   const handleZoomOut = useCallback(() => {
//     setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
//   }, []);

//   const handleResetZoom = useCallback(() => {
//     setZoomLevel(1);
//   }, []);

//   const handleToggleViewMode = useCallback(() => {
//     setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
//     // Deselect shape when switching view modes
//     setSelectedShape(null);
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
//   }, []);

//   // Handle auto populate panel
//   // const handleToggleAutoPopulate = useCallback(() => {
//   //   // Toggle the auto populate panel
//   //   const newValue = !showAutoPopulatePanel;
//   //   setShowAutoPopulatePanel(newValue);
    
//   //   // Generate a new section ID only when opening the panel
//   //   if (newValue) {
//   //     const newSectionId = `section-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
//   //     console.log("Generated new section ID:", newSectionId);
//   //     setCurrentSectionId(newSectionId);
//   //   }
//   // }, [showAutoPopulatePanel]);

//   const handleToggleAutoPopulate = useCallback(() => {
//   const newValue = !showAutoPopulatePanel;
//   setShowAutoPopulatePanel(newValue);
  
//   // Only generate a new section ID when opening the panel
//   if (newValue) {
//     const newSectionId = `section-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
//     console.log("Generated new section ID:", newSectionId);
//     setCurrentSectionId(newSectionId);
//   }
// }, [showAutoPopulatePanel]);

//   // Canvas can tell us when it hides itself (eg. Cancel button in the panel)
//   const handleAutoPopulateChange = useCallback((isShowing: boolean) => {
//     // Only update if the value is actually changing to prevent loops
//     if (showAutoPopulatePanel !== isShowing) {
//       setShowAutoPopulatePanel(isShowing);
//     }
//   }, [showAutoPopulatePanel]);

//   // Handle drawing mode changes in AutoPopulatePanel
//   const handleToggleMode = useCallback((mode: 'selection' | 'obstruction' | null) => {
//     setAutoPopulateMode(mode);
//   }, []);

//   // Clear obstructions
//   const clearObstructions = useCallback(() => {
//     setRackObstructions([]);
//   }, []);

//   // Handle generated racks from AutoPopulatePanel
//   const handleGeneratedRacks = useCallback((rackShapes: Shape[]) => {
//     console.log("Adding new racks:", rackShapes.length, "with section ID:", currentSectionId);
    
//     if (!currentSectionId) {
//       console.warn("No current section ID available");
//       return;
//     }
    
//     // Create a new section record if we have a selection rect
//     if (rackSelectionRect && currentSectionId) {
//       // Store rack IDs for this section
//       const rackIds = rackShapes.map(r => r.id.toString());
      
//       // Create or update section
//       const newSection = {
//         id: currentSectionId,
//         boundary: { ...rackSelectionRect },
//         rackIds
//       };
      
//       // Add to sections list (always add as new, never replace)
//       setRackSections(prev => [...prev, newSection]);
//     }
    
//     // Ensure all new racks have the current section ID
//     const racksWithSection = rackShapes.map(rack => ({
//       ...rack,
//       sectionId: currentSectionId
//     }));
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Update the shapes state with the combined array
//     setShapes([...shapes, ...racksWithSection]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, rackSelectionRect, history, historyIndex, currentSectionId]);
  
//   // Clear all racks and boundaries for current section
//   const clearAll = useCallback(() => {
//     // Only clear the selection rectangle and obstructions
//     setRackSelectionRect(null);
//     setRackObstructions([]);
    
//     // Remove racks from current section
//     if (currentSectionId) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Filter out racks from current section
//       const updatedShapes = shapes.filter(shape => 
//         shape.type !== 'rack' || shape.sectionId !== currentSectionId
//       );
      
//       setShapes(updatedShapes);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
      
//       // Remove the section from rackSections
//       setRackSections(prev => prev.filter(section => section.id !== currentSectionId));
//     }
//   }, [shapes, history, historyIndex, currentSectionId]);

//   // Handle selection rect updates from Canvas
//   const handleSelectionRectChange = useCallback((rect: { x: number; y: number; width: number; height: number } | null) => {
//     setRackSelectionRect(rect);
//   }, []);

//   // Handle obstruction updates from Canvas
//   const handleObstructionsChange = useCallback((obstructions: { id: string; x: number; y: number; width: number; height: number }[]) => {
//     setRackObstructions(obstructions);
//   }, []);

//   // Function to save the current layout
//   const handleSaveLayout = useCallback(() => {
//     // Create a layout object with all necessary data
//     const layout = {
//       shapes,
//       scale,
//       unit,
//       rackSections,
//       version: '1.0', // Add version for future compatibility
//     };

//     // Convert to JSON string
//     const jsonString = JSON.stringify(layout, null, 2);
    
//     // Create a blob and download link
//     const blob = new Blob([jsonString], { type: 'application/json' });
//     const url = URL.createObjectURL(blob);
    
//     // Create a temporary anchor element to trigger download
//     const a = document.createElement('a');
//     a.href = url;
//     a.download = `floor-plan-${new Date().toISOString().slice(0, 10)}.json`;
//     document.body.appendChild(a);
//     a.click();
    
//     // Clean up
//     document.body.removeChild(a);
//     URL.revokeObjectURL(url);
//   }, [shapes, scale, unit, rackSections]);

//   // Function to load a layout from file
//   const handleLoadLayout = useCallback((file: File) => {
//     const reader = new FileReader();
    
//     reader.onload = (e) => {
//       try {
//         const layout = JSON.parse(e.target?.result as string);
        
//         // Validate the layout data
//         if (!layout.shapes || !Array.isArray(layout.shapes)) {
//           throw new Error('Invalid layout file: missing shapes array');
//         }
        
//         // Update state with loaded data
//         setShapes(layout.shapes);
//         if (layout.scale) setScale(layout.scale);
//         if (layout.unit) setUnit(layout.unit);
//         if (layout.rackSections && Array.isArray(layout.rackSections)) {
//           setRackSections(layout.rackSections);
//         }
        
//         // Reset history
//         setHistory([layout.shapes]);
//         setHistoryIndex(0);
        
//         // Deselect any selected shape
//         setSelectedShape(null);
//         setSelectedShapes([]);
//         setIsMultiSelectMode(false);
        
//         // Show success message
//         alert('Layout loaded successfully!');
//       } catch (error) {
//         console.error('Error loading layout:', error);
//         alert(`Error loading layout: ${error instanceof Error ? error.message : 'Unknown error'}`);
//       }
//     };
    
//     reader.readAsText(file);
//   }, []);

//   return (
//     <div className="app">
//       <TopBar 
//         selectedTool={selectedTool}
//         onToolSelect={handleToolSelect}
//         onUndo={handleUndo}
//         onRedo={handleRedo}
//         canUndo={historyIndex > 0}
//         canRedo={historyIndex < history.length - 1}
//         showDimensions={showDimensions}
//         onToggleDimensions={handleToggleDimensions}
//         scale={scale}
//         onScaleChange={handleScaleChange}
//         unit={unit as any}
//         onUnitChange={handleUnitChange}
//         zoomLevel={zoomLevel}
//         onZoomIn={handleZoomIn}
//         onZoomOut={handleZoomOut}
//         onResetZoom={handleResetZoom}
//         viewMode={viewMode}
//         onToggleViewMode={handleToggleViewMode}
//         showAutoPopulate={showAutoPopulatePanel}
//         onToggleAutoPopulate={handleToggleAutoPopulate}
//         onSaveLayout={handleSaveLayout}
//         onLoadLayout={handleLoadLayout}
//         isPanMode={isPanMode}
//         onTogglePanMode={handleTogglePanMode}
//       />
//       <div className="main-content">
//         {/* Only show Elements Panel when Auto-Populate Panel is hidden */}
//         {!showAutoPopulatePanel && viewMode === '2D' && (
//           <div className="sidebar left-sidebar">
//             <ElementsPanel onElementDragStart={handleElementDragStart} />
//             <LayoutLeftPanel />
//           </div>
//         )}
        
//         {viewMode === '2D' ? (
//           <Canvas 
//             ref={stageRef}
//             selectedTool={selectedTool} 
//             shapes={shapes} 
//             onAddShape={handleAddShape}
//             isDraggingElement={isDraggingElement}
//             dragElement={dragElement}
//             onElementDrop={handleElementDrop}
//             showDimensions={showDimensions}
//             scale={scale}
//             unit={unit as any}
//             zoomLevel={zoomLevel}
//             onShapeSelect={handleShapeSelect}
//             selectedShape={selectedShape}
//             selectedShapes={selectedShapes}
//             isMultiSelectMode={isMultiSelectMode}
//             onUpdateGroups={handleUpdateGroups}
//             onDuplicateShape={handleDuplicateShape}
//             showRadialMenu={showRadialMenu}
//             setShowRadialMenu={setShowRadialMenu}
//             showAutoPopulate={showAutoPopulatePanel}
//             onAutoPopulateChange={handleAutoPopulateChange}
//             autoPopulateMode={autoPopulateMode}
//             onSelectionRectChange={handleSelectionRectChange}
//             onObstructionsChange={handleObstructionsChange}
//             rackSections={rackSections}
//             currentSectionId={currentSectionId}
//             gridSize={20} // Use consistent grid size
//             isPanMode={isPanMode}
//           />
//         ) : (
//           <ThreeJsView 
//             shapes={shapes}
//             scale={scale}
//             unit={unit as any}
//           />
//         )}
        
//         {/* Right sidebar - only render PropertiesPanel when AutoPopulate is hidden */}
//         {viewMode === '2D' && !showAutoPopulatePanel && (
//           <div className="sidebar right-sidebar">
//             <PropertiesPanel 
//               selectedShape={!isMultiSelectMode ? selectedShape : undefined}
//               selectedShapes={isMultiSelectMode ? selectedShapes : undefined}
//               onUpdateShape={handleUpdateShape}
//               onGroupShapes={handleGroupShapes}
//               onUngroupShapes={handleUngroupShapes}
//             />
//           </div>
//         )}
//       </div>
      
//       {/* Pan Mode Indicator */}
//       {isPanMode && viewMode === '2D' && (
//         <div 
//           className="pan-mode-indicator"
//           style={{
//             position: 'absolute',
//             top: '70px',
//             left: '50%',
//             transform: 'translateX(-50%)',
//             background: 'rgba(0, 0, 0, 0.7)',
//             color: 'white',
//             padding: '8px 16px',
//             borderRadius: '4px',
//             zIndex: 1000,
//             pointerEvents: 'none'
//           }}
//         >
//           <div style={{ textAlign: 'center' }}>
//             Pan Mode Active
//             <br />
//             <small style={{ opacity: 0.8 }}>Click the pan button again to exit</small>
//           </div>
//         </div>
//       )}
      
//       {/* Section indicator */}
//       {currentSectionId && showAutoPopulatePanel && (
//         <div 
//           className="section-indicator" 
//           style={{ 
//             position: 'absolute', 
//             bottom: '10px', 
//             left: '10px', 
//             background: 'rgba(22, 163, 74, 0.9)', 
//             color: 'white', 
//             padding: '5px 10px', 
//             borderRadius: '4px',
//             fontSize: '12px',
//             zIndex: 100
//           }}
//         >
//           Current Section: {currentSectionId.substring(0, 8)}...
//         </div>
//       )}
//     </div>
//   );
// }

// export default ConfigurationLayout;



// import React, { useState, useCallback, useRef, useEffect } from 'react';
// import Canvas from './concom/Canvas';
// import TopBar from './concom/TopBar';
// import ElementsPanel from './concom/ElementsPanel';
// import LayoutLeftPanel from './LayoutLeftPanel';
// import PropertiesPanel from './concom/PropertiesPanel';
// import ThreeJsView from './concom/ThreeJsView';
// import AutoPopulatePanel from './concom/AutoPopulatePanel';
// import './Test.css';

// interface Shape {
//   id: string | number;
//   type: string;
//   x?: number;
//   y?: number;
//   width?: number;
//   height?: number;
//   points?: number[];
//   radius?: number;
//   stroke?: string;
//   strokeWidth?: number;
//   fill?: string;
//   rotation?: 0 | 90 | 180 | 270;
//   locked?: boolean;
//   groupId?: string;
//   dash?: number[];
//   sectionId?: string;
//   label?: string;
//   [key: string]: any; // For additional properties
// }

// interface RackSection {
//   id: string;
//   boundary: { x: number; y: number; width: number; height: number };
//   rackIds: string[];
// }

// function ConfigurationLayout() {
//   // Tool and shape state
//   const [selectedTool, setSelectedTool] = useState<string | null>(null);
//   const [shapes, setShapes] = useState<Shape[]>([]);
//   const [selectedShape, setSelectedShape] = useState<Shape | null>(null);
//   const [isDraggingElement, setIsDraggingElement] = useState<boolean>(false);
//   const [dragElement, setDragElement] = useState<any>(null);
//   const [dragOffset, setDragOffset] = useState<{ offsetX: number; offsetY: number } | undefined>(undefined);
  
//   // Multi-select and grouping state
//   const [isMultiSelectMode, setIsMultiSelectMode] = useState<boolean>(false);
//   const [selectedShapes, setSelectedShapes] = useState<Shape[]>([]);
//   const [groups, setGroups] = useState<any[]>([]);
  
//   // Radial menu state
//   const [showRadialMenu, setShowRadialMenu] = useState<boolean>(false);
  
//   // History state for undo/redo
//   const [history, setHistory] = useState<Shape[][]>([]);
//   const [historyIndex, setHistoryIndex] = useState<number>(-1);
  
//   // Dimension settings
//   const [showDimensions, setShowDimensions] = useState<boolean>(true);
//   const [scale, setScale] = useState<number>(0.01); // 1 pixel = 0.01 meters (1cm)
//   const [unit, setUnit] = useState<'meters' | 'centimeters' | 'feet' | 'inches' | 'yards'>('meters');
  
//   // Zoom settings
//   const [zoomLevel, setZoomLevel] = useState<number>(1);
  
//   // View mode (2D or 3D)
//   const [viewMode, setViewMode] = useState<'2D' | '3D'>('2D');
  
//   // Auto populate panel
//   const [showAutoPopulatePanel, setShowAutoPopulatePanel] = useState<boolean>(false);
//   const [autoPopulateMode, setAutoPopulateMode] = useState<'selection' | 'obstruction' | null>(null);
//   const stageRef = useRef<any>(null);
  
//   // Pan mode state
//   const [isPanMode, setIsPanMode] = useState<boolean>(false);
  
//   // Rack sections management
//   const [rackSections, setRackSections] = useState<RackSection[]>([]);
//   const [currentSectionId, setCurrentSectionId] = useState<string | null>(null);
//   const [rackSelectionRect, setRackSelectionRect] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
//   const [rackObstructions, setRackObstructions] = useState<{ id: string; x: number; y: number; width: number; height: number }[]>([]);

//   // Add CSS for drag and drop
//   useEffect(() => {
//     // Create a style element
//     const styleElement = document.createElement('style');
//     styleElement.textContent = `
//       .dragging {
//         cursor: grabbing !important;
//       }
      
//       .canvas-container {
//         position: relative;
//       }
      
//       .canvas-container.drag-over {
//         outline: 2px dashed #3498db;
//       }
      
//       .element-item {
//         cursor: grab;
//         user-select: none;
//         transition: transform 0.2s, box-shadow 0.2s;
//       }
      
//       .element-item:hover {
//         transform: translateY(-2px);
//         box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
//       }
      
//       .element-item:active {
//         cursor: grabbing;
//         transform: translateY(0);
//       }
//     `;
    
//     // Add the style element to the document head
//     document.head.appendChild(styleElement);
    
//     // Clean up function
//     return () => {
//       document.head.removeChild(styleElement);
//     };
//   }, []);

//   // Handle drag end events (including cancelled drags)
//   useEffect(() => {
//     const handleDragEnd = () => {
//       if (isDraggingElement) {
//         setIsDraggingElement(false);
//         setDragElement(null);
//         setDragOffset(undefined);
//         document.body.classList.remove('dragging');
//         document.body.style.cursor = '';
//       }
//     };
    
//     // Handle drag end events
//     document.addEventListener('dragend', handleDragEnd);
    
//     // Handle cases where drag is cancelled without firing dragend
//     const handleKeyDown = (e: KeyboardEvent) => {
//       if (e.key === 'Escape' && isDraggingElement) {
//         handleDragEnd();
//       }
//     };
    
//     document.addEventListener('keydown', handleKeyDown);
    
//     // Handle mouse up outside the window
//     const handleMouseUp = () => {
//       if (isDraggingElement) {
//         handleDragEnd();
//       }
//     };
    
//     window.addEventListener('mouseup', handleMouseUp);
    
//     return () => {
//       document.removeEventListener('dragend', handleDragEnd);
//       document.removeEventListener('keydown', handleKeyDown);
//       window.removeEventListener('mouseup', handleMouseUp);
//       document.body.classList.remove('dragging');
//       document.body.style.cursor = '';
//     };
//   }, [isDraggingElement]);

//   const handleToolSelect = (tool: string | null) => {
//     // If selecting the same tool, toggle it off
//     if (tool === selectedTool) {
//       setSelectedTool(null);
//     } else {
//       setSelectedTool(tool);
//       // Deselect shape when selecting a tool
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   };

//   const handleAddShape = useCallback((newShapes: Shape[]) => {
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex]);

//   const handleElementDragStart = (element: any, offset?: { offsetX: number; offsetY: number }) => {
//     setIsDraggingElement(true);
//     setDragElement(element);
//     if (offset) {
//       setDragOffset(offset);
//     }
//     setSelectedTool(null); // Deselect any active drawing tool
//     setSelectedShape(null); // Deselect any selected shape
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
    
//     // Add a class to the body to indicate dragging
//     document.body.classList.add('dragging');
    
//     // Set cursor style for the entire document during drag
//     document.body.style.cursor = 'grabbing';
//   };

//   const handleElementDrop = useCallback((element: any, position: {x: number, y: number}) => {
//     setIsDraggingElement(false);
//     setDragElement(null);
//     setDragOffset(undefined);
    
//     // Remove the dragging class
//     document.body.classList.remove('dragging');
    
//     // Reset cursor style
//     document.body.style.cursor = '';
    
//     // Create a new shape based on the dropped element
//     const newElement = {
//       ...element,
//       x: position.x,
//       y: position.y,
//       id: Date.now(),
//     };
    
//     // Add section ID to rack elements
//     if (element.type === 'rack' && currentSectionId) {
//       newElement.sectionId = currentSectionId;
//     }
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     setShapes([...shapes, newElement]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex, currentSectionId]);

//   const handleShapeSelect = useCallback((shape: Shape | null, isShiftKey?: boolean) => {
//     // Deselect tool when selecting a shape
//     setSelectedTool(null);
    
//     if (isShiftKey) {
//       // Enable multi-select mode
//       setIsMultiSelectMode(true);
      
//       if (shape) {
//         // Check if shape is already selected
//         const isAlreadySelected = selectedShapes.some(s => s.id === shape.id);
        
//         if (isAlreadySelected) {
//           // Remove from selection
//           setSelectedShapes(selectedShapes.filter(s => s.id !== shape.id));
//         } else {
//           // Add to selection
//           setSelectedShapes([...selectedShapes, shape]);
//         }
//       }
      
//       // Clear single selection
//       setSelectedShape(null);
//     } else {
//       // Single selection mode
//       setIsMultiSelectMode(false);
//       setSelectedShapes([]);
//       setSelectedShape(shape);
//     }
//   }, [selectedShapes]);

//   // Handle pan mode toggle
//   const handleTogglePanMode = useCallback(() => {
//     setIsPanMode(prev => !prev);
//     // When entering pan mode, deselect any tools and shapes
//     if (!isPanMode) {
//       setSelectedTool(null);
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [isPanMode]);

//   // Group shapes function
//   const handleGroupShapes = useCallback((shapesToGroup: Shape[]) => {
//     if (shapesToGroup.length < 2) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Create a unique ID for the group
//     const groupId = `group_${Date.now()}`;
    
//     // Update shapes with the group ID
//     const updatedShapes = shapes.map(shape => 
//       shapesToGroup.some(s => s.id === shape.id) ? { ...shape, groupId } : shape
//     );
    
//     setShapes(updatedShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Clear selection
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
    
//     // Select one of the shapes in the group
//     if (shapesToGroup.length > 0) {
//       const updatedShape = updatedShapes.find(s => s.id === shapesToGroup[0].id);
//       if (updatedShape) {
//         setSelectedShape(updatedShape);
//       }
//     }
//   }, [shapes, history, historyIndex]);

//   // Ungroup shapes function
//   const handleUngroupShapes = useCallback((groupId: string) => {
//     if (!groupId) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Remove the group ID from all shapes in the group
//     const updatedShapes = shapes.map(shape => 
//       shape.groupId === groupId ? { ...shape, groupId: undefined } : shape
//     );
    
//     setShapes(updatedShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Clear selection
//     setSelectedShape(null);
//   }, [shapes, history, historyIndex]);

//   const handleUpdateGroups = useCallback((updatedGroups: any[]) => {
//     setGroups(updatedGroups);
//   }, []);

//   const handleUpdateShape = useCallback((updatedShape: Shape) => {
//     // Check if the shape should be deleted
//     if (updatedShape._delete) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Filter out the shape to be deleted
//       const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
      
//       // If it's a rack, also update the section
//       if (updatedShape.type === 'rack' && updatedShape.sectionId) {
//         const sectionId = updatedShape.sectionId;
//         const section = rackSections.find(s => s.id === sectionId);
        
//         if (section) {
//           const updatedSection = {
//             ...section,
//             rackIds: section.rackIds.filter(id => id !== updatedShape.id.toString())
//           };
          
//           setRackSections(prev => 
//             prev.map(s => s.id === sectionId ? updatedSection : s)
//               .filter(s => s.rackIds.length > 0) // Remove empty sections
//           );
//         }
//       }
      
//       setShapes(newShapes);
//       setSelectedShape(null);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
//       return;
//     }
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Update the shape
//     const newShapes = shapes.map(shape => 
//       shape.id === updatedShape.id ? { ...updatedShape } : shape
//     );
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
//   }, [shapes, history, historyIndex, rackSections]);

//   const handleDuplicateShape = useCallback((duplicates: Shape | { shape: Shape, offsetX: number, offsetY: number }[]) => {
//     // If it's a single duplicate (for backward compatibility)
//     if (!Array.isArray(duplicates)) {
//       const originalShape = duplicates;
//       const offsetX = arguments[1] || 0;
//       const offsetY = arguments[2] || 0;
      
//       // Create a new shape based on the selected one with the specified offset
//       // Use a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...originalShape,
//         id: Date.now(),
//         x: originalShape.x + offsetX,
//         y: originalShape.y + offsetY
//       }));
      
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Add the duplicated shape to the shapes array
//       const newShapes = [...shapes, duplicatedShape];
//       setShapes(newShapes);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
      
//       // Select the new shape
//       setSelectedShape(duplicatedShape);
//       return;
//     }
    
//     // Handle multiple duplicates
//     if (duplicates.length === 0) return;
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Create all duplicated shapes
//     const newShapes = [...shapes];
//     let lastShape = null;
    
//     duplicates.forEach(({ shape, offsetX, offsetY }) => {
//       // Create a deep copy to ensure all properties are duplicated
//       const duplicatedShape = JSON.parse(JSON.stringify({
//         ...shape,
//         id: Date.now() + Math.random(), // Ensure unique ID
//         x: shape.x + offsetX,
//         y: shape.y + offsetY
//       }));
      
//       newShapes.push(duplicatedShape);
//       lastShape = duplicatedShape;
//     });
    
//     setShapes(newShapes);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Select the last shape created
//     if (lastShape) {
//       setSelectedShape(lastShape);
//     }
//   }, [shapes, history, historyIndex]);

//   const handleUndo = useCallback(() => {
//     if (historyIndex > 0) {
//       setHistoryIndex(historyIndex - 1);
//       setShapes(history[historyIndex - 1]);
//       // Deselect shape when undoing
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [history, historyIndex]);

//   const handleRedo = useCallback(() => {
//     if (historyIndex < history.length - 1) {
//       setHistoryIndex(historyIndex + 1);
//       setShapes(history[historyIndex + 1]);
//       // Deselect shape when redoing
//       setSelectedShape(null);
//       setSelectedShapes([]);
//       setIsMultiSelectMode(false);
//     }
//   }, [history, historyIndex]);

//   const handleToggleDimensions = useCallback(() => {
//     setShowDimensions(!showDimensions);
//   }, [showDimensions]);

//   const handleScaleChange = useCallback((newScale: number) => {
//     setScale(newScale);
//   }, []);

//   const handleUnitChange = useCallback((newUnit: 'meters' | 'centimeters' | 'feet' | 'inches' | 'yards') => {
//     setUnit(newUnit);
//   }, []);

//   const handleZoomIn = useCallback(() => {
//     setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
//   }, []);

//   const handleZoomOut = useCallback(() => {
//     setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
//   }, []);

//   const handleResetZoom = useCallback(() => {
//     setZoomLevel(1);
//   }, []);

//   const handleToggleViewMode = useCallback(() => {
//     setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
//     // Deselect shape when switching view modes
//     setSelectedShape(null);
//     setSelectedShapes([]);
//     setIsMultiSelectMode(false);
//   }, []);

//   // Handle auto populate panel
//   const handleToggleAutoPopulate = useCallback(() => {
//     const newValue = !showAutoPopulatePanel;
//     setShowAutoPopulatePanel(newValue);
    
//     // Turn off pan mode when activating AutoPopulate
//     if (isPanMode && newValue) {
//       setIsPanMode(false);
//     }
    
//     // Only generate a new section ID when opening the panel
//     if (newValue) {
//       const newSectionId = `section-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
//       console.log("Generated new section ID:", newSectionId);
//       setCurrentSectionId(newSectionId);
      
//       // Reset selection rect and obstructions when opening panel
//       setRackSelectionRect(null);
//       setRackObstructions([]);
      
//       // Set initial mode to selection
//       setAutoPopulateMode('selection');
//     } else {
//       // Clear mode when closing panel
//       setAutoPopulateMode(null);
//     }
//   }, [showAutoPopulatePanel, isPanMode]);

//   // Canvas can tell us when it hides itself (eg. Cancel button in the panel)
//   const handleAutoPopulateChange = useCallback((isShowing: boolean) => {
//     // Only update if the value is actually changing to prevent loops
//     if (showAutoPopulatePanel !== isShowing) {
//       setShowAutoPopulatePanel(isShowing);
      
//       // Clear mode when closing panel
//       if (!isShowing) {
//         setAutoPopulateMode(null);
//       }
//     }
//   }, [showAutoPopulatePanel]);

//   // Handle drawing mode changes in AutoPopulatePanel
//   const handleToggleMode = useCallback((mode: 'selection' | 'obstruction' | null) => {
//     setAutoPopulateMode(mode);
//   }, []);

//   // Clear obstructions
//   const clearObstructions = useCallback(() => {
//     setRackObstructions([]);
//   }, []);

//   // Handle generated racks from AutoPopulatePanel
//   const handleGeneratedRacks = useCallback((rackShapes: Shape[]) => {
//     console.log("Adding new racks:", rackShapes.length, "with section ID:", currentSectionId);
    
//     if (!currentSectionId) {
//       console.warn("No current section ID available");
//       return;
//     }
    
//     // Create a new section record if we have a selection rect
//     if (rackSelectionRect && currentSectionId) {
//       // Store rack IDs for this section
//       const rackIds = rackShapes.map(r => r.id.toString());
      
//       // Create or update section
//       const newSection = {
//         id: currentSectionId,
//         boundary: { ...rackSelectionRect },
//         rackIds
//       };
      
//       // Add to sections list (always add as new, never replace)
//       setRackSections(prev => [...prev, newSection]);
//     }
    
//     // Ensure all new racks have the current section ID
//     const racksWithSection = rackShapes.map(rack => ({
//       ...rack,
//       sectionId: currentSectionId
//     }));
    
//     // Add current state to history before updating
//     const newHistory = history.slice(0, historyIndex + 1);
//     newHistory.push(shapes);
    
//     // Update the shapes state with the combined array
//     setShapes([...shapes, ...racksWithSection]);
//     setHistory(newHistory);
//     setHistoryIndex(newHistory.length - 1);
    
//     // Close the panel after applying racks
//     setShowAutoPopulatePanel(false);
//     setAutoPopulateMode(null);
//   }, [shapes, rackSelectionRect, history, historyIndex, currentSectionId]);
  
//   // Clear all racks and boundaries for current section
//   const clearAll = useCallback(() => {
//     // Only clear the selection rectangle and obstructions
//     setRackSelectionRect(null);
//     setRackObstructions([]);
    
//     // Remove racks from current section
//     if (currentSectionId) {
//       // Add current state to history before updating
//       const newHistory = history.slice(0, historyIndex + 1);
//       newHistory.push(shapes);
      
//       // Filter out racks from current section
//       const updatedShapes = shapes.filter(shape => 
//         shape.type !== 'rack' || shape.sectionId !== currentSectionId
//       );
      
//       setShapes(updatedShapes);
//       setHistory(newHistory);
//       setHistoryIndex(newHistory.length - 1);
      
//       // Remove the section from rackSections
//       setRackSections(prev => prev.filter(section => section.id !== currentSectionId));
//     }
//   }, [shapes, history, historyIndex, currentSectionId]);

//   // Handle selection rect updates from Canvas
//   const handleSelectionRectChange = useCallback((rect: { x: number; y: number; width: number; height: number } | null) => {
//     setRackSelectionRect(rect);
//   }, []);

//   // Handle obstruction updates from Canvas
//   const handleObstructionsChange = useCallback((obstructions: { id: string; x: number; y: number; width: number; height: number }[]) => {
//     setRackObstructions(obstructions);
//   }, []);

//   // Function to save the current layout
//   const handleSaveLayout = useCallback(() => {
//     // Create a layout object with all necessary data
//     const layout = {
//       shapes,
//       scale,
//       unit,
//       rackSections,
//       version: '1.0', // Add version for future compatibility
//     };

//     // Convert to JSON string
//     const jsonString = JSON.stringify(layout, null, 2);
    
//     // Create a blob and download link
//     const blob = new Blob([jsonString], { type: 'application/json' });
//     const url = URL.createObjectURL(blob);
    
//     // Create a temporary anchor element to trigger download
//     const a = document.createElement('a');
//     a.href = url;
//     a.download = `floor-plan-${new Date().toISOString().slice(0, 10)}.json`;
//     document.body.appendChild(a);
//     a.click();
    
//     // Clean up
//     document.body.removeChild(a);
//     URL.revokeObjectURL(url);
//   }, [shapes, scale, unit, rackSections]);

//   // Function to load a layout from file
//   const handleLoadLayout = useCallback((file: File) => {
//     const reader = new FileReader();
    
//     reader.onload = (e) => {
//       try {
//         const layout = JSON.parse(e.target?.result as string);
        
//         // Validate the layout data
//         if (!layout.shapes || !Array.isArray(layout.shapes)) {
//           throw new Error('Invalid layout file: missing shapes array');
//         }
        
//         // Update state with loaded data
//         setShapes(layout.shapes);
//         if (layout.scale) setScale(layout.scale);
//         if (layout.unit) setUnit(layout.unit);
//         if (layout.rackSections && Array.isArray(layout.rackSections)) {
//           setRackSections(layout.rackSections);
//         }
        
//         // Reset history
//         setHistory([layout.shapes]);
//         setHistoryIndex(0);
        
//         // Deselect any selected shape
//         setSelectedShape(null);
//         setSelectedShapes([]);
//         setIsMultiSelectMode(false);
        
//         // Show success message
//         alert('Layout loaded successfully!');
//       } catch (error) {
//         console.error('Error loading layout:', error);
//         alert(`Error loading layout: ${error instanceof Error ? error.message : 'Unknown error'}`);
//       }
//     };
    
//     reader.readAsText(file);
//   }, []);

//   // Handle AutoPopulatePanel close
//   const handleAutoPopulateClose = useCallback(() => {
//     setShowAutoPopulatePanel(false);
//     setAutoPopulateMode(null);
//   }, []);

//   return (
//     <div className="app">
//       <TopBar 
//         selectedTool={selectedTool}
//         onToolSelect={handleToolSelect}
//         onUndo={handleUndo}
//         onRedo={handleRedo}
//         canUndo={historyIndex > 0}
//         canRedo={historyIndex < history.length - 1}
//         showDimensions={showDimensions}
//         onToggleDimensions={handleToggleDimensions}
//         scale={scale}
//         onScaleChange={handleScaleChange}
//         unit={unit}
//         onUnitChange={handleUnitChange}
//         zoomLevel={zoomLevel}
//         onZoomIn={handleZoomIn}
//         onZoomOut={handleZoomOut}
//         onResetZoom={handleResetZoom}
//         viewMode={viewMode}
//         onToggleViewMode={handleToggleViewMode}
//         showAutoPopulate={showAutoPopulatePanel}
//         onToggleAutoPopulate={handleToggleAutoPopulate}
//         onSaveLayout={handleSaveLayout}
//         onLoadLayout={handleLoadLayout}
//         isPanMode={isPanMode}
//         onTogglePanMode={handleTogglePanMode}
//       />
//       <div className="main-content">
//         {/* Only show Elements Panel when Auto-Populate Panel is hidden */}
//         {!showAutoPopulatePanel && viewMode === '2D' && (
//           <div className="sidebar left-sidebar">
//             <ElementsPanel onElementDragStart={handleElementDragStart} />
//             <LayoutLeftPanel />
//           </div>
//         )}
        
//         {viewMode === '2D' ? (
//           <Canvas 
//             ref={stageRef}
//             selectedTool={selectedTool} 
//             shapes={shapes} 
//             onAddShape={handleAddShape}
//             isDraggingElement={isDraggingElement}
//             dragElement={dragElement}
//             dragOffset={dragOffset}
//             onElementDrop={handleElementDrop}
//             showDimensions={showDimensions}
//             scale={scale}
//             unit={unit}
//             zoomLevel={zoomLevel}
//             onShapeSelect={handleShapeSelect}
//             selectedShape={selectedShape}
//             selectedShapes={selectedShapes}
//             isMultiSelectMode={isMultiSelectMode}
//             onUpdateGroups={handleUpdateGroups}
//             onDuplicateShape={handleDuplicateShape}
//             showRadialMenu={showRadialMenu}
//             setShowRadialMenu={setShowRadialMenu}
//             showAutoPopulate={showAutoPopulatePanel}
//             showAutoPopulateInCanvas={false} // Don't render AutoPopulatePanel inside Canvas
//             onAutoPopulateChange={handleAutoPopulateChange}
//             autoPopulateMode={autoPopulateMode}
//             onSelectionRectChange={handleSelectionRectChange}
//             onObstructionsChange={handleObstructionsChange}
//             rackSections={rackSections}
//             currentSectionId={currentSectionId}
//             gridSize={20} // Use consistent grid size
//             isPanMode={isPanMode}
//           />
//         ) : (
//           <ThreeJsView 
//             shapes={shapes}
//             scale={scale}
//             unit={unit}
//           />
//         )}
        
//         {/* Right sidebar - conditionally show Properties Panel or AutoPopulate Panel */}
//         {viewMode === '2D' && (
//           <div className="sidebar right-sidebar">
//             {!showAutoPopulatePanel ? (
//               <PropertiesPanel 
//                 selectedShape={!isMultiSelectMode ? selectedShape : undefined}
//                 selectedShapes={isMultiSelectMode ? selectedShapes : undefined}
//                 onUpdateShape={handleUpdateShape}
//                 onGroupShapes={handleGroupShapes}
//                 onUngroupShapes={handleUngroupShapes}
//               />
//             ) : (
//               <AutoPopulatePanel
//                 controlsOnly
//                 stageRef={stageRef}
//                 selectionRect={rackSelectionRect}
//                 obstructions={rackObstructions}
//                 onToggleMode={handleToggleMode}
//                 onClearObstructions={clearObstructions}
//                 onClearAll={clearAll}
//                 onGenerateRacks={handleGeneratedRacks}
//                 onClose={handleAutoPopulateClose}
//                 sectionId={currentSectionId}
//               />
//             )}
//           </div>
//         )}
//       </div>
      
//       {/* Pan Mode Indicator */}
//       {isPanMode && viewMode === '2D' && (
//         <div 
//           className="pan-mode-indicator"
//           style={{
//             position: 'absolute',
//             top: '70px',
//             left: '50%',
//             transform: 'translateX(-50%)',
//             background: 'rgba(0, 0, 0, 0.7)',
//             color: 'white',
//             padding: '8px 16px',
//             borderRadius: '4px',
//             zIndex: 1000,
//             pointerEvents: 'none'
//           }}
//         >
//           <div style={{ textAlign: 'center' }}>
//             Pan Mode Active
//             <br />
//             <small style={{ opacity: 0.8 }}>Click the pan button again to exit</small>
//           </div>
//         </div>
//       )}
      
//       {/* Section indicator */}
//       {currentSectionId && showAutoPopulatePanel && (
//         <div 
//           className="section-indicator" 
//           style={{ 
//             position: 'absolute', 
//             bottom: '10px', 
//             left: '10px', 
//             background: 'rgba(22, 163, 74, 0.9)', 
//             color: 'white', 
//             padding: '5px 10px', 
//             borderRadius: '4px',
//             fontSize: '12px',
//             zIndex: 100
//           }}
//         >
//           Current Section: {currentSectionId.substring(0, 8)}...
//         </div>
//       )}
//     </div>
//   );
// }

// export default ConfigurationLayout;

import React, { useState, useCallback, useRef, useEffect } from 'react';
import Canvas from './concom/Canvas';
import TopBar from './concom/TopBar';
import ElementsPanel from './concom/ElementsPanel';
// import LayoutLeftPanel from './LayoutLeftPanel';
import PropertiesPanel from './concom/PropertiesPanel';
import ThreeJsView from './concom/ThreeJsView';
import AutoPopulatePanel from './concom/AutoPopulatePanel';
import './Test.css';

interface Shape {
  id: string | number;
  type: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  points?: number[];
  radius?: number;
  stroke?: string;
  strokeWidth?: number;
  fill?: string;
  rotation?: 0 | 90 | 180 | 270;
  locked?: boolean;
  groupId?: string;
  dash?: number[];
  sectionId?: string;
  label?: string;
  [key: string]: any; // For additional properties
}

interface RackSection {
  id: string;
  boundary: { x: number; y: number; width: number; height: number };
  rackIds: string[];
}

function ConfigurationLayoutExisting() {
  // Tool and shape state
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [selectedShape, setSelectedShape] = useState<Shape | null>(null);
  const [isDraggingElement, setIsDraggingElement] = useState<boolean>(false);
  const [dragElement, setDragElement] = useState<any>(null);
  const [dragOffset, setDragOffset] = useState<{ offsetX: number; offsetY: number } | undefined>(undefined);
  
  // Multi-select and grouping state
  const [isMultiSelectMode, setIsMultiSelectMode] = useState<boolean>(false);
  const [selectedShapes, setSelectedShapes] = useState<Shape[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  
  // Radial menu state
  const [showRadialMenu, setShowRadialMenu] = useState<boolean>(false);
  
  // History state for undo/redo
  const [history, setHistory] = useState<Shape[][]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  
  // Dimension settings
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [scale, setScale] = useState<number>(0.01); // 1 pixel = 0.01 meters (1cm)
  const [unit, setUnit] = useState<'meters' | 'centimeters' | 'feet' | 'inches' | 'yards'>('meters');
  
  // Zoom settings
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  
  // View mode (2D or 3D)
  const [viewMode, setViewMode] = useState<'2D' | '3D'>('2D');
  
  // Auto populate panel
  const [showAutoPopulatePanel, setShowAutoPopulatePanel] = useState<boolean>(false);
  const [autoPopulateMode, setAutoPopulateMode] = useState<'selection' | 'obstruction' | null>(null);
  const stageRef = useRef<any>(null);
  
  // Pan mode state
  const [isPanMode, setIsPanMode] = useState<boolean>(false);
  
  // Rack sections management
  const [rackSections, setRackSections] = useState<RackSection[]>([]);
  const [currentSectionId, setCurrentSectionId] = useState<string | null>(null);
  const [rackSelectionRect, setRackSelectionRect] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const [rackObstructions, setRackObstructions] = useState<{ id: string; x: number; y: number; width: number; height: number }[]>([]);

  // Snap angle setting
  const [snapAngle, setSnapAngle] = useState<number>(45); // Default to 45 degrees

  // Add CSS for drag and drop
  useEffect(() => {
    // Create a style element
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      .dragging {
        cursor: grabbing !important;
      }
      
      .canvas-container {
        position: relative;
      }
      
      .canvas-container.drag-over {
        outline: 2px dashed #3498db;
      }
      
      .element-item {
        cursor: grab;
        user-select: none;
        transition: transform 0.2s, box-shadow 0.2s;
      }
      
      .element-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      }
      
      .element-item:active {
        cursor: grabbing;
        transform: translateY(0);
      }
    `;
    
    // Add the style element to the document head
    document.head.appendChild(styleElement);
    
    // Clean up function
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Handle drag end events (including cancelled drags)
  useEffect(() => {
    const handleDragEnd = () => {
      if (isDraggingElement) {
        setIsDraggingElement(false);
        setDragElement(null);
        setDragOffset(undefined);
        document.body.classList.remove('dragging');
        document.body.style.cursor = '';
      }
    };
    
    // Handle drag end events
    document.addEventListener('dragend', handleDragEnd);
    
    // Handle cases where drag is cancelled without firing dragend
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isDraggingElement) {
        handleDragEnd();
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    
    // Handle mouse up outside the window
    const handleMouseUp = () => {
      if (isDraggingElement) {
        handleDragEnd();
      }
    };
    
    window.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('dragend', handleDragEnd);
      document.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.body.classList.remove('dragging');
      document.body.style.cursor = '';
    };
  }, [isDraggingElement]);

  const handleToolSelect = (tool: string | null) => {
    // If selecting the same tool, toggle it off
    if (tool === selectedTool) {
      setSelectedTool(null);
    } else {
      setSelectedTool(tool);
      // Deselect shape when selecting a tool
      setSelectedShape(null);
      setSelectedShapes([]);
      setIsMultiSelectMode(false);
    }
  };

  const handleAddShape = useCallback((newShapes: Shape[]) => {
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    setShapes(newShapes);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [shapes, history, historyIndex]);

  const handleElementDragStart = (element: any, offset?: { offsetX: number; offsetY: number }) => {
    setIsDraggingElement(true);
    setDragElement(element);
    if (offset) {
      setDragOffset(offset);
    }
    setSelectedTool(null); // Deselect any active drawing tool
    setSelectedShape(null); // Deselect any selected shape
    setSelectedShapes([]);
    setIsMultiSelectMode(false);
    
    // Add a class to the body to indicate dragging
    document.body.classList.add('dragging');
    
    // Set cursor style for the entire document during drag
    document.body.style.cursor = 'grabbing';
  };

  const handleElementDrop = useCallback((element: any, position: {x: number, y: number}) => {
    setIsDraggingElement(false);
    setDragElement(null);
    setDragOffset(undefined);
    
    // Remove the dragging class
    document.body.classList.remove('dragging');
    
    // Reset cursor style
    document.body.style.cursor = '';
    
    // Create a new shape based on the dropped element
    const newElement = {
      ...element,
      x: position.x,
      y: position.y,
      id: Date.now(),
    };
    
    // Add section ID to rack elements
    if (element.type === 'rack' && currentSectionId) {
      newElement.sectionId = currentSectionId;
    }
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    setShapes([...shapes, newElement]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [shapes, history, historyIndex, currentSectionId]);

  const handleShapeSelect = useCallback((shape: Shape | null, isShiftKey?: boolean) => {
    // Deselect tool when selecting a shape
    setSelectedTool(null);
    
    if (isShiftKey) {
      // Enable multi-select mode
      setIsMultiSelectMode(true);
      
      if (shape) {
        // Check if shape is already selected
        const isAlreadySelected = selectedShapes.some(s => s.id === shape.id);
        
        if (isAlreadySelected) {
          // Remove from selection
          setSelectedShapes(selectedShapes.filter(s => s.id !== shape.id));
        } else {
          // Add to selection
          setSelectedShapes([...selectedShapes, shape]);
        }
      }
      
      // Clear single selection
      setSelectedShape(null);
    } else {
      // Single selection mode
      setIsMultiSelectMode(false);
      setSelectedShapes([]);
      setSelectedShape(shape);
    }
  }, [selectedShapes]);

  // Handle snap angle change
  const handleSnapAngleChange = useCallback((angle: number) => {
    setSnapAngle(angle);
  }, []);

  // Handle pan mode toggle
  const handleTogglePanMode = useCallback(() => {
    setIsPanMode(prev => !prev);
    // When entering pan mode, deselect any tools and shapes
    if (!isPanMode) {
      setSelectedTool(null);
      setSelectedShape(null);
      setSelectedShapes([]);
      setIsMultiSelectMode(false);
    }
  }, [isPanMode]);

  // Group shapes function
  const handleGroupShapes = useCallback((shapesToGroup: Shape[]) => {
    if (shapesToGroup.length < 2) return;
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    // Create a unique ID for the group
    const groupId = `group_${Date.now()}`;
    
    // Update shapes with the group ID
    const updatedShapes = shapes.map(shape => 
      shapesToGroup.some(s => s.id === shape.id) ? { ...shape, groupId } : shape
    );
    
    setShapes(updatedShapes);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    // Clear selection
    setSelectedShapes([]);
    setIsMultiSelectMode(false);
    
    // Select one of the shapes in the group
    if (shapesToGroup.length > 0) {
      const updatedShape = updatedShapes.find(s => s.id === shapesToGroup[0].id);
      if (updatedShape) {
        setSelectedShape(updatedShape);
      }
    }
  }, [shapes, history, historyIndex]);

  // Ungroup shapes function
  const handleUngroupShapes = useCallback((groupId: string) => {
    if (!groupId) return;
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    // Remove the group ID from all shapes in the group
    const updatedShapes = shapes.map(shape => 
      shape.groupId === groupId ? { ...shape, groupId: undefined } : shape
    );
    
    setShapes(updatedShapes);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    // Clear selection
    setSelectedShape(null);
  }, [shapes, history, historyIndex]);

  const handleUpdateGroups = useCallback((updatedGroups: any[]) => {
    setGroups(updatedGroups);
  }, []);

  const handleUpdateShape = useCallback((updatedShape: Shape) => {
    // Check if the shape should be deleted
    if (updatedShape._delete) {
      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);
      
      // Filter out the shape to be deleted
      const newShapes = shapes.filter(shape => shape.id !== updatedShape.id);
      
      // If it's a rack, also update the section
      if (updatedShape.type === 'rack' && updatedShape.sectionId) {
        const sectionId = updatedShape.sectionId;
        const section = rackSections.find(s => s.id === sectionId);
        
        if (section) {
          const updatedSection = {
            ...section,
            rackIds: section.rackIds.filter(id => id !== updatedShape.id.toString())
          };
          
          setRackSections(prev => 
            prev.map(s => s.id === sectionId ? updatedSection : s)
              .filter(s => s.rackIds.length > 0) // Remove empty sections
          );
        }
      }
      
      setShapes(newShapes);
      setSelectedShape(null);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      return;
    }
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    // Update the shape
    const newShapes = shapes.map(shape => 
      shape.id === updatedShape.id ? { ...updatedShape } : shape
    );
    
    setShapes(newShapes);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [shapes, history, historyIndex, rackSections]);

  const handleDuplicateShape = useCallback((duplicates: Shape | { shape: Shape, offsetX: number, offsetY: number }[]) => {
    // If it's a single duplicate (for backward compatibility)
    if (!Array.isArray(duplicates)) {
      const originalShape = duplicates;
      const offsetX = arguments[1] || 0;
      const offsetY = arguments[2] || 0;
      
      // Create a new shape based on the selected one with the specified offset
      // Use a deep copy to ensure all properties are duplicated
      const duplicatedShape = JSON.parse(JSON.stringify({
        ...originalShape,
        id: Date.now(),
        x: originalShape.x + offsetX,
        y: originalShape.y + offsetY
      }));
      
      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);
      
      // Add the duplicated shape to the shapes array
      const newShapes = [...shapes, duplicatedShape];
      setShapes(newShapes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      
      // Select the new shape
      setSelectedShape(duplicatedShape);
      return;
    }
    
    // Handle multiple duplicates
    if (duplicates.length === 0) return;
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    // Create all duplicated shapes
    const newShapes = [...shapes];
    let lastShape = null;
    
    duplicates.forEach(({ shape, offsetX, offsetY }) => {
      // Create a deep copy to ensure all properties are duplicated
      const duplicatedShape = JSON.parse(JSON.stringify({
        ...shape,
        id: Date.now() + Math.random(), // Ensure unique ID
        x: shape.x + offsetX,
        y: shape.y + offsetY
      }));
      
      newShapes.push(duplicatedShape);
      lastShape = duplicatedShape;
    });
    
    setShapes(newShapes);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    // Select the last shape created
    if (lastShape) {
      setSelectedShape(lastShape);
    }
  }, [shapes, history, historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setShapes(history[historyIndex - 1]);
      // Deselect shape when undoing
      setSelectedShape(null);
      setSelectedShapes([]);
      setIsMultiSelectMode(false);
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setShapes(history[historyIndex + 1]);
      // Deselect shape when redoing
      setSelectedShape(null);
      setSelectedShapes([]);
      setIsMultiSelectMode(false);
    }
  }, [history, historyIndex]);

  const handleToggleDimensions = useCallback(() => {
    setShowDimensions(!showDimensions);
  }, [showDimensions]);

  const handleScaleChange = useCallback((newScale: number) => {
    setScale(newScale);
  }, []);

  const handleUnitChange = useCallback((newUnit: 'meters' | 'centimeters' | 'feet' | 'inches' | 'yards') => {
    setUnit(newUnit);
  }, []);

  const handleZoomIn = useCallback(() => {
    setZoomLevel(prevZoom => Math.min(prevZoom * 1.2, 5)); // Limit max zoom to 500%
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoomLevel(prevZoom => Math.max(prevZoom / 1.2, 0.2)); // Limit min zoom to 20%
  }, []);

  const handleResetZoom = useCallback(() => {
    setZoomLevel(1);
  }, []);

  const handleToggleViewMode = useCallback(() => {
    setViewMode(prevMode => prevMode === '2D' ? '3D' : '2D');
    // Deselect shape when switching view modes
    setSelectedShape(null);
    setSelectedShapes([]);
    setIsMultiSelectMode(false);
  }, []);

  // Handle auto populate panel
  const handleToggleAutoPopulate = useCallback(() => {
    const newValue = !showAutoPopulatePanel;
    setShowAutoPopulatePanel(newValue);
    
    // Turn off pan mode when activating AutoPopulate
    if (isPanMode && newValue) {
      setIsPanMode(false);
    }
    
    // Only generate a new section ID when opening the panel
    if (newValue) {
      const newSectionId = `section-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      console.log("Generated new section ID:", newSectionId);
      setCurrentSectionId(newSectionId);
      
      // Reset selection rect and obstructions when opening panel
      setRackSelectionRect(null);
      setRackObstructions([]);
      
      // Set initial mode to selection
      setAutoPopulateMode('selection');
    } else {
      // Clear mode when closing panel
      setAutoPopulateMode(null);
    }
  }, [showAutoPopulatePanel, isPanMode]);

  // Canvas can tell us when it hides itself (eg. Cancel button in the panel)
  const handleAutoPopulateChange = useCallback((isShowing: boolean) => {
    // Only update if the value is actually changing to prevent loops
    if (showAutoPopulatePanel !== isShowing) {
      setShowAutoPopulatePanel(isShowing);
      
      // Clear mode when closing panel
      if (!isShowing) {
        setAutoPopulateMode(null);
      }
    }
  }, [showAutoPopulatePanel]);

  // Handle drawing mode changes in AutoPopulatePanel
  const handleToggleMode = useCallback((mode: 'selection' | 'obstruction' | null) => {
    setAutoPopulateMode(mode);
  }, []);

  // Clear obstructions
  const clearObstructions = useCallback(() => {
    setRackObstructions([]);
  }, []);

  // Handle generated racks from AutoPopulatePanel
  const handleGeneratedRacks = useCallback((rackShapes: Shape[]) => {
    console.log("Adding new racks:", rackShapes.length, "with section ID:", currentSectionId);
    
    if (!currentSectionId) {
      console.warn("No current section ID available");
      return;
    }
    
    // Create a new section record if we have a selection rect
    if (rackSelectionRect && currentSectionId) {
      // Store rack IDs for this section
      const rackIds = rackShapes.map(r => r.id.toString());
      
      // Create or update section
      const newSection = {
        id: currentSectionId,
        boundary: { ...rackSelectionRect },
        rackIds
      };
      
      // Add to sections list (always add as new, never replace)
      setRackSections(prev => [...prev, newSection]);
    }
    
    // Ensure all new racks have the current section ID
    const racksWithSection = rackShapes.map(rack => ({
      ...rack,
      sectionId: currentSectionId
    }));
    
    // Add current state to history before updating
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(shapes);
    
    // Update the shapes state with the combined array
    setShapes([...shapes, ...racksWithSection]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    // Close the panel after applying racks
    setShowAutoPopulatePanel(false);
    setAutoPopulateMode(null);
  }, [shapes, rackSelectionRect, history, historyIndex, currentSectionId]);
  
  // Clear all racks and boundaries for current section
  const clearAll = useCallback(() => {
    // Only clear the selection rectangle and obstructions
    setRackSelectionRect(null);
    setRackObstructions([]);
    
    // Remove racks from current section
    if (currentSectionId) {
      // Add current state to history before updating
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(shapes);
      
      // Filter out racks from current section
      const updatedShapes = shapes.filter(shape => 
        shape.type !== 'rack' || shape.sectionId !== currentSectionId
      );
      
      setShapes(updatedShapes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      
      // Remove the section from rackSections
      setRackSections(prev => prev.filter(section => section.id !== currentSectionId));
    }
  }, [shapes, history, historyIndex, currentSectionId]);

  // Handle selection rect updates from Canvas
  const handleSelectionRectChange = useCallback((rect: { x: number; y: number; width: number; height: number } | null) => {
    setRackSelectionRect(rect);
  }, []);

  // Handle obstruction updates from Canvas
  const handleObstructionsChange = useCallback((obstructions: { id: string; x: number; y: number; width: number; height: number }[]) => {
    setRackObstructions(obstructions);
  }, []);

  // Function to save the current layout
  const handleSaveLayout = useCallback(() => {
    // Create a layout object with all necessary data
    const layout = {
      shapes,
      scale,
      unit,
      rackSections,
      version: '1.0', // Add version for future compatibility
    };

    // Convert to JSON string
    const jsonString = JSON.stringify(layout, null, 2);
    
    // Create a blob and download link
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    // Create a temporary anchor element to trigger download
    const a = document.createElement('a');
    a.href = url;
    a.download = `floor-plan-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [shapes, scale, unit, rackSections]);

  // Function to load a layout from file
  const handleLoadLayout = useCallback((file: File) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const layout = JSON.parse(e.target?.result as string);
        
        // Validate the layout data
        if (!layout.shapes || !Array.isArray(layout.shapes)) {
          throw new Error('Invalid layout file: missing shapes array');
        }
        
        // Update state with loaded data
        setShapes(layout.shapes);
        if (layout.scale) setScale(layout.scale);
        if (layout.unit) setUnit(layout.unit);
        if (layout.rackSections && Array.isArray(layout.rackSections)) {
          setRackSections(layout.rackSections);
        }
        
        // Reset history
        setHistory([layout.shapes]);
        setHistoryIndex(0);
        
        // Deselect any selected shape
        setSelectedShape(null);
        setSelectedShapes([]);
        setIsMultiSelectMode(false);
        
        // Show success message
        alert('Layout loaded successfully!');
      } catch (error) {
        console.error('Error loading layout:', error);
        alert(`Error loading layout: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    };
    
    reader.readAsText(file);
  }, []);

  // Handle AutoPopulatePanel close
  const handleAutoPopulateClose = useCallback(() => {
    setShowAutoPopulatePanel(false);
    setAutoPopulateMode(null);
  }, []);

  return (
    <div className="app">
      <TopBar 
        selectedTool={selectedTool}
        onToolSelect={handleToolSelect}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        showDimensions={showDimensions}
        onToggleDimensions={handleToggleDimensions}
        scale={scale}
        onScaleChange={handleScaleChange}
        unit={unit}
        onUnitChange={handleUnitChange}
        zoomLevel={zoomLevel}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetZoom={handleResetZoom}
        viewMode={viewMode}
        onToggleViewMode={handleToggleViewMode}
        showAutoPopulate={showAutoPopulatePanel}
        onToggleAutoPopulate={handleToggleAutoPopulate}
        onSaveLayout={handleSaveLayout}
        onLoadLayout={handleLoadLayout}
        isPanMode={isPanMode}
        onTogglePanMode={handleTogglePanMode}
        snapAngle={snapAngle}
        onSnapAngleChange={handleSnapAngleChange}
      />
      <div className="main-content">
        {/* Only show Elements Panel when Auto-Populate Panel is hidden */}
        {!showAutoPopulatePanel && viewMode === '2D' && (
          <div className="sidebar left-sidebar">
            <ElementsPanel onElementDragStart={handleElementDragStart} />
            {/* <LayoutLeftPanel /> */}
          </div>
        )}
        
        {viewMode === '2D' ? (
          <Canvas 
            ref={stageRef}
            selectedTool={selectedTool} 
            shapes={shapes} 
            onAddShape={handleAddShape}
            isDraggingElement={isDraggingElement}
            dragElement={dragElement}
            dragOffset={dragOffset}
            onElementDrop={handleElementDrop}
            showDimensions={showDimensions}
            scale={scale}
            unit={unit}
            zoomLevel={zoomLevel}
            onShapeSelect={handleShapeSelect}
            selectedShape={selectedShape}
            selectedShapes={selectedShapes}
            isMultiSelectMode={isMultiSelectMode}
            onUpdateGroups={handleUpdateGroups}
            onDuplicateShape={handleDuplicateShape}
            showRadialMenu={showRadialMenu}
            setShowRadialMenu={setShowRadialMenu}
            showAutoPopulate={showAutoPopulatePanel}
            showAutoPopulateInCanvas={false} // Don't render AutoPopulatePanel inside Canvas
            onAutoPopulateChange={handleAutoPopulateChange}
            autoPopulateMode={autoPopulateMode}
            onSelectionRectChange={handleSelectionRectChange}
            onObstructionsChange={handleObstructionsChange}
            rackSections={rackSections}
            currentSectionId={currentSectionId}
            gridSize={20} // Use consistent grid size
            isPanMode={isPanMode}
            snapAngle={snapAngle}
          />
        ) : (
          <ThreeJsView 
            shapes={shapes}
            scale={scale}
            unit={unit}
          />
        )}
        
        {/* Right sidebar - conditionally show Properties Panel or AutoPopulate Panel */}
        {viewMode === '2D' && (
          <div className="sidebar right-sidebar">
            {!showAutoPopulatePanel ? (
              <PropertiesPanel 
                selectedShape={!isMultiSelectMode ? selectedShape : undefined}
                selectedShapes={isMultiSelectMode ? selectedShapes : undefined}
                onUpdateShape={handleUpdateShape}
                onGroupShapes={handleGroupShapes}
                onUngroupShapes={handleUngroupShapes}
              />
            ) : (
              <AutoPopulatePanel
                controlsOnly
                stageRef={stageRef}
                selectionRect={rackSelectionRect}
                obstructions={rackObstructions}
                onToggleMode={handleToggleMode}
                onClearObstructions={clearObstructions}
                onClearAll={clearAll}
                onGenerateRacks={handleGeneratedRacks}
                onClose={handleAutoPopulateClose}
                sectionId={currentSectionId}
              />
            )}
          </div>
        )}
      </div>
      
      {/* Pan Mode Indicator */}
      {isPanMode && viewMode === '2D' && (
        <div 
          className="pan-mode-indicator"
          style={{
            position: 'absolute',
            top: '70px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(0, 0, 0, 0.7)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '4px',
            zIndex: 1000,
            pointerEvents: 'none'
          }}
        >
          <div style={{ textAlign: 'center' }}>
            Pan Mode Active
            <br />
            <small style={{ opacity: 0.8 }}>Click the pan button again to exit</small>
          </div>
        </div>
      )}
      
      {/* Section indicator */}
      {currentSectionId && showAutoPopulatePanel && (
        <div 
          className="section-indicator" 
          style={{ 
            position: 'absolute', 
            bottom: '10px', 
            left: '10px', 
            background: 'rgba(22, 163, 74, 0.9)', 
            color: 'white', 
            padding: '5px 10px', 
            borderRadius: '4px',
            fontSize: '12px',
            zIndex: 100
          }}
        >
          Current Section: {currentSectionId.substring(0, 8)}...
        </div>
      )}
    </div>
  );
}

export default ConfigurationLayoutExisting;