import React, { useEffect, useRef, useState } from 'react';
import { Box, Drawer, IconButton, Typography, CircularProgress, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
 
interface ModelPreviewDrawerProps {
  open: boolean;
  onClose: () => void;
  modelUrl?: string;
  modelName?: string;
}
 
export const ModelPreviewDrawer: React.FC<ModelPreviewDrawerProps> = ({
  open,
  onClose,
  modelUrl,
  modelName
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<string>('');
 
  console.log("ModelPreviewDrawer props:", { modelName, modelUrl, open });
 
  // Store scene objects for cleanup
  const sceneRef = useRef<{
    scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera;
    renderer?: THREE.WebGLRenderer;
    controls?: OrbitControls;
    animationId?: number;
  }>({});
 
  const cleanModelUrl = (url: string): string => {
  // Check if the URL contains '.glb-' pattern (specific to your case)
  const glbDashIndex = url.indexOf('.glb-');
  if (glbDashIndex !== -1) {
    return url.substring(0, glbDashIndex + 4); // +4 to include '.glb'
  }
 
  // Standard handling for normal .glb files
  const glbIndex = url.indexOf('.glb');
  if (glbIndex !== -1 && glbIndex === url.lastIndexOf('.glb')) {
    return url.substring(0, glbIndex + 4);
  }
 
  // Similarly for '.gltf' files
  const gltfDashIndex = url.indexOf('.gltf-');
  if (gltfDashIndex !== -1) {
    return url.substring(0, gltfDashIndex + 5); // +5 to include '.gltf'
  }
 
  const gltfIndex = url.indexOf('.gltf');
  if (gltfIndex !== -1 && gltfIndex === url.lastIndexOf('.gltf')) {
    return url.substring(0, gltfIndex + 5);
  }
 
  // If neither extension is found, return the original URL
  return url;
};
 
  // Helper function to validate and fix URLs
  const ensureValidUrl = (url: string): string => {
    try {
      new URL(url);
      return url;
    } catch (e) {
      if (url.startsWith('/')) {
        return window.location.origin + url;
      } else if (!url.startsWith('http')) {
        return 'https://' + url;
      }
      return url;
    }
  };
 
  // Test if URL is accessible
  const testUrlAccess = async (url: string): Promise<boolean> => {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      return response.ok;
    } catch (e) {
      console.error('Error testing URL access:', e);
      return false;
    }
  };
 
  useEffect(() => {
    if (!open) return;
   
    setLoading(true);
    setError(null);
    setDebugInfo('');
   
    // Log the URL we're trying to load
    console.log('Attempting to load model from:', modelUrl);
   
    if (!modelUrl) {
      setError('No model URL provided');
      setLoading(false);
      return;
    }
   
    const processedUrl = cleanModelUrl(ensureValidUrl(modelUrl));
console.log('Processed URL:', processedUrl);
setDebugInfo(prev => prev + `Original URL: ${modelUrl}\nProcessed URL: ${processedUrl}\n`);
   
    // Test URL accessibility
    testUrlAccess(processedUrl).then(accessible => {
      setDebugInfo(prev => prev + `URL accessible: ${accessible}\n`);
     
      if (!accessible) {
        setError(`URL not accessible: ${processedUrl}. This might be due to CORS restrictions or the file doesn't exist.`);
        setLoading(false);
        return;
      }
     
      // Continue with model loading...
      initScene(processedUrl);
    });
  }, [open, modelUrl]);
 
  const initScene = (url: string) => {
    if (!containerRef.current) return;
   
    // Initialize scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8f9fa);
    sceneRef.current.scene = scene;
   
    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);
   
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);
   
    const directionalLight2 = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight2.position.set(-1, 0.5, -1);
    scene.add(directionalLight2);
   
    // Add grid helper for orientation
    const gridHelper = new THREE.GridHelper(10, 10, 0x888888, 0x444444);
    scene.add(gridHelper);
   
    // Add axes helper
    const axesHelper = new THREE.AxesHelper(5);
    scene.add(axesHelper);
   
    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(5, 3, 5);
    camera.lookAt(0, 0, 0);
    sceneRef.current.camera = camera;
   
    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    sceneRef.current.renderer = renderer;
   
    // Clear container and add renderer
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);
   
    // Controls setup
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 50;
    controls.target.set(0, 0, 0);
    controls.update();
    sceneRef.current.controls = controls;
   
    // Determine file type and load accordingly
    const extension = url.split('.').pop()?.toLowerCase();
    setDebugInfo(prev => prev + `File extension: ${extension || 'unknown'}\n`);
   
    if (!extension) {
      setError('Unable to determine file format');
      setLoading(false);
      return;
    }
   
    if (extension === 'gltf' || extension === 'glb') {
      loadGLTF(url, scene, camera, controls);
    } else {
      setError(`Unsupported file format: ${extension}. Only GLTF/GLB formats are supported.`);
      setLoading(false);
    }
   
    // Handle window resize
    const handleResize = () => {
      if (!camera || !renderer || !containerRef.current) return;
     
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
   
    window.addEventListener('resize', handleResize);
   
    // Animation loop
    const animate = () => {
      const animationId = requestAnimationFrame(animate);
      sceneRef.current.animationId = animationId;
     
      if (controls) controls.update();
      if (renderer && scene && camera) renderer.render(scene, camera);
    };
   
    animate();
   
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
     
      if (sceneRef.current.animationId) {
        cancelAnimationFrame(sceneRef.current.animationId);
      }
     
      if (sceneRef.current.controls) {
        sceneRef.current.controls.dispose();
      }
     
      if (sceneRef.current.renderer) {
        sceneRef.current.renderer.dispose();
      }
     
      if (sceneRef.current.scene) {
        sceneRef.current.scene.traverse((object) => {
          if (object instanceof THREE.Mesh) {
            if (object.geometry) object.geometry.dispose();
           
            if (object.material) {
              if (Array.isArray(object.material)) {
                object.material.forEach(material => material.dispose());
              } else {
                object.material.dispose();
              }
            }
          }
        });
      }
    };
  };
 
  const loadGLTF = (url: string, scene: THREE.Scene, camera: THREE.PerspectiveCamera, controls: OrbitControls) => {
    const loader = new GLTFLoader();
   
    loader.load(
      url,
      (gltf) => {
        console.log('Model loaded successfully:', url);
        setDebugInfo(prev => prev + `Model loaded successfully\n`);
       
        const model = gltf.scene;
       
        // Log model details
        console.log('Model details:', {
          children: model.children.length,
          animations: gltf.animations.length
        });
       
        // Center the model
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
       
        console.log('Model size:', {
          width: size.x,
          height: size.y,
          depth: size.z
        });
       
        // Reset model position to center
        model.position.x = -center.x;
        model.position.y = -center.y;
        model.position.z = -center.z;
       
        // Scale model if it's too large
        const maxDim = Math.max(size.x, size.y, size.z);
        if (maxDim > 10) {
          const scale = 10 / maxDim;
          model.scale.set(scale, scale, scale);
        }
       
        scene.add(model);
       
        // Position camera to view the entire model
        const distance = Math.max(size.x, size.y, size.z) * 2.5;
        camera.position.set(distance, distance, distance);
        camera.lookAt(0, 0, 0);
        controls.update();
       
        setLoading(false);
      },
      (progress) => {
        if (progress.lengthComputable) {
          const percentComplete = Math.round((progress.loaded / progress.total) * 100);
          console.log(`Loading progress: ${percentComplete}%`);
          setDebugInfo(prev => prev + `Loading progress: ${percentComplete}%\n`);
        }
      },
      (error) => {
        console.error('Error loading 3D model:', error);
        console.error('Failed URL:', url);
        setDebugInfo(prev => prev + `Error loading model: ${error || error}\n`);
        setError(`Failed to load 3D model: ${error || 'Unknown error'}`);
        setLoading(false);
      }
    );
  };
 
  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      sx={{
        '& .MuiDrawer-paper': {
          width: { xs: '100%', sm: '80%', md: '60%' },
          maxWidth: '800px'
        }
      }}
    >
      <Box sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid rgba(0,0,0,0.12)' }}>
        <Typography variant="h6">{modelName || '3D Model Preview'}</Typography>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </Box>
     
      <Box sx={{ height: 'calc(100% - 64px)', position: 'relative' }}>
  {loading && (
    <Box sx={{
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(255,255,255,0.8)',
      zIndex: 10
    }}>
      <Box sx={{ textAlign: 'center' }}>
        <CircularProgress size={40} />
        <Typography sx={{ mt: 2 }}>Loading 3D model...</Typography>
      </Box>
    </Box>
  )}
 
  {error && (
    <Box sx={{
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(255,255,255,0.8)',
      zIndex: 10
    }}>
      <Box sx={{ textAlign: 'center', maxWidth: '80%' }}>
        <Typography color="error" variant="h6" gutterBottom>
          Error Loading Model
        </Typography>
        <Typography color="error">{error}</Typography>
        <Button
          variant="outlined"
          color="primary"
          sx={{ mt: 2 }}
          onClick={() => window.open(modelUrl, '_blank')}
        >
          Open Model URL Directly
        </Button>
      </Box>
    </Box>
  )}
 
  {debugInfo && (
    <Box sx={{
      position: 'absolute',
      bottom: 8,
      left: 8,
      right: 8,
      maxHeight: '150px',
      overflowY: 'auto',
      backgroundColor: 'rgba(0,0,0,0.05)',
      padding: 1,
      borderRadius: 1,
      zIndex: 5,
      fontSize: '12px',
      fontFamily: 'monospace'
    }}>
      <pre style={{ margin: 0 }}>{debugInfo}</pre>
    </Box>
  )}
 
  <Box
    ref={containerRef}
    sx={{
      width: '100%',
      height: '100%',
      backgroundColor: '#f8f9fa'
    }}
  />
</Box>
</Drawer>
);
};