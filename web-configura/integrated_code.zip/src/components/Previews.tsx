import React, { useState } from "react";
import FloatingEmailFields from "../components/custom-inputs/FloatingEmailFields"
import Button from "./button/Button";
import FLoatingPasswordFields from "../components/custom-inputs/FloatingPasswordFields";
import FloatingTextArea from "../components/custom-inputs/FloatingTextArea";
import FloatingPhoneInput from "../components/custom-inputs/FloatingPhoneInput";
import FloatingOrderQunatity from "../components/custom-inputs/FloatingOrderQunatity";
import FloatingUploadFile from "../components/custom-inputs/FloatingUploadFile";
import CodeInput from "../components/custom-inputs/CodeInput";
import GenericDropdown from "../components/custom-inputs/GenericDropdown";
import GenericDropdown2 from "../components/custom-inputs/GenericDropdown2";
import FloatingLabelInputFields from "../components/custom-inputs/FloatingLabelInputFields";

interface Country {
  code: string;
  name: string;
}

const countries: Country[] = [
  { code: "IN", name: "India" },
  { code: "US", name: "United State" },
  { code: "AUS", name: "Australia" },
  { code: "AL", name: "Albania" },
];

const Previews = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [selected, setSelected] = useState<Country | null>(null);
  const [selectedName, setSelectedName] = useState<string | null>(null);

  const handleEmail = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };
  const handlePassword = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };

  return (
    <>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Banners
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="ban-desk01">Example Text</p>
        <p className="ban-desk02">Example Text</p>
        <p className="ban-mob01">Example Text</p>
        <p className="ban-mob02">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Titles
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="title01">Example Text</p>
        <p className="title02">Example Text</p>
        <p className="title03">Example Text</p>
        <p className="title04">Example Text</p>
        <p className="title05">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Chips
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="chips01">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Body Copy
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="body-copy01">Example Text</p>
        <p className="body-copy02">Example Text</p>
        <p className="body-copy03">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Labels
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="label01">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        CTAs(Buttons & Links)
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="text-link01">Example Text</p>
        <p className="text-link02">Example Text</p>
        <p className="text-cta01">Example Text</p>
        <p className="text-cta02">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Section Menu (Inside Page)
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="section-menu01">Example Text</p>
        <p className="section-menu02">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Card Title
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <p className="card-title01">Example Text</p>
        <p className="card-title02">Example Text</p>
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Primary Buttons
      </h3>
      <div className="flex flex-row justify-center items-center gap-4 p-4">
        <Button
          className="btn-primary-32 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
        <Button
          className="btn-primary-40 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
        <Button
          className="btn-primary-48 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        Secondary Buttons
      </h3>
      <div className="flex flex-row justify-center items-center gap-4 p-4">
        <Button
          className="btn-secondary-32 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
        <Button
          className="btn-secondary-40 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
        <Button
          className="btn-secondary-48 flex items-center"
          label={"Export"}
          iconClass="icon-[ix--export]"
        />
      </div>
      <h3 className="flex justify-center items-center bg-godrej-cool-grey p-2 m-2">
        FLoating Inputs
      </h3>
      <div className="flex flex-col gap-4 p-4 justify-center items-center">
        <FloatingEmailFields
          type="email"
          id="email"
          value={email}
          placeholder="email"
          onChange={handleEmail}
          label="Email*"
          helperText="You will receive a verification code in this ID"
          errorText="Enter a valid email ID"
        />

        <FLoatingPasswordFields
          type="password"
          id="password"
          value={password}
          onChange={handlePassword}
          label="Password*"
          placeholder="password"
          className={`peer block w-full border border-gray-300 rounded-md px-3 pt-5 pb-2 text-[15px] text-black placeholder-transparent outline-none focus:ring-1 focus:ring-godrej-grey
            ${disabled ? "bg-gray-100 cursor-not-allowed" : ""}
            ${error ? "border-red-500 focus:ring-red-500" : ""}
            `}
        />

        <FloatingPhoneInput />
        <FloatingOrderQunatity />
        <CodeInput />
        <FloatingUploadFile />
        <FloatingTextArea />

        {/* <GenericDropdown
          label="Country*"
          options={countries}
          value={selected}
          onChange={setSelected}
          displayKey="name"
        /> */}
        <FloatingLabelInputFields/>
        <GenericDropdown2
          label="Country*"
          options={countries.map((item) => item.name)}
          value={selectedName}
          onChange={(val) => {
            // val is string | null
            setSelectedName(val);
            const match = countries.find((c) => c.name === val) ?? null;
            setSelected(match);
          }}
          allowUseCurrentLocation={true}
          error={selectedName ? "" : "Select your country"}
        />
      </div>
    </>
  );
};

export default Previews;
