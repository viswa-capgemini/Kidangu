
import React, { useEffect, useRef, useState } from "react";

interface UserMenuProps {
  userName: string;
  onLogout: () => void;
  trigger?: React.ReactNode;
  avatarUrl?: string;
  align?: "left" | "right";
  testId?: string;
}

const UserMenu: React.FC<UserMenuProps> = ({
  userName,
  onLogout,
  trigger,
  avatarUrl,
  align = "right",
  testId = "user-menu",
}) => {
  const [open, setOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);

  // ✅ This is the line: correct, concise, and valid
  const handleToggle = () => setOpen((v) => !v);

  const handleLogout = () => {
    setOpen(false);
    onLogout();
  };

  useEffect(() => {
    if (!open) return;
    const onClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        panelRef.current &&
        !panelRef.current.contains(target) &&
        buttonRef.current &&
        !buttonRef.current.contains(target)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open]);

  useEffect(() => {
    if (!open && buttonRef.current) {
      buttonRef.current.focus();
    }
  }, [open]);

  const panelAlignment = align === "right" ? "right-0" : "left-0";

  return (
    <div className="relative inline-block text-left" data-testid={testId}>
      <button
        ref={buttonRef}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={handleToggle}
        className="inline-flex items-center gap-2 bg-white px-3 py-2 text-md"
        data-testid={`${testId}-trigger`}
      >
        {trigger ? (
          trigger
        ) : (
          <>
            <span className="icon-[qlementine-icons--user-24] text-xl" />
            {/* <span className="hidden sm:inline">{userName || "Guest"}</span> */}
            {/* <span className="icon-[iconamoon--arrow-down-2-light] text-base" /> */}
          </>
        )}
      </button>

      {open && (
        <div
          ref={panelRef}
          role="menu"
          aria-label="User menu"
          tabIndex={-1}
          className={`absolute ${panelAlignment} z-50 mt-2 w-56 origin-top rounded-md border border-gray-200 bg-white shadow-lg focus:outline-none`}
          data-testid={`${testId}-panel`}
        >
          <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={`${userName} avatar`}
                className="h-8 w-8 rounded-full object-cover"
              />
            ) : (
              <div className="h-8 w-8 rounded-full bg-gray-200 text-gray-600 grid place-items-center text-sm font-medium">
                {(userName || "G").charAt(0).toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-gray-900">
                {userName || "Guest"}
              </p>
              <p className="text-xs text-gray-500">Signed in</p>
            </div>
          </div>

          <div className="py-1">
            <button
              role="menuitem"
              className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 focus:bg-gray-100"
                           onClick={handleLogout}
              data-testid={`${testId}-logout`}
            >
              <span className="icon-[material-symbols--logout-rounded] text-godrej-purple" />
              Logout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserMenu;