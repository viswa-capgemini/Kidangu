import React from "react";
import {
  Card,
  CardContent,
  Typography,
  Stack,
  IconButton,
  Checkbox,
  Switch,
} from "@mui/material";
import {
  DataGrid,
  type GridColDef,
  type GridRenderCellParams,
} from "@mui/x-data-grid";

type Role = "Designer" | "Viewer" | "Admin";
type Product = "SPR" | "Shelving" | "Mobistack" | "Mezzanine";
type SubProduct = "Components";
type WeightOption = "With Weight" | "Without weight";
type PriceOption = "INR" | "USD" | "Both";
type OutputOption =
  | "BOM"
  | "Drawing pdf"
  | "Drawing dwg"
  | "Tech spec"
  | "3D"
  | "Assembly dwg";
type BomType = "Excel" | "pdf" | "Assembly level";
type StandardType = "GFA" | "Std1" | "Std2" | "All";

interface Access {
  products: Product[];
  subProducts: SubProduct[];
  weight: "" | WeightOption;
  price: "" | PriceOption;
  outputs: OutputOption[];
  bomType: BomType[];
  standardType: "" | StandardType;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: "" | Role;
  access: Access;
}

interface UsersListProps {
  users: User[];
  onDelete: (id: string) => void;
  onEdit: (user: User) => void;
}

// SVG icons as React components
const DeleteIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
  >
    <path
      fill="#810055"
      d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z"
    />
  </svg>
);

const EditIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
  >
    <path
      fill="#810055"
      d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83l3.75 3.75z"
    />
  </svg>
);

export default function UsersList({ users, onDelete, onEdit }: UsersListProps) {
  // Create a safe version of users with all required fields
  const safeUsers = React.useMemo(() => {
    return (users || []).map((user) => ({
      ...user,
      // Ensure access object exists
      access: user.access || {
        products: [],
        subProducts: [],
        weight: "",
        price: "",
        outputs: [],
        bomType: [],
        standardType: "",
      },
      // Add derived fields directly to the user object for DataGrid
      productsDisplay: user.access?.products?.join(", ") || "",
      priceDisplay: user.access?.price || "",
      outputsDisplay: user.access?.outputs?.join(", ") || "",
    }));
  }, [users]);

  const columns: GridColDef[] = [
    { field: "name", headerName: "Name", flex: 1, sortable: true },
    { field: "email", headerName: "Email", flex: 1, sortable: true },
    { field: "role", headerName: "Role", width: 140 },
    { field: "productsDisplay", headerName: "Products", flex: 1 },
    { field: "priceDisplay", headerName: "Price", width: 120 },
    { field: "outputsDisplay", headerName: "Outputs", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      width: 120,
      sortable: false,
      filterable: false,
      renderCell: (params: GridRenderCellParams) => (
        <Stack direction="row" spacing={1}>
          <IconButton
            size="small"
            onClick={() => onEdit(params.row as User)}
            sx={{
              "&:hover": {
                backgroundColor: "rgba(129, 0, 85, 0.04)",
              },
            }}
          >
            <EditIcon />
          </IconButton>
          <IconButton
            size="small"
            onClick={() => onDelete(params.row.id as string)}
            sx={{
              "&:hover": {
                backgroundColor: "rgba(129, 0, 85, 0.04)",
              },
            }}
          >
            <DeleteIcon />
          </IconButton>
        </Stack>
      ),
    },
  ];
  // Custom component to replace checkbox with switch in columns panel
  const CustomColumnsPanel = (props) => {
    const { field, value, onChange } = props;

    return (
      <Switch
        checked={value}
        onChange={(event) => onChange(event.target.checked)}
        sx={{
          "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#810055",
          },
          "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#810055",
          },
        }}
      />
    );
  };

  return (
    <Card variant="outlined">
      <CardContent>
        <Typography variant="h6" sx={{ mb: 2, color: "#810055" }}>
          Users
        </Typography>
        <div style={{ height: 480, width: "100%" }}>
          <DataGrid
            rows={safeUsers}
            columns={columns}
            getRowId={(row) => row.id}
            pageSizeOptions={[5, 10]}
            initialState={{
              pagination: { paginationModel: { pageSize: 5, page: 0 } },
            }}
            // Add this slots configuration to replace the checkbox with switch
            components={{
              ColumnsManagementCheckbox: CustomColumnsPanel,
            }}
            sx={{
              // Remove default focus outline and border colors
              "& .MuiDataGrid-columnHeader:focus, & .MuiDataGrid-cell:focus": {
                outline: "none !important",
              },
              "& .MuiDataGrid-columnHeader:focus-within, & .MuiDataGrid-cell:focus-within":
                {
                  outline: "none !important",
                },

              // Style for column headers
              "& .MuiDataGrid-columnHeader": {
                "&:focus, &:focus-within": {
                  outline: "none !important",
                  outlineOffset: 0,
                },
                "&.MuiDataGrid-columnHeader--sorted": {
                  color: "#810055",
                },
              },

              // Style for column menu checkboxes
              "& .MuiDataGrid-panelContent .MuiCheckbox-root": {
                display: "none", // Hide checkboxes
              },
              "& .MuiDataGrid-panelContent .MuiSwitch-root": {
                display: "inline-flex", // Show switches
              },
              // Style for column header menu button
              "& .MuiDataGrid-columnHeaderTitleContainer .MuiButtonBase-root": {
                color: "rgba(0, 0, 0, 0.54)",
                "&:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04)",
                },
              },

              // Style for selected rows - change from light blue to #F9F2F6
              "& .MuiDataGrid-row.Mui-selected": {
                backgroundColor: "#F9F2F6 !important",
                "&:hover": {
                  backgroundColor: "#F9F2F6 !important",
                },
              },

              // Style for row hover
              "& .MuiDataGrid-row:hover": {
                backgroundColor: "rgba(249, 242, 246, 0.5)",
              },

              // Style for checkbox
              "& .MuiCheckbox-root": {
                color: "rgba(0, 0, 0, 0.54)",
                "&.Mui-checked": {
                  color: "#810055",
                },
              },
              // Target the "Manage Columns" button that appears when all columns are hidden
              "& .MuiDataGrid-main .MuiButtonBase-root": {
                color: "#810055 !important", // Change from blue to Godrej purple
              },

              // Target the "No columns" text
              "& .MuiDataGrid-overlay": {
                "& .MuiButtonBase-root": {
                  color: "#810055 !important",
                },
              },

              // Target specifically the "Manage Columns" button in the empty grid
              "& .MuiDataGrid-overlay .MuiButton-root": {
                color: "#810055 !important",
                borderColor: "#810055 !important",
                "&:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04) !important",
                },
              },

              // Style for pagination
              "& .MuiTablePagination-root": {
                color: "rgba(0, 0, 0, 0.87)",
              },
              "& .MuiTablePagination-actions .MuiIconButton-root.Mui-disabled":
                {
                  color: "rgba(0, 0, 0, 0.26)",
                },
              "& .MuiTablePagination-actions .MuiIconButton-root": {
                color: "rgba(0, 0, 0, 0.54)",
                "&:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04)",
                },
              },

              // Style for sort icons
              "& .MuiDataGrid-sortIcon": {
                color: "#810055",
              },

              // Style for column separator
              "& .MuiDataGrid-columnSeparator": {
                color: "#e0e0e0",
              },

              // Style for footer
              "& .MuiDataGrid-footerContainer": {
                borderTop: "1px solid #e0e0e0",
              },

              // Style for cell focus
              "& .MuiDataGrid-cell:focus-within": {
                outline: "none !important",
              },

              // Filter and column management styles - change blue to #810055
              "& .MuiDataGrid-filterForm": {
                "& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                  {
                    borderColor: "#810055",
                  },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#810055",
                },
                "& .MuiInputBase-input:focus": {
                  boxShadow: "0 0 0 0.2rem rgba(129, 0, 85, 0.25)",
                },
                "& .MuiSelect-select:focus": {
                  backgroundColor: "rgba(129, 0, 85, 0.05)",
                },
                "& .MuiButton-contained": {
                  backgroundColor: "#810055",
                  "&:hover": {
                    backgroundColor: "#6a0046",
                  },
                },
              },

              // Column menu panel styles
              "& .MuiDataGrid-panel": {
                "& .MuiButtonBase-root.Mui-selected": {
                  backgroundColor: "rgba(129, 0, 85, 0.08)",
                  color: "#810055",
                },
                "& .MuiButtonBase-root:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04)",
                },
                "& .MuiSwitch-root .MuiSwitch-switchBase.Mui-checked": {
                  color: "#810055",
                },
                "& .MuiSwitch-root .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                  {
                    backgroundColor: "#810055",
                  },
              },

              // Filter icon color
              "& .MuiDataGrid-iconButtonContainer .MuiIconButton-root": {
                color: "rgba(0, 0, 0, 0.54)",
                "&:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04)",
                },
              },
              "& .MuiDataGrid-filterIcon": {
                color: "#810055",
              },

              // Active filter icon color
              "& .MuiDataGrid-columnHeader--filtered .MuiDataGrid-filterIcon": {
                color: "#810055",
              },

              // Search box styles - comprehensive targeting
              "& .MuiDataGrid-toolbarQuickFilter": {
                "& .MuiInputBase-root": {
                  "&.Mui-focused": {
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055",
                    },
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#810055",
                },
                "& .MuiInputBase-input:focus": {
                  boxShadow: "0 0 0 0.2rem rgba(129, 0, 85, 0.25)",
                },
              },

              // Quick filter icon color
              "& .MuiDataGrid-toolbarQuickFilter .MuiSvgIcon-root": {
                color: "rgba(0, 0, 0, 0.54)",
              },

              // Quick filter clear button
              "& .MuiDataGrid-toolbarQuickFilter .MuiIconButton-root": {
                color: "rgba(0, 0, 0, 0.54)",
                "&:hover": {
                  backgroundColor: "rgba(129, 0, 85, 0.04)",
                },
              },

              // Search results highlight
              "& .MuiDataGrid-cell.MuiDataGrid-cell--highlighted": {
                backgroundColor: "rgba(129, 0, 85, 0.08)",
              },

              // Global input styles for all inputs in DataGrid
              "& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                {
                  borderColor: "#810055",
                },
              "& .MuiInputLabel-root.Mui-focused": {
                color: "#810055",
              },

              // Target all search fields in the DataGrid
              "& .MuiTextField-root .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                {
                  borderColor: "#810055",
                },
              "& .MuiTextField-root .MuiInputLabel-root.Mui-focused": {
                color: "#810055",
              },

              // Target the search icon specifically
              "& .MuiInputAdornment-root .MuiSvgIcon-root": {
                color: "rgba(0, 0, 0, 0.54)",
              },

              // Target any search input in any panel
              "& .MuiDataGrid-panel .MuiTextField-root .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                {
                  borderColor: "#810055",
                },
              "& .MuiDataGrid-panel .MuiTextField-root .MuiInputLabel-root.Mui-focused":
                {
                  color: "#810055",
                },
            }}
            slotProps={{
              // ... [previous slotProps remain unchanged]

              toolbar: {
                sx: {
                  "& .MuiButtonBase-root": {
                    color: "rgba(0, 0, 0, 0.54)",
                    "&:hover": {
                      backgroundColor: "rgba(129, 0, 85, 0.04)",
                    },
                  },
                  // Search box in toolbar
                  "& .MuiInputBase-root": {
                    "&.Mui-focused": {
                      "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                    },
                  },
                  "& .MuiInputLabel-root.Mui-focused": {
                    color: "#810055",
                  },
                  // Quick filter specific styles
                  "& .MuiDataGrid-toolbarQuickFilter": {
                    "& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                      {
                        borderColor: "#810055",
                      },
                    "& .MuiInputBase-root .MuiOutlinedInput-notchedOutline": {
                      borderColor: "rgba(0, 0, 0, 0.23)",
                      "&:hover": {
                        borderColor: "rgba(129, 0, 85, 0.5)",
                      },
                    },
                    "& .MuiFormLabel-root.Mui-focused": {
                      color: "#810055",
                    },
                  },
                },
              },

              quickFilterPanel: {
                sx: {
                  "& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                    {
                      borderColor: "#810055",
                    },
                  "& .MuiInputLabel-root.Mui-focused": {
                    color: "#810055",
                  },
                },
              },

              // Style all panels that might contain search inputs
              panel: {
                sx: {
                  // Target all checkboxes in any panel
                  "& .MuiCheckbox-root": {
                    color: "rgba(0, 0, 0, 0.54)",
                    "&.Mui-checked": {
                      color: "#810055",
                    },
                    "& .MuiSvgIcon-root": {
                      color: "inherit",
                    },
                  },

                  // Target all text fields in any panel
                  "& .MuiTextField-root .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                    {
                      borderColor: "#810055",
                    },
                  "& .MuiTextField-root .MuiInputLabel-root.Mui-focused": {
                    color: "#810055",
                  },

                  // Other panel styles
                  "& .MuiButtonBase-root": {
                    color: "rgba(0, 0, 0, 0.87)",
                    "&.Mui-selected, &.Mui-selected:hover": {
                      color: "#810055",
                      backgroundColor: "rgba(129, 0, 85, 0.12)",
                    },
                    "&:hover": {
                      backgroundColor: "rgba(129, 0, 85, 0.04)",
                    },
                  },
                  "& .MuiDataGrid-panelHeader": {
                    color: "#810055",
                  },
                  "& .MuiSwitch-root .MuiSwitch-switchBase.Mui-checked": {
                    color: "#810055",
                  },
                  "& .MuiSwitch-root .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                    {
                      backgroundColor: "#810055",
                      opacity: 0.5,
                    },
                  "& .MuiDataGrid-filterForm .MuiFormControl-root .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                    {
                      borderColor: "#810055",
                    },
                  "& .MuiDataGrid-filterForm .MuiFormControl-root .MuiInputLabel-root.Mui-focused":
                    {
                      color: "#810055",
                    },
                  "& .MuiDataGrid-filterForm .MuiButton-root": {
                    color: "#810055",
                  },
                },
              },
            }}
            // Override the default checkbox color at the component level
            componentsProps={{
              baseCheckbox: {
                sx: {
                  color: "rgba(0, 0, 0, 0.54)",
                  "&.Mui-checked": {
                    color: "#810055",
                  },
                  "& .MuiSvgIcon-root": {
                    color: "inherit",
                  },
                },
              },
              baseTextField: {
                // Style all text fields in the DataGrid
                sx: {
                  "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline":
                    {
                      borderColor: "#810055",
                    },
                  "& .MuiInputLabel-root.Mui-focused": {
                    color: "#810055",
                  },
                },
              },
            }}
            // Add quickFilterProps to style the quick filter input
            quickFilterProps={{
              debounceMs: 300,
              sx: {
                "& .MuiInputBase-root": {
                  "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#810055",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "rgba(129, 0, 85, 0.5)",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#810055",
                },
                "& .MuiSvgIcon-root": {
                  color: "rgba(0, 0, 0, 0.54)",
                },
              },
              InputProps: {
                sx: {
                  "&.Mui-focused": {
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055",
                    },
                  },
                },
              },
            }}
          />
        </div>
      </CardContent>
    </Card>
  );
}
