import React from 'react';
import {
    Box,
    Typography,
    Button,
    Stack,
    Paper,
    Divider,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    ListItemButton,
    TextField,
    InputAdornment,
    Collapse
} from '@mui/material';
import {
    CloudUpload,
    SquareFoot,
    Flip,
    LocationSearching,
    Settings,
    PrecisionManufacturing,
    ViewInAr
} from '@mui/icons-material';

const Sidebar = ({
    onFileUpload,
    viewMode,
    setViewMode,
    hierarchy,
    selectedId,
    setSelectedId,
    componentsData,
    onUpdateProperty
}) => {
    const views = [
        { id: '3d', label: '3D View', icon: <ViewInAr /> },
        { id: 'top', label: 'Top', icon: <SquareFoot /> },
        { id: 'front', label: 'Front', icon: <Flip /> },
        { id: 'side', label: 'Side', icon: <Flip sx={{ transform: 'rotate(90deg)' }} /> },
    ];

    return (
        <Box sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column', gap: 2, bgcolor: 'background.paper', overflowY: 'auto' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <LocationSearching color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 800 }}>CAD ANALYZER</Typography>
            </Box>

            <Paper variant="outlined" sx={{ p: 2, textAlign: 'center', bgcolor: '#fcfcfc', borderRadius: 2 }}>
                <Button
                    variant="contained"
                    component="label"
                    startIcon={<CloudUpload />}
                    fullWidth
                    disableElevation
                    sx={{ py: 1, textTransform: 'none', fontWeight: 600, borderRadius: 1.5 }}
                >
                    Upload GLB
                    <input type="file" accept=".glb" hidden onChange={onFileUpload} />
                </Button>
            </Paper>

            <Divider />

            {/* View Selection */}
            <Box>
                <Typography variant="overline" sx={{ fontWeight: 700, ml: 1, color: 'text.secondary' }}>Views</Typography>
                <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                    {views.map((view) => (
                        <Button
                            key={view.id}
                            size="small"
                            variant={viewMode === view.id ? 'contained' : 'outlined'}
                            onClick={() => setViewMode(view.id)}
                            sx={{ minWidth: 0, flexGrow: 1, px: 0, py: 1, borderRadius: 1.5, textTransform: 'none' }}
                            title={view.label}
                        >
                            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5 }}>
                                {view.icon}
                                <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>{view.label}</Typography>
                            </Box>
                        </Button>
                    ))}
                </Stack>
            </Box>

            <Divider />

            {/* Components Hierarchy with Inline Property Editor */}
            <Box sx={{ flexGrow: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
                <Typography variant="overline" sx={{ fontWeight: 700, ml: 1, color: 'text.secondary' }}>Components ({hierarchy.length})</Typography>
                <List sx={{ mt: 1, overflowY: 'auto', flexGrow: 1, border: '1px solid #eee', borderRadius: 2, bgcolor: '#fafafa' }}>
                    {hierarchy.length > 0 ? hierarchy.map((item) => {
                        const isSelected = selectedId === item.id;
                        const data = componentsData[item.id] || { widthScale: 1, heightScale: 1, depthScale: 1, thicknessScale: 1 };

                        return (
                            <React.Fragment key={item.id}>
                                <ListItem disablePadding>
                                    <ListItemButton
                                        selected={isSelected}
                                        onClick={() => setSelectedId(isSelected ? null : item.id)}
                                        sx={{
                                            py: 1,
                                            borderLeft: isSelected ? '4px solid' : '0px solid',
                                            borderColor: 'primary.main',
                                            '&.Mui-selected': { bgcolor: 'primary.light', color: 'primary.contrastText', '&:hover': { bgcolor: 'primary.light' } }
                                        }}
                                    >
                                        <ListItemIcon sx={{ minWidth: 32, color: 'inherit' }}>
                                            <PrecisionManufacturing fontSize="small" />
                                        </ListItemIcon>
                                        <ListItemText
                                            primary={item.name}
                                            primaryTypographyProps={{ variant: 'caption', fontWeight: 800, noWrap: true }}
                                        />
                                    </ListItemButton>
                                </ListItem>

                                <Collapse in={isSelected} timeout="auto" unmountOnExit>
                                    <Box sx={{ p: 2, bgcolor: '#ffffff', borderBottom: '1px solid #eee' }}>
                                        <Stack spacing={2}>
                                            <PropertyField
                                                label="Width (X)"
                                                value={data.widthScale}
                                                onChange={(v) => onUpdateProperty(item.id, 'widthScale', v)}
                                            />
                                            <PropertyField
                                                label="Depth (Y)"
                                                value={data.depthScale}
                                                onChange={(v) => onUpdateProperty(item.id, 'depthScale', v)}
                                            />
                                            <PropertyField
                                                label="Height (Z)"
                                                value={data.heightScale}
                                                onChange={(v) => onUpdateProperty(item.id, 'heightScale', v)}
                                            />
                                            <PropertyField
                                                label="Thickness"
                                                value={data.thicknessScale || 1}
                                                onChange={(v) => onUpdateProperty(item.id, 'thicknessScale', v)}
                                            />
                                        </Stack>
                                    </Box>
                                </Collapse>
                            </React.Fragment>
                        );
                    }) : (
                        <Typography variant="caption" sx={{ p: 2, display: 'block', textAlign: 'center', opacity: 0.5 }}>No components found</Typography>
                    )}
                </List>
            </Box>

            <Typography variant="caption" sx={{ opacity: 0.5, textAlign: 'center', fontWeight: 600 }}>
                v1.1.0
            </Typography>
        </Box>
    );
};

const PropertyField = ({ label, value, onChange }) => (
    <TextField
        label={label}
        type="number"
        size="small"
        variant="standard"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 1)}
        fullWidth
        inputProps={{ step: 0.1 }}
        sx={{
            '& .MuiInputBase-root': { fontSize: '0.7rem' },
            '& .MuiInputLabel-root': { fontSize: '0.7rem' }
        }}
    />
);

export default Sidebar;
