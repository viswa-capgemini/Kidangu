import React, { useEffect, useRef } from 'react';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

const Model = ({ url, onDimensionsUpdate, onHierarchyUpdate, componentsData, selectedId }) => {
    const { scene } = useGLTF(url);
    const groupRef = useRef();

    useEffect(() => {
        if (scene) {
            const meshes = [];
            scene.traverse((node) => {
                if (node.isMesh) {
                    meshes.push({
                        id: node.uuid,
                        name: node.name || 'Component',
                        type: node.type
                    });

                    // Highlight selected node
                    if (selectedId === node.uuid) {
                        node.material.emissive = new THREE.Color(0x00ccff);
                        node.material.emissiveIntensity = 0.5;
                    } else {
                        if (node.material.emissive) {
                            node.material.emissive = new THREE.Color(0x000000);
                            node.material.emissiveIntensity = 0;
                        }
                    }

                    // Apply individual component scaling from componentsData
                    if (componentsData && componentsData[node.uuid]) {
                        const data = componentsData[node.uuid];
                        node.scale.set(
                            data.widthScale || 1,
                            data.heightScale || 1,
                            data.depthScale || 1
                        );
                        // Thickness could be mapped to an axis, assuming Z for now if not specified
                        if (data.thicknessScale) {
                            node.scale.z *= data.thicknessScale;
                        }
                    } else {
                        node.scale.set(1, 1, 1);
                    }
                }
            });

            // Report hierarchy back to parent
            if (onHierarchyUpdate) {
                onHierarchyUpdate(meshes);
            }

            // Calculate bounding box of the whole scene 
            const box = new THREE.Box3().setFromObject(scene);
            const size = new THREE.Vector3();
            box.getSize(size);

            onDimensionsUpdate({
                width: size.x,
                height: size.y,
                depth: size.z
            });

            // Center the model base on current scaled state
            const center = new THREE.Vector3();
            box.getCenter(center);
            scene.position.x = -center.x;
            scene.position.y = -center.y;
            scene.position.z = -center.z;
        }
    }, [scene, onDimensionsUpdate, onHierarchyUpdate, componentsData, selectedId]);

    return (
        <group ref={groupRef}>
            <primitive object={scene} dispose={null} />
        </group>
    );
};

export default Model;
