import React, { Suspense, useEffect, useState, useRef } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import {
    OrbitControls,
    Stage,
    OrthographicCamera,
    Grid,
    Environment,
    Html
} from '@react-three/drei';
import Model from './Model';
import { Box, Typography } from '@mui/material';
import * as THREE from 'three';

const Viewport = ({ file, viewMode, onDimensionsUpdate, onHierarchyUpdate, componentsData, selectedId }) => {
    const [modelDimensions, setModelDimensions] = useState(null);

    const handleDimensions = React.useCallback((dims) => {
        setModelDimensions(dims);
        onDimensionsUpdate(dims);
    }, [onDimensionsUpdate]);

    const handleHierarchy = React.useCallback((meshes) => {
        onHierarchyUpdate(meshes);
    }, [onHierarchyUpdate]);

    const is3D = viewMode === '3d';

    return (
        <Box sx={{ width: '100%', height: '100%', position: 'relative' }}>
            {!file && (
                <Box sx={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    zIndex: 1,
                    textAlign: 'center'
                }}>
                    <Typography variant="h6" sx={{ color: 'text.secondary' }}>
                        Upload a model to visualize views
                    </Typography>
                </Box>
            )}

            <Canvas shadows dpr={[1, 2]}>
                {is3D ? (
                    <perspectiveCamera makeDefault position={[5, 5, 5]} fov={50} />
                ) : (
                    <OrthographicCamera makeDefault position={[0, 0, 10]} zoom={50} />
                )}

                <CameraController viewMode={viewMode} />

                <Suspense fallback={null}>
                    <Stage environment="warehouse" intensity={0.5} contactShadow={false} adjustCamera={true}>
                        <group>
                            {file && (
                                <Model
                                    url={file}
                                    onDimensionsUpdate={handleDimensions}
                                    onHierarchyUpdate={handleHierarchy}
                                    componentsData={componentsData}
                                    selectedId={selectedId}
                                />
                            )}
                        </group>
                    </Stage>
                    {modelDimensions && !is3D && <DimensionLines dimensions={modelDimensions} viewMode={viewMode} />}
                </Suspense>

                <Grid
                    infiniteGrid
                    fadeDistance={50}
                    sectionSize={1}
                    colorCell="#e0e0e0"
                    visible={!is3D}
                />
                <ambientLight intensity={0.5} />
                <pointLight position={[10, 10, 10]} />
            </Canvas>
        </Box>
    );
};

const DimensionLines = ({ dimensions, viewMode }) => {
    const { width, height, depth } = dimensions;
    const padding = 0.5;

    // X-axis (Width)
    const renderWidth = (['top', 'front'].includes(viewMode));
    // Y-axis (Height)
    const renderHeight = (['front', 'side'].includes(viewMode));
    // Z-axis (Depth/Length)
    const renderDepth = (viewMode === 'side');

    return (
        <group>
            {renderWidth && (
                <group position={[0, -height / 2 - padding, 0]}>
                    <line>
                        <bufferGeometry attach="geometry" {...new THREE.BufferGeometry().setFromPoints([
                            new THREE.Vector3(-width / 2, 0, 0),
                            new THREE.Vector3(width / 2, 0, 0)
                        ])} />
                        <lineBasicMaterial attach="material" color="#2c3e50" linewidth={2} />
                    </line>
                    <Html center>
                        <div style={{ background: 'white', padding: '2px 6px', border: '1px solid #2c3e50', fontSize: '10px', fontWeight: 'bold' }}>
                            W: {width.toFixed(2)}
                        </div>
                    </Html>
                </group>
            )}

            {renderHeight && (
                <group position={[width / 2 + padding, 0, 0]}>
                    <line disablePointerEvents>
                        <bufferGeometry attach="geometry" {...new THREE.BufferGeometry().setFromPoints([
                            new THREE.Vector3(0, -height / 2, 0),
                            new THREE.Vector3(0, height / 2, 0)
                        ])} />
                        <lineBasicMaterial attach="material" color="#2c3e50" linewidth={2} />
                    </line>
                    <Html center>
                        <div style={{ background: 'white', padding: '2px 6px', border: '1px solid #2c3e50', fontSize: '10px', fontWeight: 'bold' }}>
                            H: {height.toFixed(2)}
                        </div>
                    </Html>
                </group>
            )}

            {renderDepth && (
                <group position={[0, -height / 2 - padding, 0]}>
                    <line>
                        <bufferGeometry attach="geometry" {...new THREE.BufferGeometry().setFromPoints([
                            new THREE.Vector3(0, 0, -depth / 2),
                            new THREE.Vector3(0, 0, depth / 2)
                        ])} />
                        <lineBasicMaterial attach="material" color="#2c3e50" linewidth={2} />
                    </line>
                    <Html center>
                        <div style={{ background: 'white', padding: '2px 6px', border: '1px solid #2c3e50', fontSize: '10px', fontWeight: 'bold' }}>
                            D: {depth.toFixed(2)}
                        </div>
                    </Html>
                </group>
            )}
        </group>
    );
};

const CameraController = ({ viewMode }) => {
    const { camera } = useThree();
    const is3D = viewMode === '3d';

    useEffect(() => {
        const distance = 10;

        if (viewMode === 'top') {
            camera.position.set(0, distance, 0);
            camera.up.set(0, 0, -1);
        } else if (viewMode === 'front') {
            camera.position.set(0, 0, distance);
            camera.up.set(0, 1, 0);
        } else if (viewMode === 'side') {
            camera.position.set(distance, 0, 0);
            camera.up.set(0, 1, 0);
        } else if (viewMode === '3d') {
            camera.position.set(distance, distance, distance);
            camera.up.set(0, 1, 0);
        }

        camera.lookAt(0, 0, 0);
        camera.updateProjectionMatrix();
    }, [viewMode, camera]);

    return <OrbitControls
        enableRotate={is3D}
        makeDefault
        enableDamping
    />;
};

export default Viewport;
