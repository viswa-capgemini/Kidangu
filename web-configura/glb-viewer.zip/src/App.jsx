import React, { useState, useMemo } from 'react';
import {
  ThemeProvider,
  createTheme,
  CssBaseline,
  Box,
  Typography,
} from '@mui/material';
import Sidebar from './components/Sidebar';
import Viewport from './components/Viewport';

const lightTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#2c3e50',
    },
    background: {
      default: '#f8f9fa',
      paper: '#ffffff',
    },
    divider: '#e0e0e0',
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h5: {
      fontWeight: 700,
      color: '#2c3e50',
    },
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          border: '1px solid #e0e0e0',
          boxShadow: 'none',
        },
      },
    },
  },
});

function App() {
  const [file, setFile] = useState(null);
  const [dimensions, setDimensions] = useState(null);
  const [viewMode, setViewMode] = useState('front');
  const [hierarchy, setHierarchy] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [componentsData, setComponentsData] = useState({});

  // const [uprightHeight, setUprightHeight] = useState(5.01); 

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile && uploadedFile.name.endsWith('.glb')) {
      const url = URL.createObjectURL(uploadedFile);
      setFile(url);
      // Reset state for new file
      setHierarchy([]);
      setSelectedId(null);
      setComponentsData({});
    }
  };

  const updateComponentProperty = (id, key, value) => {
    setComponentsData(prev => ({
      ...prev,
      [id]: {
        ...prev[id] || { widthScale: 1, heightScale: 1, depthScale: 1, thicknessScale: 1 },
        [key]: value
      }
    }));
  };

  return (
    <ThemeProvider theme={lightTheme}>
      <CssBaseline />
      <Box sx={{ height: '100vh', width: '100vw', display: 'flex', overflow: 'hidden', bgcolor: 'background.default' }}>
        {/* Left Panel - Fixed Width Sidebar */}
        <Box sx={{ width: 350, minWidth: 350, height: '100%', borderRight: '1px solid', borderColor: 'divider', zIndex: 10 }}>
          <Sidebar
            onFileUpload={handleFileUpload}
            viewMode={viewMode}
            setViewMode={setViewMode}
            hierarchy={hierarchy}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            componentsData={componentsData}
            onUpdateProperty={updateComponentProperty}
          />
        </Box>

        {/* Right Panel - Expansive Viewport */}
        <Box sx={{ flexGrow: 1, height: '100%', position: 'relative', bgcolor: '#ffffff' }}>
          <Viewport
            file={file}
            viewMode={viewMode}
            onDimensionsUpdate={setDimensions}
            onHierarchyUpdate={setHierarchy}
            componentsData={componentsData}
            selectedId={selectedId}
          />
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;
