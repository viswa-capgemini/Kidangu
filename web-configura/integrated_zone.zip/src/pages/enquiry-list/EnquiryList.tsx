import React from "react";
import EnquirySearch from "./EnquirySearch";
import Button from "../../components/button/Button";
import UsersTable from "../../components/UsersTable";

const EnquiryList = () => {
  return (
    <>
      <div data-testid="enquiryListContainer" className="flex flex-row gap-4 m-6 justify-between items-center relative">
        <h1 data-testid="enquiryListHeader" className="text-company-purple text-4xl mt-0">Enquiry List</h1>
        <div className="relative">
          <EnquirySearch />
        </div>
        <Button id="enquiryListExportButton" className="btn-primary-32 flex items-center" label="Export" iconClass="icon-[ix--export]" />
      </div>
      <div>
        <UsersTable />
      </div>
    </>

  );
};

export default EnquiryList;
