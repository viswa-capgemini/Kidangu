import React, { useState, useContext } from "react";
import companyLogo from "../../assets/images/company-logo.png";
import ProductGroup from "../configuration-design/LayoutLeftPanel/ProductGroup";
import ComponentsSection from "./LayoutLeftPanel/ComponentsSection";
import SmartProductGroup from "./LayoutLeftPanel/SmartProductGroup";
import CollapseIcon from "../../assets/images/Component 186 – 3.svg";
import ExpandIcon from "../../assets/images/Component 191 – 3.svg";
import LayoutRightPanel from "./LayoutRightPanel";
import { LayoutContext } from "../../context/propertyPanelContext";
import Search from "../../components/search/Search";
import LayersSection from "./LayoutLeftPanel/LayersSection";

const NewLayoutLeftPanel = () => {
  const [isOpen, setIsOpen] = React.useState(true);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);

  const context = useContext(LayoutContext);
  if (!context)
    throw new Error("LayoutLeftPanel must be used within LayoutProvider");
  const { setSelectedItem } = context;

  const handleSearch = (query: string) => {
    console.log("Searching for:", query);
    // You can call an API or filter data here
  };

  return (
    // <CollapsibleWrapper>
    <div>
      {/* <div className="sticky top-0 z-10 bg-white shadow"> */}
      {/* Your header code here */}

      <div
        data-testid="leftPanelToggle"
        className={`relative flex justify-between ${isOpen
          ? "flex justify-between w-[160px] h-[35px]items-center bg-white"
          : "flex justify-start m-1"
          } `}
      >
        <button>
          {isOpen && (
            <span>
              <img
                data-testid="company-logo"
                src={companyLogo}
                alt="company Logo"
                className="h-8 w-auto pl-1"
              />
            </span>
          )}
        </button>
        <button
          data-testid="leftPanelToggleBtn"
          onClick={() => setIsOpen(!isOpen)}
          className={`px-3 ${isOpen ? "py-3" : "py-2"} border border-gray-100 rounded hover:bg-gray-300`}
        >
          {isOpen ? (
            // <img src={CollapseIcon} alt="Collapse" className="w-5 h-5" />
            <span className="icon-[icon-park-outline--expand-right] p-2"></span>
          ) : (
            // <img src={ExpandIcon} alt="Expand" className="w-5 h-5" />
            <span className="icon-[icon-park-outline--expand-left]"></span>
          )}
        </button>
      </div>
      {/* </div> */}
      {isOpen && (
        <div
          data-testid="leftPanelContainer"
          className="bg-gray-100 border-r border-gray-300 overflow-y-auto w-[160px] h-screen scrollbar-hide"
        >
          {/* <Search onSearch={handleSearch} /> */}
          <ProductGroup
            onSelect={(name) => setSelectedItem({ type: "product", name })}
          />
          <ComponentsSection />
          <SmartProductGroup />
          <LayersSection />
        </div>
      )}

      {/* Right Panel */}
      {selectedProduct && (
        <div
          data-testid="rightPanelWrapper"
          className=" flex flex-end w-1/4 bg-gray-50 border-l border-gray-300 p-4"
        >
          <LayoutRightPanel />
        </div>
      )}
    </div>
  );
};

export default NewLayoutLeftPanel;
