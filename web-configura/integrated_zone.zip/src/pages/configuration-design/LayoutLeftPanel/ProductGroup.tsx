import { PRODUCT_GROUPS } from "../../../constants/constants";
// import ProductGroupItem from "./ProductGroupItems";
import { useState } from "react";
import { type Product, type TreeNode } from "../../../types/products";
import Accordion from "../../../components/accordion/Accordion";
import { PRODUCT_GROUP_DATA } from "../../../constants/constants";
import ProductTree from "./ProductTree";

type ProductGroupProps = {
  onSelect: (nodeId: string) => void;
};

const ProductGroup: React.FC<ProductGroupProps> = ({ onSelect }) => {
  const data: TreeNode[] = PRODUCT_GROUP_DATA;

  return (
    <div>
    <Accordion title="Product Group" defaultOpen={true}>
      <ProductTree onSelect={onSelect} />
    </Accordion>
    </div>
  );
};

export default ProductGroup;
