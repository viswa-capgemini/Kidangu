import Box from '@mui/material/Box';
import type { TreeViewBaseItem } from '@mui/x-tree-view/models';
import { RichTreeView } from '@mui/x-tree-view/RichTreeView';

const MUI_X_PRODUCTS: TreeViewBaseItem[] = [
  {
    id: 'racking',
    label: 'Racking',
    children: [
      { id: 'selective-pallet-racking', 
        label: 'Selective Pallet racking',
        children: [
          { id: 'single-deep', label: 'Single Deep Pallet Racking' },
          { id: 'double-deep', label: 'Double Deep Pallet Racking' },
          { id: 'vna-racking', label: 'VNA Racking' },
        ],
      },
      { id: 'shuttle-pallet-racking', label: 'Shuttle Pallet racking' },
      { id: '4-way-shuttle', label: '4 Way Shuttle' },
    ],
  },
  {
    id: 'shelving',
    label: 'Shelving',
    children: [
      { id: 'single-tier',
        label: 'Single tier',
        children: [
          { id: 'st-short-span', label: 'Short Span' }, //st - single tier
          { id: 'st-long-span', label: 'Long Span' },
        ],
      },
      { id: 'multi-tier',
        label: 'Multi tier',
        children: [
          { id: 'mt-short-span', label: 'Short Span' }, //mt - multi tier
          { id: 'mt-long-span', label: 'Long Span' },
        ],
      },
      { id: 'mezzanine', label: 'Mezzanine' },
      { id: 'mobistack', label: 'Mobistack'
      },
    ],
  },
];

interface ProductTreeProps {
  onSelect: (nodeId: string) => void;
}

export default function ProductTree({ onSelect }: ProductTreeProps) {
  return (
    <Box
      sx={{
        // minHeight: 300,
        minWidth: 100,
        // reduce tree item label font-size; adjust value as needed
        '& .MuiTreeItem-content .MuiTreeItem-label': {
          fontSize: '0.8rem',
        },
        // tighten vertical padding
        '& .MuiTreeItem-root .MuiTreeItem-content': {
          paddingTop: '4px',
          paddingBottom: '4px',
        },
        // remove extra left padding on root items
        '& .MuiTreeItem-root': {
          paddingLeft: 0,
        },
        // reduce indentation for nested groups (controls subtree indent)
        '& .MuiTreeItem-group': {
          marginLeft: '4px', // adjust to 4px/12px as needed
        },
        // reduce icon container width/gap if present
        '& .MuiTreeItem-iconContainer': {
          minWidth: '8px',
        },
        // ensure the underlying TreeView doesn't clip expanded groups
        "& .MuiTreeView-root": {
          overflow: "visible",
        },
      }}
    >
      <RichTreeView
        items={MUI_X_PRODUCTS}
        onItemClick={(event, itemId) => {
          console.log('Selected Item ID:', itemId);
          onSelect(itemId);
        }}
      />
    </Box>
  );
}

