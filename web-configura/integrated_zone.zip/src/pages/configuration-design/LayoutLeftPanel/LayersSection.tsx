import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    Eye,
    EyeOff,
    Search,
} from 'lucide-react';
import { toggleLayerVisibility, setAllLayersVisibility, setSelectedLayer } from '../../../store/slices/dxfSlice';
import type { RootState } from '../../../store';
import Accordion from '../../../components/accordion/Accordion';

const LayersSection: React.FC = () => {
    const dispatch = useDispatch();
    const { data: dxfData, visibleLayers, selectedLayer } = useSelector((state: RootState) => state.dxf);
    const [searchTerm, setSearchTerm] = useState('');

    if (!dxfData || !dxfData.layers) return null;

    const filteredLayers = (dxfData.layers as any[]).filter(layer =>
        layer.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Accordion title="Layers" defaultOpen={true}>
            <div className="flex flex-col h-full overflow-hidden">
                <div className="mb-2">
                    <div className="relative">
                        <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-400" size={12} />
                        <input
                            type="text"
                            placeholder="Search layers..."
                            className="w-full bg-zinc-100 border-none rounded-md py-1.5 pl-8 pr-2 text-xs focus:ring-1 focus:ring-brand"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <div className="flex justify-between mt-3 text-[10px] font-bold text-gray-500 uppercase px-1">
                        <button onClick={() => dispatch(setAllLayersVisibility(true))} className="hover:text-company-purple transition-colors">Show All</button>
                        <button onClick={() => dispatch(setAllLayersVisibility(false))} className="hover:text-company-purple transition-colors">Hide All</button>
                    </div>
                </div>

                <div className="overflow-y-auto space-y-0.5 max-h-[300px] scrollbar-hide">
                    {filteredLayers.map((layer) => (
                        <div
                            key={layer.name}
                            onClick={() => dispatch(setSelectedLayer(layer))}
                            className={`
                                group flex items-center gap-2 p-1.5 px-2 rounded-md cursor-pointer transition-all duration-150
                                ${selectedLayer?.name === layer.name
                                    ? 'bg-company-purple/10 text-company-purple'
                                    : 'hover:bg-zinc-100'
                                }
                            `}
                        >
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    dispatch(toggleLayerVisibility(layer.name));
                                }}
                                className="transition-colors hover:text-company-purple"
                            >
                                {visibleLayers.includes(layer.name) ? <Eye size={14} /> : <EyeOff size={14} className="opacity-30" />}
                            </button>

                            <div
                                className="w-2.5 h-2.5 rounded-sm border border-black/10 shrink-0"
                                style={{ backgroundColor: layer.rgb_color }}
                            />

                            <span className="flex-1 truncate text-xs font-medium">
                                {layer.name}
                            </span>

                            <span className="text-[10px] text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity">
                                {layer.entity_count}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </Accordion>
    );
};

export default LayersSection;
