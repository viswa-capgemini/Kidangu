
import React from "react";
import Accordion from "../../../components/accordion/Accordion";

const ConfigurationSummary: React.FC = () => {
  const summaryData = [
    { label: "Total Area", value: "10,000 sqm" },
    { label: "Utilized Area", value: "20%" },
    { label: "Material Tonnage", value: "500MT" },
    { label: "No of product group", value: "2" },
    { label: "No of Components", value: "25" },
    { label: "No of Smart Product Group", value: "11" },
  ];

  return (
    <Accordion title="Configuration Summary" defaultOpen={false}>
      <div className="grid grid-cols-2 gap-y-2 px-2">
        {summaryData.map((item, index) => (
          <React.Fragment key={index}>
            <div className="text-[12px] text-gray-600">{item.label}</div>
            <div className="text-right text-[12px]">{item.value}</div>
          </React.Fragment>
        ))}
      </div>
    </Accordion>
  );
};

export default ConfigurationSummary;
