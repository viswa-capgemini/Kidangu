import React, { useState } from "react";

const MheForm: React.FC = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const options = [
    "Forklift/stacker",
    "Reach truck",
    "Stacker",
    "Articulated forklift",
  ];

  const handleCheckboxChange = (item: string) => {
    setSelected((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  return (
    <div className="p-4 bg-gray-100 rounded shadow-md w-full max-w-lg">

      {/* Checkbox Group */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        {options.map((item) => (
          <label key={item} className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selected.includes(item)}
              onChange={() => handleCheckboxChange(item)}
              className="w-4 h-4 border-gray-400 rounded"
            />
            <span>{item}</span>
          </label>
        ))}
      </div>

      {/* Debug Selected */}
      <div className="mt-4 text-xs text-gray-600">
        Selected: {selected.join(", ") || "None"}
      </div>
    </div>
  );
};

export default MheForm;