import React from 'react'
import Accordion from "../../../components/accordion/Accordion";

const MHETable = () => {
  return (
    <Accordion title="Configuration Summary" defaultOpen={false}>
        <div>MHE Details</div>
    </Accordion>
  )
}

export default MHETable;
