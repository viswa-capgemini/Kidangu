import React, { useState } from "react";
import LayoutLeftPanel from "./LayoutLeftPanel";
import LayoutRightPanel from "./LayoutRightPanel";

const ConfigurationLayout = () => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);

  const handleNodeSelect = (nodeId: string) => {
    console.log("Node selected in ConfigurationLayout:", nodeId);
    setSelectedNode(nodeId);
    setRightPanelOpen(true);
  };

  const handleCloseRightPanel = () => {
    setRightPanelOpen(false);
    setSelectedNode(null);
  };

  return (
    <div className="flex justify-between h-full w-full">
      {/* LEFT PANEL */}
      <LayoutLeftPanel onSelect={handleNodeSelect} />

      {/* RIGHT PANEL */}
      {rightPanelOpen && (
        <LayoutRightPanel
          selectedNodeId={selectedNode}
          onClose={handleCloseRightPanel}
        />
      )}
    </div>
  );
};

export default ConfigurationLayout;