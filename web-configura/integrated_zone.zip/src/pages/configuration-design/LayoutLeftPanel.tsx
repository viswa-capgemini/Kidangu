import React, { useState } from "react";
import companyLogo from "../../assets/images/company-logo.png";
import ProductGroup from "./LayoutLeftPanel/ProductGroup";
import ComponentsSection from "./LayoutLeftPanel/ComponentsSection";
import SmartProductGroup from "./LayoutLeftPanel/SmartProductGroup";

interface LayoutLeftPanelProps {
  onSelect: (nodeId: string) => void;
}

const LayoutLeftPanel: React.FC<LayoutLeftPanelProps> = ({ onSelect }) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className={`${isOpen ? "w-[160px]" : "w-auto"} bg-white flex-shrink-0`}>
      <div
        data-testid="leftPanelToggle"
        className={`sticky top-0 z-10 flex justify-between ${isOpen
            ? "w-[160px] h-[50px] items-center bg-white"
            : "flex justify-start m-1"
          }`}
      >
        <button>
          {isOpen && (
            <span>
              <img
                data-testid="company-logo"
                src={companyLogo}
                alt="company Logo"
                className="h-8 w-auto pl-1"
              />
            </span>
          )}
        </button>

        <button
          data-testid="leftPanelToggleBtn"
          onClick={() => setIsOpen(!isOpen)}
          className={`px-3 ${isOpen ? "py-3" : "py-2"
            } border border-gray-100 rounded hover:bg-gray-300`}
          aria-label={isOpen ? "Collapse left panel" : "Expand left panel"}
        >
          {isOpen ? (
            <span className="icon-[icon-park-outline--expand-right] p-2" />
          ) : (
            <span className="inline-flex items-center space-x-1">
              <span className="icon-[icon-park-outline--expand-left]" />
              <img
                data-testid="company-logo"
                src={companyLogo}
                alt="company Logo"
                className="h-8 w-auto"
              />
            </span>
          )}
        </button>
      </div>

      {isOpen && (
        <div
          data-testid="leftPanelContainer"
          className="bg-gray-100 border-r border-gray-300 overflow-y-auto w-[160px] h-screen scrollbar-hide"
        >
          <ProductGroup onSelect={onSelect} />
          <ComponentsSection />
          <SmartProductGroup />
        </div>
      )}
    </div>
  );
};

export default LayoutLeftPanel;

//max-h-[calc(100vh-50px)]