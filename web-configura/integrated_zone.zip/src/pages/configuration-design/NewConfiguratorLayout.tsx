import React from "react";
import NewLayoutLeftPanel from "./NewLayoutLeftPanel";
import LayoutRightPanel from "./LayoutRightPanel";
import { LayoutProvider } from "../../context/propertyPanelContext";
import { useSelector } from "react-redux";
import type { RootState } from "../../store";
import Canvas from "../../components/new-configurations/Canvas/Canvas";
import Toolbar from "../../components/new-configurations/Toolbar/Toolbar";

const NewConfiguratorLayout: React.FC = () => {
  const { isImported } = useSelector((state: RootState) => state.dxf);

  return (
    <LayoutProvider>
      <div data-testid="configurationLayoutContainer" className="relative flex flex-row h-screen overflow-hidden bg-zinc-50 font-sans">
        {/* Left Panel */}
        <div className="h-full bg-white border-r border-gray-200 z-20">
          <NewLayoutLeftPanel />
        </div>

        {/* Main Content Area */}
        <div className="relative flex-1 flex flex-col h-full overflow-hidden">
          {/* DXF Canvas - Visible only after import */}
          {isImported ? (
            <div className="flex-1 w-full h-full relative">
              <Canvas />
              {/* Floating Toolbar */}
              <Toolbar />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-zinc-400 font-medium">
                Select a layout or import to begin
              </div>
            </div>
          )}
        </div>

        {/* Right Panel */}
        <div className="h-full bg-white border-l border-gray-200 z-20">
          <LayoutRightPanel onClose={() => { }} />
        </div>
      </div>
    </LayoutProvider>
  );
};

export default NewConfiguratorLayout;