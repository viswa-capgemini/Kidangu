import { Link, useLocation } from "react-router";
import { useAuth } from "../../context/AuthContext";
import { slugify } from "../../helper";
import leftPanelFields from "../../config/leftPanelFields";
import type { LeftField } from "../../config/leftPanelFields";

type LeftSidePanelProps = {
  showLabels: boolean;
  selectedKey: string | null;
  setShowLabels: (value: boolean) => void;
  setSelectedKey: (key: string) => void;
  isOpen: boolean;
  reducedLeftPan?: boolean;
};

const fields: LeftField[] = leftPanelFields;

const LeftSidePanel: React.FC<LeftSidePanelProps> = ({
  showLabels,
  setShowLabels,
  selectedKey,
  setSelectedKey,
  isOpen,
  reducedLeftPan
}) => {
  // const location = useLocation();
  // const reduceLeftSidePanel = ["/configuration-layout"];
  // const reducedLeftPan = reduceLeftSidePanel.includes(location.pathname);
  return (
    <div
      data-testid="left-side-container"
      className={`left-side-panel absolute top-0 left-0 h-screen z-10 bg-company-lite-purple text-white p-2 space-y-2 transition-all duration-300 ${showLabels || isOpen ? "w-50" : "w-10"
        } ${reducedLeftPan ? "top-[50px] h-[calc(100vh-50px)]" : "top-0 h-screen"}`}
      onMouseEnter={() => setShowLabels(true)}
      onMouseLeave={() => setShowLabels(false)}
    >
      {/* Hamburger icon only when reduced */}
      {/* {reducedLeftPan && (
        <div className="relative">
        <button >
        <span data-testid="hamburger-icon" className="icon-[solar--hamburger-menu-outline]"style={{color: "black"}}></span>
        </button>
        </div>
      )} */}

      <div data-testid="left-side-wrapper" className="flex flex-col space-y-4">
        {/* show only a subset for admin, full set for dealer */}
        {(() => {
          const { user } = useAuth();
          const visibleFields = user ? fields.filter((f) => f.roles.includes(user.role)) : [];
          return visibleFields.map((field) => (
            <button
              data-testid={`${field.label
                .toLocaleLowerCase()
                .replace(" ", "-")}-btn`}
              key={field.slug}
              className={`flex items-center space-x-3 py-2 transition-all duration-300 ${selectedKey === field.slug ? "text-company-purple" : "hover:bg-pink-100"
                }`}
              onClick={() => setSelectedKey(field.slug)}
            >
              <span
                className={`${field.iconClass} text-2xl shrink-0 ${selectedKey === field.slug ? "text-company-purple" : "text-black"
                  }`}
              ></span>

              {(showLabels || isOpen) && (
                <Link to={`${slugify(field.label)}`}>
                  <span
                    className={`text-sm font-medium whitespace-nowrap ${selectedKey === field.slug ? "text-company-purple" : "text-black"
                      }`}
                  >
                    {field.label}
                  </span>
                </Link>
              )}
            </button>
          ));
        })()}
      </div>
    </div>
  );
};

export default LeftSidePanel;
