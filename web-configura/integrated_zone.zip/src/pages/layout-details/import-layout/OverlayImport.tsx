import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../components/button/Button";
import Card from "../../../components/card/Card";
import { useDispatch, useSelector } from "react-redux";
import { uploadDxf, setUploadProgress, resetDxfState, setIsImported } from "../../../store/slices/dxfSlice";
import type { AppDispatch, RootState } from "../../../store";
import Canvas from "../../../components/new-configurations/Canvas/Canvas";
import Toolbar from "../../../components/new-configurations/Toolbar/Toolbar";
import Explorer from "../../../components/new-configurations/LayerPanel/LayerPanel";

const OverlayImport: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [viewMode, setViewMode] = useState<'UPLOAD' | 'PREVIEW'>('UPLOAD');
  const { loading, error } = useSelector((state: RootState) => state.dxf);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleImportClick = async () => {
    if (!selectedFile) {
      alert("Please select a file first");
      return;
    }

    try {
      await dispatch(uploadDxf({
        file: selectedFile,
        onProgress: (progress) => dispatch(setUploadProgress(progress))
      })).unwrap();

      setViewMode('PREVIEW');
    } catch (err) {
      console.error("Import failed:", err);
    }
  };

  const handleConfirmImport = () => {
    dispatch(setIsImported(true));
    // Reset internal view mode for next time the component is used
    setViewMode('UPLOAD');
    setSelectedFile(null);
    navigate('/layout-design');
  };

  const handleBackToUpload = () => {
    dispatch(resetDxfState());
    setViewMode('UPLOAD');
    setSelectedFile(null);
  };

  if (viewMode === 'PREVIEW') {
    return (
      <div className="fixed inset-0 z-[9999] bg-white flex flex-col overflow-hidden">
        {/* Top Header Bar */}
        <div className="h-14 border-b border-gray-200 flex items-center justify-between px-6 bg-white shadow-sm shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={handleBackToUpload}
              className="text-gray-500 hover:text-company-purple transition-colors p-2"
            >
              <span className="icon-[icon-park-outline--back] text-xl"></span>
            </button>
            <h2 className="text-company-purple font-semibold text-lg">DXF Layout Preview</h2>
          </div>

          <Button
            id="confirmImportBtn"
            label="Import the Layer"
            className="bg-company-purple text-white px-6 py-2 rounded-md shadow-md hover:bg-company-purple/90 transition-all font-medium"
            onClick={handleConfirmImport}
          />
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - DXF Explorer */}
          <div className="w-[280px] h-full border-r border-gray-200 bg-white shadow-sm overflow-hidden flex flex-col">
            <Explorer />
          </div>

          {/* Central Area - Canvas */}
          <div className="flex-1 relative bg-zinc-50 overflow-hidden">
            <Canvas />
            {/* Floating Toolbar */}
            <Toolbar />
          </div>
        </div>
      </div>
    );
  }

  return (
    <Card
      data-testid="overlayImportContainer"
      widthClassName="w-full" // responsive width; matches your original 400px cap
      heightClassName="h-full"  // auto on small screens, 320px on md+
      className="flex flex-col p-2 bg-white shadow-md rounded-lg"     // keep your original surface styling here
    >
      <h3
        data-testid="overlayImportHeader"
        className="text-company-purple text-xl font-semibold"
      >
        Import Layout
      </h3>

      {/* Upload input */}
      <div
        data-testid="overlayImportUpload"
        className="mt-4 border border-gray-300 w-full h-[30px] text-center cursor-pointer flex items-center group hover:border-company-purple transition-colors"
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept=".dxf,.dwg"
        />
        <input
          type="text"
          placeholder="Upload files"
          value={selectedFile ? selectedFile.name : ""}
          readOnly
          className="outline-none w-full h-full px-2 cursor-pointer text-sm text-gray-700 placeholder:text-gray-400"
        />
        <span className="icon-[mdi--upload] text-gray-400 group-hover:text-company-purple mr-2"></span>
      </div>

      <p
        data-testid="overlayImportUploadHelperText"
        className="text-gray-500 text-[10px] mt-1"
      >
        File size up to 15Mb, in .dwg, .dxf format
      </p>

      {error && (
        <p className="text-red-500 text-[10px] mt-2 italic">{error}</p>
      )}

      {/* Actions */}
      <div className="flex flex-row justify-center items-center mt-8 gap-4">
        <Button
          id="overlayImport-importBtn"
          className={`btn-primary-32 flex items-center transition-all px-6 py-2 rounded-md font-medium ${loading || !selectedFile ? 'opacity-50 bg-gray-400 text-white' : 'bg-company-purple text-white hover:bg-company-purple/90 shadow-md'}`}
          label={loading ? "Importing..." : "Import"}
          iconClass="icon-[mdi--import]"
          onClick={handleImportClick}
        />
      </div>

      <p
        data-testid="overlayImportHelperText"
        className="text-gray-500 text-[10px] mt-6 leading-tight"
      >
        Note: File may be component, product group, plan layout, smart product group
      </p>
    </Card>
  );
};

export default OverlayImport;