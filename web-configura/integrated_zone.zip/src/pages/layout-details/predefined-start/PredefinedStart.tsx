
import React, { useState } from "react";
import Card from "../../../components/card/Card";

type DimensionUnit = "M" | "Feet";

const PredefinedStart: React.FC = () => {
  const [unit, setUnit] = useState<DimensionUnit>("M");
  const [dimensions, setDimensions] = useState({
    length: "",
    width: "",
    height: "",
  });

  const [rackType, setRackType] = useState("Shuttle Pallet");
  const [mhe, setMhe] = useState("Forklift");
  const [sku, setSku] = useState("Box");
  const [accessory, setAccessory] = useState("");

  const [spg, setSpg] = useState({
    mensRoom: false,
    womensRoom: false,
    office: false,
    reception: false,
    conference: false,
    showroom: false,
  });

  const handleDimChange = (key: "length" | "width" | "height", val: string) => {
    // Only allow numbers and optional decimal
    const safe = val.replace(/[^\d.]/g, "");
    setDimensions((prev) => ({ ...prev, [key]: safe }));
  };

  const handleSpgToggle = (key: keyof typeof spg) => {
    setSpg((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleCreate = () => {
    // Collect the payload
    const payload = {
      unit,
      dimensions,
      rackType,
      mhe,
      sku,
      accessory,
      smartProductGroup: spg,
    };
    // TODO: wire up with your parent flow or API
    console.log("Create with:", payload);
    // You can emit an event, call a prop callback, etc.
  };

  return (
    <Card
      data-testid="predefinedStartContainer"
      widthClassName="w-full"
      heightClassName="h-full"
      className="flex flex-col p-4 bg-white shadow-md min-h-0"
    >
      {/* Title */}
      <h3
        data-testid="predefinedStartTitle"
        className="text-company-purple text-xl font-semibold"
      >
        Start from Pre-defined
      </h3>

      {/* Form body */}
      <div className="mt-3 space-y-4">
        {/* Dimension block */}
        <fieldset
          className="border border-gray-300 rounded-md p-3"
          aria-labelledby="dimensionLegend"
        >
          <legend
            id="dimensionLegend"
            className="px-1 text-sm text-gray-700"
          >
            Dimension
          </legend>

          {/* Unit toggle */}
          <div className="flex items-center gap-4 mb-3">
            {/* M */}
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="unit"
                value="M"
                checked={unit === "M"}
                onChange={() => setUnit("M")}
                className="accent-company-purple"
              />
              <span className="text-sm">M</span>
            </label>

            {/* Feet */}
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="unit"
                value="Feet"
                checked={unit === "Feet"}
                onChange={() => setUnit("Feet")}
                className="accent-company-purple"
              />
              <span className="text-sm">Feet</span>
            </label>
          </div>

          {/* L W H inputs */}
          <div className="grid grid-cols-3 gap-3">
            <div className="border border-gray-300 rounded-md h-[40px] flex items-center">
              <input
                data-testid="dimLength"
                type="text"
                inputMode="decimal"
                placeholder="Length"
                value={dimensions.length}
                onChange={(e) => handleDimChange("length", e.target.value)}
                className="w-full h-full px-3 outline-none"
                aria-label="Length"
              />
            </div>
            <div className="border border-gray-300 rounded-md h-[40px] flex items-center">
              <input
                data-testid="dimWidth"
                type="text"
                inputMode="decimal"
                placeholder="Width"
                value={dimensions.width}
                onChange={(e) => handleDimChange("width", e.target.value)}
                className="w-full h-full px-3 outline-none"
                aria-label="Width"
              />
            </div>
            <div className="border border-gray-300 rounded-md h-[40px] flex items-center">
              <input
                data-testid="dimHeight"
                type="text"
                inputMode="decimal"
                placeholder="Height"
                value={dimensions.height}
                onChange={(e) => handleDimChange("height", e.target.value)}
                className="w-full h-full px-3 outline-none"
                aria-label="Height"
              />
            </div>
          </div>
        </fieldset>

        {/* Rack Type */}
        <div className="border border-gray-300 rounded-md h-[48px] flex items-center px-3">
          <select
            data-testid="rackTypeSelect"
            value={rackType}
            onChange={(e) => setRackType(e.target.value)}
            className="w-full outline-none bg-transparent"
            aria-label="Rack Type"
          >
            <option>Shuttle Pallet</option>
            <option>Selective Pallet</option>
            <option>Drive-In</option>
            <option>Push Back</option>
          </select>
        </div>

        {/* MHE */}
        <div className="border border-gray-300 rounded-md h-[48px] flex items-center px-3">
          <select
            data-testid="mheSelect"
            value={mhe}
            onChange={(e) => setMhe(e.target.value)}
            className="w-full outline-none bg-transparent"
            aria-label="MHE Equipment"
          >
            <option>Forklift</option>
            <option>Reach Truck</option>
            <option>Stacker</option>
            <option>Pallet Jack</option>
          </select>
        </div>
      </div>
    </Card>
  );
};

export default PredefinedStart
