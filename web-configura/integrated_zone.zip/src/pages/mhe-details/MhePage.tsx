
import * as React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { theme } from "../../theme";
import {
  Box, Stack, Drawer, TextField, Button, IconButton,
  Snackbar, Alert, Typography, Tabs, Tab
} from '@mui/material';
import { DataGrid, GridToolbar, type GridColDef } from '@mui/x-data-grid';
import SaveAltIcon from '@mui/icons-material/SaveAlt';
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useState } from 'react';
import { fetchMhe, upsertMhe } from "../../services/api";
import { useAuth } from '../../context/AuthContext';


interface MheRow {
  id?: number;
  name?: string;
  picking_aisel_width_mm?: number;
  pallet_to_pallet_width_mm?: number;
  cross_aisle_width_mm?: number;
  end_aisle_width_mm?: number;
  capacity_kg?: number;
  max_loading_height_mm?: number;
  overall_height_lowered_mm?: number;
  straddle_outer_to_outer_mm?: number;
  straddle_height_mm?: number;
}

interface SnakeState {
  open: boolean;
  msg: string,
  sev: "success" | "error" | "info" | "warning"
}

const ATTR_COLUMNS: GridColDef<MheRow>[] = [
  { field: 'picking_aisle_width_mm', headerName: 'Picking aisle (mm)', type: 'number', width: 160, editable: true },
  { field: 'pallet_to_pallet_width_mm', headerName: 'Pallet↔Pallet (mm)', type: 'number', width: 170, editable: true },
  { field: 'cross_aisle_width_mm', headerName: 'Cross aisle (mm)', type: 'number', width: 160, editable: true },
  { field: 'end_aisle_width_mm', headerName: 'End aisle (mm)', type: 'number', width: 150, editable: true },
  { field: 'capacity_kg', headerName: 'Capacity (kg)', type: 'number', width: 150, editable: true },
  { field: 'max_loading_height_mm', headerName: 'Max loading (mm)', type: 'number', width: 170, editable: true },
  { field: 'overall_height_lowered_mm', headerName: 'Overall lowered (mm)', type: 'number', width: 180, editable: true },
  { field: 'straddle_outer_to_outer_mm', headerName: 'Straddle o-o (mm)', type: 'number', width: 170, editable: true },
  { field: 'straddle_height_mm', headerName: 'Straddle height (mm)', type: 'number', width: 170, editable: true },
];

export default function MhePage() {
  const { user, logout } = useAuth();
  console.log(user)
  const [rows, setRows] = useState<MheRow[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [query, setQuery] = useState<string>('');
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [current, setCurrent] = useState<MheRow | null>(null);
  const [snack, setSnack] = useState<SnakeState>({ open: false, msg: '', sev: 'success' });
  const [tab, setTab] = useState<number>(0);


  useEffect(() => {
    (async () => {
      try {

        const response = await fetchMhe();
        const list = response.mhe;
        const rowsWithId: MheRow[] = list.map((r, i) => ({ id: r.id ?? i + 1, ...r }));
        console.log("rowsWithId", rowsWithId)
        setRows(rowsWithId);
      } catch (e) {
        setSnack({ open: true, msg: 'Failed to load MHE', sev: 'error' });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const columns: GridColDef<MheRow>[] = [
    { field: 'id', headerName: 'ID', width: 70 },
    {
      field: 'name',
      headerName: 'MHE Name',
      width: 220,
      editable: true,
      renderCell: (params: any) => (
        <Stack direction="row" alignItems="center" spacing={1}>
          <Typography variant="body2">{params.value}</Typography>
          {user?.role == "admin" &&
            (<IconButton size="small" onClick={() => openDrawer(params.row)} aria-label="edit">
              <EditIcon fontSize="inherit" />
            </IconButton>)
          }

        </Stack>
      ),
    },
    ...ATTR_COLUMNS,
  ];




  const filteredRows = rows.filter(r =>
    (query ? (r.name?.toLowerCase().includes(query.toLowerCase())) : true)
  );

  const addRow = () => {
    const maxId = rows.reduce((m, r) => Math.max(m, r.id || 0), 0) + 1;
    const emptyAttrs = Object.fromEntries(ATTR_COLUMNS.map(c => [c.field, null]));
    const newRow = { id: maxId, name: `Custom${maxId}`, ...emptyAttrs };
    setRows(prev => [newRow, ...prev]);
    openDrawer(newRow);
  };



  const openDrawer = (row: MheRow) => { setCurrent(row); setDrawerOpen(true); };
  const closeDrawer = () => { setDrawerOpen(false); setCurrent(null); };





  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ p: 3, minHeight: "400px" }}>
        <h1 data-testid="enquiryListHeader" className="text-company-purple text-4xl mt-0">Existing MHE</h1>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="center" sx={{ mb: 2, mt: 4 }}>

          <TextField
            label="Search MHE"
            value={query}
            onChange={e => setQuery(e.target.value)}
            size="small"
          />
          <Button variant="contained" startIcon={<AddIcon />} onClick={addRow}>
            Add MHE
          </Button>
          <Button variant="outlined" startIcon={<SaveAltIcon />} >
            Export JSON
          </Button>
          <Button variant="outlined" color="secondary">
            Save to Backend
          </Button>
        </Stack>

        <Box sx={{ height: 520, width: '100%' }}>
          <DataGrid
            loading={loading}
            rows={filteredRows}
            columns={columns}
            checkboxSelection
            disableRowSelectionOnClick
            showToolbar
          />
        </Box>

        <Drawer anchor="right" open={drawerOpen} onClose={closeDrawer} PaperProps={{ sx: { width: 460 } }}>
          <Stack spacing={2} sx={{ p: 2 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Typography variant="h6">Edit MHE</Typography>
              <IconButton onClick={closeDrawer}><CloseIcon /></IconButton>
            </Stack>

            {current && (
              <>
                <Tabs value={tab} onChange={(e, v) => setTab(v)} aria-label="Edit tabs">
                  <Tab label="Details" />
                  <Tab label="Visualizer" />
                </Tabs>

                {tab === 0 && (
                  <Stack spacing={2} sx={{ mt: 1 }}>
                    <TextField
                      label="MHE Name"
                      value={current.name || ''}
                    />
                    {ATTR_COLUMNS.map(col => (
                      <TextField
                        key={col.field}
                        label={col.headerName}
                        type="number"
                        inputProps={{ min: 0 }}
                      />
                    ))}
                    <Stack direction="row" spacing={1}>
                      <Button variant="contained">Save</Button>
                      <Button variant="text" onClick={closeDrawer}>Cancel</Button>
                    </Stack>
                  </Stack>
                )}

                {tab === 1 && (
                  <Box sx={{ mt: 1 }}>
                    {/* <AisleVisualizer record={current} /> */}
                  </Box>
                )}
              </>
            )}
          </Stack>
        </Drawer>

        <Snackbar open={snack.open} autoHideDuration={3000} onClose={() => setSnack(s => ({ ...s, open: false }))}>
          <Alert severity={snack.sev} variant="filled">{snack.msg}</Alert>
        </Snackbar>
      </Box>
    </ThemeProvider>
  );
}
