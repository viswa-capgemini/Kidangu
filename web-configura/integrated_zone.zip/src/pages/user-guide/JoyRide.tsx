import React from 'react'

const JoyRide = () => {
  return (
    <div>
      
    </div>
  )
}

export default JoyRide
