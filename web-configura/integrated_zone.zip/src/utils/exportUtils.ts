/**
 * High-fidelity Vector Export Utilities (SVG/PDF)
 */

interface Point {
    x: number;
    y: number;
}

interface Geometry {
    type: string;
    start?: Point;
    end?: Point;
    center?: Point;
    radius?: number;
    start_angle?: number;
    end_angle?: number;
    points?: Point[];
    closed?: boolean;
    insert?: Point;
    text?: string;
    height?: number;
}

interface Entity {
    layer: string;
    color?: number;
    lineweight: number;
    geometry: Geometry;
}

interface Extents {
    min_x: number;
    max_x: number;
    min_y: number;
    max_y: number;
    width: number;
    height: number;
}

interface Layer {
    name: string;
    rgb_color: string;
}

interface DxfData {
    extents: Extents;
    entities: Entity[];
    layers: Layer[];
}

/**
 * Generate a standardized SVG string from DXF entities
 */
export function generateSVG(dxfData: DxfData | null, visibleLayers: Set<string>, theme: 'light' | 'dark' = 'light'): string | null {
    if (!dxfData || !dxfData.extents) return null;

    const { min_x, max_y, width, height } = dxfData.extents;
    const padding = 20;

    // SVG viewBox: minX minY width height
    // We flip Y because SVG is top-down and DXF is bottom-up
    const svgWidth = width + padding * 2;
    const svgHeight = height + padding * 2;

    let svg = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg width="${svgWidth}" height="${svgHeight}" viewBox="${min_x - padding} ${-max_y - padding} ${svgWidth} ${svgHeight}" xmlns="http://www.w3.org/2000/svg">
    <rect width="100%" height="100%" fill="${theme === 'dark' ? '#0B0E14' : '#FFFFFF'}" />
    <g transform="scale(1, -1)">`;

    dxfData.entities.forEach(entity => {
        if (!visibleLayers.has(entity.layer)) return;

        const geom = entity.geometry;
        const color = getSVGColor(entity.color, dxfData.layers, entity.layer, theme);
        const strokeWidth = (entity.lineweight > 0 ? entity.lineweight / 100 : 0.25);

        switch (geom.type) {
            case 'LINE':
                if (geom.start && geom.end) {
                    svg += `\n        <line x1="${geom.start.x}" y1="${geom.start.y}" x2="${geom.end.x}" y2="${geom.end.y}" stroke="${color}" stroke-width="${strokeWidth}" />`;
                }
                break;
            case 'CIRCLE':
                if (geom.center && geom.radius !== undefined) {
                    svg += `\n        <circle cx="${geom.center.x}" cy="${geom.center.y}" r="${geom.radius}" stroke="${color}" fill="none" stroke-width="${strokeWidth}" />`;
                }
                break;
            case 'ARC':
                if (geom.center && geom.radius !== undefined && geom.start_angle !== undefined && geom.end_angle !== undefined) {
                    const pathData = describeSVGArc(geom.center.x, geom.center.y, geom.radius, geom.start_angle, geom.end_angle);
                    svg += `\n        <path d="${pathData}" stroke="${color}" fill="none" stroke-width="${strokeWidth}" />`;
                }
                break;
            case 'LWPOLYLINE':
            case 'POLYLINE':
                if (geom.points && geom.points.length > 0) {
                    const pointsStr = geom.points.map(p => `${p.x},${p.y}`).join(' ');
                    svg += `\n        <polyline points="${pointsStr}" stroke="${color}" fill="none" stroke-width="${strokeWidth}" ${geom.closed ? 'fill-rule="nonzero"' : ''} />`;
                }
                break;
            case 'TEXT':
            case 'MTEXT':
                if (geom.insert) {
                    // Note: SVG text handles flipping differently. We un-flip it in a nested <g>
                    svg += `\n        <g transform="scale(1, -1) translate(0, ${-geom.insert.y * 2})">
            <text x="${geom.insert.x}" y="${geom.insert.y}" fill="${color}" font-family="Inter, Arial" font-size="${geom.height || 10}">${geom.text || ''}</text>
        </g>`;
                }
                break;
            default:
                break;
        }
    });

    svg += `\n    </g>\n</svg>`;
    return svg;
}

function getSVGColor(colorIndex: number | undefined, layers: Layer[], layerName: string, theme: 'light' | 'dark'): string {
    // Basic ACI mapping for SVG
    const ACI: Record<number, string> = {
        1: '#FF0000', 2: '#FFFF00', 3: '#00FF00', 4: '#00FFFF', 5: '#0000FF', 6: '#FF00FF', 7: theme === 'dark' ? '#FFFFFF' : '#000000'
    };

    if (colorIndex === 256 || colorIndex === undefined) {
        const layer = layers.find(l => l.name === layerName);
        return layer ? layer.rgb_color : (theme === 'dark' ? '#FFFFFF' : '#000000');
    }

    return ACI[colorIndex] || '#808080';
}

function describeSVGArc(x: number, y: number, radius: number, startAngle: number, endAngle: number): string {
    const start = polarToCartesian(x, y, radius, endAngle);
    const end = polarToCartesian(x, y, radius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    return [
        "M", start.x, start.y,
        "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(" ");
}

function polarToCartesian(centerX: number, centerY: number, radius: number, angleInDegrees: number): Point {
    const angleInRadians = (angleInDegrees * Math.PI) / 180.0;
    return {
        x: centerX + radius * Math.cos(angleInRadians),
        y: centerY + radius * Math.sin(angleInRadians)
    };
}

/**
 * Download a string as a file
 */
export function downloadFile(content: string, fileName: string, contentType: string): void {
    const a = document.createElement("a");
    const file = new Blob([content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(a.href);
}
