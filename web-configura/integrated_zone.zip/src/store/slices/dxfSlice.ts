import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { uploadDxfFile as uploadDxfApi } from '../../services/api';

export interface DxfState {
    data: any | null;
    loading: boolean;
    error: string | null;
    uploadProgress: number;
    visibleLayers: string[];
    selectedLayer: any | null;
    selectedEntity: any | null;
    selectedEntities: any[];
    blockedAreas: { x: number; y: number; width: number; height: number; id: string }[];
    isImported: boolean;
}

export const uploadDxf = createAsyncThunk(
    'dxf/upload',
    async ({ file, onProgress }: { file: File; onProgress?: (progress: number) => void }, { rejectWithValue }) => {
        try {
            const response = await uploadDxfApi(file, onProgress || (() => { }));
            return response;
        } catch (error: any) {
            return rejectWithValue(error.message || 'Failed to upload DXF file');
        }
    }
);

const initialState: DxfState = {
    data: null,
    loading: false,
    error: null,
    uploadProgress: 0,
    visibleLayers: [],
    selectedLayer: null,
    selectedEntity: null,
    selectedEntities: [],
    blockedAreas: [],
    isImported: false,
};

const dxfSlice = createSlice({
    name: 'dxf',
    initialState,
    reducers: {
        setDxfData: (state: DxfState, action: PayloadAction<any>) => {
            state.data = action.payload;
            state.visibleLayers = action.payload?.layers?.map((l: any) => l.name) || [];
            state.loading = false;
            state.error = null;
        },
        toggleLayerVisibility: (state: DxfState, action: PayloadAction<string>) => {
            const layerName = action.payload;
            if (state.visibleLayers.includes(layerName)) {
                state.visibleLayers = state.visibleLayers.filter(l => l !== layerName);
            } else {
                state.visibleLayers.push(layerName);
            }
        },
        setAllLayersVisibility: (state: DxfState, action: PayloadAction<boolean>) => {
            const visible = action.payload;
            if (visible && state.data) {
                state.visibleLayers = state.data.layers.map((l: any) => l.name);
            } else {
                state.visibleLayers = [];
            }
        },
        setSelectedLayer: (state: DxfState, action: PayloadAction<any | null>) => {
            state.selectedLayer = action.payload;
        },
        setSelectedEntity: (state: DxfState, action: PayloadAction<any | null>) => {
            state.selectedEntity = action.payload;
            if (action.payload) {
                state.selectedEntities = [action.payload];
            } else {
                state.selectedEntities = [];
            }
        },
        toggleSelectedEntity: (state: DxfState, action: PayloadAction<any>) => {
            const entity = action.payload;
            if (!entity) return;

            const index = state.selectedEntities.findIndex(e => e.handle === entity.handle);
            if (index >= 0) {
                state.selectedEntities.splice(index, 1);
            } else {
                state.selectedEntities.push(entity);
            }
            state.selectedEntity = state.selectedEntities[state.selectedEntities.length - 1] || null;
        },
        clearSelection: (state: DxfState) => {
            state.selectedEntity = null;
            state.selectedEntities = [];
        },
        deleteSelectedEntities: (state: DxfState) => {
            if (!state.data || !state.data.entities) return;
            const handlesToRemove = new Set(state.selectedEntities.map(e => e.handle));
            state.data.entities = state.data.entities.filter((e: any) => !handlesToRemove.has(e.handle));
            state.selectedEntities = [];
            state.selectedEntity = null;
        },
        addBlockedArea: (state: DxfState, action: PayloadAction<{ x: number; y: number; width: number; height: number }>) => {
            state.blockedAreas.push({
                ...action.payload,
                id: crypto.randomUUID()
            });
        },
        removeBlockedArea: (state: DxfState, action: PayloadAction<string>) => {
            state.blockedAreas = state.blockedAreas.filter(area => area.id !== action.payload);
        },
        setUploadProgress: (state: DxfState, action: PayloadAction<number>) => {
            state.uploadProgress = action.payload;
        },
        setIsImported: (state: DxfState, action: PayloadAction<boolean>) => {
            state.isImported = action.payload;
        },
        resetDxfState: () => {
            return initialState;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(uploadDxf.pending, (state: DxfState) => {
                state.loading = true;
                state.error = null;
                state.uploadProgress = 0;
            })
            .addCase(uploadDxf.fulfilled, (state: DxfState, action: PayloadAction<any>) => {
                state.data = action.payload;
                state.visibleLayers = (action.payload.layers || []).map((l: any) => l.name);
                state.loading = false;
                state.uploadProgress = 100;
            })
            .addCase(uploadDxf.rejected, (state: DxfState, action: PayloadAction<any>) => {
                state.loading = false;
                state.error = action.payload as string;
            });
    },
});

export const {
    setDxfData,
    toggleLayerVisibility,
    setAllLayersVisibility,
    setSelectedLayer,
    setSelectedEntity,
    toggleSelectedEntity,
    clearSelection,
    setUploadProgress,
    setIsImported,
    resetDxfState,
    deleteSelectedEntities,
    addBlockedArea,
    removeBlockedArea,
} = dxfSlice.actions;

export default dxfSlice.reducer;
