import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface UiState {
    theme: 'light' | 'dark';
    activeTool: string;
    zoom: number;
    panOffset: { x: number; y: number };
    canvasSize: { width: number; height: number };
    snapPoint: { x: number; y: number; type: 'endpoint' | 'midpoint' | 'center' } | null;
    measurePoints: { x: number; y: number }[];
    sidebarVisible: boolean;
    isLoaded: boolean;
    fitToScreenCounter: number;
}

const initialState: UiState = {
    theme: 'light',
    activeTool: 'pan',
    zoom: 1,
    panOffset: { x: 0, y: 0 },
    canvasSize: { width: 0, height: 0 },
    snapPoint: null,
    measurePoints: [],
    sidebarVisible: true,
    isLoaded: false,
    fitToScreenCounter: 0,
};

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        setTheme: (state: UiState, action: PayloadAction<'light' | 'dark'>) => {
            state.theme = action.payload;
        },
        toggleTheme: (state: UiState) => {
            state.theme = state.theme === 'dark' ? 'light' : 'dark';
        },
        setActiveTool: (state: UiState, action: PayloadAction<string>) => {
            state.activeTool = action.payload;
        },
        setZoom: (state: UiState, action: PayloadAction<number>) => {
            state.zoom = action.payload;
        },
        setPanOffset: (state: UiState, action: PayloadAction<{ x: number; y: number }>) => {
            state.panOffset = action.payload;
        },
        setCanvasSize: (state: UiState, action: PayloadAction<{ width: number; height: number }>) => {
            state.canvasSize = action.payload;
        },
        zoomByFactor: (state: UiState, action: PayloadAction<number>) => {
            const factor = action.payload;
            const { width, height } = state.canvasSize;

            if (width === 0 || height === 0) {
                state.zoom *= factor;
                return;
            }

            const pivotX = width / 2;
            const pivotY = height / 2;

            const dx = (pivotX - (width / 2 + state.panOffset.x)) * (1 - factor);
            const dy = (pivotY - (height / 2 + state.panOffset.y)) * (1 - factor);

            state.zoom *= factor;
            state.panOffset.x += dx;
            state.panOffset.y += dy;
        },
        setSnapPoint: (state: UiState, action: PayloadAction<{ x: number; y: number; type: 'endpoint' | 'midpoint' | 'center' } | null>) => {
            state.snapPoint = action.payload;
        },
        addMeasurePoint: (state: UiState, action: PayloadAction<{ x: number; y: number }>) => {
            state.measurePoints.push(action.payload);
        },
        clearMeasure: (state: UiState) => {
            state.measurePoints = [];
        },
        toggleSidebar: (state: UiState) => {
            state.sidebarVisible = !state.sidebarVisible;
        },
        setAppLoaded: (state: UiState, action: PayloadAction<boolean>) => {
            state.isLoaded = action.payload;
        },
        triggerFitToScreen: (state: UiState) => {
            state.fitToScreenCounter += 1;
        },
    },
});

export const {
    setTheme,
    toggleTheme,
    setActiveTool,
    setZoom,
    setPanOffset,
    setCanvasSize,
    zoomByFactor,
    setSnapPoint,
    addMeasurePoint,
    clearMeasure,
    toggleSidebar,
    setAppLoaded,
    triggerFitToScreen,
} = uiSlice.actions;

export default uiSlice.reducer;
