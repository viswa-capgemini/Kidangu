import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
 
const dynamoDBClient = new DynamoDBClient({
  region: "eu-north-1",
  credentials: {
    accessKeyId: "AKIA4JKI67FIJN246WKO",
    secretAccessKey: "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",
  },
});
export default dynamoDBClient