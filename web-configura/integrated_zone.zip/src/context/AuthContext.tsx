
import React, { createContext, useContext, useEffect, useState } from 'react';
import type { Role, User } from '../types/auth';

// Hardcoded demo users (frontend-only)
const USERS = [
  { name: "Abhishek Kumar", email: 'admin@example.com', password: 'admin123', role: 'admin' as Role },
  { name: "Viswa Prasad", email: 'dealer@example.com', password: 'dealer123', role: 'dealer' as Role },
];

type AuthContextValue = {
  user: User | null;
  login: (email: string, password: string) => Promise<{ ok: boolean; message?: string }>;
  logout: () => void;
  hasRole: (role: Role | Role[]) => boolean;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string) => {
    // Simulate async (e.g., to show loading states)
    await new Promise((r) => setTimeout(r, 300));

    const match = USERS.find(u => u.email === email && u.password === password);
    if (!match) {
      return { ok: false, message: 'Invalid email or password' };
    }

    const nextUser: User = { name: match.name, email: match.email, role: match.role };
    setUser(nextUser);
    return { ok: true };
  };

  const logout = () => {
    setUser(null);
  };

  const hasRole = (role: Role | Role[]) => {
    if (!user) return false;
    const arr = Array.isArray(role) ? role : [role];
    return arr.includes(user.role);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, hasRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
