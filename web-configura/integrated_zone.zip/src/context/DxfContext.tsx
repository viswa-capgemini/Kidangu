import React, { createContext, useContext, useReducer, ReactNode } from 'react';

// Initial state
interface DxfState {
    dxfData: any | null;
    isLoading: boolean;
    uploadProgress: number;
    error: string | null;
    tool: string;
    zoom: number;
    panOffset: { x: number; y: number };
    visibleLayers: Set<string>;
    selectedLayer: string | null;
    selectedEntities: any[];
}

const initialState: DxfState = {
    // File data
    dxfData: null,
    isLoading: false,
    uploadProgress: 0,
    error: null,

    // Canvas state
    tool: 'pan', // 'select', 'pan', 'zoom'
    zoom: 1,
    panOffset: { x: 0, y: 0 },

    // Layer visibility
    visibleLayers: new Set(),
    selectedLayer: null,

    // Selection
    selectedEntities: [],
};

// Action types
enum ActionTypes {
    SET_LOADING = 'SET_LOADING',
    SET_UPLOAD_PROGRESS = 'SET_UPLOAD_PROGRESS',
    SET_DXF_DATA = 'SET_DXF_DATA',
    SET_ERROR = 'SET_ERROR',
    CLEAR_DATA = 'CLEAR_DATA',
    SET_TOOL = 'SET_TOOL',
    SET_ZOOM = 'SET_ZOOM',
    SET_PAN_OFFSET = 'SET_PAN_OFFSET',
    TOGGLE_LAYER_VISIBILITY = 'TOGGLE_LAYER_VISIBILITY',
    SET_ALL_LAYERS_VISIBILITY = 'SET_ALL_LAYERS_VISIBILITY',
    SET_SELECTED_LAYER = 'SET_SELECTED_LAYER',
    SET_SELECTED_ENTITIES = 'SET_SELECTED_ENTITIES',
    ZOOM_IN = 'ZOOM_IN',
    ZOOM_OUT = 'ZOOM_OUT',
    ZOOM_FIT = 'ZOOM_FIT',
}

type Action =
    | { type: ActionTypes.SET_LOADING; payload: boolean }
    | { type: ActionTypes.SET_UPLOAD_PROGRESS; payload: number }
    | { type: ActionTypes.SET_DXF_DATA; payload: any }
    | { type: ActionTypes.SET_ERROR; payload: string | null }
    | { type: ActionTypes.CLEAR_DATA }
    | { type: ActionTypes.SET_TOOL; payload: string }
    | { type: ActionTypes.SET_ZOOM; payload: number }
    | { type: ActionTypes.SET_PAN_OFFSET; payload: { x: number; y: number } }
    | { type: ActionTypes.TOGGLE_LAYER_VISIBILITY; payload: string }
    | { type: ActionTypes.SET_ALL_LAYERS_VISIBILITY; payload: boolean }
    | { type: ActionTypes.SET_SELECTED_LAYER; payload: string | null }
    | { type: ActionTypes.SET_SELECTED_ENTITIES; payload: any[] }
    | { type: ActionTypes.ZOOM_IN }
    | { type: ActionTypes.ZOOM_OUT }
    | { type: ActionTypes.ZOOM_FIT };

// Reducer
function dxfReducer(state: DxfState, action: Action): DxfState {
    switch (action.type) {
        case ActionTypes.SET_LOADING:
            return { ...state, isLoading: action.payload };

        case ActionTypes.SET_UPLOAD_PROGRESS:
            return { ...state, uploadProgress: action.payload };

        case ActionTypes.SET_DXF_DATA: {
            const data = action.payload;
            const visibleLayers = new Set<string>(
                data.layers
                    .filter((layer: any) => !layer.is_off && !layer.is_frozen)
                    .map((layer: any) => layer.name)
            );
            return {
                ...state,
                dxfData: data,
                visibleLayers,
                isLoading: false,
                error: null,
                uploadProgress: 100,
            };
        }

        case ActionTypes.SET_ERROR:
            return { ...state, error: action.payload, isLoading: false };

        case ActionTypes.CLEAR_DATA:
            return { ...initialState };

        case ActionTypes.SET_TOOL:
            return { ...state, tool: action.payload };

        case ActionTypes.SET_ZOOM:
            return { ...state, zoom: Math.max(0.01, Math.min(100, action.payload)) };

        case ActionTypes.ZOOM_IN:
            return { ...state, zoom: Math.min(100, state.zoom * 1.25) };

        case ActionTypes.ZOOM_OUT:
            return { ...state, zoom: Math.max(0.01, state.zoom / 1.25) };

        case ActionTypes.ZOOM_FIT:
            return { ...state, zoom: 1, panOffset: { x: 0, y: 0 } };

        case ActionTypes.SET_PAN_OFFSET:
            return { ...state, panOffset: action.payload };

        case ActionTypes.TOGGLE_LAYER_VISIBILITY: {
            const newVisible = new Set(state.visibleLayers);
            if (newVisible.has(action.payload)) {
                newVisible.delete(action.payload);
            } else {
                newVisible.add(action.payload);
            }
            return { ...state, visibleLayers: newVisible };
        }

        case ActionTypes.SET_ALL_LAYERS_VISIBILITY: {
            if (action.payload) {
                const allLayers = new Set<string>(state.dxfData?.layers?.map((l: any) => l.name) || []);
                return { ...state, visibleLayers: allLayers };
            } else {
                return { ...state, visibleLayers: new Set<string>() };
            }
        }

        case ActionTypes.SET_SELECTED_LAYER:
            return { ...state, selectedLayer: action.payload };

        case ActionTypes.SET_SELECTED_ENTITIES:
            return { ...state, selectedEntities: action.payload };

        default:
            return state;
    }
}

// Create context
interface DxfContextType {
    state: DxfState;
    actions: {
        setLoading: (loading: boolean) => void;
        setUploadProgress: (progress: number) => void;
        setDxfData: (data: any) => void;
        setError: (error: string | null) => void;
        clearData: () => void;
        setTool: (tool: string) => void;
        setZoom: (zoom: number) => void;
        zoomIn: () => void;
        zoomOut: () => void;
        zoomFit: () => void;
        setPanOffset: (offset: { x: number; y: number }) => void;
        toggleLayerVisibility: (layerName: string) => void;
        setAllLayersVisibility: (visible: boolean) => void;
        setSelectedLayer: (layerName: string | null) => void;
        setSelectedEntities: (entities: any[]) => void;
    };
}

const DxfContext = createContext<DxfContextType | null>(null);

// Provider component
export function DxfProvider({ children }: { children: ReactNode }) {
    const [state, dispatch] = useReducer(dxfReducer, initialState);

    // Action creators
    const actions = {
        setLoading: (loading: boolean) => dispatch({ type: ActionTypes.SET_LOADING, payload: loading }),
        setUploadProgress: (progress: number) => dispatch({ type: ActionTypes.SET_UPLOAD_PROGRESS, payload: progress }),
        setDxfData: (data: any) => dispatch({ type: ActionTypes.SET_DXF_DATA, payload: data }),
        setError: (error: string | null) => dispatch({ type: ActionTypes.SET_ERROR, payload: error }),
        clearData: () => dispatch({ type: ActionTypes.CLEAR_DATA }),
        setTool: (tool: string) => dispatch({ type: ActionTypes.SET_TOOL, payload: tool }),
        setZoom: (zoom: number) => dispatch({ type: ActionTypes.SET_ZOOM, payload: zoom }),
        zoomIn: () => dispatch({ type: ActionTypes.ZOOM_IN }),
        zoomOut: () => dispatch({ type: ActionTypes.ZOOM_OUT }),
        zoomFit: () => dispatch({ type: ActionTypes.ZOOM_FIT }),
        setPanOffset: (offset: { x: number; y: number }) => dispatch({ type: ActionTypes.SET_PAN_OFFSET, payload: offset }),
        toggleLayerVisibility: (layerName: string) => dispatch({ type: ActionTypes.TOGGLE_LAYER_VISIBILITY, payload: layerName }),
        setAllLayersVisibility: (visible: boolean) => dispatch({ type: ActionTypes.SET_ALL_LAYERS_VISIBILITY, payload: visible }),
        setSelectedLayer: (layerName: string | null) => dispatch({ type: ActionTypes.SET_SELECTED_LAYER, payload: layerName }),
        setSelectedEntities: (entities: any[]) => dispatch({ type: ActionTypes.SET_SELECTED_ENTITIES, payload: entities }),
    };

    return (
        <DxfContext.Provider value={{ state, actions }}>
            {children}
        </DxfContext.Provider>
    );
}

// Custom hook to use the context
export function useDxf() {
    const context = useContext(DxfContext);
    if (!context) {
        throw new Error('useDxf must be used within a DxfProvider');
    }
    return context;
}

export { ActionTypes };
