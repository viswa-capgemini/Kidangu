
import React from 'react';
import { useAuth } from "../../context/AuthContext";

const AdminPage: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Admin Dashboard</h2>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-600">{user?.email}</span>
          <button onClick={logout} className="rounded bg-gray-200 px-3 py-1 text-sm hover:bg-gray-300">
            Logout
          </button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded border p-4">User Management</div>
        <div className="rounded border p-4">System Settings</div>
      </div>
    </div>
  );
};

export default AdminPage;
