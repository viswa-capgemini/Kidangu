import companyLogo from "../../assets/images/company-logo.png";
import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import UserMenu from "../user-menu/UserMenu";

interface HeaderProps {
  setRunTour: (value: boolean) => void;
  tour?: boolean;
  setTour: (value: boolean) => void;
  onHamburgerClick: () => void;
}

const Header: React.FC<HeaderProps> = ({
  setTour,
  tour,
  setRunTour,
  onHamburgerClick,
}) => {
  const handleTour = () => {
    setRunTour(true);
    setTour(!tour);
  };
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header
      data-testid="main-header"
      className="border-b-2 border-company-purple bg-white-500 text-black text-lg font-medium pr-3 pl-3 py-4 flex items-center justify-between"
    >
      {/* <div data-testid="main-header-wrapper"> */}
      <div
        data-testid="logo-container"
        className="text-2xl font-bold flex items-center space-x-4"
      >
        <button onClick={onHamburgerClick}>
          <span
            data-testid="hamburger-icon"
            className="icon-[solar--hamburger-menu-outline]"
          ></span>
        </button>
        <span>
          <img
            data-testid="company-logo"
            src={companyLogo}
            alt="company Logo"
            className="h-8 w-auto"
          />
        </span>
      </div>
      <div className="flex space-x-10">
        <button
          data-testid="help-btn"
          // className="border-2 rounded-full w-10 bg-gray-200"
          onClick={handleTour}
        >
          <span className="icon-[cuida--help-outline]"></span>
        </button>

        {/* <div className="flex items-center space-x-3">
          <span
            data-testid="user-icon"
            className="icon-[qlementine-icons--user-24]"
          ></span>
          <span data-testid="user-name" className="user px-2">
            {user?.name ?? 'Guest'}
          </span>
          <button
            data-testid="logout-btn"
            onClick={handleLogout}
            className="text-sm bg-transparent border border-gray-300 px-2 py-1 rounded hover:bg-gray-100"
          >
            Logout
          </button>
        </div> */}

        {/* User Menu (replaces inline name + logout) */}
        <UserMenu
          userName={user?.name ?? "Guest"}
          onLogout={handleLogout}
          align="right"
          // Optional: provide a custom trigger that matches your existing look
          trigger={
            <div className="flex items-center gap-2">
              <span
                data-testid="user-icon"
                className="icon-[qlementine-icons--user-24] text-xl"
              />
              {/* <span data-testid="user-name" className="user px-2 text-sm">
                {user?.name ?? "Guest"}
              </span> */}
              {/* <span className="icon-[iconamoon--arrow-down-2-light] text-base" /> */}
            </div>
          }
        />
      </div>
      {/* </div> */}
    </header>
  );
};

export default Header;
