
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext'; // assumes you have AuthContext from earlier
import type { Role } from '../types/auth';

interface Props {
  children: React.ReactNode;
  allowedRoles?: Role[]; // e.g. ['admin'], ['dealer'], or both
}

export const ProtectedRoute: React.FC<Props> = ({ children, allowedRoles }) => {
  const { user } = useAuth();

  // Not logged in → go to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Role not allowed → show NotAuthorized
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/not-authorized" replace />;
  }

  return <>{children}</>;
};
