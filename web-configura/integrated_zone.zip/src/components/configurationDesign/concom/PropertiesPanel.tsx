import React, { useState, useEffect } from 'react';
import { SketchPicker } from 'react-color'; // You'll need to install react-color
import './PropertiesPanel.css';

const PropertiesPanel = ({ selectedShape, selectedShapes, onUpdateShape, onGroupShapes, onUngroupShapes }) => {
  const [localShape, setLocalShape] = useState(null);
  const [multiSelectInfo, setMultiSelectInfo] = useState({ count: 0 });
  const [showColorPicker, setShowColorPicker] = useState(false);
  
  // Update local state when selected shape changes
  useEffect(() => {
    // Support selection passed either as `selectedShape` (single) or `selectedShapes` (single or array)
    if (Array.isArray(selectedShapes)) {
      setMultiSelectInfo({ count: selectedShapes.length });
      if (selectedShapes.length === 1) {
        setLocalShape(selectedShapes[0]);
      } else {
        setLocalShape(null);
      }
    } else if (selectedShapes !== undefined) {
      // Parent may pass a single selected shape in the `selectedShapes` prop (legacy/variant)
      setMultiSelectInfo({ count: 0 });
      setLocalShape(selectedShapes as any);
    } else {
      setMultiSelectInfo({ count: 0 });
      setLocalShape(selectedShape);
    }
  }, [selectedShape, selectedShapes]);
  
  if (!localShape) {
    // If multiple items selected, show simple multi-selection actions
    if (Array.isArray(selectedShapes) && selectedShapes.length > 0) {
      return (
        <div className="properties-panel">
          <h3>Properties</h3>
          <p className="no-selection">{selectedShapes.length} elements selected</p>
          <div className="property-actions">
            {onGroupShapes && (
              <button className="group-button" onClick={() => onGroupShapes(selectedShapes)}>
                Group
              </button>
            )}
            {onUngroupShapes && (
              <button className="ungroup-button" onClick={() => onUngroupShapes(selectedShapes)}>
                Ungroup
              </button>
            )}
          </div>
        </div>
      );
    }

    return (
      <div className="properties-panel">
        <h3>Properties</h3>
        <p className="no-selection">No element selected</p>
      </div>
    );
  }
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const numericValue = name !== 'name' ? parseFloat(value) : value;
    
    const updatedShape = {
      ...localShape,
      [name]: numericValue
    };
    
    setLocalShape(updatedShape);
    onUpdateShape(updatedShape);
  };
  
  const handleColorChange = (color) => {
    const updatedShape = {
      ...localShape,
      fill: color.hex
    };
    
    setLocalShape(updatedShape);
    onUpdateShape(updatedShape);
  };
  
  const renderTransformationControls = () => {
    switch (localShape.type) {
      case 'line':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>Start X:</label>
                <input
                  type="number"
                  name="points[0]"
                  value={localShape.points[0]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[0] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>Start Y:</label>
                <input
                  type="number"
                  name="points[1]"
                  value={localShape.points[1]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[1] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>End X:</label>
                <input
                  type="number"
                  name="points[2]"
                  value={localShape.points[2]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[2] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
              <div className="property-row">
                <label>End Y:</label>
                <input
                  type="number"
                  name="points[3]"
                  value={localShape.points[3]}
                  onChange={(e) => {
                    const newPoints = [...localShape.points];
                    newPoints[3] = parseFloat(e.target.value);
                    const updatedShape = { ...localShape, points: newPoints };
                    setLocalShape(updatedShape);
                    onUpdateShape(updatedShape);
                  }}
                />
              </div>
            </div>
          </>
        );
        
      case 'rectangle':
      case 'wall':
      case 'door':
      case 'window':
      case 'sliding-door':
      case 'bed':
      case 'sofa':
      case 'table':
      case 'chair':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Size</h4>
              <div className="property-row">
                <label>Width:</label>
                <input
                  type="number"
                  name="width"
                  value={localShape.width}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Height:</label>
                <input
                  type="number"
                  name="height"
                  value={localShape.height}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            {(localShape.rotation !== undefined) && (
              <div className="property-group">
                <h4>Rotation</h4>
                <div className="property-row">
                  <label>Angle:</label>
                  <input
                    type="number"
                    name="rotation"
                    value={localShape.rotation || 0}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            )}
          </>
        );
        
      case 'circle':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Size</h4>
              <div className="property-row">
                <label>Radius:</label>
                <input
                  type="number"
                  name="radius"
                  value={localShape.radius}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </>
        );
        
      case 'text':
        return (
          <>
            <div className="property-group">
              <h4>Position</h4>
              <div className="property-row">
                <label>X:</label>
                <input
                  type="number"
                  name="x"
                  value={localShape.x}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Y:</label>
                <input
                  type="number"
                  name="y"
                  value={localShape.y}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="property-group">
              <h4>Text</h4>
              <div className="property-row">
                <label>Content:</label>
                <input
                  type="text"
                  name="text"
                  value={localShape.text}
                  onChange={handleInputChange}
                />
              </div>
              <div className="property-row">
                <label>Font Size:</label>
                <input
                  type="number"
                  name="fontSize"
                  value={localShape.fontSize}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="properties-panel">
      <h3>Properties: {localShape.name || localShape.type}</h3>
      
      {renderTransformationControls()}
      
      <div className="property-group">
        <h4>Appearance</h4>
        {localShape.fill !== undefined && (
          <div className="property-row">
            <label>Fill Color:</label>
            <div className="color-picker-container">
              <div 
                className="color-preview" 
                style={{ backgroundColor: localShape.fill }}
                onClick={() => setShowColorPicker(!showColorPicker)}
              ></div>
              {showColorPicker && (
                <div className="color-picker-popover">
                  <div 
                    className="color-picker-cover" 
                    onClick={() => setShowColorPicker(false)}
                  />
                  <SketchPicker 
                    color={localShape.fill} 
                    onChange={handleColorChange}
                  />
                </div>
              )}
            </div>
          </div>
        )}
        
        {localShape.stroke !== undefined && (
          <div className="property-row">
            <label>Stroke:</label>
            <input
              type="text"
              name="stroke"
              value={localShape.stroke}
              onChange={handleInputChange}
            />
          </div>
        )}
        
        {localShape.strokeWidth !== undefined && (
          <div className="property-row">
            <label>Stroke Width:</label>
            <input
              type="number"
              name="strokeWidth"
              value={localShape.strokeWidth}
              onChange={handleInputChange}
            />
          </div>
        )}
      </div>
      
      <div className="property-actions">
        <button 
          className="delete-button"
          onClick={() => onUpdateShape({ ...localShape, _delete: true })}
        >
          Delete Element
        </button>
      </div>
    </div>
  );
};

export default PropertiesPanel;