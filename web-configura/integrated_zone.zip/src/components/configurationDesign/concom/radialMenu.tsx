import React, { useState, useEffect } from 'react';
import { Group, Circle, Text, Rect, Path } from 'react-konva';

// Define the shape type based on your application's shape structure
export interface Shape {
  id: number | string;
  type: string;
  x: number;
  y: number;
  width?: number;
  height?: number;
  radius?: number;
  points?: number[];
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  rotation?: number;
}

// Define prop types for the RadialMenu component
export interface RadialMenuProps {
  x: number;
  y: number;
  isOpen: boolean;
  onToggle: () => void;
  onAction: (actionId: string) => void;
  zoomLevel: number;
  selectedShape: Shape;
}

// Define menu item type
interface MenuItem {
  id: string;
  renderIcon: (props: IconProps) => JSX.Element;
  label: string;
  angle: number; // Angle in degrees for arc positioning
  disabled?: boolean;
}

interface IconProps {
  size: number;
  color: string;
}

const RadialMenu: React.FC<RadialMenuProps> = ({
  x,
  y,
  isOpen,
  onToggle,
  onAction,
  zoomLevel,
  selectedShape
}) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [animationProgress, setAnimationProgress] = useState<number>(0);

  // company purple color
  const companyPurple = ' #810055';
  // Gray outline color
  const grayOutline = ' #707070';

  // Custom SVG icons
  const CopyIcon = ({ size, color }: IconProps) => (
    <Group width={size} height={size} offsetX={size / 2} offsetY={size / 2}>
      <Path
        data="M15.24 2h-3.894c-1.764 0-3.162 0-4.255.148c-1.126.152-2.037.472-2.755 1.193c-.719.721-1.038 1.636-1.189 2.766C3 7.205 3 8.608 3 10.379v5.838c0 1.508.92 2.8 2.227 3.342c-.067-.91-.067-2.185-.067-3.247v-5.01c0-1.281 0-2.386.118-3.27c.127-.948.413-1.856 1.147-2.593s1.639-1.024 2.583-1.152c.88-.118 1.98-.118 3.257-.118h3.07c1.276 0 2.374 0 3.255.118A3.6 3.6 0 0 0 15.24 2"
        fill="white"
        stroke={color}
        strokeWidth={1 * (iconSize / 24)}
        scaleX={iconSize / 24}
        scaleY={iconSize / 24}
      />
      <Path
        data="M6.6 11.397c0-2.726 0-4.089.844-4.936c.843-.847 2.2-.847 4.916-.847h2.88c2.715 0 4.073 0 4.917.847S21 8.671 21 11.397v4.82c0 2.726 0 4.089-.843 4.936c-.844.847-2.202.847-4.917.847h-2.88c-2.715 0-4.073 0-4.916-.847c-.844-.847-.844-2.21-.844-4.936z"
        fill="white"
        stroke={color}
        strokeWidth={1 * (size / 24)}
        scaleX={size / 24}
        scaleY={size / 24}
      />
    </Group>
  );

  const DeleteIcon = ({ size, color }: IconProps) => (
    <Group width={size} height={size} offsetX={size / 2} offsetY={size / 2}>
      <Path
        data="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z"
        fill="white"
        stroke={color}
        strokeWidth={1 * (size / 24)}
        scaleX={size / 24}
        scaleY={size / 24}
      />
    </Group>
  );

  const FavoriteIcon = ({ size, color }: IconProps) => (
    <Group width={size} height={size} offsetX={size / 2} offsetY={size / 2}>
      <Path
        data="m12 21l-1.45-1.3q-2.525-2.275-4.175-3.925T3.75 12.812T2.388 10.4T2 8.15Q2 5.8 3.575 4.225T7.5 2.65q1.3 0 2.475.55T12 4.75q.85-1 2.025-1.55t2.475-.55q2.35 0 3.925 1.575T22 8.15q0 1.15-.387 2.25t-1.363 2.412t-2.625 2.963T13.45 19.7z"
        fill="white"
        stroke={color}
        strokeWidth={1 * (size / 24)}
        scaleX={size / 24}
        scaleY={size / 24}
      />
    </Group>
  );

  const SettingsIcon = ({ size, color }: IconProps) => (
    <Group width={size} height={size} offsetX={size / 2} offsetY={size / 2}>
      <Path
        data="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 0 0-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 0 0-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 0 0-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 0 0-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 0 0 1.066-2.573c-.94-1.543.826-3.31 2.37-2.37c1 .608 2.296.07 2.572-1.065"
        stroke={color}
        strokeWidth={2 * (size / 24)}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="white"
        scaleX={size / 24}
        scaleY={size / 24}
      />
      <Path
        data="M9 12a3 3 0 1 0 6 0a3 3 0 0 0-6 0"
        stroke={color}
        strokeWidth={2 * (size / 24)}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="white"
        scaleX={size / 24}
        scaleY={size / 24}
      />
    </Group>
  );

  const MoveIcon = ({ size, color }: IconProps) => (
    <Text
      text="↔"
      fontSize={size * 0.7}
      fill={color}
      align="center"
      verticalAlign="middle"
      width={size}
      height={size}
      offsetX={size / 2}
      offsetY={size / 2}
    />
  );

  // Menu items configuration - arc layout with custom icons
  const menuItems: MenuItem[] = [
    { id: 'move', renderIcon: MoveIcon, label: 'Move', angle: 180, disabled: true },
    { id: 'duplicate', renderIcon: CopyIcon, label: 'Copy', angle: 135, disabled: true },
    { id: 'favorite', renderIcon: FavoriteIcon, label: 'Favorite', angle: 90, disabled: true },
    { id: 'delete', renderIcon: DeleteIcon, label: 'Delete', angle: 45, disabled: true },
    { id: 'settings', renderIcon: SettingsIcon, label: 'Settings', angle: 0, disabled: true },
  ];

  // Animation effect - automatically open the menu when it appears
  useEffect(() => {
    // Auto-open the menu when it's shown
    if (!isOpen) {
      onToggle(); // Automatically open the menu
    }

    let animationFrame: number;
    const targetProgress = isOpen ? 1 : 0;
    const animationSpeed = 0.1;

    const animate = (): void => {
      setAnimationProgress(prev => {
        const newProgress = isOpen
          ? Math.min(prev + animationSpeed, targetProgress)
          : Math.max(prev - animationSpeed, targetProgress);

        if ((isOpen && newProgress < targetProgress) || (!isOpen && newProgress > targetProgress)) {
          animationFrame = requestAnimationFrame(animate);
        }

        return newProgress;
      });
    };

    animationFrame = requestAnimationFrame(animate);

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [isOpen, onToggle]);

  // Calculate radius of the arc
  const arcRadius = 80 / zoomLevel;

  // Circle size and icon size
  const circleRadius = 15 / zoomLevel;
  // Size for the icon
  const iconSize = 10 / zoomLevel;

  // Tooltip position higher up
  const tooltipOffset = -50 / zoomLevel;

  return (
    <Group x={x} y={y}>
      {/* Menu items in arc layout */}
      {menuItems.map((item) => {
        // Calculate position based on animation progress and angle
        const angleInRadians = (item.angle * Math.PI) / 180;
        const itemX = Math.cos(angleInRadians) * arcRadius * animationProgress;
        const itemY = -Math.sin(angleInRadians) * arcRadius * animationProgress;
        const opacity = animationProgress;

        // Determine if this item is hovered
        const isHovered = hoveredItem === item.id;

        return (
          <Group
            key={item.id}
            x={itemX}
            y={itemY}
            opacity={opacity}
            onMouseEnter={() => setHoveredItem(item.id)}
            onMouseLeave={() => setHoveredItem(null)}
            onClick={(e) => {
              e.cancelBubble = true;
              if (animationProgress > 0.8) onAction(item.id);
            }}
            onTap={(e) => {
              e.cancelBubble = true;
              if (animationProgress > 0.8) onAction(item.id);
            }}
          >
            {/* White background circle with gray/purple outline */}
            <Circle
              radius={circleRadius}
              fill="white"
              stroke={isHovered ? companyPurple : grayOutline}
              strokeWidth={2 / zoomLevel}
              opacity={0.9}
              shadowColor="black"
              shadowBlur={3 / zoomLevel}
              shadowOpacity={0.2}
            />

            {/* Render the custom icon */}
            {item.renderIcon({
              size: iconSize * 2,
              color: isHovered ? companyPurple : grayOutline
            })}

            {/* Tooltip */}
            {isHovered && animationProgress > 0.9 && (
              <Group y={tooltipOffset}>
                <Rect
                  width={item.label.length * 8 / zoomLevel}
                  height={30 / zoomLevel}
                  fill="#707070"
                  cornerRadius={4 / zoomLevel}
                  offsetX={(item.label.length * 8 / zoomLevel) / 2}
                />
                <Text
                  text={item.label}
                  fontSize={12 / zoomLevel}
                  fill="white"
                  align="center"
                  width={item.label.length * 8 / zoomLevel}
                  height={30 / zoomLevel}
                  offsetX={(item.label.length * 8 / zoomLevel) / 2}
                  verticalAlign="middle"
                />
              </Group>
            )}
          </Group>
        );
      })}
    </Group>
  );
};

export default RadialMenu;