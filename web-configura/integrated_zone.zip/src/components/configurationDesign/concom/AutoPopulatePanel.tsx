
// import React, { useMemo, useRef, useState, useEffect } from 'react';
// import { Stage, Layer, Line, Rect, Text, Group } from 'react-konva';

// /** ---------- Styles ---------- */
// const styles = {
//   container: {
//     display: 'grid',
//     gridTemplateColumns: '360px 1fr',
//     gap: '16px',
//     padding: '16px',
//     fontFamily: 'sans-serif',
//     color: '#111827',
//     height: '100%',
//   },
//   sidebar: {
//     color: '#111827',
//     padding: '16px',
//     borderRadius: '8px',
//     display: 'flex',
//     flexDirection: 'column' as const,
//     gap: '16px',
//     overflowY: 'auto' as const,
//     maxHeight: 'calc(100vh - 32px)',
//   },
//   h2: {
//     margin: 0,
//     marginBottom: '12px',
//     fontSize: '1.25rem',
//     color: '#111827',
//     borderBottom: '1px solid #e5e7eb',
//     paddingBottom: '8px',
//   },
//   h3: {
//     margin: 0,
//     marginBottom: '8px',
//     fontSize: '1rem',
//     color: '#111827',
//   },
//   settingGroup: {
//     marginBottom: '16px',
//   },
//   label: {
//     display: 'block',
//     marginBottom: '4px',
//     fontSize: '0.875rem',
//     color: '#9ca3af',
//   },
//   input: {
//     width: '100%',
//     padding: '8px 10px',
//     background: 'white',
//     border: '1px solid #d1d5db',
//     borderRadius: '4px',
//     color: '#111827',
//     fontSize: '0.875rem',
//     marginBottom: '6px',
//   },
//   select: {
//     width: '100%',
//     padding: '8px 10px',
//     background: 'white',
//     border: '1px solid #d1d5db',
//     borderRadius: '4px',
//     color: '#111827',
//     fontSize: '0.875rem',
//     marginBottom: '6px',
//   },
//   inputFocus: {
//     outline: 'none',
//     borderColor: '#16a34a',
//     boxShadow: '0 0 0 1px rgba(59, 130, 246, 0.5)',
//   },
//   inputDisabled: {
//     opacity: 0.6,
//     cursor: 'not-allowed',
//   },
//   row: {
//     display: 'grid',
//     gridTemplateColumns: '1fr 1fr',
//     gap: '8px',
//   },
//   note: {
//     fontSize: '0.75rem',
//     color: '#9ca3af',
//     marginTop: '4px',
//     marginBottom: '8px',
//   },
//   small: {
//     fontSize: '0.75rem',
//     color: '#9ca3af',
//     marginTop: '4px',
//     marginBottom: '8px',
//   },
//   button: {
//     padding: '8px 12px',
//     borderRadius: '4px',
//     fontSize: '0.875rem',
//     fontWeight: 500,
//     cursor: 'pointer',
//     transition: 'all 0.2s',
//     background: '#f3f4f6',
//     color: '#111827',
//     border: '1px solid #d1d5db',
//   },
//   buttonHover: {
//     background: 'green',
//   },
//   buttonActive: {
//     transform: 'translateY(1px)',
//   },
//   buttonDisabled: {
//     opacity: 0.6,
//     cursor: 'not-allowed',
//   },
//   primaryButton: {
//     background: '#2563eb',
//     color: 'white',
//     border: '1px solid #1d4ed8',
//   },
//   primaryButtonHover: {
//     background: '#1d4ed8',
//   },
//   dangerButton: {
//     background: '#dc2626',
//     color: 'white',
//     border: '1px solid #b91c1c',
//   },
//   dangerButtonHover: {
//     background: '#b91c1c',
//   },
//   help: {
//     background: '#1e293b',
//     padding: '10px',
//     borderRadius: '4px',
//     fontSize: '0.75rem',
//     color: '#94a3b8',
//     borderLeft: '3px solid #3b82f6',
//   },
//   badge: {
//     background: '#374151',
//     padding: '2px 6px',
//     borderRadius: '4px',
//     fontSize: '0.75rem',
//     fontFamily: 'monospace',
//   },
//   canvas: {
//     position: 'relative' as const,
//     borderRadius: '8px',
//     overflow: 'hidden',
//   },
//   sectionInfo: {
//     background: '#f0f9ff',
//     border: '1px solid #bae6fd',
//     borderRadius: '4px',
//     padding: '10px',
//     marginBottom: '16px',
//   },
//   sectionTitle: {
//     margin: 0,
//     marginBottom: '8px',
//     color: '#0284c7',
//     fontSize: '14px',
//   },
//   sectionNote: {
//     margin: 0,
//     fontSize: '12px',
//     color: '#64748b',
//   }
// };

// /** ---------- Props ---------- */
// export type AutoPopulatePanelProps = {
//   /** Standalone preview canvas size (ignored if controlsOnly=true) */
//   width?: number;
//   height?: number;

//   /** Close panel */
//   onClose: () => void;

//   /** Return generated rack shapes to parent (Konva-friendly objects) */
//   onGenerateRacks: (racks: any[]) => void;

//   /** Seed values; panel will fall back to these if provided */
//   initialSettings?: Record<string, any>;

//   /** --------- Controls-Only mode (Render sidebar only; operate on main canvas) ---------- */
//   controlsOnly?: boolean;

//   /** Main canvas Stage ref (used for PNG/SVG/DXF exports when controlsOnly=true) */
//   stageRef?: React.RefObject<any>;

//   /** Live selection rect from main canvas (controlsOnly=true) */
//   selectionRect?: { x: number; y: number; width: number; height: number } | null;

//   /** Live obstructions from main canvas (controlsOnly=true) */
//   obstructions?: { id: string; x: number; y: number; width: number; height: number }[];

//   /** Ask canvas to switch drawing mode when controlsOnly=true */
//   onToggleMode?: (mode: 'selection' | 'obstruction' | null) => void;

//   /** Clear obstructions (main canvas) when controlsOnly=true */
//   onClearObstructions?: () => void;

//   hideModeButtons?: boolean;

//   /** Clear selection+obstructions (main canvas) when controlsOnly=true */
//   onClearAll?: () => void;
  
//   /** Current section ID for multi-section support */
//   sectionId?: string | null;
// };

// /** ---------- Helpers ---------- */
// function drawGridLines(width: number, height: number, step: number) {
//   const lines: { points: number[] }[] = [];
//   for (let x = 0; x <= width; x += step) lines.push({ points: [x, 0, x, height] });
//   for (let y = 0; y <= height; y += step) lines.push({ points: [0, y, width, y] });
//   return lines;
// }

// function rectsOverlap(a: any, b: any) {
//   return !(
//     a.x + a.width <= b.x ||
//     b.x + b.width <= a.x ||
//     a.y + a.height <= b.y ||
//     b.y + b.height <= a.y
//   );
// }

// function triggerDownload(href: string, filename: string) {
//   const a = document.createElement('a');
//   a.href = href;
//   a.download = filename;
//   a.click();
//   if (href.startsWith('blob:')) URL.revokeObjectURL(href);
// }

// /** Build SVG from shapes (mm units for size, px within viewBox) */
// function buildSVGFromShapes(
//   racks: any[],
//   obstructions: any[],
//   selection: any,
//   wpx: number, hpx: number,
//   scale: number
// ) {
//   const rect = (r: any, stroke: string, fill: string) =>
//     `<rect x="${r.x}" y="${r.y}" width="${r.width}" height="${r.height}" stroke="${stroke}" fill="${fill}" stroke-width="1" />`;
//   const racksSvg = racks.map((r) => rect(r, '#22c55e', '#1e293b')).join('');
//   const obsSvg = obstructions.map((o) => rect(o, '#ef4444', 'rgba(239,68,68,0.2)')).join('');
//   const selSvg =
//     selection && selection.width > 0 && selection.height > 0
//       ? `<rect x="${selection.x}" y="${selection.y}" width="${selection.width}" height="${selection.height}" stroke="#93c5fd" fill="none" stroke-dasharray="6 4" />`
//       : '';
//   const wmm = (wpx / scale).toFixed(2), hmm = (hpx / scale).toFixed(2);
//   return `<?xml version="1.0" encoding="UTF-8"?>
// <svg xmlns="http://www.w3.org/2000/svg" width="${wmm}mm" height="${hmm}mm" viewBox="0 0 ${wpx} ${hpx}">
//   <g id="racks">${racksSvg}</g>
//   <g id="obstructions">${obsSvg}</g>
//   <g id="selection">${selSvg}</g>
// </svg>`;
// }

// /** Build DXF (mm) using LWPOLYLINE (closed) */
// function buildDXFFromShapes(
//   racks: any[],
//   obstructions: any[],
//   selection: any,
//   stageHmm: number, // stage height in mm
//   scale: number
// ) {
//   const rectToDxf = (r: any, layer: string) => {
//     const x1 = r.x / scale, y1 = r.y / scale;
//     const x2 = (r.x + r.width) / scale, y2 = (r.y + r.height) / scale;
//     const fy1 = stageHmm - y1, fy2 = stageHmm - y2; // flip Y
//     return [
//       '0','LWPOLYLINE','8',layer,'90','4','70','1',
//       '10', `${x1}`, '20', `${fy1}`,
//       '10', `${x2}`, '20', `${fy1}`,
//       '10', `${x2}`, '20', `${fy2}`,
//       '10', `${x1}`, '20', `${fy2}`,
//     ].join('\n');
//   };

//   const parts: string[] = [];
//   parts.push('0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC');
//   parts.push('0','SECTION','2','ENTITIES');
//   racks.forEach((r) => parts.push(rectToDxf(r, 'RACKS')));
//   obstructions.forEach((o) => parts.push(rectToDxf(o, 'OBSTRUCTIONS')));
//   if (selection && selection.width > 0 && selection.height > 0) parts.push(rectToDxf(selection, 'SELECTION'));
//   parts.push('0','ENDSEC','0','EOF');
//   return parts.join('\n');
// }

// /** ---------- Component ---------- */
// export default function AutoPopulatePanel({
//   width = 1200,
//   height = 800,
//   onClose,
//   onGenerateRacks,
//   initialSettings = {},

//   controlsOnly = false,
//   stageRef, // main canvas Stage (for exports)
//   selectionRect, // main canvas selection (controlsOnly)
//   obstructions: obstructionsExternal = [],
//   onToggleMode,
//   onClearObstructions,
//   onClearAll,
//   sectionId = null,
// }: AutoPopulatePanelProps) {
//   /** ----- Settings (same defaults as your prototype) ----- */
//   const [scale, setScale] = useState<number>(initialSettings.scale || 1); // px per mm
//   const [gridMM, setGridMM] = useState<number>(initialSettings.gridMM || 100);
//   const [rackWmm, setRackWmm] = useState<number>(initialSettings.rackWmm || 2700);
//   const [rackHmm, setRackHmm] = useState<number>(initialSettings.rackHmm || 1100);
//   const [spacingXmm, setSpacingXmm] = useState<number>(initialSettings.spacingXmm || 100);
//   const [aisleMM, setAisleMM] = useState<number>(initialSettings.aisleMM || 3000);
//   const [marginMM, setMarginMM] = useState<number>(initialSettings.marginMM || 100);
//   const [rotate90, setRotate90] = useState<boolean>(initialSettings.rotate90 || false);
//   const [doubleDeep, setDoubleDeep] = useState<boolean>(initialSettings.doubleDeep || false);
//   const [backGapMM, setBackGapMM] = useState<number>(initialSettings.backGapMM || 0);
//   const [crossAisleEvery, setCrossAisleEvery] = useState<number>(initialSettings.crossAisleEvery || 3);
//   const [crossAisleWidthMM, setCrossAisleWidthMM] = useState<number>(initialSettings.crossAisleWidthMM || 1500);

//   /** ----- Live racks generated by Populate (px units) ----- */
//   const [racks, setRacks] = useState<any[]>([]);

//   /** ----- Standalone drawing state (ignored if controlsOnly) ----- */
//   const [isDrawing, setIsDrawing] = useState<boolean>(false);
//   const [points, setPoints] = useState<number[]>([]);
//   const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
//   const [currentShape, setCurrentShape] = useState<any | null>(null);
//   const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
//   const [stageSize, setStageSize] = useState({ 
//     width: window.innerWidth - 500, 
//     height: window.innerHeight - 50 
//   });
//   const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 });
//   const localStageRef = useRef<any>(null);
//   const containerRef = useRef<HTMLDivElement | null>(null);
//   const transformerRef = useRef<any>(null);

//   /** ----- Auto-populate state ----- */
//   const [localAutoPopulateMode, setLocalAutoPopulateMode] = useState<'selection' | 'obstruction' | null>('selection');

//   /** ----- Selection & obstructions for auto-populate ----- */
//   type RectPx = { x: number; y: number; width: number; height: number };
//   type ObstructionPx = RectPx & { id: string };
//   const [rackSelectionRect, setRackSelectionRect] = useState<RectPx | null>(null);
//   const [rackObstructions, setRackObstructions] = useState<ObstructionPx[]>([]);
//   const [isDrawingAP, setIsDrawingAP] = useState<boolean>(false);
//   const [apDrawRect, setApDrawRect] = useState<RectPx | null>(null);

//   /** Standalone Stage ref */
//   //const localStageRef = useRef<any>(null);

//   // Grid
//   const gridPx = useMemo(() => Math.max(10, gridMM * scale), [gridMM, scale]);
//   const gridLines = useMemo(
//     () => drawGridLines(width, height, gridPx),
//     [width, height, gridPx]
//   );
//   const px = (mm: number) => mm * scale;
//   const snap = (n: number) => Math.round(n / gridPx) * gridPx;

//   /** ---------- Data source selection (controlsOnly vs standalone) ---------- */
//   const effectiveSelection = controlsOnly ? selectionRect : rackSelectionRect;
//   const effectiveObstructions = controlsOnly ? (obstructionsExternal || []) : rackObstructions;

//   // Log section ID for debugging
//   useEffect(() => {
//     console.log("AutoPopulatePanel received section ID:", sectionId);
//   }, [sectionId]);

//   /** ---------- Populate algorithm ---------- */
//   const canPopulate =
//     !!effectiveSelection &&
//     effectiveSelection.width > 0 &&
//     effectiveSelection.height > 0 &&
//     rackWmm > 0 &&
//     rackHmm > 0 &&
//     aisleMM >= 0 &&
//     spacingXmm >= 0 &&
//     scale > 0;
  
//   const blockers: string[] = [];
//   if (!effectiveSelection) blockers.push('Draw a selection area on the canvas.');
//   else {
//     if (effectiveSelection.width <= 0)  blockers.push('Selection width must be > 0.');
//     if (effectiveSelection.height <= 0) blockers.push('Selection height must be > 0.');
//   }
//   if (scale <= 0)          blockers.push('Scale (px/mm) must be > 0 mm.');
//   if (rackWmm <= 0)        blockers.push('Rack length X must be > 0 mm.');
//   if (rackHmm <= 0)        blockers.push('Rack depth Y must be > 0 mm.');
//   if (spacingXmm < 0)      blockers.push('Gap between racks (X) must be ≥ 0 mm.');
//   if (aisleMM < 0)         blockers.push('Main aisle width (Y) must be ≥ 0 mm.');

//   const handlePopulate = () => {
//     if (!canPopulate) return;

//     // Clear existing racks first
//     setRacks([]);

//     const rackW = px(rotate90 ? rackHmm : rackWmm);
//     const rackH = px(rotate90 ? rackWmm : rackHmm);
//     const spacingX = px(spacingXmm);
//     const aisle = px(aisleMM);
//     const margin = px(marginMM);
//     const backGap = px(backGapMM);
//     const crossAisleWidth = px(crossAisleWidthMM);

//     const sel = effectiveSelection!;
//     const usableW = Math.max(0, sel.width - 2 * margin);
//     const usableH = Math.max(0, sel.height - 2 * margin);
    
//     console.log("Selection area:", sel);
//     console.log("Usable area:", { usableW, usableH });
    
//     if (usableW <= 0 || usableH <= 0) { 
//       console.log("Usable area too small");
//       setRacks([]); 
//       return; 
//     }

//     const cols = Math.max(0, Math.floor((usableW + spacingX) / (rackW + spacingX)));
//     console.log("Calculated columns:", cols);
    
//     if (cols === 0) { 
//       console.log("No columns fit in the area");
//       setRacks([]); 
//       return; 
//     }

//     const groupHeight = doubleDeep ? (rackH * 2 + backGap) : rackH;

//     // Build vertical blocks: rack groups + main aisle + optional cross aisles every N rows
//     const blocks: { type: 'racks' | 'cross'; heightPx: number }[] = [];
//     let used = 0, groupIndex = 0;
//     while (used + groupHeight <= usableH + 1e-6) {
//       // cross-aisle every N rows (between rack groups)
//       if (groupIndex > 0 && crossAisleEvery > 0 && groupIndex % crossAisleEvery === 0) {
//         if (used + crossAisleWidth > usableH) break;
//         blocks.push({ type: 'cross', heightPx: crossAisleWidth }); used += crossAisleWidth;
//       }
//       blocks.push({ type: 'racks', heightPx: groupHeight }); used += groupHeight;
//       groupIndex += 1;
//       // main aisle (between rack groups)
//       if (used + aisle + groupHeight <= usableH + 1e-6) { 
//         blocks.push({ type: 'cross', heightPx: aisle }); 
//         used += aisle; 
//       } else break;
//     }
    
//     console.log("Generated blocks:", blocks);
    
//     if (!blocks.some(b => b.type === 'racks')) { 
//       console.log("No rack blocks generated");
//       setRacks([]); 
//       return; 
//     }

//     const leftoverY = usableH - used;
//     const startY = sel.y + margin + Math.max(0, leftoverY) / 2;
//     const leftoverX = usableW - cols * rackW - (cols - 1) * spacingX;
//     const startX = sel.x + margin + Math.max(0, leftoverX) / 2;

//     console.log("Starting position:", { startX, startY });

//     const candidate: any[] = [];
//     let yCursor = startY;
//     for (const blk of blocks) {
//       if (blk.type === 'racks') {
//         for (let c = 0; c < cols; c++) {
//           const x = startX + c * (rackW + spacingX);
//           if (doubleDeep) {
//             const yTop = yCursor;
//             const yBottom = yCursor + rackH + backGap;
//             candidate.push({ 
//               id: `rack-${Date.now()}-${yCursor}-${c}-a`, 
//               x, 
//               y: yTop, 
//               width: rackW, 
//               height: rackH,
//               // Add section ID for multi-section support
//               sectionId: sectionId,
//               // Add metadata to help with maintaining pattern
//               metadata: {
//                 fromAutoPopulate: true,
//                 selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
//                 gridSize: gridPx
//               }
//             });
//             candidate.push({ 
//               id: `rack-${Date.now()}-${yCursor}-${c}-b`, 
//               x, 
//               y: yBottom, 
//               width: rackW, 
//               height: rackH,
//               // Add section ID for multi-section support
//               sectionId: sectionId,
//               // Add metadata to help with maintaining pattern
//               metadata: {
//                 fromAutoPopulate: true,
//                 selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
//                 gridSize: gridPx
//               }
//             });
//           } else {
//             candidate.push({ 
//               id: `rack-${Date.now()}-${yCursor}-${c}`, 
//               x, 
//               y: yCursor, 
//               width: rackW, 
//               height: rackH,
//               // Add section ID for multi-section support
//               sectionId: sectionId,
//               // Add metadata to help with maintaining pattern
//               metadata: {
//                 fromAutoPopulate: true,
//                 selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
//                 gridSize: gridPx
//               }
//             });
//           }
//         }
//         yCursor += blk.heightPx;
//       } else {
//         yCursor += blk.heightPx;
//       }
//     }

//     console.log("Generated candidates:", candidate.length);

//     // Filter candidates intersecting obstructions
//     const filtered = candidate.filter(r => !effectiveObstructions.some(o => rectsOverlap(r, o)));
    
//     // Ensure all racks are within the selection area
//     const withinBounds = filtered.filter(rack => {
//       if (!effectiveSelection) return true;
      
//       return (
//         rack.x >= effectiveSelection.x &&
//         rack.y >= effectiveSelection.y &&
//         rack.x + rack.width <= effectiveSelection.x + effectiveSelection.width &&
//         rack.y + rack.height <= effectiveSelection.y + effectiveSelection.height
//       );
//     });
    
//     console.log("After filtering:", withinBounds.length);
    
//     setRacks(withinBounds);
//   };

//   // Handle AutoPopulatePanel close
//   const handleAutoPopulateClose = () => {
//     // Simply call the onClose prop without any additional logic
//     onClose();
//   };

//   /** ---------- Exports (use local stage or main stage) ---------- */
//   const resolveStage = () => controlsOnly ? stageRef?.current : localStageRef.current;

//   function exportJSON() {
//     const data = {
//       units: 'mm',
//       scale_px_per_mm: scale,
//       selection: effectiveSelection,
//       obstructions: effectiveObstructions,
//       racks: racks.map(r => ({
//         ...r,
//         x_mm: r.x / scale, y_mm: r.y / scale,
//         width_mm: r.width / scale, height_mm: r.height / scale,
//       })),
//       sectionId: sectionId
//     };
//     const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
//     triggerDownload(URL.createObjectURL(blob), 'racking-layout.json');
//   }

//   function exportPNG() {
//     const s = resolveStage(); if (!s) return;
//     const url = s.toDataURL({ pixelRatio: 2 });
//     triggerDownload(url, 'racking-layout.png');
//   }

//   function exportSVG() {
//     const s = resolveStage(); if (!s) return;
//     const wpx = s.width(), hpx = s.height();
//     const svg = buildSVGFromShapes(racks, effectiveObstructions, effectiveSelection, wpx, hpx, scale);
//     const blob = new Blob([svg], { type: 'image/svg+xml' });
//     triggerDownload(URL.createObjectURL(blob), 'racking-layout.svg');
//   }

//   function exportDXF() {
//     const s = resolveStage(); if (!s) return;
//     const stageHmm = s.height() / scale; // mm
//     const dxfText = buildDXFFromShapes(racks, effectiveObstructions, effectiveSelection, stageHmm, scale);
//     const blob = new Blob([dxfText], { type: 'application/dxf' });
//     triggerDownload(URL.createObjectURL(blob), 'racking-layout.dxf');
//   }

//   /** ---------- Apply back to parent ---------- */
//   const applyRacks = () => {
//     console.log("AutoPopulatePanel - Applying racks:", racks.length, "with section ID:", sectionId);
    
//     // Ensure all racks are within the selection area
//     const validRacks = racks.filter(rack => {
//       if (!effectiveSelection) return true;
      
//       return (
//         rack.x >= effectiveSelection.x &&
//         rack.y >= effectiveSelection.y &&
//         rack.x + rack.width <= effectiveSelection.x + effectiveSelection.width &&
//         rack.y + rack.height <= effectiveSelection.y + effectiveSelection.height
//       );
//     });
    
//     console.log("Valid racks count:", validRacks.length);
    
//     // Create rack shapes with guaranteed section ID
//     const rackShapes = validRacks.map(rack => {
//       const rackId = rack.id || `rack-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
//       console.log(`Creating rack ${rackId} with section ${sectionId}`);
      
//       return {
//         ...rack,
//         id: rackId,
//         type: 'rack',
//         fill: '#1e293b',
//         stroke: '#22c55e',
//         strokeWidth: 1.5,
//         // IMPORTANT: Always set the section ID
//         sectionId: sectionId,
//         // Add metadata to help with maintaining pattern
//         metadata: {
//           fromAutoPopulate: true,
//           selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
//           gridSize: gridPx
//         }
//       };
//     });
    
//     console.log("Generated rack shapes:", rackShapes.length);
//     console.log("Section IDs in generated racks:", rackShapes.map(r => r.sectionId).filter(Boolean).length);
    
//     // Pass racks to parent component and close the panel
//     onGenerateRacks(rackShapes);
//     onClose();
//   };

//   /** ---------- Standalone drawing (ignored in controlsOnly) ---------- */
//   const onMouseDown = (e: any) => {
//     if (controlsOnly) return;
//     const stage = e.target.getStage(); if (!stage) return;
//     const pos = stage.getPointerPosition(); if (!pos) return;
//     const x = snap(pos.x), y = snap(pos.y);
//     setTempRect({ x, y, width: 0, height: 0 });
//     setIsDrawing(true);
//   };

//   const onMouseMove = (e: any) => {
//     if (controlsOnly) return;
//     if (!isDrawing || !tempRect) return;
//     const stage = e.target.getStage(); if (!stage) return;
//     const pos = stage.getPointerPosition(); if (!pos) return;
//     const x2 = snap(pos.x), y2 = snap(pos.y);
//     const width2 = x2 - tempRect.x, height2 = y2 - tempRect.y;
//     const rect = {
//       x: width2 >= 0 ? tempRect.x : tempRect.x + width2,
//       y: height2 >= 0 ? tempRect.y : tempRect.y + height2,
//       width: Math.abs(width2),
//       height: Math.abs(height2),
//     };
//     if (e.evt.shiftKey) {
//       const size = Math.min(rect.width, rect.height);
//       rect.width = size;
//       rect.height = size;
//     }
//     setTempRect(rect);
//   };

//   const onMouseUp = () => {
//     if (controlsOnly) return;
//     if (!isDrawing || !tempRect) return;
//     setIsDrawing(false);
//     if (tempRect.width > 0 && tempRect.height > 0) {
//       if (mode === 'selection') {
//         setSelection(tempRect);
//       } else {
//         setObstructionsLocal(prev => [...prev, { ...tempRect, id: `obs-${Date.now()}` }]);
//       }
//     }
//     setTempRect(null);
//   };

//   // Get world position from event
//   function getWorldPointer(e: any) {
//     const stage = e.target.getStage?.();
//     if (!stage) return null;
    
//     const pos = stage.getPointerPosition();
//     if (!pos) return null;
    
//     const world = { 
//       x: (pos.x - stage.x()) / stage.scaleX(), 
//       y: (pos.y - stage.y()) / stage.scaleY() 
//     };
    
//     return { stage, world };
//   }

//   // Auto-populate mouse handlers
//   const onAutoPopulateMouseDown = (e: any) => {
//     if (!localAutoPopulateMode) return;
    
//     const ctx = getWorldPointer(e);
//     if (!ctx) return;
    
//     const { world } = ctx;
//     const x = snap(world.x, gridSize);
//     const y = snap(world.y, gridSize);
    
//     setApDrawRect({ x, y, width: 0, height: 0 });
//     setIsDrawingAP(true);
//   };

//   const onAutoPopulateMouseMove = (e: any) => {
//     if (!localAutoPopulateMode || !isDrawingAP || !apDrawRect) return;
    
//     const ctx = getWorldPointer(e);
//     if (!ctx) return;
    
//     const { world } = ctx;
//     const x2 = snap(world.x, gridSize);
//     const y2 = snap(world.y, gridSize);
    
//     const w2 = x2 - apDrawRect.x;
//     const h2 = y2 - apDrawRect.y;
    
//     const rect = {
//       x: w2 >= 0 ? apDrawRect.x : apDrawRect.x + w2,
//       y: h2 >= 0 ? apDrawRect.y : apDrawRect.y + h2,
//       width: Math.abs(w2),
//       height: Math.abs(h2),
//     } as RectPx;
    
//     if ((e as any).evt.shiftKey) {
//       const size = Math.min(rect.width, rect.height);
//       rect.width = size;
//       rect.height = size;
//     }
    
//     setApDrawRect(rect);
//     if (localAutoPopulateMode === 'selection') setRackSelectionRect(rect);
//   };

//   const onAutoPopulateMouseUp = () => {
//     if (!localAutoPopulateMode || !isDrawingAP) return;
    
//     setIsDrawingAP(false);
//     if (!apDrawRect || apDrawRect.width <= 0 || apDrawRect.height <= 0) { 
//       setApDrawRect(null); 
//       return; 
//     }
    
//     if (localAutoPopulateMode === 'obstruction') {
//       setRackObstructions(prev => [...prev, { id: `obs-${Date.now()}`, ...apDrawRect! }]);
//       setApDrawRect(null);
//     } else {
//       setRackSelectionRect(apDrawRect!);
//       setApDrawRect(null);
//     }
//   };

//   // Clear obstructions
//   const clearObstructions = () => {
//     if (controlsOnly) { 
//       onClearObstructions?.(); 
//       return; 
//     }
//     setRackObstructions([]);
//   };
  
//   // Clear all (selection and obstructions)
//   const clearAll = () => {
//     if (controlsOnly) { 
//       onClearAll?.(); 
//       return; 
//     }
//     setRackSelectionRect(null);
//     setRackObstructions([]);
//   };

//   // Section information display component
//   const SectionInfo = () => {
//     if (!sectionId) return null;
    
//     return (
//       <div style={styles.sectionInfo}>
//         <h4 style={styles.sectionTitle}>Section: {sectionId.substring(0, 8)}...</h4>
//         <p style={styles.sectionNote}>
//           Racks in this section will stay within the selection boundary.
//         </p>
//       </div>
//     );
//   };

//   // Drawing mode controls
//   const DrawingModeControls = () => (
//     <div style={styles.settingGroup}>
//       <h3 style={styles.h3}>Drawing Mode</h3>
//       <div style={styles.row}>
//         <button
//           style={{
//             ...styles.button,
//             ...(localAutoPopulateMode === 'selection' ? styles.primaryButton : {})
//           }}
//           onClick={() => {
//             setLocalAutoPopulateMode('selection');
//             onToggleMode?.('selection');
//           }}
//         >
//           Selection
//         </button>
//         <button
//           style={{
//             ...styles.button,
//             ...(localAutoPopulateMode === 'obstruction' ? styles.primaryButton : {})
//           }}
//           onClick={() => {
//             setLocalAutoPopulateMode('obstruction');
//             onToggleMode?.('obstruction');
//           }}
//         >
//           Add Obstruction
//         </button>
//       </div>
//       <button style={styles.button} onClick={clearObstructions}>Clear Obstructions</button>
//       <div style={styles.small}>Tip: Hold <span style={styles.badge}>Shift</span> to constrain perfect squares while drawing.</div>
//     </div>
//   );

//   return (
//     <div style={controlsOnly ? { padding: '16px' } : styles.container}>
//       {/* -------- Sidebar -------- */}
//       <div style={styles.sidebar}>
//         <h2 style={styles.h2}>SPR Auto‑Populate</h2>
        
//         {/* Section information */}
//         <SectionInfo />

//         <div style={styles.settingGroup}>
//           <label style={styles.label}>Pixels per mm</label>
//           <input 
//             type="number" 
//             min="0.1" 
//             step="0.1" 
//             value={scale}
//             style={styles.input}
//             onChange={e => setScale(Number(e.target.value) || 1)} 
//           />
//         </div>

//         <div style={styles.settingGroup}>
//           <label style={styles.label}>Grid size (mm)</label>
//           <input 
//             type="number" 
//             min="10" 
//             step="10" 
//             value={gridMM}
//             style={styles.input}
//             onChange={e => setGridMM(Number(e.target.value) || 100)} 
//           />
//           <div style={styles.note}>Selection & obstructions snap to grid.</div>
//         </div>

//         <div style={styles.settingGroup}>
//           <h3 style={styles.h3}>Rack & Aisle (mm)</h3>
//           <div style={styles.row}>
//             <div>
//               <label style={styles.label}>Rack length X</label>
//               <input 
//                 type="number" 
//                 value={rackWmm}
//                 style={styles.input}
//                 onChange={e => setRackWmm(Number(e.target.value) || 0)} 
//               />
//             </div>
//             <div>
//               <label style={styles.label}>Rack depth Y</label>
//               <input 
//                 type="number" 
//                 value={rackHmm}
//                 style={styles.input}
//                 onChange={e => setRackHmm(Number(e.target.value) || 0)} 
//               />
//             </div>
//           </div>
//           <div style={styles.row}>
//             <div>
//               <label style={styles.label}>Gap between racks (X)</label>
//               <input 
//                 type="number" 
//                 value={spacingXmm}
//                 style={styles.input}
//                 onChange={e => setSpacingXmm(Number(e.target.value) || 0)} 
//               />
//             </div>
//             <div>
//               <label style={styles.label}>Main aisle width (Y)</label>
//               <input 
//                 type="number" 
//                 value={aisleMM}
//                 style={styles.input}
//                 onChange={e => setAisleMM(Number(e.target.value) || 0)} 
//               />
//             </div>
//           </div>
//           <div style={styles.row}>
//             <div>
//               <label style={styles.label}>Selection margin</label>
//               <input 
//                 type="number" 
//                 value={marginMM}
//                 style={styles.input}
//                 onChange={e => setMarginMM(Number(e.target.value) || 0)} 
//               />
//             </div>
//             <div>
//               <label style={styles.label}>Rotate racks 90°</label>
//               <select 
//                 value={rotate90 ? 'yes' : 'no'}
//                 style={styles.select}
//                 onChange={e => setRotate90(e.target.value === 'yes')}
//               >
//                 <option value="no">No</option>
//                 <option value="yes">Yes</option>
//               </select>
//             </div>
//           </div>
//         </div>

//         <div style={styles.settingGroup}>
//           <h3 style={styles.h3}>Double‑Deep & Cross‑Aisles</h3>
//           <div style={styles.row}>
//             <div>
//               <label style={styles.label}>Double‑deep</label>
//               <select 
//                 value={doubleDeep ? 'yes' : 'no'}
//                 style={styles.select}
//                 onChange={e => setDoubleDeep(e.target.value === 'yes')}
//               >
//                 <option value="no">No</option>
//                 <option value="yes">Yes</option>
//               </select>
//             </div>
//             <div>
//               <label style={styles.label}>Back gap (mm)</label>
//               <input 
//                 type="number" 
//                 value={backGapMM}
//                 style={styles.input}
//                 onChange={e => setBackGapMM(Number(e.target.value) || 0)} 
//               />
//             </div>
//           </div>

//           <div style={styles.row}>
//             <div>
//               <label style={styles.label}>Cross‑aisle every N rows</label>
//               <input 
//                 type="number" 
//                 min="0" 
//                 value={crossAisleEvery}
//                 style={styles.input}
//                 onChange={e => setCrossAisleEvery(Number(e.target.value) || 0)} 
//               />
//             </div>
//             <div>
//               <label style={styles.label}>Cross‑aisle width (mm)</label>
//               <input 
//                 type="number" 
//                 value={crossAisleWidthMM}
//                 style={styles.input}
//                 onChange={e => setCrossAisleWidthMM(Number(e.target.value) || 0)} 
//               />
//             </div>
//           </div>
//           <div style={styles.small}>Set N=0 to disable cross‑aisles.</div>
//         </div>

//         {/* Drawing mode controls */}
//         <DrawingModeControls />

//         <div style={styles.settingGroup}>
//           <button 
//             style={{
//               ...styles.button,
//               ...styles.primaryButton,
//               ...(canPopulate ? {} : styles.buttonDisabled)
//             }} 
//             onClick={handlePopulate} 
//             disabled={!canPopulate}
//           >
//             Populate Racks
//           </button>
          
//           {!canPopulate && blockers.length > 0 && (
//             <div style={styles.note}>
//               Can't populate yet:
//               <ul style={{ marginTop: 6 }}>
//                 {blockers.map((b, i) => <li key={i}>{b}</li>)}
//               </ul>
//             </div>
//           )}

//           <button 
//             style={{...styles.button, ...styles.dangerButton}} 
//             onClick={clearAll}
//           >
//             Clear Selection
//           </button>
//         </div>

//         {/* Exports */}
//         <div style={styles.settingGroup}>
//           <button 
//             style={{
//               ...styles.button,
//               ...(racks.length === 0 ? styles.buttonDisabled : {})
//             }} 
//             onClick={exportJSON} 
//             disabled={racks.length === 0}
//           >
//             Download JSON
//           </button>
//           <div style={styles.row}>
//             <button style={styles.button} onClick={exportPNG}>Export PNG</button>
//             <button style={styles.button} onClick={exportSVG}>Export SVG</button>
//           </div>
//           <button style={styles.button} onClick={exportDXF}>Export DXF</button>
//         </div>

//         <div style={styles.settingGroup}>
//           <div style={styles.row}>
//             <button style={styles.button} onClick={onClose}>Cancel</button>
//             <button 
//               style={{
//                 ...styles.button,
//                 ...styles.primaryButton,
//                 ...(racks.length === 0 ? styles.buttonDisabled : {})
//               }} 
//               onClick={applyRacks} 
//               disabled={racks.length === 0}
//             >
//               Apply Racks
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* -------- Preview Canvas (hidden in controlsOnly) -------- */}
//       {!controlsOnly && (
//         <div style={styles.canvas}>
//           <Stage
//             ref={localStageRef}
//             width={width}
//             height={height}
//             onMouseDown={onAutoPopulateMouseDown}
//             onMouseMove={onAutoPopulateMouseMove}
//             onMouseUp={onAutoPopulateMouseUp}
//             style={{ background: '#0a0f1d', borderRadius: 8, border: '1px solid #1f2937' }}
//           >
//             {/* Grid */}
//             <Layer listening={false}>
//               {gridLines.map((l, i) => (<Line key={i} points={l.points} stroke="#0b2942" strokeWidth={1} />))}
//             </Layer>

//             {/* Racks */}
//             <Layer listening={false}>
//               {racks.map((r) => (
//                 <Group key={r.id}>
//                   <Rect x={r.x} y={r.y} width={r.width} height={r.height}
//                         fill="#1e293b" stroke="#22c55e" strokeWidth={1.5} cornerRadius={3} />
//                 </Group>
//               ))}
//             </Layer>

//             {/* Obstructions */}
//             <Layer listening={false}>
//               {rackObstructions.map((o) => (
//                 <Rect key={o.id} x={o.x} y={o.y} width={o.width} height={o.height}
//                       fill="rgba(239,68,68,0.2)" stroke="#ef4444" strokeWidth={1.5} cornerRadius={3} />
//               ))}
//             </Layer>

//             {/* Selection */}
//             <Layer listening={false}>
//               {rackSelectionRect && rackSelectionRect.width > 0 && rackSelectionRect.height > 0 && (
//                 <Group>
//                   <Rect x={rackSelectionRect.x} y={rackSelectionRect.y} width={rackSelectionRect.width} height={rackSelectionRect.height}
//                         stroke="#93c5fd" dash={[6, 4]} cornerRadius={4} />
//                   <Rect x={rackSelectionRect.x} y={rackSelectionRect.y} width={rackSelectionRect.width} height={rackSelectionRect.height}
//                         fillLinearGradientStartPoint={{ x:0, y:0 }}
//                         fillLinearGradientEndPoint={{ x:0, y:rackSelectionRect.height }}
//                         fillLinearGradientColorStops={[0,'rgba(59,130,246,0.08)',1,'rgba(59,130,246,0.02)']} />
//                 </Group>
//               )}

//               {/* Drawing preview */}
//               {isDrawingAP && apDrawRect && apDrawRect.width > 0 && apDrawRect.height > 0 && (
//                 <Group>
//                   <Rect x={apDrawRect.x} y={apDrawRect.y} width={apDrawRect.width} height={apDrawRect.height}
//                         stroke={localAutoPopulateMode === 'selection' ? '#93c5fd' : '#ef4444'} dash={[6,4]} cornerRadius={4} />
//                   <Rect x={apDrawRect.x} y={apDrawRect.y} width={apDrawRect.width} height={apDrawRect.height}
//                         fill={localAutoPopulateMode === 'selection' ? 'rgba(59,130,246,0.08)' : 'rgba(239,68,68,0.08)'} />
//                 </Group>
//               )}
//             </Layer>
//           </Stage>
//         </div>
//       )}
//     </div>
//   );
// }
      

import React, { useMemo, useRef, useState, useEffect } from 'react';
import { Stage, Layer, Line, Rect, Text, Group } from 'react-konva';

/** ---------- Styles ---------- */
const styles = {
  container: {
    display: 'grid',
    gridTemplateColumns: '360px 1fr',
    gap: '16px',
    padding: '16px',
    fontFamily: 'sans-serif',
    color: '#111827',
    height: '100%',
  },
  sidebar: {
    color: '#111827',
    padding: '16px',
    borderRadius: '8px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
    overflowY: 'auto' as const,
    maxHeight: 'calc(100vh - 32px)',
  },
  h2: {
    margin: 0,
    marginBottom: '12px',
    fontSize: '1.25rem',
    color: '#111827',
    borderBottom: '1px solid #e5e7eb',
    paddingBottom: '8px',
  },
  h3: {
    margin: 0,
    marginBottom: '8px',
    fontSize: '1rem',
    color: '#111827',
  },
  settingGroup: {
    marginBottom: '16px',
  },
  label: {
    display: 'block',
    marginBottom: '4px',
    fontSize: '0.875rem',
    color: '#9ca3af',
  },
  input: {
    width: '100%',
    padding: '8px 10px',
    background: 'white',
    border: '1px solid #d1d5db',
    borderRadius: '4px',
    color: '#111827',
    fontSize: '0.875rem',
    marginBottom: '6px',
  },
  select: {
    width: '100%',
    padding: '8px 10px',
    background: 'white',
    border: '1px solid #d1d5db',
    borderRadius: '4px',
    color: '#111827',
    fontSize: '0.875rem',
    marginBottom: '6px',
  },
  inputFocus: {
    outline: 'none',
    borderColor: '#16a34a',
    boxShadow: '0 0 0 1px rgba(59, 130, 246, 0.5)',
  },
  inputDisabled: {
    opacity: 0.6,
    cursor: 'not-allowed',
  },
  row: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '8px',
  },
  note: {
    fontSize: '0.75rem',
    color: '#9ca3af',
    marginTop: '4px',
    marginBottom: '8px',
  },
  small: {
    fontSize: '0.75rem',
    color: '#9ca3af',
    marginTop: '4px',
    marginBottom: '8px',
  },
  button: {
    padding: '8px 12px',
    borderRadius: '4px',
    fontSize: '0.875rem',
    fontWeight: 500,
    cursor: 'pointer',
    transition: 'all 0.2s',
    background: '#f3f4f6',
    color: '#111827',
    border: '1px solid #d1d5db',
  },
  buttonHover: {
    background: 'green',
  },
  buttonActive: {
    transform: 'translateY(1px)',
  },
  buttonDisabled: {
    opacity: 0.6,
    cursor: 'not-allowed',
  },
  primaryButton: {
    background: '#2563eb',
    color: 'white',
    border: '1px solid #1d4ed8',
  },
  primaryButtonHover: {
    background: '#1d4ed8',
  },
  dangerButton: {
    background: '#dc2626',
    color: 'white',
    border: '1px solid #b91c1c',
  },
  dangerButtonHover: {
    background: '#b91c1c',
  },
  help: {
    background: '#1e293b',
    padding: '10px',
    borderRadius: '4px',
    fontSize: '0.75rem',
    color: '#94a3b8',
    borderLeft: '3px solid #3b82f6',
  },
  badge: {
    background: '#374151',
    padding: '2px 6px',
    borderRadius: '4px',
    fontSize: '0.75rem',
    fontFamily: 'monospace',
  },
  canvas: {
    position: 'relative' as const,
    borderRadius: '8px',
    overflow: 'hidden',
  },
  sectionInfo: {
    background: '#f0f9ff',
    border: '1px solid #bae6fd',
    borderRadius: '4px',
    padding: '10px',
    marginBottom: '16px',
  },
  sectionTitle: {
    margin: 0,
    marginBottom: '8px',
    color: '#0284c7',
    fontSize: '14px',
  },
  sectionNote: {
    margin: 0,
    fontSize: '12px',
    color: '#64748b',
  }
};

/** ---------- Props ---------- */
export type AutoPopulatePanelProps = {
  /** Standalone preview canvas size (ignored if controlsOnly=true) */
  width?: number;
  height?: number;

  /** Close panel */
  onClose: () => void;

  /** Return generated rack shapes to parent (Konva-friendly objects) */
  onGenerateRacks: (racks: any[]) => void;

  /** Seed values; panel will fall back to these if provided */
  initialSettings?: Record<string, any>;

  /** --------- Controls-Only mode (Render sidebar only; operate on main canvas) ---------- */
  controlsOnly?: boolean;

  /** Main canvas Stage ref (used for PNG/SVG/DXF exports when controlsOnly=true) */
  stageRef?: React.RefObject<any>;

  /** Live selection rect from main canvas (controlsOnly=true) */
  selectionRect?: { x: number; y: number; width: number; height: number } | null;

  /** Live obstructions from main canvas (controlsOnly=true) */
  obstructions?: { id: string; x: number; y: number; width: number; height: number }[];

  /** Ask canvas to switch drawing mode when controlsOnly=true */
  onToggleMode?: (mode: 'selection' | 'obstruction' | null) => void;

  /** Clear obstructions (main canvas) when controlsOnly=true */
  onClearObstructions?: () => void;

  hideModeButtons?: boolean;

  /** Clear selection+obstructions (main canvas) when controlsOnly=true */
  onClearAll?: () => void;
  
  /** Current section ID for multi-section support */
  sectionId?: string | null;
};

/** ---------- Helpers ---------- */
function drawGridLines(width: number, height: number, step: number) {
  const lines: { points: number[] }[] = [];
  for (let x = 0; x <= width; x += step) lines.push({ points: [x, 0, x, height] });
  for (let y = 0; y <= height; y += step) lines.push({ points: [0, y, width, y] });
  return lines;
}

function rectsOverlap(a: any, b: any) {
  return !(
    a.x + a.width <= b.x ||
    b.x + b.width <= a.x ||
    a.y + a.height <= b.y ||
    b.y + b.height <= a.y
  );
}

function triggerDownload(href: string, filename: string) {
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  a.click();
  if (href.startsWith('blob:')) URL.revokeObjectURL(href);
}

/** Build SVG from shapes (mm units for size, px within viewBox) */
function buildSVGFromShapes(
  racks: any[],
  obstructions: any[],
  selection: any,
  wpx: number, hpx: number,
  scale: number
) {
  const rect = (r: any, stroke: string, fill: string) =>
    `<rect x="${r.x}" y="${r.y}" width="${r.width}" height="${r.height}" stroke="${stroke}" fill="${fill}" stroke-width="1" />`;
  const racksSvg = racks.map((r) => rect(r, '#22c55e', '#1e293b')).join('');
  const obsSvg = obstructions.map((o) => rect(o, '#ef4444', 'rgba(239,68,68,0.2)')).join('');
  const selSvg =
    selection && selection.width > 0 && selection.height > 0
      ? `<rect x="${selection.x}" y="${selection.y}" width="${selection.width}" height="${selection.height}" stroke="#93c5fd" fill="none" stroke-dasharray="6 4" />`
      : '';
  const wmm = (wpx / scale).toFixed(2), hmm = (hpx / scale).toFixed(2);
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${wmm}mm" height="${hmm}mm" viewBox="0 0 ${wpx} ${hpx}">
  <g id="racks">${racksSvg}</g>
  <g id="obstructions">${obsSvg}</g>
  <g id="selection">${selSvg}</g>
</svg>`;
}

/** Build DXF (mm) using LWPOLYLINE (closed) */
function buildDXFFromShapes(
  racks: any[],
  obstructions: any[],
  selection: any,
  stageHmm: number, // stage height in mm
  scale: number
) {
  const rectToDxf = (r: any, layer: string) => {
    const x1 = r.x / scale, y1 = r.y / scale;
    const x2 = (r.x + r.width) / scale, y2 = (r.y + r.height) / scale;
    const fy1 = stageHmm - y1, fy2 = stageHmm - y2; // flip Y
    return [
      '0','LWPOLYLINE','8',layer,'90','4','70','1',
      '10', `${x1}`, '20', `${fy1}`,
      '10', `${x2}`, '20', `${fy1}`,
      '10', `${x2}`, '20', `${fy2}`,
      '10', `${x1}`, '20', `${fy2}`,
    ].join('\n');
  };

  const parts: string[] = [];
  parts.push('0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC');
  parts.push('0','SECTION','2','ENTITIES');
  racks.forEach((r) => parts.push(rectToDxf(r, 'RACKS')));
  obstructions.forEach((o) => parts.push(rectToDxf(o, 'OBSTRUCTIONS')));
  if (selection && selection.width > 0 && selection.height > 0) parts.push(rectToDxf(selection, 'SELECTION'));
  parts.push('0','ENDSEC','0','EOF');
  return parts.join('\n');
}

/** ---------- Component ---------- */
export default function AutoPopulatePanel({
  width = 1200,
  height = 800,
  onClose,
  onGenerateRacks,
  initialSettings = {},

  controlsOnly = false,
  stageRef, // main canvas Stage (for exports)
  selectionRect, // main canvas selection (controlsOnly)
  obstructions: obstructionsExternal = [],
  onToggleMode,
  onClearObstructions,
  onClearAll,
  sectionId = null,
}: AutoPopulatePanelProps) {
  /** ----- Settings (same defaults as your prototype) ----- */
  const [scale, setScale] = useState<number>(initialSettings.scale || 1); // px per mm
  const [gridMM, setGridMM] = useState<number>(initialSettings.gridMM || 100);
  const [rackWmm, setRackWmm] = useState<number>(initialSettings.rackWmm || 2700);
  const [rackHmm, setRackHmm] = useState<number>(initialSettings.rackHmm || 1100);
  const [spacingXmm, setSpacingXmm] = useState<number>(initialSettings.spacingXmm || 100);
  const [aisleMM, setAisleMM] = useState<number>(initialSettings.aisleMM || 3000);
  const [marginMM, setMarginMM] = useState<number>(initialSettings.marginMM || 100);
  const [rotate90, setRotate90] = useState<boolean>(initialSettings.rotate90 || false);
  const [doubleDeep, setDoubleDeep] = useState<boolean>(initialSettings.doubleDeep || false);
  const [backGapMM, setBackGapMM] = useState<number>(initialSettings.backGapMM || 0);
  const [crossAisleEvery, setCrossAisleEvery] = useState<number>(initialSettings.crossAisleEvery || 3);
  const [crossAisleWidthMM, setCrossAisleWidthMM] = useState<number>(initialSettings.crossAisleWidthMM || 1500);

  /** ----- Live racks generated by Populate (px units) ----- */
  const [racks, setRacks] = useState<any[]>([]);

  /** ----- Standalone drawing state (ignored if controlsOnly) ----- */
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [points, setPoints] = useState<number[]>([]);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [currentShape, setCurrentShape] = useState<any | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [stageSize, setStageSize] = useState({ 
    width: window.innerWidth - 0, 
    height: window.innerHeight - 0 
  });
  const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 });
  const localStageRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const transformerRef = useRef<any>(null);

  /** ----- Auto-populate state ----- */
  const [localAutoPopulateMode, setLocalAutoPopulateMode] = useState<'selection' | 'obstruction' | null>('selection');

  /** ----- Selection & obstructions for auto-populate ----- */
  type RectPx = { x: number; y: number; width: number; height: number };
  type ObstructionPx = RectPx & { id: string };
  const [rackSelectionRect, setRackSelectionRect] = useState<RectPx | null>(null);
  const [rackObstructions, setRackObstructions] = useState<ObstructionPx[]>([]);
  const [isDrawingAP, setIsDrawingAP] = useState<boolean>(false);
  const [apDrawRect, setApDrawRect] = useState<RectPx | null>(null);

  /** Standalone Stage ref */
  //const localStageRef = useRef<any>(null);

  // Grid
  const gridPx = useMemo(() => Math.max(10, gridMM * scale), [gridMM, scale]);
  const gridLines = useMemo(
    () => drawGridLines(width, height, gridPx),
    [width, height, gridPx]
  );
  const px = (mm: number) => mm * scale;
  const snap = (n: number) => Math.round(n / gridPx) * gridPx;

  /** ---------- Data source selection (controlsOnly vs standalone) ---------- */
  const effectiveSelection = controlsOnly ? selectionRect : rackSelectionRect;
  const effectiveObstructions = controlsOnly ? (obstructionsExternal || []) : rackObstructions;

  // Log section ID for debugging
  useEffect(() => {
    console.log("AutoPopulatePanel received section ID:", sectionId);
  }, [sectionId]);

  /** ---------- Populate algorithm ---------- */
  const canPopulate =
    !!effectiveSelection &&
    effectiveSelection.width > 0 &&
    effectiveSelection.height > 0 &&
    rackWmm > 0 &&
    rackHmm > 0 &&
    aisleMM >= 0 &&
    spacingXmm >= 0 &&
    scale > 0;
  
  const blockers: string[] = [];
  if (!effectiveSelection) blockers.push('Draw a selection area on the canvas.');
  else {
    if (effectiveSelection.width <= 0)  blockers.push('Selection width must be > 0.');
    if (effectiveSelection.height <= 0) blockers.push('Selection height must be > 0.');
  }
  if (scale <= 0)          blockers.push('Scale (px/mm) must be > 0 mm.');
  if (rackWmm <= 0)        blockers.push('Rack length X must be > 0 mm.');
  if (rackHmm <= 0)        blockers.push('Rack depth Y must be > 0 mm.');
  if (spacingXmm < 0)      blockers.push('Gap between racks (X) must be ≥ 0 mm.');
  if (aisleMM < 0)         blockers.push('Main aisle width (Y) must be ≥ 0 mm.');

  const handlePopulate = () => {
    if (!canPopulate) return;

    // Clear existing racks first
    setRacks([]);

    const rackW = px(rotate90 ? rackHmm : rackWmm);
    const rackH = px(rotate90 ? rackWmm : rackHmm);
    const spacingX = px(spacingXmm);
    const aisle = px(aisleMM);
    const margin = px(marginMM);
    const backGap = px(backGapMM);
    const crossAisleWidth = px(crossAisleWidthMM);

    const sel = effectiveSelection!;
    const usableW = Math.max(0, sel.width - 2 * margin);
    const usableH = Math.max(0, sel.height - 2 * margin);
    
    console.log("Selection area:", sel);
    console.log("Usable area:", { usableW, usableH });
    
    if (usableW <= 0 || usableH <= 0) { 
      console.log("Usable area too small");
      setRacks([]); 
      return; 
    }

    const cols = Math.max(0, Math.floor((usableW + spacingX) / (rackW + spacingX)));
    console.log("Calculated columns:", cols);
    
    if (cols === 0) { 
      console.log("No columns fit in the area");
      setRacks([]); 
      return; 
    }

    const groupHeight = doubleDeep ? (rackH * 2 + backGap) : rackH;

    // Build vertical blocks: rack groups + main aisle + optional cross aisles every N rows
    const blocks: { type: 'racks' | 'cross'; heightPx: number }[] = [];
    let used = 0, groupIndex = 0;
    while (used + groupHeight <= usableH + 1e-6) {
      // cross-aisle every N rows (between rack groups)
      if (groupIndex > 0 && crossAisleEvery > 0 && groupIndex % crossAisleEvery === 0) {
        if (used + crossAisleWidth > usableH) break;
        blocks.push({ type: 'cross', heightPx: crossAisleWidth }); used += crossAisleWidth;
      }
      blocks.push({ type: 'racks', heightPx: groupHeight }); used += groupHeight;
      groupIndex += 1;
      // main aisle (between rack groups)
      if (used + aisle + groupHeight <= usableH + 1e-6) { 
        blocks.push({ type: 'cross', heightPx: aisle }); 
        used += aisle; 
      } else break;
    }
    
    console.log("Generated blocks:", blocks);
    
    if (!blocks.some(b => b.type === 'racks')) { 
      console.log("No rack blocks generated");
      setRacks([]); 
      return; 
    }

    const leftoverY = usableH - used;
    const startY = sel.y + margin + Math.max(0, leftoverY) / 2;
    const leftoverX = usableW - cols * rackW - (cols - 1) * spacingX;
    const startX = sel.x + margin + Math.max(0, leftoverX) / 2;

    console.log("Starting position:", { startX, startY });

    const candidate: any[] = [];
    let yCursor = startY;
    for (const blk of blocks) {
      if (blk.type === 'racks') {
        for (let c = 0; c < cols; c++) {
          const x = startX + c * (rackW + spacingX);
          if (doubleDeep) {
            const yTop = yCursor;
            const yBottom = yCursor + rackH + backGap;
            candidate.push({ 
              id: `rack-${Date.now()}-${yCursor}-${c}-a`, 
              x, 
              y: yTop, 
              width: rackW, 
              height: rackH,
              // Add section ID for multi-section support
              sectionId: sectionId,
              // Add metadata to help with maintaining pattern
              metadata: {
                fromAutoPopulate: true,
                selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
                gridSize: gridPx
              }
            });
            candidate.push({ 
              id: `rack-${Date.now()}-${yCursor}-${c}-b`, 
              x, 
              y: yBottom, 
              width: rackW, 
              height: rackH,
              // Add section ID for multi-section support
              sectionId: sectionId,
              // Add metadata to help with maintaining pattern
              metadata: {
                fromAutoPopulate: true,
                selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
                gridSize: gridPx
              }
            });
          } else {
            candidate.push({ 
              id: `rack-${Date.now()}-${yCursor}-${c}`, 
              x, 
              y: yCursor, 
              width: rackW, 
              height: rackH,
              // Add section ID for multi-section support
              sectionId: sectionId,
              // Add metadata to help with maintaining pattern
              metadata: {
                fromAutoPopulate: true,
                selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
                gridSize: gridPx
              }
            });
          }
        }
        yCursor += blk.heightPx;
      } else {
        yCursor += blk.heightPx;
      }
    }

    console.log("Generated candidates:", candidate.length);

    // Filter candidates intersecting obstructions
    const filtered = candidate.filter(r => !effectiveObstructions.some(o => rectsOverlap(r, o)));
    
    // Ensure all racks are within the selection area
    const withinBounds = filtered.filter(rack => {
      if (!effectiveSelection) return true;
      
      return (
        rack.x >= effectiveSelection.x &&
        rack.y >= effectiveSelection.y &&
        rack.x + rack.width <= effectiveSelection.x + effectiveSelection.width &&
        rack.y + rack.height <= effectiveSelection.y + effectiveSelection.height
      );
    });
    
    console.log("After filtering:", withinBounds.length);
    
    // Update state with the new racks
    setRacks(withinBounds);
    
    // Apply racks immediately if there are any
    if (withinBounds.length > 0) {
      // Create rack shapes with guaranteed section ID
      const rackShapes = withinBounds.map(rack => {
        const rackId = rack.id || `rack-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        console.log(`Creating rack ${rackId} with section ${sectionId}`);
        
        return {
          ...rack,
          id: rackId,
          type: 'rack',
          fill: '#1e293b',
          stroke: '#22c55e',
          strokeWidth: 1.5,
          // IMPORTANT: Always set the section ID
          sectionId: sectionId,
          // Add metadata to help with maintaining pattern
          metadata: {
            fromAutoPopulate: true,
            selectionRect: effectiveSelection ? { ...effectiveSelection } : null,
            gridSize: gridPx
          }
        };
      });
      
      console.log("Generated rack shapes:", rackShapes.length);
      console.log("Section IDs in generated racks:", rackShapes.map(r => r.sectionId).filter(Boolean).length);
      
      // Pass racks to parent component and close the panel
      onGenerateRacks(rackShapes);
      onClose();
    }
  };

  // Handle AutoPopulatePanel close
  const handleAutoPopulateClose = () => {
    // Simply call the onClose prop without any additional logic
    onClose();
  };

  /** ---------- Exports (use local stage or main stage) ---------- */
  const resolveStage = () => controlsOnly ? stageRef?.current : localStageRef.current;

  function exportJSON() {
    const data = {
      units: 'mm',
      scale_px_per_mm: scale,
      selection: effectiveSelection,
      obstructions: effectiveObstructions,
      racks: racks.map(r => ({
        ...r,
        x_mm: r.x / scale, y_mm: r.y / scale,
        width_mm: r.width / scale, height_mm: r.height / scale,
      })),
      sectionId: sectionId
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    triggerDownload(URL.createObjectURL(blob), 'racking-layout.json');
  }

  function exportPNG() {
    const s = resolveStage(); if (!s) return;
    const url = s.toDataURL({ pixelRatio: 2 });
    triggerDownload(url, 'racking-layout.png');
  }

  function exportSVG() {
    const s = resolveStage(); if (!s) return;
    const wpx = s.width(), hpx = s.height();
    const svg = buildSVGFromShapes(racks, effectiveObstructions, effectiveSelection, wpx, hpx, scale);
    const blob = new Blob([svg], { type: 'image/svg+xml' });
    triggerDownload(URL.createObjectURL(blob), 'racking-layout.svg');
  }

  function exportDXF() {
    const s = resolveStage(); if (!s) return;
    const stageHmm = s.height() / scale; // mm
    const dxfText = buildDXFFromShapes(racks, effectiveObstructions, effectiveSelection, stageHmm, scale);
    const blob = new Blob([dxfText], { type: 'application/dxf' });
    triggerDownload(URL.createObjectURL(blob), 'racking-layout.dxf');
  }

  /** ---------- Standalone drawing (ignored in controlsOnly) ---------- */
  const onMouseDown = (e: any) => {
    if (controlsOnly) return;
    const stage = e.target.getStage(); if (!stage) return;
    const pos = stage.getPointerPosition(); if (!pos) return;
    const x = snap(pos.x), y = snap(pos.y);
    setTempRect({ x, y, width: 0, height: 0 });
    setIsDrawing(true);
  };

  const onMouseMove = (e: any) => {
    if (controlsOnly) return;
    if (!isDrawing || !tempRect) return;
    const stage = e.target.getStage(); if (!stage) return;
    const pos = stage.getPointerPosition(); if (!pos) return;
    const x2 = snap(pos.x), y2 = snap(pos.y);
    const width2 = x2 - tempRect.x, height2 = y2 - tempRect.y;
    const rect = {
      x: width2 >= 0 ? tempRect.x : tempRect.x + width2,
      y: height2 >= 0 ? tempRect.y : tempRect.y + height2,
      width: Math.abs(width2),
      height: Math.abs(height2),
    };
    if (e.evt.shiftKey) {
      const size = Math.min(rect.width, rect.height);
      rect.width = size;
      rect.height = size;
    }
    setTempRect(rect);
  };

  const onMouseUp = () => {
    if (controlsOnly) return;
    if (!isDrawing || !tempRect) return;
    setIsDrawing(false);
    if (tempRect.width > 0 && tempRect.height > 0) {
      if (mode === 'selection') {
        setSelection(tempRect);
      } else {
        setObstructionsLocal(prev => [...prev, { ...tempRect, id: `obs-${Date.now()}` }]);
      }
    }
    setTempRect(null);
  };

  // Get world position from event
  function getWorldPointer(e: any) {
    const stage = e.target.getStage?.();
    if (!stage) return null;
    
    const pos = stage.getPointerPosition();
    if (!pos) return null;
    
    const world = { 
      x: (pos.x - stage.x()) / stage.scaleX(), 
      y: (pos.y - stage.y()) / stage.scaleY() 
    };
    
    return { stage, world };
  }

  // Auto-populate mouse handlers
  const onAutoPopulateMouseDown = (e: any) => {
    if (!localAutoPopulateMode) return;
    
    const ctx = getWorldPointer(e);
    if (!ctx) return;
    
    const { world } = ctx;
    const x = snap(world.x, gridSize);
    const y = snap(world.y, gridSize);
    
    setApDrawRect({ x, y, width: 0, height: 0 });
    setIsDrawingAP(true);
  };

  const onAutoPopulateMouseMove = (e: any) => {
    if (!localAutoPopulateMode || !isDrawingAP || !apDrawRect) return;
    
    const ctx = getWorldPointer(e);
    if (!ctx) return;
    
    const { world } = ctx;
    const x2 = snap(world.x, gridPx);
    const y2 = snap(world.y, gridPx);
    
    const w2 = x2 - apDrawRect.x;
    const h2 = y2 - apDrawRect.y;
    
    const rect = {
      x: w2 >= 0 ? apDrawRect.x : apDrawRect.x + w2,
      y: h2 >= 0 ? apDrawRect.y : apDrawRect.y + h2,
      width: Math.abs(w2),
      height: Math.abs(h2),
    } as RectPx;
    
    if ((e as any).evt.shiftKey) {
      const size = Math.min(rect.width, rect.height);
      rect.width = size;
      rect.height = size;
    }
    
    setApDrawRect(rect);
    if (localAutoPopulateMode === 'selection') setRackSelectionRect(rect);
  };

  const onAutoPopulateMouseUp = () => {
    if (!localAutoPopulateMode || !isDrawingAP) return;
    
    setIsDrawingAP(false);
    if (!apDrawRect || apDrawRect.width <= 0 || apDrawRect.height <= 0) { 
      setApDrawRect(null); 
      return; 
    }
    
    if (localAutoPopulateMode === 'obstruction') {
      setRackObstructions(prev => [...prev, { id: `obs-${Date.now()}`, ...apDrawRect! }]);
      setApDrawRect(null);
    } else {
      setRackSelectionRect(apDrawRect!);
      setApDrawRect(null);
    }
  };

  // Clear obstructions
  const clearObstructions = () => {
    if (controlsOnly) { 
      onClearObstructions?.(); 
      return; 
    }
    setRackObstructions([]);
  };
  
  // Clear all (selection and obstructions)
  const clearAll = () => {
    if (controlsOnly) { 
      onClearAll?.(); 
      return; 
    }
    setRackSelectionRect(null);
    setRackObstructions([]);
  };

  // Section information display component
  const SectionInfo = () => {
    if (!sectionId) return null;
    
    return (
      <div style={styles.sectionInfo}>
        <h4 style={styles.sectionTitle}>Section: {sectionId.substring(0, 8)}...</h4>
        <p style={styles.sectionNote}>
          Racks in this section will stay within the selection boundary.
        </p>
      </div>
    );
  };

  // Drawing mode controls
  const DrawingModeControls = () => (
    <div style={styles.settingGroup}>
      <h3 style={styles.h3}>Drawing Mode</h3>
      <div style={styles.row}>
        <button
          style={{
            ...styles.button,
            ...(localAutoPopulateMode === 'selection' ? styles.primaryButton : {})
          }}
          onClick={() => {
            setLocalAutoPopulateMode('selection');
            onToggleMode?.('selection');
          }}
        >
          Selection
        </button>
        <button
          style={{
            ...styles.button,
            ...(localAutoPopulateMode === 'obstruction' ? styles.primaryButton : {})
          }}
          onClick={() => {
            setLocalAutoPopulateMode('obstruction');
            onToggleMode?.('obstruction');
          }}
        >
          Add Obstruction
        </button>
      </div>
      <button style={styles.button} onClick={clearObstructions}>Clear Obstructions</button>
      <div style={styles.small}>Tip: Hold <span style={styles.badge}>Shift</span> to constrain perfect squares while drawing.</div>
    </div>
  );

  return (
    <div style={controlsOnly ? { padding: '16px' } : styles.container}>
      {/* -------- Sidebar -------- */}
      <div style={styles.sidebar}>
        <h2 style={styles.h2}>SPR Auto‑Populate</h2>
        
        {/* Section information */}
        <SectionInfo />

        <div style={styles.settingGroup}>
          <label style={styles.label}>Pixels per mm</label>
          <input 
            type="number" 
            min="0.1" 
            step="0.1" 
            value={scale}
            style={styles.input}
            onChange={e => setScale(Number(e.target.value) || 1)} 
          />
        </div>

        <div style={styles.settingGroup}>
          <label style={styles.label}>Grid size (mm)</label>
          <input 
            type="number" 
            min="10" 
            step="10" 
            value={gridMM}
            style={styles.input}
            onChange={e => setGridMM(Number(e.target.value) || 100)} 
          />
          <div style={styles.note}>Selection & obstructions snap to grid.</div>
        </div>

        <div style={styles.settingGroup}>
          <h3 style={styles.h3}>Rack & Aisle (mm)</h3>
          <div style={styles.row}>
            <div>
              <label style={styles.label}>Rack length X</label>
              <input 
                type="number" 
                value={rackWmm}
                style={styles.input}
                onChange={e => setRackWmm(Number(e.target.value) || 0)} 
              />
            </div>
            <div>
              <label style={styles.label}>Rack depth Y</label>
              <input 
                type="number" 
                value={rackHmm}
                style={styles.input}
                onChange={e => setRackHmm(Number(e.target.value) || 0)} 
              />
            </div>
          </div>
          <div style={styles.row}>
            <div>
              <label style={styles.label}>Gap between racks (X)</label>
              <input 
                type="number" 
                value={spacingXmm}
                style={styles.input}
                onChange={e => setSpacingXmm(Number(e.target.value) || 0)} 
              />
            </div>
            <div>
              <label style={styles.label}>Main aisle width (Y)</label>
              <input 
                type="number" 
                value={aisleMM}
                style={styles.input}
                onChange={e => setAisleMM(Number(e.target.value) || 0)} 
              />
            </div>
          </div>
          <div style={styles.row}>
            <div>
              <label style={styles.label}>Selection margin</label>
              <input 
                type="number" 
                value={marginMM}
                style={styles.input}
                onChange={e => setMarginMM(Number(e.target.value) || 0)} 
              />
            </div>
            <div>
              <label style={styles.label}>Rotate racks 90°</label>
              <select 
                value={rotate90 ? 'yes' : 'no'}
                style={styles.select}
                onChange={e => setRotate90(e.target.value === 'yes')}
              >
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
          </div>
        </div>

        <div style={styles.settingGroup}>
          <h3 style={styles.h3}>Double‑Deep & Cross‑Aisles</h3>
          <div style={styles.row}>
            <div>
              <label style={styles.label}>Double‑deep</label>
              <select 
                value={doubleDeep ? 'yes' : 'no'}
                style={styles.select}
                onChange={e => setDoubleDeep(e.target.value === 'yes')}
              >
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            <div>
              <label style={styles.label}>Back gap (mm)</label>
              <input 
                type="number" 
                value={backGapMM}
                style={styles.input}
                onChange={e => setBackGapMM(Number(e.target.value) || 0)} 
              />
            </div>
          </div>

          <div style={styles.row}>
            <div>
              <label style={styles.label}>Cross‑aisle every N rows</label>
              <input 
                type="number" 
                min="0" 
                value={crossAisleEvery}
                style={styles.input}
                onChange={e => setCrossAisleEvery(Number(e.target.value) || 0)} 
              />
            </div>
            <div>
              <label style={styles.label}>Cross‑aisle width (mm)</label>
              <input 
                type="number" 
                value={crossAisleWidthMM}
                style={styles.input}
                onChange={e => setCrossAisleWidthMM(Number(e.target.value) || 0)} 
              />
            </div>
          </div>
          <div style={styles.small}>Set N=0 to disable cross‑aisles.</div>
        </div>

        {/* Drawing mode controls */}
        <DrawingModeControls />

        <div style={styles.settingGroup}>
          <button 
            style={{
              ...styles.button,
              ...styles.primaryButton,
              ...(canPopulate ? {} : styles.buttonDisabled)
            }} 
            onClick={handlePopulate} 
            disabled={!canPopulate}
          >
            Populate Racks
          </button>
          
          {!canPopulate && blockers.length > 0 && (
            <div style={styles.note}>
              Can't populate yet:
              <ul style={{ marginTop: 6 }}>
                {blockers.map((b, i) => <li key={i}>{b}</li>)}
              </ul>
            </div>
          )}

          <button 
            style={{...styles.button, ...styles.dangerButton}} 
            onClick={clearAll}
          >
            Clear Selection
          </button>
        </div>

        {/* Exports */}
        {/* <div style={styles.settingGroup}>
          <button 
            style={{
              ...styles.button,
              ...(racks.length === 0 ? styles.buttonDisabled : {})
            }} 
            onClick={exportJSON} 
            disabled={racks.length === 0}
          >
            Download JSON
          </button>
          <div style={styles.row}>
            <button style={styles.button} onClick={exportPNG}>Export PNG</button>
            <button style={styles.button} onClick={exportSVG}>Export SVG</button>
          </div>
          <button style={styles.button} onClick={exportDXF}>Export DXF</button>
        </div> */}

        <div style={styles.settingGroup}>
          <button style={styles.button} onClick={onClose}>Cancel</button>
        </div>
      </div>

      {/* -------- Preview Canvas (hidden in controlsOnly) -------- */}
      {!controlsOnly && (
        <div style={styles.canvas}>
          <Stage
            ref={localStageRef}
            width={width}
            height={height}
            onMouseDown={onAutoPopulateMouseDown}
            onMouseMove={onAutoPopulateMouseMove}
            onMouseUp={onAutoPopulateMouseUp}
            style={{ background: '#0a0f1d', borderRadius: 8, border: '1px solid #1f2937' }}
          >
            {/* Grid */}
            <Layer listening={false}>
              {gridLines.map((l, i) => (<Line key={i} points={l.points} stroke="#0b2942" strokeWidth={1} />))}
            </Layer>

            {/* Racks */}
            <Layer listening={false}>
              {racks.map((r) => (
                <Group key={r.id}>
                  <Rect x={r.x} y={r.y} width={r.width} height={r.height}
                        fill="#1e293b" stroke="#22c55e" strokeWidth={1.5} cornerRadius={3} />
                </Group>
              ))}
            </Layer>

            {/* Obstructions */}
            <Layer listening={false}>
              {rackObstructions.map((o) => (
                <Rect key={o.id} x={o.x} y={o.y} width={o.width} height={o.height}
                      fill="rgba(239,68,68,0.2)" stroke="#ef4444" strokeWidth={1.5} cornerRadius={3} />
              ))}
            </Layer>

            {/* Selection */}
            <Layer listening={false}>
              {rackSelectionRect && rackSelectionRect.width > 0 && rackSelectionRect.height > 0 && (
                <Group>
                  <Rect x={rackSelectionRect.x} y={rackSelectionRect.y} width={rackSelectionRect.width} height={rackSelectionRect.height}
                        stroke="#93c5fd" dash={[6, 4]} cornerRadius={4} />
                  <Rect x={rackSelectionRect.x} y={rackSelectionRect.y} width={rackSelectionRect.width} height={rackSelectionRect.height}
                        fillLinearGradientStartPoint={{ x:0, y:0 }}
                        fillLinearGradientEndPoint={{ x:0, y:rackSelectionRect.height }}
                        fillLinearGradientColorStops={[0,'rgba(59,130,246,0.08)',1,'rgba(59,130,246,0.02)']} />
                </Group>
              )}

              {/* Drawing preview */}
              {isDrawingAP && apDrawRect && apDrawRect.width > 0 && apDrawRect.height > 0 && (
                <Group>
                  <Rect x={apDrawRect.x} y={apDrawRect.y} width={apDrawRect.width} height={apDrawRect.height}
                        stroke={localAutoPopulateMode === 'selection' ? '#93c5fd' : '#ef4444'} dash={[6,4]} cornerRadius={4} />
                  <Rect x={apDrawRect.x} y={apDrawRect.y} width={apDrawRect.width} height={apDrawRect.height}
                        fill={localAutoPopulateMode === 'selection' ? 'rgba(59,130,246,0.08)' : 'rgba(239,68,68,0.08)'} />
                </Group>
              )}
            </Layer>
          </Stage>
        </div>
      )}
    </div>
  );
}