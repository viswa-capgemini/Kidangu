import React, { useMemo, useRef, useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { Stage, Layer, Line, Rect, Circle, Text, Group, Transformer } from 'react-konva';
import { useKonvaSnapping } from 'use-konva-snapping';
import DuplicateControls from './DuplicateControls';
import RadialMenu from './RadialMenu';
import AutoPopulatePanel from './AutoPopulatePanel';

// Type definitions
type ShapeType =
  | 'line'
  | 'rectangle'
  | 'wall'
  | 'door'
  | 'window'
  | 'sliding-door'
  | 'bed'
  | 'sofa'
  | 'table'
  | 'chair'
  | 'rack'
  | 'circle'
  | 'pillar'
  | 'text'
  | 'pencil'
  | 'aisle';

type BaseShape = {
  id: number | string;
  type: ShapeType;
  stroke?: string;
  strokeWidth?: number;
  fill?: string;
  rotation?: 0 | 90 | 180 | 270;
  locked?: boolean;
  groupId?: string;
  dash?: number[];
  sectionId?: string;
  label?: string;
};

type LineShape = BaseShape & { 
  type: 'line' | 'pencil'; 
  points: [number, number, number, number] | number[] 
};

type RectShape = BaseShape & {
  type: Exclude<ShapeType, 'line' | 'pencil' | 'circle' | 'pillar' | 'text'>;
  x: number;
  y: number;
  width: number;
  height: number;
};

type CircleShape = BaseShape & { 
  type: 'circle'; 
  x: number; 
  y: number; 
  radius: number 
};

type PillarShape = BaseShape & { 
  type: 'pillar'; 
  x: number; 
  y: number; 
  width: number; 
  height: number 
};

type TextShape = BaseShape & { 
  type: 'text'; 
  x: number; 
  y: number; 
  text: string; 
  fontSize: number 
};

type Shape = LineShape | RectShape | CircleShape | PillarShape | TextShape;

// Constants
const GRID_SIZE = 20;

// Helper functions
const snapToGrid = (v: number, gridSize = GRID_SIZE) => Math.round(v / gridSize) * gridSize;

const distance = (x1: number, y1: number, x2: number, y2: number) => Math.hypot(x2 - x1, y2 - y1);

// Units configuration
const units = {
  meters: { 
    toMeters: 1, 
    abbr: 'm', 
    smallerUnit: { divisor: 100, id: 'centimeters', abbr: 'cm', threshold: 1 } 
  },
  centimeters: { 
    toMeters: 0.01, 
    abbr: 'cm', 
    smallerUnit: null 
  },
  feet: { 
    toMeters: 0.3048, 
    abbr: 'ft', 
    smallerUnit: { divisor: 12, id: 'inches', abbr: 'in', threshold: 1 } 
  },
  inches: { 
    toMeters: 0.0254, 
    abbr: 'in', 
    smallerUnit: null 
  },
  yards: { 
    toMeters: 0.9144, 
    abbr: 'yd', 
    smallerUnit: { divisor: 3, id: 'feet', abbr: 'ft', threshold: 1 } 
  },
} as const;

type UnitName = keyof typeof units;

// Collision detection helpers
function getBounds(shape: Shape) {
  switch (shape.type) {
    case 'circle': 
      return { 
        x: (shape as CircleShape).x - (shape as CircleShape).radius, 
        y: (shape as CircleShape).y - (shape as CircleShape).radius, 
        w: (shape as CircleShape).radius * 2, 
        h: (shape as CircleShape).radius * 2 
      };
    case 'pillar': 
      return { 
        x: (shape as PillarShape).x, 
        y: (shape as PillarShape).y, 
        w: (shape as PillarShape).width, 
        h: (shape as PillarShape).height 
      };
    case 'line': {
      const pts = (shape as LineShape).points as number[];
      const minX = Math.min(pts[0], pts[2]);
      const maxX = Math.max(pts[0], pts[2]);
      const minY = Math.min(pts[1], pts[3]);
      const maxY = Math.max(pts[1], pts[3]);
      return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
    }
    case 'text': 
      return { 
        x: (shape as TextShape).x, 
        y: (shape as TextShape).y, 
        w: ((shape as TextShape).text?.length ?? 1) * ((shape as TextShape).fontSize ?? 12) * 0.6, 
        h: ((shape as TextShape).fontSize ?? 12) * 1.2 
      };
    default: {
      const r = shape as RectShape;
      const w = r.rotation === 90 ? r.height : r.width;
      const h = r.rotation === 90 ? r.width : r.height;
      return { x: r.x, y: r.y, w, h };
    }
  }
}

function aabbOverlap(a: {x: number; y: number; w: number; h: number}, b: {x: number; y: number; w: number; h: number}) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function checkCollision(newShape: Shape, shapes: Shape[]) {
  const a = getBounds(newShape);
  for (const s of shapes) {
    if (s.id === newShape.id) continue;
    if (s.type === 'line' || s.type === 'wall') continue;
    const b = getBounds(s);
    if (aabbOverlap(a, b)) return true;
  }
  return false;
}

// Wall snapping helpers
function distanceToLineSegment(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
  const A = px - x1, B = py - y1, C = x2 - x1, D = y2 - y1;
  const dot = A * C + B * D;
  const lenSq = C * C + D * D;
  const param = lenSq !== 0 ? (dot / lenSq) : -1;
  let xx, yy;
  
  if (param < 0) { 
    xx = x1; yy = y1; 
  } else if (param > 1) { 
    xx = x2; yy = y2; 
  } else { 
    xx = x1 + param * C; yy = y1 + param * D; 
  }
  
  return Math.hypot(px - xx, py - yy);
}

function formatDimension(pixels: number, scale: number, unit: UnitName) {
  const meters = pixels * scale;
  const currentUnit = units[unit] ?? units.meters;
  const value = meters / currentUnit.toMeters;
  
  if (currentUnit.smallerUnit && value < currentUnit.smallerUnit.threshold) {
    const v = value * currentUnit.smallerUnit.divisor;
    return `${v.toFixed(1)} ${currentUnit.smallerUnit.abbr}`;
  }
  
  return `${value.toFixed(2)} ${currentUnit.abbr}`;
}

// Section type for rack organization
type Section = {
  id: string;
  boundary: { x: number; y: number; width: number; height: number };
  rackIds: string[];
};

// Component interface
interface CanvasProps {
  selectedTool: ShapeType | null;
  shapes: Shape[];
  onAddShape: (next: Shape[]) => void;
  isDraggingElement: boolean;
  dragElement: Partial<RectShape> & { type: ShapeType; isCircle?: boolean };
  dragOffset?: { offsetX: number; offsetY: number };
  onElementDrop: (element: any, pos: {x: number, y: number}) => void;
  showDimensions: boolean;
  scale: number;
  unit: UnitName;
  zoomLevel: number;
  onShapeSelect: (shape: Shape | null) => void;
  selectedShape: Shape | null;
  selectedShapes?: Shape[];
  isMultiSelectMode?: boolean;
  onUpdateGroups?: (groups: any[]) => void;
  onDuplicateShape?: (shape: Shape) => void;
  showRadialMenu: boolean;
  setShowRadialMenu: (show: boolean) => void;
  showAutoPopulate?: boolean;
  // When false, Canvas will not render the in-canvas AutoPopulatePanel
  showAutoPopulateInCanvas?: boolean;
  onAutoPopulateChange?: (isShowing: boolean) => void;
  autoPopulateMode?: 'selection' | 'obstruction' | null;
  onSelectionRectChange?: (rect: { x: number; y: number; width: number; height: number } | null) => void;
  onObstructionsChange?: (obstructions: { id: string; x: number; y: number; width: number; height: number }[]) => void;
  boundaryRect?: { x: number; y: number; width: number; height: number } | null;
  gridSize?: number;
  rackSections?: Section[];
  currentSectionId?: string | null;
  isPanMode?: boolean;
  snapAngle?: number; // New prop for snap angle
}

const Canvas = forwardRef<any, CanvasProps>((props, ref) => {
  const {
    selectedTool,
    shapes,
    onAddShape,
    isDraggingElement,
    dragElement,
    dragOffset,
    onElementDrop,
    showDimensions,
    scale,
    unit,
    zoomLevel,
    onShapeSelect,
    selectedShape,
    selectedShapes = [],
    isMultiSelectMode = false,
    onUpdateGroups,
    onDuplicateShape,
    showRadialMenu,
    setShowRadialMenu,
    showAutoPopulateInCanvas = true,
    showAutoPopulate,
    onAutoPopulateChange,
    autoPopulateMode,
    onSelectionRectChange,
    onObstructionsChange,
    boundaryRect = null,
    gridSize = GRID_SIZE,
    rackSections = [],
    currentSectionId = null,
    isPanMode = false,
    snapAngle = 45, // Default to 45 degrees
  } = props;

  // Define snapToAngle function inside the component to access snapAngle prop
  const snapToAngle = (dx: number, dy: number) => {
    const angle = Math.atan2(dy, dx) * (180 / Math.PI);
    const snappedAngle = Math.round(angle / snapAngle) * snapAngle;
    const rad = snappedAngle * (Math.PI / 180);
    const len = Math.hypot(dx, dy);
    return { dx: Math.cos(rad) * len, dy: Math.sin(rad) * len };
  };

  // State
  const [isDrawing, setIsDrawing] = useState(false);
  const [points, setPoints] = useState<number[]>([]);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [currentShape, setCurrentShape] = useState<Shape | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [dragPreviewPos, setDragPreviewPos] = useState({ x: 0, y: 0 });
  const [stageSize, setStageSize] = useState({ 
    width: window.innerWidth - 500, 
    height: window.innerHeight - 50 
  });
  const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 });
  const stageRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const transformerRef = useRef<any>(null);

  // Radial menu state
  const [radialMenuPosition, setRadialMenuPosition] = useState({ x: 0, y: 0 });
  const [radialMenuOpen, setRadialMenuOpen] = useState(true);
  const [isRightClickSelection, setIsRightClickSelection] = useState(false);

  // Selection state
  const [selectionRect, setSelectionRect] = useState<any>(null);
  const [isSelecting, setIsSelecting] = useState(false);
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [selectionBounds, setSelectionBounds] = useState<{x: number, y: number, width: number, height: number} | null>(null);

  // Drag state
  const [isDragging, setIsDragging] = useState(false);
  const [isDraggingGroup, setIsDraggingGroup] = useState(false);
  const [draggedGroupId, setDraggedGroupId] = useState<string | null>(null);
  const [groupDragOffset, setGroupDragOffset] = useState({ x: 0, y: 0 });
  const [dragStartPosition, setDragStartPosition] = useState({ x: 0, y: 0 });

  // Context menu state
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean,
    x: number,
    y: number,
    targetShape?: Shape | null,
    isMultiSelect?: boolean
  }>({ visible: false, x: 0, y: 0 });

  // Auto-populate state
  const [localAutoPopulateMode, setLocalAutoPopulateMode] = useState<'selection' | 'obstruction' | null>(autoPopulateMode || null);

  // Selection & obstructions for auto-populate
  type RectPx = { x: number; y: number; width: number; height: number };
  type ObstructionPx = RectPx & { id: string };
  const [rackSelectionRect, setRackSelectionRect] = useState<RectPx | null>(null);
  const [rackObstructions, setRackObstructions] = useState<ObstructionPx[]>([]);
  const [isDrawingAP, setIsDrawingAP] = useState<boolean>(false);
  const [apDrawRect, setApDrawRect] = useState<RectPx | null>(null);

  // Initialize Konva snapping
  const { 
    handleDragging, 
    handleDragEnd: handleSnapDragEnd, 
    handleResizing, 
    handleResizeEnd 
  } = useKonvaSnapping({
    guidelineColor: '#3498db',
    guidelineDash: true,
    snapToStageCenter: true,
    snapRange: 5,
    guidelineThickness: 1,
    showGuidelines: true,
    snapToShapes: true,
    snapToStageBorders: true,
  });

  // Forward the stage ref
  useImperativeHandle(ref, () => ({
    getStage: () => stageRef.current,
    toDataURL: (options?: any) => stageRef.current?.toDataURL(options),
  }));

  // Effects
  
  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setStageSize({
        width: window.innerWidth - 0,
        height: window.innerHeight - 0
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Update the window resize effect
  // useEffect(() => {
  //   const handleResize = () => {
  //     const autoPopulatePanelWidth = 340;
  //     const elementsPanelWidth = 500;
  //     const totalRightPanelWidth = showAutoPopulate ? 
  //       elementsPanelWidth + autoPopulatePanelWidth : 
  //       elementsPanelWidth;
      
  //     setStageSize({
  //       width: window.innerWidth - totalRightPanelWidth,
  //       height: window.innerHeight - 50
  //     });
  //   };

  //   handleResize();
  //   window.addEventListener('resize', handleResize);
  //   return () => window.removeEventListener('resize', handleResize);
  // }, [showAutoPopulate]);

  // Disable default browser context menu within canvas container
  useEffect(() => {
    const container = containerRef.current;
    const handleCtx = (e: MouseEvent) => { 
      e.preventDefault(); 
      return false; 
    };
    
    container?.addEventListener('contextmenu', handleCtx);
    return () => container?.removeEventListener('contextmenu', handleCtx);
  }, []);

  // Handle wheel events for zooming
  useEffect(() => {
    const container = containerRef.current;
    
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      const stage = stageRef.current;
      if (!stage) return;
      
      const oldScale = stage.scaleX();
      const pointer = stage.getPointerPosition();
      if (!pointer) return;
      
      const mousePointTo = {
        x: (pointer.x - stage.x()) / oldScale,
        y: (pointer.y - stage.y()) / oldScale
      };
      
      const newScale = e.deltaY < 0 ? oldScale * 1.1 : oldScale / 1.1;
      const limitedScale = Math.min(Math.max(newScale, 0.2), 5);
      
      const newPos = {
        x: pointer.x - mousePointTo.x * limitedScale,
        y: pointer.y - mousePointTo.y * limitedScale
      };
      
      stage.scale({ x: limitedScale, y: limitedScale });
      stage.position(newPos);
      stage.batchDraw();
    };
    
    container?.addEventListener('wheel', handleWheel, { passive: false });
    return () => container?.removeEventListener('wheel', handleWheel);
  }, []);

  // Update stage scale when zoomLevel changes
  useEffect(() => {
    const stage = stageRef.current;
    if (stage) {
      const centerX = stageSize.width / 2;
      const centerY = stageSize.height / 2;
      
      const oldScale = stage.scaleX();
      const worldCenter = {
        x: (centerX - stage.x()) / oldScale,
        y: (centerY - stage.y()) / oldScale
      };
      
      const newPos = {
        x: centerX - worldCenter.x * zoomLevel,
        y: centerY - worldCenter.y * zoomLevel
      };
      
      stage.scale({ x: zoomLevel, y: zoomLevel });
      stage.position(newPos);
      stage.batchDraw();
      setStagePosition(newPos);
    }
  }, [zoomLevel, stageSize]);

  // Set up transformer when selected shape changes
  useEffect(() => {
    if (selectedShape && transformerRef.current && !isMultiSelect && !isPanMode) {
      const stage = stageRef.current;
      if (!stage) return;
      
      const selectedNode = stage.findOne(`#node-${selectedShape.id}`);
      if (selectedNode) {
        transformerRef.current.nodes([selectedNode]);
        transformerRef.current.getLayer().batchDraw();
      } else {
        transformerRef.current.nodes([]);
      }
    } else if (transformerRef.current) {
      transformerRef.current.nodes([]);
      if (transformerRef.current.getLayer()) {
        transformerRef.current.getLayer().batchDraw();
      }
    }
  }, [selectedShape, isMultiSelect, isPanMode]);

  // Track mouse for drag-over element preview
  useEffect(() => {
    const container = containerRef.current;
    
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      
      if (isDraggingElement && dragElement) {
        // Update mouse position for drag preview
        const containerRect = container?.getBoundingClientRect();
        if (!containerRect) return;
        
        const stage = stageRef.current;
        if (!stage) return;
        
        // Calculate position relative to the stage
        const relX = e.clientX - containerRect.left;
        const relY = e.clientY - containerRect.top;
        
        // Convert to stage coordinates
        const stageX = (relX - stage.x()) / stage.scaleX();
        const stageY = (relY - stage.y()) / stage.scaleY();
        
        setMousePosition({ x: stageX, y: stageY });
        
        // Update drag preview position
        setDragPreviewPos({
          x: stageX - (dragOffset?.offsetX || 0) / stage.scaleX(),
          y: stageY - (dragOffset?.offsetY || 0) / stage.scaleY()
        });
      }
    };
    
    container?.addEventListener('dragover', handleDragOver);
    return () => container?.removeEventListener('dragover', handleDragOver);
  }, [isDraggingElement, dragElement, dragOffset]);

  // Handle external drop (from palette)
  useEffect(() => {
    const container = containerRef.current;
    
    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      
      if (!isDraggingElement || !dragElement) return;
      
      const stage = stageRef.current;
      if (!stage) return;
      
      const containerRect = container?.getBoundingClientRect();
      if (!containerRect) return;
      
      // Calculate position relative to the container
      const relX = e.clientX - containerRect.left;
      const relY = e.clientY - containerRect.top;
      
      // Convert to stage coordinates
      const stagePos = {
        x: (relX - stage.x()) / stage.scaleX(),
        y: (relY - stage.y()) / stage.scaleY()
      };
      
      // Adjust for the drag offset
      const dropPosition = {
        x: stagePos.x - (dragOffset?.offsetX || 0) / stage.scaleX(),
        y: stagePos.y - (dragOffset?.offsetY || 0) / stage.scaleY()
      };
      
      // Special handling for doors, windows, sliding doors
      if (['door', 'window', 'sliding-door'].includes(dragElement.type)) {
        const snapped = findWallToSnapTo(stagePos, dragElement, shapes, zoomLevel);
        onElementDrop({ 
          ...dragElement, 
          ...snapped.elementProps 
        }, snapped.position);
      } else if (dragElement.type === 'rack' && currentSectionId) {
        // For racks, add the current section ID
        const dropPos = { 
          x: dropPosition.x, 
          y: dropPosition.y 
        };
        
        onElementDrop({ 
          ...dragElement, 
          sectionId: currentSectionId 
        }, dropPos);
      } else {
        onElementDrop(dragElement, dropPosition);
      }
    };
    
    container?.addEventListener('drop', handleDrop);
    return () => container?.removeEventListener('drop', handleDrop);
  }, [isDraggingElement, dragElement, dragOffset, onElementDrop, shapes, zoomLevel, currentSectionId]);

  // Close custom context menu on outside click
  useEffect(() => {
    const close = () => contextMenu.visible && setContextMenu(prev => ({ ...prev, visible: false }));
    document.addEventListener('click', close);
    return () => document.removeEventListener('click', close);
  }, [contextMenu.visible]);

  // Ensure radial menu appears at center of selected shape
  useEffect(() => {
    if (!selectedShape || selectedShape.locked || isRightClickSelection || isPanMode) return;
    
    const { x, y } = calcShapeCenter(selectedShape);
    setRadialMenuPosition({ x, y });
    setShowRadialMenu(true);
    setRadialMenuOpen(true);
    stageRef.current?.batchDraw();
  }, [selectedShape?.id, isPanMode]);

  // Hide radial menu when selected shape changes programmatically
  useEffect(() => { 
    setShowRadialMenu(false); 
  }, [selectedShape?.id]);

  // Marquee selection end (global mouseup guard)
  useEffect(() => {
    const onUp = () => {
      if (isSelecting) {
        setIsSelecting(false);
        setSelectionRect(null);
      }
    };
    
    window.addEventListener('mouseup', onUp);
    return () => window.removeEventListener('mouseup', onUp);
  }, [isSelecting]);

  // Sync auto-populate visibility with parent
  useEffect(() => {
    // Only initialize mode when panel opens
    if (showAutoPopulate && localAutoPopulateMode === null) {
      setLocalAutoPopulateMode('selection');
    }
  }, [showAutoPopulate, localAutoPopulateMode]);

  // Sync selection rect and obstructions with parent
  useEffect(() => {
    if (onSelectionRectChange) {
      onSelectionRectChange(rackSelectionRect);
    }
  }, [rackSelectionRect, onSelectionRectChange]);

  useEffect(() => {
    if (onObstructionsChange) {
      onObstructionsChange(rackObstructions);
    }
  }, [rackObstructions, onObstructionsChange]);

  // Update cursor based on pan mode
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.style.cursor = isPanMode ? 'grab' : 'default';
    }
  }, [isPanMode]);

  // Track mouse position for drag preview
  useEffect(() => {
    if (isDraggingElement && dragElement) {
      const handleMouseMove = (e: MouseEvent) => {
        const containerRect = containerRef.current?.getBoundingClientRect();
        if (!containerRect) return;
        
        const stage = stageRef.current;
        if (!stage) return;
        
        // Calculate position relative to the stage
        const relX = e.clientX - containerRect.left;
        const relY = e.clientY - containerRect.top;
        
        // Convert to stage coordinates
        const stageX = (relX - stage.x()) / stage.scaleX();
        const stageY = (relY - stage.y()) / stage.scaleY();
        
        setMousePosition({ x: stageX, y: stageY });
        
        // Update drag preview position
        setDragPreviewPos({
          x: stageX - (dragOffset?.offsetX || 0) / stage.scaleX(),
          y: stageY - (dragOffset?.offsetY || 0) / stage.scaleY()
        });
      };
      
      window.addEventListener('mousemove', handleMouseMove);
      return () => window.removeEventListener('mousemove', handleMouseMove);
    }
  }, [isDraggingElement, dragElement, dragOffset]);

  // Keyboard shortcuts
  const handleKeydown = React.useCallback((e: KeyboardEvent) => {
    // Skip keyboard shortcuts in pan mode
    if (isPanMode) return;
    
    const ctrl = e.ctrlKey || e.metaKey;

    // Multi-selection operations
    if (isMultiSelect && selectedShapes.length > 0) {
      // Delete
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        const next = shapes.filter(sh => 
          !selectedShapes.some(sel => sel.id === sh.id) || sh.locked
        );
        onAddShape(next);
        setIsMultiSelect(false);
        setSelectionBounds(null);
        return;
      }
      
      // Duplicate
      if (ctrl && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        const duplicates: Shape[] = [];
        
        for (const sh of selectedShapes) {
          if (sh.locked) continue;
          
          const dupId = Date.now() + Math.random();
          if (sh.type === 'line') {
            const pts = (sh as LineShape).points as number[];
            duplicates.push({ 
              ...sh, 
              id: dupId, 
              points: [pts[0] + 20, pts[1] + 20, pts[2] + 20, pts[3] + 20] 
            } as Shape);
          } else {
            duplicates.push({ 
              ...sh, 
              id: dupId, 
              x: (sh as any).x + 20, 
              y: (sh as any).y + 20 
            } as Shape);
          }
        }
        
        const next = [...shapes, ...duplicates].filter(Boolean);
        onAddShape(next);
        setSelectionBounds(calcBounds(duplicates));
        return;
      }
    }

    // Grouping
    if (ctrl && e.key.toLowerCase() === 'g' && selectedShapes.length >= 2) {
      e.preventDefault();
      const groupId = `group-${Date.now()}`;
      const next = shapes.map(sh => 
        selectedShapes.some(sel => sel.id === sh.id) ? { ...sh, groupId } : sh
      );
      
      onAddShape(next);
      const grouped = next.filter(s => s.groupId === groupId);
      setIsMultiSelect(true);
      setSelectionBounds(calcBounds(grouped as Shape[]));
      onShapeSelect(grouped[0] as Shape); // focus
      return;
    }
    
    // Ungrouping
    if (ctrl && e.shiftKey && e.key === 'G') {
      e.preventDefault();
      
      // Ungroup selection
      if (isMultiSelect && selectedShapes.length > 0) {
        const groupIds = [...new Set(
          selectedShapes
            .filter(s => s.groupId)
            .map(s => s.groupId!)
        )];
        
        const next = shapes.map(s => 
          groupIds.includes(s.groupId!) ? ({ ...s, groupId: undefined }) : s
        );
        
        onAddShape(next);
        const updSel = selectedShapes.map(s => ({ ...s, groupId: undefined }));
        setSelectionBounds(calcBounds(updSel));
        return;
      }
      
      // Or single selected shape inside a group
      if (selectedShape?.groupId) {
        const gid = selectedShape.groupId;
        const next = shapes.map(s => 
          s.groupId === gid ? ({ ...s, groupId: undefined }) : s
        );
        
        onAddShape(next);
        const groupMembers = shapes
          .filter(s => s.groupId === gid)
          .map(s => ({ ...s, groupId: undefined })) as Shape[];
        
        setIsMultiSelect(true);
        setSelectionBounds(calcBounds(groupMembers));
        onShapeSelect({ ...selectedShape, groupId: undefined });
        return;
      }
    }

    // Radial menu shortcut (M)
    if (!selectedTool && selectedShape && !selectedShape.locked && (e.key === 'm' || e.key === 'M')) {
      e.preventDefault();
      const { x, y } = calcShapeCenter(selectedShape);
      setRadialMenuPosition({ x, y });
      setShowRadialMenu(true);
      setRadialMenuOpen(true);
      return;
    }

    // Arrow-key move for single or group
    if (!selectedTool && selectedShape && !selectedShape.locked && 
        ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      e.preventDefault();
      const amt = e.shiftKey ? 10 : 1;
      
      const mv = (dx: number, dy: number) => {
        const next = shapes.map(s => {
          const inSameGroup = selectedShape.groupId && s.groupId === selectedShape.groupId;
          const isTarget = s.id === selectedShape.id;
          
          if (inSameGroup || isTarget) {
            if (s.type === 'line') {
              const p = (s as LineShape).points as number[];
              return { 
                ...s, 
                points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
              } as Shape;
            } else {
              return { 
                ...s, 
                x: (s as any).x + dx, 
                y: (s as any).y + dy 
              } as Shape;
            }
          }
          return s;
        });
        onAddShape(next);
      };
      
      if (e.key === 'ArrowUp') mv(0, -amt);
      if (e.key === 'ArrowDown') mv(0, amt);
      if (e.key === 'ArrowLeft') mv(-amt, 0);
      if (e.key === 'ArrowRight') mv(amt, 0);
    }

    // Delete single
    if (!selectedTool && selectedShape && (e.key === 'Delete' || e.key === 'Backspace')) {
      e.preventDefault();
      if (!selectedShape.locked) {
        onAddShape(shapes.filter(s => s.id !== selectedShape.id));
        onShapeSelect(null);
      }
    }

    // Arrow duplication with Ctrl
    if (selectedShape && (ctrl && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key))) {
      e.preventDefault();
      const offset = 100;
      let dx = 0, dy = 0;
      
      if (e.key === 'ArrowUp') dy = -offset;
      if (e.key === 'ArrowDown') dy = offset;
      if (e.key === 'ArrowLeft') dx = -offset;
      if (e.key === 'ArrowRight') dx = offset;
      
      const dup = duplicateOne(selectedShape as Shape, dx, dy, shapes);
      if (dup) { 
        onAddShape([...shapes, dup]); 
        onShapeSelect(dup); 
      }
    }
  }, [isMultiSelect, selectedShapes, selectedShape, selectedTool, shapes, onAddShape, onShapeSelect, isPanMode]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [handleKeydown]);

  // Grid layer (memoized)
  const gridLines = useMemo(() => {
    const bounds = {
      startX: -stagePosition.x / zoomLevel,
      startY: -stagePosition.y / zoomLevel,
      endX: (stageSize.width - stagePosition.x) / zoomLevel,
      endY: (stageSize.height - stagePosition.y) / zoomLevel,
    };
    
    const sx = Math.floor(bounds.startX / gridSize) * gridSize;
    const sy = Math.floor(bounds.startY / gridSize) * gridSize;
    const ex = Math.ceil(bounds.endX / gridSize) * gridSize;
    const ey = Math.ceil(bounds.endY / gridSize) * gridSize;
    
    const arr: JSX.Element[] = [];
    
    // Vertical lines
    for (let x = sx; x <= ex; x += gridSize) {
      arr.push(
        <Line 
          key={`v-${x}`} 
          points={[x, sy, x, ey]} 
          stroke="#ddd" 
          strokeWidth={1 / zoomLevel} 
        />
      );
    }
    
    // Horizontal lines
    for (let y = sy; y <= ey; y += gridSize) {
      arr.push(
        <Line 
          key={`h-${y}`} 
          points={[sx, y, ex, y]} 
          stroke="#ddd" 
          strokeWidth={1 / zoomLevel} 
        />
      );
    }
    
    return arr;
  }, [stagePosition, stageSize, zoomLevel, gridSize]);

  // Calculate scale bar dimensions for the current unit
  const scaleBar = useMemo(() => {
    const currentUnit = units[unit] ?? units.meters;
    const pxPerMeter = 1 / scale;
    const pxPerUnit = pxPerMeter * currentUnit.toMeters;
    
    let unitValue: number;
    if (pxPerUnit > 200) unitValue = 0.1;
    else if (pxPerUnit > 100) unitValue = 0.2;
    else if (pxPerUnit > 50) unitValue = 0.5;
    else unitValue = 1;
    
    return { 
      width: (pxPerUnit * unitValue) / zoomLevel, 
      label: `${unitValue} ${currentUnit.abbr}` 
    };
  }, [unit, scale, zoomLevel]);

  // Helper Functions
  
  // Visual feedback for invalid positions
  const showFeedback = (message: string) => {
    console.warn(message);
    
    // Create a temporary visual feedback element
    const feedback = document.createElement('div');
    feedback.className = 'drag-feedback';
    feedback.textContent = message;
    feedback.style.position = 'fixed';
    feedback.style.bottom = '20px';
    feedback.style.left = '50%';
    feedback.style.transform = 'translateX(-50%)';
    feedback.style.backgroundColor = 'rgba(255, 0, 0, 0.8)';
    feedback.style.color = 'white';
    feedback.style.padding = '10px 20px';
    feedback.style.borderRadius = '4px';
    feedback.style.zIndex = '9999';
    feedback.style.transition = 'opacity 0.3s ease';
    
    document.body.appendChild(feedback);
    
    setTimeout(() => {
      feedback.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(feedback);
      }, 300);
    }, 2700);
  };

  // Calculate the center of a shape
  function calcShapeCenter(shape: Shape) {
    switch (shape.type) {
      case 'circle': 
        return { 
          x: (shape as CircleShape).x, 
          y: (shape as CircleShape).y 
        };
      case 'line': {
        const p = (shape as LineShape).points as number[];
        return { 
          x: (p[0] + p[2]) / 2, 
          y: (p[1] + p[3]) / 2 
        };
      }
      case 'pillar': 
        return { 
          x: (shape as PillarShape).x + (shape as PillarShape).width / 2, 
          y: (shape as PillarShape).y + (shape as PillarShape).height / 2 
        };
      default: 
        return { 
          x: (shape as any).x + ((shape as any).width ?? 0) / 2, 
          y: (shape as any).y + ((shape as any).height ?? 0) / 2 
        };
    }
  }

  // Calculate bounds for a group of shapes
  function calcBounds(items: Shape[]) {
    if (!items || items.length === 0) return null;
    
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    
    for (const s of items) {
      const b = getBounds(s);
      minX = Math.min(minX, b.x);
      minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.w);
      maxY = Math.max(maxY, b.y + b.h);
    }
    
    return { 
      x: minX, 
      y: minY, 
      width: maxX - minX, 
      height: maxY - minY 
    };
  }

  // Check if a shape is within the selection rectangle
  function isShapeInSelection(shape: Shape, rect: {x: number; y: number; width: number; height: number}) {
    if (shape.locked) return false;
    
    const b = getBounds(shape);
    return rect.x <= b.x + b.w && 
           rect.x + rect.width >= b.x && 
           rect.y <= b.y + b.h && 
           rect.y + rect.height >= b.y;
  }

  // Find a wall to snap to
  function findWallToSnapTo(
    position: {x: number; y: number}, 
    element: any, 
    shapes: Shape[], 
    zoomLevel: number
  ) {
    const snapThreshold = 20 / zoomLevel;
    let closestWall: Shape | null = null;
    let minDist = snapThreshold;
    let orientation: 'horizontal' | 'vertical' | null = null;
    let snapPos = { x: position.x, y: position.y };
    let elementProps: any = {};

    shapes.forEach(shape => {
      if (shape.type === 'line') {
        const pts = (shape as LineShape).points as number[];
        const dist = distanceToLineSegment(position.x, position.y, pts[0], pts[1], pts[2], pts[3]);
        
        if (dist < minDist) {
          minDist = dist;
          closestWall = shape;
          
          const dx = Math.abs(pts[2] - pts[0]);
          const dy = Math.abs(pts[3] - pts[1]);
          
          if (dx > dy) { // horizontal wall
            orientation = 'horizontal';
            
            // Project the position onto the line
            const t = ((position.x - pts[0]) * (pts[2] - pts[0]) + 
                       (position.y - pts[1]) * (pts[3] - pts[1])) / 
                      ((pts[2] - pts[0]) * (pts[2] - pts[0]) + 
                       (pts[3] - pts[1]) * (pts[3] - pts[1]));
            const clampedT = Math.max(0, Math.min(1, t));
            
            snapPos = {
              x: pts[0] + clampedT * (pts[2] - pts[0]),
              y: (pts[1] + pts[3]) / 2
            };
            
            elementProps = { 
              rotation: 0, 
              width: element.width, 
              height: element.height 
            };
          } else { // vertical wall
            orientation = 'vertical';
            
            // Project the position onto the line
            const t = ((position.x - pts[0]) * (pts[2] - pts[0]) + 
                       (position.y - pts[1]) * (pts[3] - pts[1])) / 
                      ((pts[2] - pts[0]) * (pts[2] - pts[0]) + 
                       (pts[3] - pts[1]) * (pts[3] - pts[1]));
            const clampedT = Math.max(0, Math.min(1, t));
            
            snapPos = {
              x: (pts[0] + pts[2]) / 2,
              y: pts[1] + clampedT * (pts[3] - pts[1])
            };
            
            elementProps = { 
              rotation: 90, 
              width: element.height, 
              height: element.width 
            };
          }
        }
      } else if (shape.type === 'rectangle' || shape.type === 'wall') {
        const r = shape as RectShape;
        
        // Check each edge of the rectangle
        // Top edge
        const topDist = Math.abs(position.y - r.y);
        if (position.x >= r.x && position.x <= r.x + r.width && topDist < minDist) {
          minDist = topDist;
          closestWall = shape;
          orientation = 'horizontal';
          snapPos = { x: position.x, y: r.y };
          elementProps = { 
            rotation: 0, 
            width: element.width, 
            height: element.height 
          };
        }
        
        // Bottom edge
        const bottomDist = Math.abs(position.y - (r.y + r.height));
        if (position.x >= r.x && position.x <= r.x + r.width && bottomDist < minDist) {
          minDist = bottomDist;
          closestWall = shape;
          orientation = 'horizontal';
          snapPos = { x: position.x, y: r.y + r.height };
          elementProps = { 
            rotation: 0, 
            width: element.width, 
            height: element.height 
          };
        }
        
        // Left edge
        const leftDist = Math.abs(position.x - r.x);
        if (position.y >= r.y && position.y <= r.y + r.height && leftDist < minDist) {
          minDist = leftDist;
          closestWall = shape;
          orientation = 'vertical';
          snapPos = { x: r.x, y: position.y };
          elementProps = { 
            rotation: 90, 
            width: element.height, 
            height: element.width 
          };
        }
        
        // Right edge
        const rightDist = Math.abs(position.x - (r.x + r.width));
        if (position.y >= r.y && position.y <= r.y + r.height && rightDist < minDist) {
          minDist = rightDist;
          closestWall = shape;
          orientation = 'vertical';
          snapPos = { x: r.x + r.width, y: position.y };
          elementProps = { 
            rotation: 90, 
            width: element.height, 
            height: element.width 
          };
        }
      }
    });

    if (closestWall) {
      if (orientation === 'horizontal') {
        snapPos = { 
          x: snapPos.x - (element.width / 2), 
          y: snapPos.y - (element.height / 2) 
        };
      } else {
        snapPos = { 
          x: snapPos.x - (element.height / 2), 
          y: snapPos.y - (element.width / 2) 
        };
      }
      return { position: snapPos, elementProps };
    }
    
    return { 
      position: { 
        x: position.x - element.width / 2, 
        y: position.y - element.height / 2 
      }, 
      elementProps: {} 
    };
  }

  // Helper function to check if a position is valid for a rack
  const isValidRackPosition = (shape: Shape) => {
    // Get the section boundary for this rack
    const sectionId = (shape as any).sectionId;
    const section = sectionId ? rackSections.find(s => s.id === sectionId) : null;
    const sectionBoundary = section ? section.boundary : boundaryRect;
    
    // Check section boundary constraints
    if (sectionBoundary) {
      const shapeBounds = getBounds(shape);
      if (
        shapeBounds.x < sectionBoundary.x ||
        shapeBounds.y < sectionBoundary.y ||
        shapeBounds.x + shapeBounds.w > sectionBoundary.x + sectionBoundary.width ||
        shapeBounds.y + shapeBounds.h > sectionBoundary.y + sectionBoundary.height
      ) {
        return false;
      }
    }
    
    // Check collisions with other shapes
    return !checkCollision(shape, shapes.filter(s => s.id !== shape.id));
  };

  // Duplicate one shape
  function duplicateOne(shape: Shape, dx: number, dy: number, shapesList: Shape[]) {
    // For racks, we need special handling to maintain pattern and boundary constraints
    if (shape.type === 'rack') {
      // Get metadata from the original rack (if available)
      const metadata = (shape as any).metadata || {};
      const sectionId = (shape as any).sectionId;
      
      // Find the appropriate boundary
      let sectionBoundary = null;
      if (sectionId) {
        const section = rackSections.find(s => s.id === sectionId);
        if (section) sectionBoundary = section.boundary;
      }
      
      const selectionBoundary = metadata.selectionRect || sectionBoundary || boundaryRect;
      const gridSizeToUse = metadata.gridSize || gridSize;
      
      // Create the duplicated shape
      // Calculate new position with grid snapping
      const newX = Math.round(((shape as any).x + dx) / gridSizeToUse) * gridSizeToUse;
      const newY = Math.round(((shape as any).y + dy) / gridSizeToUse) * gridSizeToUse;
      
      const dup = {
        ...shape,
        id: Date.now() + Math.random(),
        x: newX,
        y: newY,
        sectionId: sectionId // Preserve section ID
      } as Shape;
      
      // Check if the duplicated rack would be outside the boundary
      if (selectionBoundary) {
        const isOutOfBounds = 
          dup.x < selectionBoundary.x ||
          dup.y < selectionBoundary.y ||
          dup.x + (dup as any).width > selectionBoundary.x + selectionBoundary.width ||
          dup.y + (dup as any).height > selectionBoundary.y + selectionBoundary.height;
        
        if (isOutOfBounds) {
          showFeedback("Cannot duplicate rack outside the boundary area");
          return null;
        }
      }
      
      // Check for collisions with other shapes
      if (checkCollision(dup, shapesList)) {
        showFeedback("Cannot duplicate rack here - it overlaps with another element");
        return null;
      }
      
      return dup;
    }
    
    // For other shape types, use the existing logic
    let dup: Shape;
    if (shape.type === 'line') {
      const p = (shape as LineShape).points as number[];
      dup = { 
        ...shape, 
        id: Date.now(), 
        points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
      } as Shape;
    } else if (shape.type === 'pillar') {
      dup = { 
        ...shape, 
        id: Date.now(), 
        x: (shape as any).x + dx, 
        y: (shape as any).y + dy 
      } as Shape;
    } else {
      dup = { 
        ...shape, 
        id: Date.now(), 
        x: (shape as any).x + dx, 
        y: (shape as any).y + dy 
      } as Shape;
    }
    
    return dup;
  }

  // Event Handlers
  
  // Stage drag guard - allow dragging in pan mode or when no tool is selected
  const handleStageDragStart = () => {
    if (isPanMode) {
      if (containerRef.current) {
        containerRef.current.style.cursor = 'grabbing';
      }
      return true;
    }
    else {
      return false;
    }
  };

  // Stage drag move - update cursor during panning
  const handleStageDragMove = () => {
    if (isPanMode && containerRef.current) {
      containerRef.current.style.cursor = 'grabbing';
    }
  };

  // Stage drag end - reset cursor and update position
  const handleStageDragEnd = () => {
    if (isPanMode && containerRef.current) {
      containerRef.current.style.cursor = 'grab';
    }
    
    if (stageRef.current) {
      setStagePosition(stageRef.current.position());
    }
  };

  // Stage click handler
  const handleStageClick = (e: any) => {
    if (e.target === e.target.getStage() && !selectedTool && !isSelecting && !isPanMode) {
      onShapeSelect(null);
      setShowRadialMenu(false);
      setContextMenu({ ...contextMenu, visible: false });
      setIsMultiSelect(false);
      setSelectionBounds(null);
      stageRef.current?.batchDraw();
    }
  };

  // Multi-select context menu
  const handleMultiSelectContextMenu = (e: any) => {
    if (isMultiSelect && selectedShapes.length > 0 && !isPanMode) {
      e.evt.preventDefault();
      const stage = e.target.getStage();
      const pos = stage.getPointerPosition();
      setContextMenu({ 
        visible: true, 
        x: pos.x, 
        y: pos.y, 
        targetShape: null, 
        isMultiSelect: true 
      });
    }
  };

  // Get world position from event
  function getWorldPointer(e: any) {
    const stage = e.target.getStage?.();
    if (!stage) return null;
    
    const pos = stage.getPointerPosition();
    if (!pos) return null;
    
    const world = { 
      x: (pos.x - stage.x()) / stage.scaleX(), 
      y: (pos.y - stage.y()) / stage.scaleY() 
    };
    
    return { stage, world };
  }

  // Auto-populate mouse handlers
  const onAutoPopulateMouseDown = (e: any) => {
    if (!localAutoPopulateMode) return;
    
    const ctx = getWorldPointer(e);
    if (!ctx) return;
    
    const { world } = ctx;
    const x = snapToGrid(world.x, gridSize);
    const y = snapToGrid(world.y, gridSize);
    
    setApDrawRect({ x, y, width: 0, height: 0 });
    setIsDrawingAP(true);
  };

  const onAutoPopulateMouseMove = (e: any) => {
    if (!localAutoPopulateMode || !isDrawingAP || !apDrawRect) return;
    
    const ctx = getWorldPointer(e);
    if (!ctx) return;
    
    const { world } = ctx;
    const x2 = snapToGrid(world.x, gridSize);
    const y2 = snapToGrid(world.y, gridSize);
    
    const w2 = x2 - apDrawRect.x;
    const h2 = y2 - apDrawRect.y;
    
    const rect = {
      x: w2 >= 0 ? apDrawRect.x : apDrawRect.x + w2,
      y: h2 >= 0 ? apDrawRect.y : apDrawRect.y + h2,
      width: Math.abs(w2),
      height: Math.abs(h2),
    } as RectPx;
    
    if ((e as any).evt.shiftKey) {
      const size = Math.min(rect.width, rect.height);
      rect.width = size;
      rect.height = size;
    }
    
    setApDrawRect(rect);
    if (localAutoPopulateMode === 'selection') setRackSelectionRect(rect);
  };

  const onAutoPopulateMouseUp = () => {
    if (!localAutoPopulateMode || !isDrawingAP) return;
    
    setIsDrawingAP(false);
    if (!apDrawRect || apDrawRect.width <= 0 || apDrawRect.height <= 0) { 
      setApDrawRect(null); 
      return; 
    }
    
    if (localAutoPopulateMode === 'obstruction') {
      setRackObstructions(prev => [...prev, { id: `obs-${Date.now()}`, ...apDrawRect! }]);
      setApDrawRect(null);
    } else {
      setRackSelectionRect(apDrawRect!);
      setApDrawRect(null);
    }
  };

  // Mouse down: marquee OR draw
  const handleMouseDown = (e: any) => {
    // Skip if in pan mode - pan mode uses the stage's draggable property
    if (isPanMode) return;
    
    const stage = e.target.getStage();
    if (!stage) return;
    
    const pos = stage.getPointerPosition();
    if (!pos) return;
    
    const world = { 
      x: (pos.x - stage.x()) / stage.scaleX(), 
      y: (pos.y - stage.y()) / stage.scaleY() 
    };
    
    // Marquee start (stage background + no tool)
    if (e.target === stage && !selectedTool) {
      e.evt.preventDefault();
      e.evt.stopPropagation();
      
      setIsSelecting(true);
      setSelectionRect({ 
        x: world.x, 
        y: world.y, 
        width: 0, 
        height: 0, 
        startX: world.x, 
        startY: world.y 
      });
      
      // Clear selection if not shift
      if (!e.evt.shiftKey) {
        onShapeSelect(null);
        setIsMultiSelect(false);
        setSelectionBounds(null);
      } else {
        setIsMultiSelect(true);
      }
      
      stage.batchDraw();
      return;
    }
    
    // Drawing
    if (selectedTool) {
      setIsDrawing(true);
      setStartPoint(world);
      
      if (selectedTool === 'line') {
        const sx = snapToGrid(world.x, gridSize);
        const sy = snapToGrid(world.y, gridSize);
        
        setCurrentShape({ 
          type: 'line', 
          points: [sx, sy, sx, sy], 
          stroke: '#000', 
          strokeWidth: 2, 
          id: Date.now() 
        } as LineShape);
      } else if (selectedTool === 'pencil') {
        setPoints([world.x, world.y]);
      } else if (selectedTool === 'text') {
        // Text input overlay
        const input = document.createElement('input');
        const rect = stage.container().getBoundingClientRect();
        
        input.style.position = 'absolute';
        input.style.left = `${rect.left + pos.x}px`;
        input.style.top = `${rect.top + pos.y}px`;
        input.style.zIndex = '1000';
        
        document.body.appendChild(input);
        input.focus();
        
        input.addEventListener('keydown', (ke) => {
          if (ke.key === 'Enter') {
            const newText: TextShape = { 
              type: 'text', 
              x: world.x, 
              y: world.y, 
              text: input.value, 
              fontSize: 16, 
              fill: '#000', 
              id: Date.now() 
            };
            
            onAddShape([...shapes, newText]);
            document.body.removeChild(input);
          }
        });
        
        input.addEventListener('blur', () => document.body.removeChild(input));
      } else {
        let ns: Shape | null = null;
        
        if ([
          'rectangle', 'wall', 'door', 'window', 'sliding-door',
          'bed', 'sofa', 'table', 'chair', 'rack', 'aisle'
        ].includes(selectedTool)) {
          ns = { 
            type: selectedTool, 
            x: world.x, 
            y: world.y, 
            width: 0, 
            height: 0, 
            stroke: '#000', 
            fill: selectedTool === 'aisle' ? 'rgba(200, 200, 200, 0.5)' : 'transparent', 
            strokeWidth: 2, 
            id: Date.now(),
            label: selectedTool === 'aisle' ? 'aisle' : undefined
          } as RectShape;
          
          // Add section ID to rack shapes
          if (selectedTool === 'rack' && currentSectionId) {
            (ns as any).sectionId = currentSectionId;
          }
        } else if (selectedTool === 'circle') {
          ns = { 
            type: 'circle', 
            x: world.x, 
            y: world.y, 
            radius: 0, 
            stroke: '#000', 
            fill: 'transparent', 
            strokeWidth: 2, 
            id: Date.now() 
          } as CircleShape;
        }
        
        if (ns) setCurrentShape(ns);
      }
    }
  };

  const handleMouseMove = (e: any) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    const stage = e.target.getStage();
    const pos = stage?.getPointerPosition();
    if (!pos || !stage) return;
    
    const world = { 
      x: (pos.x - stage.x()) / stage.scaleX(), 
      y: (pos.y - stage.y()) / stage.scaleY() 
    };
    
    setMousePosition(world);

    // Marquee
    if (isSelecting && selectionRect) {
      e.evt.preventDefault();
      
      const w = world.x - selectionRect.startX;
      const h = world.y - selectionRect.startY;
      
      setSelectionRect({
        ...selectionRect,
        x: w < 0 ? world.x : selectionRect.startX,
        y: h < 0 ? world.y : selectionRect.startY,
        width: Math.abs(w),
        height: Math.abs(h),
      });
      
      stage.batchDraw();
      return;
    }

    // Drawing
    if (!isDrawing) return;
    
    if (selectedTool === 'line' && currentShape) {
      const pts = (currentShape as LineShape).points as number[];
      const startX = pts[0], startY = pts[1];
      
      const dx = world.x - startX;
      const dy = world.y - startY;
      
      const snapped = snapToAngle(dx, dy);
      const endX = snapToGrid(startX + snapped.dx, gridSize);
      const endY = snapToGrid(startY + snapped.dy, gridSize);
      
      setCurrentShape({ 
        ...(currentShape as any), 
        points: [startX, startY, endX, endY] 
      });
    } else if (selectedTool === 'pencil') {
      setPoints(prev => [...prev, world.x, world.y]);
    } else if (currentShape) {
      const upd = { ...(currentShape as any) };
      
      if ([
        'rectangle', 'wall', 'door', 'window', 'sliding-door',
        'bed', 'sofa', 'table', 'chair', 'rack', 'aisle'
      ].includes(currentShape.type)) {
        upd.width = world.x - startPoint.x;
        upd.height = world.y - startPoint.y;
      } else if (currentShape.type === 'circle') {
        const dx = world.x - startPoint.x;
        const dy = world.y - startPoint.y;
        upd.radius = Math.hypot(dx, dy);
      }
      
      setCurrentShape(upd);
    }
  };

  const handleMouseUp = (e: any) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    const stage = e.target?.getStage?.();
    
    // Finish marquee selection
    if (isSelecting && selectionRect) {
      setIsSelecting(false);
      
      // If rect is big enough, compute selection
      if (selectionRect.width > 3 || selectionRect.height > 3) {
        const picked = shapes.filter(s => isShapeInSelection(s, selectionRect));
        
        if (picked.length > 0) {
          if (isMultiSelect && selectedShapes.length > 0) {
            const existingIds = new Set(selectedShapes.map(s => s.id));
            const combined = [
              ...selectedShapes, 
              ...picked.filter(s => !existingIds.has(s.id))
            ];
            setSelectionBounds(calcBounds(combined));
          } else {
            setSelectionBounds(calcBounds(picked));
          }
          
          if (picked.length === 1 && !isMultiSelect) {
            onShapeSelect(picked[0]);
            setIsMultiSelect(false);
            setSelectionBounds(null);
          } else {
            onShapeSelect(null);
            setIsMultiSelect(true);
          }
        } else {
          if (!isMultiSelect) {
            setIsMultiSelect(false);
            setSelectionBounds(null);
            onShapeSelect(null);
          }
        }
      } else {
        if (!isMultiSelect) {
          setIsMultiSelect(false);
          setSelectionBounds(null);
          onShapeSelect(null);
        }
      }
      
      setSelectionRect(null);
      stage?.batchDraw();
      return;
    }

    // Finish drawing
    if (!isDrawing) return;
    
    setIsDrawing(false);
    
    if (selectedTool === 'pencil' && points.length > 2) {
      const newShape: LineShape = { 
        type: 'pencil', 
        points, 
        stroke: '#000', 
        strokeWidth: 2, 
        id: Date.now() 
      };
      
      onAddShape([...shapes, newShape]);
      setPoints([]);
    } else if (currentShape) {
      onAddShape([...shapes, currentShape]);
      setCurrentShape(null);
    }
  };

  // Augmented handlers that route to AP when panel is active
  const handleMouseDownAug = (e: any) => {
    if (showAutoPopulate && localAutoPopulateMode) { 
      onAutoPopulateMouseDown(e); 
      return; 
    }
    handleMouseDown(e);
  };

  const handleMouseMoveAug = (e: any) => {
    if (showAutoPopulate && localAutoPopulateMode) { 
      onAutoPopulateMouseMove(e); 
      return; 
    }
    handleMouseMove(e);
  };

  const handleMouseUpAug = (e: any) => {
    if (showAutoPopulate && localAutoPopulateMode) { 
      onAutoPopulateMouseUp(); 
      return; 
    }
    handleMouseUp(e);
  };

  // Drag handlers
  const handleDragStart = (e: any, shape: Shape) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    setIsDragging(true);
    if (shape.locked) return;
    
    // Store original position for potential revert
    if (shape.type === 'line') {
      const pts = (shape as LineShape).points as number[];
      setDragStartPosition({ x: pts[0], y: pts[1] });
    } else {
      setDragStartPosition({ x: (shape as any).x, y: (shape as any).y });
    }
    
    // Store section ID if it's a rack
    if (shape.type === 'rack' && (shape as any).sectionId) {
      e.target.setAttr('sectionId', (shape as any).sectionId);
    }
    
    if (shape.groupId) {
      setIsDraggingGroup(true);
      
      // Calculate offset from mouse to shape position
      let offsetX: number, offsetY: number;
      
      if (shape.type === 'line') {
        const pts = (shape as LineShape).points as number[];
        offsetX = e.evt.clientX - pts[0];
        offsetY = e.evt.clientY - pts[1];
      } else if (shape.type === 'pillar') {
        offsetX = e.evt.clientX - ((shape as PillarShape).x + (shape as PillarShape).width / 2);
        offsetY = e.evt.clientY - ((shape as PillarShape).y + (shape as PillarShape).height / 2);
      } else {
        offsetX = e.evt.clientX - (shape as any).x;
        offsetY = e.evt.clientY - (shape as any).y;
      }
      
      setGroupDragOffset({ x: offsetX, y: offsetY });
      setDraggedGroupId(shape.groupId);
    } else {
      setIsDraggingGroup(false);
      setDraggedGroupId(null);
    }
  };

  const handleDragMove = (e: any, shape: Shape) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    if (shape.locked) return;
    
    // Special handling for racks
    if (shape.type === 'rack') {
      const newX = e.target.x();
      const newY = e.target.y();
      
      // Snap to grid during drag
      const snappedX = Math.round(newX / gridSize) * gridSize;
      const snappedY = Math.round(newY / gridSize) * gridSize;
      
      // Create a preview shape to check validity
      const previewShape = {
        ...shape,
        x: snappedX,
        y: snappedY
      };
      
      // Check if position is valid
      const isValid = isValidRackPosition(previewShape);
      
      // Visual feedback
      if (!isValid) {
        e.target.stroke('#ff0000');
        e.target.strokeWidth(2);
        if (e.target.getStage()) {
          e.target.getStage().container().style.cursor = 'not-allowed';
        }
      } else {
        e.target.stroke(shape.stroke || '#22c55e');
        e.target.strokeWidth(shape.strokeWidth || 1.5);
        if (e.target.getStage()) {
          e.target.getStage().container().style.cursor = 'move';
        }
      }
    }
    
    // Group dragging
    if (isDraggingGroup && shape.groupId === draggedGroupId) {
      const newX = e.evt.clientX - groupDragOffset.x;
      const newY = e.evt.clientY - groupDragOffset.y;
      
      let dx: number, dy: number;
      
      if (shape.type === 'line') {
        const pts = (shape as LineShape).points as number[];
        dx = newX - pts[0];
        dy = newY - pts[1];
      } else if (shape.type === 'pillar') {
        dx = newX - ((shape as PillarShape).x + (shape as PillarShape).width / 2);
        dy = newY - ((shape as PillarShape).y + (shape as PillarShape).height / 2);
      } else {
        dx = newX - (shape as any).x;
        dy = newY - (shape as any).y;
      }
      
      const next = shapes.map(s => {
        if (s.groupId === shape.groupId) {
          if (s.type === 'line') {
            const p = (s as LineShape).points as number[];
            return { 
              ...s, 
              points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
            } as Shape;
          } else {
            return { 
              ...s, 
              x: (s as any).x + dx, 
              y: (s as any).y + dy 
            } as Shape;
          }
        }
        return s;
      });
      
      onAddShape(next);
    }
    
    // Apply Konva snapping
    handleDragging(e);
  };

  const handleDragEnd = (e: any, shape: Shape) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    // First apply the snapping library's drag end handler
    handleSnapDragEnd(e);
    
    setIsDragging(false);
    setIsDraggingGroup(false);
    setDraggedGroupId(null);
    
    // Reset cursor
    if (e.target.getStage()) {
      e.target.getStage().container().style.cursor = 'default';
    }
    
    // If locked via group, revert
    const groupLocked = shape.groupId && shapes.some(s => 
      s.groupId === shape.groupId && s.locked
    );
    
    if (shape.locked || groupLocked) {
      return; // Konva props are driven by state; no need to manually revert
    }
    
    const newKonvaX = e.target.x();
    const newKonvaY = e.target.y();
    
    // Special handling for racks
    if (shape.type === 'rack') {
      // Snap to grid
      const snappedX = Math.round(newKonvaX / gridSize) * gridSize;
      const snappedY = Math.round(newKonvaY / gridSize) * gridSize;
      
      // Create new shape with snapped position
      const newShape = {
        ...shape,
        x: snappedX,
        y: snappedY
      };
      
      // Get the section ID for this rack
      const sectionId = (shape as any).sectionId;
      
      // Check if position is valid
      if (!isValidRackPosition(newShape)) {
        // Revert to original position
        const next = shapes.map(s => s.id === shape.id ? shape : s);
        onAddShape(next);
        
        // Show feedback
        showFeedback("Cannot place rack here - check for collisions or boundaries");
        return;
      }
      
      // Update with snapped position
      const next = shapes.map(s => s.id === shape.id ? newShape : s);
      onAddShape(next);
      
      // Update selected shape if needed
      if (selectedShape?.id === shape.id) {
        onShapeSelect(newShape);
        if (showRadialMenu) {
          const c = calcShapeCenter(newShape);
          setRadialMenuPosition(c);
        }
      }
      return;
    }
    
    // Calculate movement delta
    let dx: number, dy: number;
    
    if (shape.type === 'pillar') {
      dx = newKonvaX - ((shape as PillarShape).x + (shape as PillarShape).width / 2);
      dy = newKonvaY - ((shape as PillarShape).y + (shape as PillarShape).height / 2);
    } else if (shape.type === 'line') {
      const pts = (shape as LineShape).points as number[];
      dx = newKonvaX - pts[0];
      dy = newKonvaY - pts[1];
    } else {
      dx = newKonvaX - (shape as any).x;
      dy = newKonvaY - (shape as any).y;
    }
    
    // Group dragging
    if (shape.groupId && isDraggingGroup) {
      const next = shapes.map(s => {
        if (s.groupId === shape.groupId) {
          if (s.type === 'line') {
            const p = (s as LineShape).points as number[];
            return { 
              ...s, 
              points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
            } as Shape;
          } else {
            return { 
              ...s, 
              x: (s as any).x + dx, 
              y: (s as any).y + dy 
            } as Shape;
          }
        }
        return s;
      });
      
      onAddShape(next);
      
      if (selectedShape?.groupId === shape.groupId) {
        const us = next.find(s => s.id === selectedShape.id)!;
        onShapeSelect(us);
        if (showRadialMenu) { 
          const c = calcShapeCenter(us); 
          setRadialMenuPosition(c); 
        }
      }
      
      if (isMultiSelect && selectedShapes.some(s => s.groupId === shape.groupId)) {
        const updSel = selectedShapes.map(s => 
          next.find(ns => ns.id === s.id) ?? s
        );
        setSelectionBounds(calcBounds(updSel));
      }
      return;
    }
    
    // Individual shapes & snapping for doors/windows
    let newShape: Shape;
    
    if (shape.type === 'line') {
      const p = (shape as LineShape).points as number[];
      newShape = { 
        ...shape, 
        points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
      } as Shape;
    } else {
      newShape = { 
        ...shape, 
        x: (shape as any).x + dx, 
        y: (shape as any).y + dy 
      } as Shape;
    }
    
    // Collision check for rack
    if (shape.type === 'rack' && checkCollision(newShape, shapes)) {
      showFeedback('Cannot move rack here - it overlaps with another element.');
      return;
    }
    
    // Doors/windows/sliding-door snap to walls
    if (['door', 'window', 'sliding-door'].includes(shape.type)) {
      const center = (shape as any).rotation === 90
        ? { 
            x: (shape as any).x + (shape as any).height / 2 + dx, 
            y: (shape as any).y + (shape as any).width / 2 + dy 
          }
        : { 
            x: (shape as any).x + (shape as any).width / 2 + dx, 
            y: (shape as any).y + (shape as any).height / 2 + dy 
          };
          
      const original = {
        width: (shape as any).rotation === 90 ? (shape as any).height : (shape as any).width,
        height: (shape as any).rotation === 90 ? (shape as any).width : (shape as any).height,
      };
      
      const snapped = findWallToSnapTo(center, original, shapes, zoomLevel);
      
      const next = shapes.map(s => s.id === shape.id
        ? ({ ...s, ...snapped.elementProps, x: snapped.position.x, y: snapped.position.y })
        : s);
      
      onAddShape(next);
      
      if (selectedShape?.id === shape.id) {
        const us = next.find(s => s.id === shape.id)!;
        onShapeSelect(us);
        if (showRadialMenu) { 
          const c = calcShapeCenter(us); 
          setRadialMenuPosition(c); 
        }
      }
      return;
    }

    // Plain position update
    const next = shapes.map(s => s.id === shape.id ? newShape : s);
    onAddShape(next);

    if (selectedShape?.id === shape.id) {
      const us = next.find(s => s.id === shape.id)!;
      onShapeSelect(us);
      if (showRadialMenu) { 
        const c = calcShapeCenter(us); 
        setRadialMenuPosition(c); 
      }
    }
  };

  // Handle transform end (resizing)
  const handleTransformEnd = (e: any, shape: Shape) => {
    // Skip in pan mode
    if (isPanMode) return;
    
    // Apply the snapping library's resize end handler
    handleResizeEnd(e);
    
    // Get the node that was transformed
    const node = e.target;
    
    // Get the new properties
    const scaleX = node.scaleX();
    const scaleY = node.scaleY();
    const rotation = node.rotation();
    
    // Reset scale and apply it to width and height
    node.scaleX(1);
    node.scaleY(1);
    
    // Update the shape in the shapes array
    const updatedShapes = shapes.map(s => {
      if (s.id === shape.id) {
        if (s.type === 'circle') {
          return {
            ...s,
            radius: (s as CircleShape).radius * scaleX, // Assuming uniform scaling for circles
            rotation: rotation
          };
        } else if (s.type === 'line') {
          // For lines, we need to handle differently
          // This is a simplified approach - you might need more complex logic
          const points = (s as LineShape).points as number[];
          const centerX = (points[0] + points[2]) / 2;
          const centerY = (points[1] + points[3]) / 2;
          
          // Calculate new points based on scale and rotation
          // This is a simplified approach
          return s;
        } else {
          // For rectangles and other shapes
          return {
            ...s,
            width: Math.abs((s as RectShape).width * scaleX),
            height: Math.abs((s as RectShape).height * scaleY),
            rotation: rotation as 0 | 90 | 180 | 270
          };
        }
      }
      return s;
    });
    
    onAddShape(updatedShapes);
    
    // Update selected shape if this is the currently selected one
    if (selectedShape && selectedShape.id === shape.id) {
      const updatedShape = updatedShapes.find(s => s.id === shape.id)!;
      onShapeSelect(updatedShape);
    }
  };

  // Radial menu actions
  const handleRadialMenuAction = (action: 'delete' | 'duplicate' | 'rotate' | 'flipVertical' | 'flipHorizontal') => {
    if (!selectedShape) return;
    
    switch (action) {
      case 'delete': {
        const next = shapes.filter(s => s.id !== selectedShape.id);
        onAddShape(next);
        onShapeSelect(null);
        break;
      }
      case 'duplicate': {
        const dup = duplicateOne(selectedShape as Shape, 20, 20, shapes);
        if (!dup) break;
        const next = [...shapes, dup];
        onAddShape(next);
        onShapeSelect(dup);
        break;
      }
      case 'rotate': {
        const next = shapes.map(s => s.id === selectedShape.id
          ? ({ 
              ...s, 
              rotation: ((((s as any).rotation ?? 0) + 90) % 360) as 0 | 90 | 180 | 270 
            })
          : s);
        onAddShape(next);
        break;
      }
      case 'flipVertical': {
        const next = shapes.map(s => s.id === selectedShape.id 
          ? ({ 
              ...s, 
              height: -(s as any).height, 
              y: (s as any).y + (s as any).height 
            }) 
          : s);
        onAddShape(next);
        break;
      }
      case 'flipHorizontal': {
        const next = shapes.map(s => s.id === selectedShape.id 
          ? ({ 
              ...s, 
              width: -(s as any).width, 
              x: (s as any).x + (s as any).width 
            }) 
          : s);
        onAddShape(next);
        break;
      }
    }
    
    setShowRadialMenu(false);
  };

  const toggleRadialMenu = () => {
    stageRef.current?.batchDraw();
    setRadialMenuOpen(!radialMenuOpen);
  };

  // Auto-populate handlers
  const handleAutoPopulateClose = () => {
    setLocalAutoPopulateMode(null);
    onAutoPopulateChange?.(false); // Notify parent component
  };

  const handleGeneratedRacks = (rackShapes: any[]) => {
    console.log("Applying generated racks:", rackShapes.length, "with section ID:", currentSectionId);
    
    if (!currentSectionId) {
      console.warn("No current section ID available");
      return;
    }
    
    // Keep existing racks that aren't part of the current section
    const existingShapes = shapes.filter(s => {
      // Keep non-rack shapes
      if (s.type !== 'rack') return true;
      
      // Keep racks from other sections
      if ((s as any).sectionId && (s as any).sectionId !== currentSectionId) {
        return true;
      }
      
      // Filter out racks from current section (they'll be replaced)
      return false;
    });
    
    // Add section ID to new racks if not already present
    const racksWithSection = rackShapes.map(rack => {
      if (!rack.sectionId) {
        return {
          ...rack,
          sectionId: currentSectionId
        };
      }
      return rack;
    });
    
    // Combine existing shapes with new racks
    const newShapes = [...existingShapes, ...racksWithSection];
    
    // Update the shapes state
    onAddShape(newShapes);
  };

  const clearObstructions = () => setRackObstructions([]);

  // Modified to only clear current section
  const clearAll = () => {
    setRackSelectionRect(null);
    setRackObstructions([]);
    
    // Remove only racks from current section
    if (currentSectionId) {
      console.log("Clearing racks from section:", currentSectionId);
      const updatedShapes = shapes.filter(s => {
        // Keep non-rack shapes
        if (s.type !== 'rack') return true;
        
        // Keep racks from other sections
        if ((s as any).sectionId !== currentSectionId) return true;
        
        // Remove racks from current section
        return false;
      });
      onAddShape(updatedShapes);
    } else {
      // If no section ID, clear all racks
      console.log("No section ID - clearing all racks");
      const shapesWithoutRacks = shapes.filter(s => s.type !== 'rack');
      onAddShape(shapesWithoutRacks);
    }
  };

  // Rendering helpers
  function determineShapeStroke(shape: Shape, isSelected: boolean) {
    if (shape.groupId) return shape.stroke ?? 'transparent';
    if (shape.locked) return '#E1142E';
    if (isSelected) return '#3498db';
    return shape.stroke ?? '#000';
  }

  function determineStrokeWidth(shape: Shape, isSelected: boolean, zoomLevel: number) {
    if (shape.groupId) return Math.max(0, shape.strokeWidth ?? 0);
    if (shape.locked) return 1 / zoomLevel;
    if (isSelected) return ((shape.strokeWidth ?? 1) + 2);
    return shape.strokeWidth ?? 1;
  }

  // Render a shape
  const renderShape = (shape: Shape) => {
    const isSel = !!selectedShape && selectedShape.id === shape.id;
    const stroke = determineShapeStroke(shape, isSel);
    const sw = determineStrokeWidth(shape, isSel, zoomLevel);
    
    const commonProps = {
      id: `node-${shape.id}`, // Add an ID for the transformer to find
      onClick: (e: any) => {
        if (!selectedTool && !isPanMode) {
          e.cancelBubble = true;
          
          if (shape.groupId && !e.evt.shiftKey) {
            // select entire group
            const groupShapes = shapes.filter(s => s.groupId === shape.groupId);
            setIsMultiSelect(true);
            setSelectionBounds(calcBounds(groupShapes as Shape[]));
            onShapeSelect(shape);
            return;
          }
          
          if (!shape.locked) {
            setIsRightClickSelection(false);
            const c = calcShapeCenter(shape);
            setRadialMenuPosition(c);
            onShapeSelect(shape);
            setTimeout(() => { 
              setShowRadialMenu(true); 
              setRadialMenuOpen(true); 
              stageRef.current?.batchDraw(); 
            }, 10);
          } else {
            onShapeSelect(shape); // select but no menu
          }
        }
      },
      onContextMenu: (e: any) => {
        if (isPanMode) return;
        
        e.evt.preventDefault();
        e.cancelBubble = true;
        
        const stage = e.target.getStage();
        const pos = stage.getPointerPosition();
        
        setShowRadialMenu(false);
        setIsRightClickSelection(true);
        setContextMenu({ visible: true, x: pos.x, y: pos.y, targetShape: shape });
        onShapeSelect(shape);
      },
      onTap: (e: any) => {
        if (!selectedTool && !isPanMode) {
          e.cancelBubble = true;
          
          if (!shape.locked) {
            setIsRightClickSelection(false);
            const c = calcShapeCenter(shape);
            setRadialMenuPosition(c);
            setShowRadialMenu(true);
            setRadialMenuOpen(true);
            onShapeSelect(shape);
            setTimeout(() => stageRef.current?.batchDraw(), 10);
          } else {
            onShapeSelect(shape);
          }
        }
      },
    };
    
    const draggable = !selectedTool && 
                    !isDrawing && 
                    !isPanMode &&
                    !(shape.locked || 
                      (shape.groupId && 
                       shapes.some(s => s.groupId === shape.groupId && s.locked)));
    
    switch (shape.type) {
      case 'line':
        return (
          <Line
            key={shape.id}
            points={(shape as LineShape).points as number[]}
            stroke={stroke}
            strokeWidth={sw}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            {...commonProps}
          />
        );
      case 'rectangle':
      case 'wall':
      case 'door':
      case 'window':
      case 'sliding-door':
      case 'bed':
      case 'sofa':
      case 'table':
      case 'chair':
        return (
          <Rect
            key={shape.id}
            x={(shape as RectShape).x}
            y={(shape as RectShape).y}
            width={(shape as RectShape).width}
            height={(shape as RectShape).height}
            fill={(shape as RectShape).fill}
            stroke={stroke}
            strokeWidth={sw}
            dash={(shape as RectShape).dash}
            rotation={(shape as RectShape).rotation ?? 0}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            onTransformEnd={(e) => handleTransformEnd(e, shape)}
            {...commonProps}
          />
        );
      case 'aisle':
        return (
          <Group key={shape.id}>
            <Rect
              x={(shape as RectShape).x}
              y={(shape as RectShape).y}
              width={(shape as RectShape).width}
              height={(shape as RectShape).height}
              fill={(shape as RectShape).fill}
              stroke={stroke}
              strokeWidth={sw}
              opacity={0.7}
              draggable={draggable}
              onDragStart={(e) => handleDragStart(e, shape)}
              onDragMove={(e) => handleDragMove(e, shape)}
              onDragEnd={(e) => handleDragEnd(e, shape)}
              onTransformEnd={(e) => handleTransformEnd(e, shape)}
              {...commonProps}
            />
            <Text
              x={(shape as RectShape).x + (shape as RectShape).width / 2 - 50}
              y={(shape as RectShape).y + (shape as RectShape).height / 2 - 10}
              text={(shape as any).label || "aisle"}
              fontSize={16}
              fill="#000"
              width={100}
              align="center"
              opacity={0.8}
              draggable={false}
            />
          </Group>
        );
      case 'rack':
        return (
          <Rect
            key={shape.id}
            x={(shape as RectShape).x}
            y={(shape as RectShape).y}
            width={(shape as RectShape).width}
            height={(shape as RectShape).height}
            fill={(shape as RectShape).fill}
            stroke={stroke}
            strokeWidth={sw}
            dash={(shape as RectShape).dash}
            rotation={(shape as RectShape).rotation ?? 0}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            onTransformEnd={(e) => handleTransformEnd(e, shape)}
            dragBoundFunc={(pos) => {
              // Snap to grid during drag
              const snappedX = Math.round(pos.x / gridSize) * gridSize;
              const snappedY = Math.round(pos.y / gridSize) * gridSize;
              return { x: snappedX, y: snappedY };
            }}
            {...commonProps}
          />
        );
      case 'pillar':
        return (
          <Circle
            key={shape.id}
            x={(shape as PillarShape).x + (shape as PillarShape).width / 2}
            y={(shape as PillarShape).y + (shape as PillarShape).height / 2}
            radius={(shape as PillarShape).width / 2}
            fill={(shape as PillarShape).fill}
            stroke={stroke}
            strokeWidth={sw}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            onTransformEnd={(e) => handleTransformEnd(e, shape)}
            {...commonProps}
          />
        );
      case 'circle':
        return (
          <Circle
            key={shape.id}
            x={(shape as CircleShape).x}
            y={(shape as CircleShape).y}
            radius={(shape as CircleShape).radius}
            fill={(shape as CircleShape).fill}
            stroke={stroke}
            strokeWidth={sw}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            onTransformEnd={(e) => handleTransformEnd(e, shape)}
            {...commonProps}
          />
        );
      case 'pencil':
        return (
          <Line
            key={shape.id}
            points={(shape as LineShape).points as number[]}
            stroke={stroke}
            strokeWidth={sw}
            tension={0.5}
            lineCap="round"
            lineJoin="round"
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            {...commonProps}
          />
        );
      case 'text':
        return (
          <Text
            key={shape.id}
            x={(shape as TextShape).x}
            y={(shape as TextShape).y}
            text={(shape as TextShape).text}
            fontSize={(shape as TextShape).fontSize}
            fill={(shape as TextShape).fill}
            stroke={isSel && !shape.groupId ? '#3498db' : (shape.groupId ? 'transparent' : '')}
            strokeWidth={isSel && !shape.groupId ? 1 : 0}
            draggable={draggable}
            onDragStart={(e) => handleDragStart(e, shape)}
            onDragMove={(e) => handleDragMove(e, shape)}
            onDragEnd={(e) => handleDragEnd(e, shape)}
            {...commonProps}
          />
        );
      default:
        return null;
    }
  };

  // Render dimensions for a shape
  const renderDimensions = (shape: Shape) => {
    if (!showDimensions) return null;
    
    switch (shape.type) {
      case 'line': {
        const p = (shape as LineShape).points as number[];
        const x1 = p[0], y1 = p[1], x2 = p[2], y2 = p[3];
        const len = Math.hypot(x2 - x1, y2 - y1);
        const dim = formatDimension(len, scale, unit);
        const midX = (x1 + x2) / 2, midY = (y1 + y2) / 2;
        const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        const offset = 15 / zoomLevel;
        const perp = (angle + 90) * Math.PI / 180;
        const offX = Math.cos(perp) * offset, offY = Math.sin(perp) * offset;
        
        return (
          <Group key={`dim-${shape.id}`}>
            <Line 
              points={[x1, y1, midX + offX, midY + offY, x2, y2]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
              dash={[3 / zoomLevel, 3 / zoomLevel]} 
            />
            <Text 
              x={midX + offX} 
              y={midY + offY} 
              text={dim} 
              fontSize={12 / zoomLevel}
              fill="#555" 
              align="center" 
              verticalAlign="middle"
              rotation={angle > 90 || angle < -90 ? angle + 180 : angle} 
            />
          </Group>
        );
      }
      case 'rectangle': 
      case 'wall': 
      case 'door': 
      case 'window': 
      case 'sliding-door':
      case 'bed': 
      case 'sofa': 
      case 'table': 
      case 'chair': 
      case 'rack': 
      case 'aisle': {
        const r = shape as RectShape;
        const wText = formatDimension(Math.abs(r.width), scale, unit);
        const hText = formatDimension(Math.abs(r.height), scale, unit);
        
        return (
          <Group key={`dim-${shape.id}`} rotation={r.rotation ?? 0} x={r.x} y={r.y}>
            <Line 
              points={[0, -10 / zoomLevel, r.width, -10 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
              dash={[3 / zoomLevel, 3 / zoomLevel]} 
            />
            <Line 
              points={[0, -15 / zoomLevel, 0, -5 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Line 
              points={[r.width, -15 / zoomLevel, r.width, -5 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Text 
              x={r.width / 2} 
              y={-20 / zoomLevel} 
              text={wText} 
              fontSize={12 / zoomLevel} 
              fill="#555" 
              align="center" 
            />
            <Line 
              points={[r.width + 10 / zoomLevel, 0, r.width + 10 / zoomLevel, r.height]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
              dash={[3 / zoomLevel, 3 / zoomLevel]} 
            />
            <Line 
              points={[r.width + 5 / zoomLevel, 0, r.width + 15 / zoomLevel, 0]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Line 
              points={[r.width + 5 / zoomLevel, r.height, r.width + 15 / zoomLevel, r.height]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Text 
              x={r.width + 20 / zoomLevel} 
              y={r.height / 2} 
              text={hText} 
              fontSize={12 / zoomLevel} 
              fill="#555" 
              align="left" 
              verticalAlign="middle" 
            />
          </Group>
        );
      }
      case 'circle': 
      case 'pillar': {
        let x: number, y: number, radius: number;
        
        if (shape.type === 'circle') { 
          x = (shape as CircleShape).x; 
          y = (shape as CircleShape).y; 
          radius = (shape as CircleShape).radius; 
        } else { 
          x = (shape as PillarShape).x + (shape as PillarShape).width / 2; 
          y = (shape as PillarShape).y + (shape as PillarShape).height / 2; 
          radius = (shape as PillarShape).width / 2; 
        }
        
        const dim = formatDimension(radius * 2, scale, unit);
        
        return (
          <Group key={`dim-${shape.id}`}>
            <Line 
              points={[x, y - radius - 10 / zoomLevel, x, y + radius + 10 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
              dash={[3 / zoomLevel, 3 / zoomLevel]} 
            />
            <Line 
              points={[x - 5 / zoomLevel, y - radius - 10 / zoomLevel, x + 5 / zoomLevel, y - radius - 10 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Line 
              points={[x - 5 / zoomLevel, y + radius + 10 / zoomLevel, x + 5 / zoomLevel, y + radius + 10 / zoomLevel]} 
              stroke="#555" 
              strokeWidth={1 / zoomLevel} 
            />
            <Text 
              x={x + 10 / zoomLevel} 
              y={y} 
              text={dim} 
              fontSize={12 / zoomLevel} 
              fill="#555" 
              verticalAlign="middle" 
            />
          </Group>
        );
      }
      default: 
        return null;
    }
  };

  // Render drag element preview
  const renderDragElementPreview = () => {
    if (!isDraggingElement || !dragElement || !mousePosition || isPanMode) return null;
    
    const stage = stageRef.current;
    if (!stage) return null;
    
    switch (dragElement.type) {
      case 'door': 
      case 'window': 
      case 'sliding-door': {
        const snap = findWallToSnapTo(mousePosition, dragElement, shapes, zoomLevel);
        const w = (snap.elementProps as any).width ?? dragElement.width;
        const h = (snap.elementProps as any).height ?? dragElement.height;
        const r = (snap.elementProps as any).rotation ?? 0;
        const preview: Shape = { 
          ...dragElement, 
          ...snap.elementProps, 
          x: snap.position.x, 
          y: snap.position.y, 
          id: 'preview' 
        } as any;
        
        const coll = dragElement.type === 'rack' && checkCollision(preview, shapes);
        
        return (
          <Rect 
            x={snap.position.x} 
            y={snap.position.y} 
            width={w} 
            height={h}
            fill={coll ? 'rgba(255,0,0,0.4)' : dragElement.fill}
            stroke={coll ? '#ff0000' : dragElement.stroke}
            strokeWidth={dragElement.strokeWidth} 
            dash={dragElement.dash}
            rotation={r} 
            opacity={0.6} 
          />
        );
      }
      case 'wall': 
      case 'bed': 
      case 'sofa': 
      case 'table': 
      case 'chair': 
      case 'aisle': {
        return (
          <Rect 
            x={mousePosition.x - dragElement.width / 2} 
            y={mousePosition.y - dragElement.height / 2}
            width={dragElement.width} 
            height={dragElement.height}
            fill={dragElement.fill}
            stroke={dragElement.stroke}
            strokeWidth={dragElement.strokeWidth} 
            opacity={0.6} 
          />
        );
      }
      case 'rack': {
        // For racks, check boundary and collisions
        const x = mousePosition.x - dragElement.width / 2;
        const y = mousePosition.y - dragElement.height / 2;
        
        // Snap to grid
        const snappedX = Math.round(x / gridSize) * gridSize;
        const snappedY = Math.round(y / gridSize) * gridSize;
        
        const previewShape = {
          ...dragElement,
          x: snappedX,
          y: snappedY,
          id: 'preview',
          sectionId: currentSectionId
        } as any;
        
        // Check if position is valid
        const isValid = isValidRackPosition(previewShape);
        
        return (
          <Rect 
            x={snappedX}
            y={snappedY}
            width={dragElement.width}
            height={dragElement.height}
            fill={isValid ? dragElement.fill : 'rgba(255,0,0,0.4)'}
            stroke={isValid ? dragElement.stroke : '#ff0000'}
            strokeWidth={dragElement.strokeWidth}
            opacity={0.6}
          />
        );
      }
      case 'pillar':
        return (
          <Circle 
            x={mousePosition.x} 
            y={mousePosition.y} 
            radius={dragElement.width / 2}
            fill={dragElement.fill} 
            stroke={dragElement.stroke}
            strokeWidth={dragElement.strokeWidth} 
            opacity={0.6} 
          />
        );
      default: 
        return null;
    }
  };

  // Define the style for context menu items
  const liStyle = {
    padding: '8px 12px',
    cursor: 'pointer',
    borderBottom: '1px solid #eee',
    whiteSpace: 'nowrap' as 'nowrap',
    fontSize: '14px'
  };

  return (
    <div 
      className={`canvas-container ${isPanMode ? 'pan-mode' : ''}`}
      ref={containerRef}
      style={{ 
        position: 'relative',
        cursor: isPanMode ? 'grab' : 'default'
      }}
    >
      <Stage
        width={stageSize.width}
        height={stageSize.height}
        onMouseDown={handleMouseDownAug}
        onMouseMove={handleMouseMoveAug}
        onMouseUp={handleMouseUpAug}
        onMouseLeave={handleMouseUpAug}
        onClick={handleStageClick}
        onContextMenu={handleMultiSelectContextMenu}
        ref={stageRef}
        draggable={isPanMode && !showAutoPopulate}
        onDragStart={handleStageDragStart}
        onDragMove={handleStageDragMove}
        onDragEnd={handleStageDragEnd}
      >
        <Layer>
          {/* Grid Layer */}
          {gridLines}
        </Layer>
        
        <Layer>
          {/* Existing Shapes */}
          {shapes.map(renderShape)}
          
          {/* Transformer for resizing - only show for selected shape */}
          {selectedShape && !selectedTool && !isMultiSelect && !selectedShape.locked && !isPanMode && (
            <Transformer
              ref={transformerRef}
              boundBoxFunc={(oldBox, newBox) => {
                // Limit minimum size
                if (newBox.width < 5 || newBox.height < 5) {
                  return oldBox;
                }
                return newBox;
              }}
              onTransform={handleResizing}
              rotateEnabled={true}
              keepRatio={false}
              enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
            />
          )}
          
          {/* Duplicate Controls - only show for selected shape */}
          {selectedShape && !selectedShape.locked && !isRightClickSelection && !isDragging && !isPanMode && (
            <DuplicateControls 
              shape={selectedShape} 
              onDuplicate={(d: any) => {
                if (Array.isArray(d)) {
                  let next = [...shapes];
                  let last: Shape | null = null;
                  let collision = false;
                  
                  d.forEach(({shape, offsetX, offsetY}: any) => {
                    const dup = duplicateOne(shape, offsetX, offsetY, next);
                    if (!dup) { 
                      collision = true; 
                      return; 
                    }
                    next.push(dup);
                    last = dup;
                  });
                  
                  if (collision) {
                    showFeedback("Some duplicates couldn't be placed due to overlaps or boundary constraints.");
                  }
                  
                  onAddShape(next);
                  if (last) onShapeSelect(last);
                } else {
                  const dup = duplicateOne(
                    d, 
                    (arguments as any)[1] ?? 0, 
                    (arguments as any)[2] ?? 0, 
                    shapes
                  );
                  
                  if (dup) { 
                    onAddShape([...shapes, dup]); 
                    onShapeSelect(dup); 
                  }
                }
              }} 
              zoomLevel={zoomLevel} 
            />
          )}
          
          {/* Dimensions */}
          {showDimensions && shapes.map(renderDimensions)}
          
          {/* Drawing live feedback */}
          {isDrawing && selectedTool === 'pencil' && (
            <Line 
              points={points} 
              stroke="#000" 
              strokeWidth={2} 
              tension={0.5} 
              lineCap="round" 
              lineJoin="round" 
            />
          )}
          
          {/* Drawing line with measurement */}
          {isDrawing && selectedTool === 'line' && currentShape && (
            <>
              <Line 
                points={(currentShape as LineShape).points as number[]} 
                stroke="red" 
                strokeWidth={2} 
              />
              {showDimensions && (
                <Text
                  x={((currentShape as LineShape).points[0] + (currentShape as LineShape).points[2]) / 2}
                  y={((currentShape as LineShape).points[1] + (currentShape as LineShape).points[3]) / 2 - 20 / zoomLevel}
                  text={formatDimension(
                    distance(
                      (currentShape as LineShape).points[0], 
                      (currentShape as LineShape).points[1],
                      (currentShape as LineShape).points[2], 
                      (currentShape as LineShape).points[3]
                    ), 
                    scale, 
                    unit
                  )}
                  fontSize={14 / zoomLevel}
                  fill="red"
                  align="center"
                />
              )}
            </>
          )}
          
          {/* Drawing other shapes */}
          {currentShape && selectedTool !== 'line' && renderShape(currentShape)}
          
          {/* Drag element preview */}
          {renderDragElementPreview()}
          
          {/* Marquee selection rectangle */}
          {isSelecting && selectionRect && (
            <Rect
              x={selectionRect.x} 
              y={selectionRect.y} 
              width={selectionRect.width} 
              height={selectionRect.height}
              fill="rgba(0, 161, 255, 0.2)" 
              stroke="rgb(0, 161, 255)" 
              strokeWidth={2 / zoomLevel}
              dash={[5 / zoomLevel, 5 / zoomLevel]} 
              perfectDrawEnabled={false} 
              listening={false}
            />
          )}
          
          {/* Enhanced selection outline */}
          {selectionBounds && selectedShapes.length > 0 && !isPanMode && (
            <>
              {/* Orange selection outline when not same group */}
              {!selectedShapes.every(s => 
                s.groupId && selectedShapes.every(ss => ss.groupId === s.groupId)
              ) && (
                <Rect
                  x={selectionBounds.x - 4 / zoomLevel} 
                  y={selectionBounds.y - 4 / zoomLevel}
                  width={selectionBounds.width + 8 / zoomLevel} 
                  height={selectionBounds.height + 8 / zoomLevel}
                  stroke="#ff9800" 
                  strokeWidth={2 / zoomLevel} 
                  fill="rgba(255, 152, 0, 0.05)"
                  listening={true} 
                  draggable={!isPanMode}
                  onContextMenu={(e: any) => {
                    if (isPanMode) return;
                    
                    e.evt.preventDefault();
                    e.cancelBubble = true;
                    
                    const stage = e.target.getStage();
                    const pos = stage.getPointerPosition();
                    
                    setContextMenu({ 
                      visible: true, 
                      x: pos.x, 
                      y: pos.y, 
                      targetShape: null, 
                      isMultiSelect: true 
                    });
                  }}
                  onDragStart={(e: any) => {
                    if (isPanMode) return;
                    setDragStartPosition({ 
                      x: e.target.x(), 
                      y: e.target.y() 
                    });
                  }}
                  onDragEnd={(e: any) => {
                    if (isPanMode) return;
                    
                    const dx = e.target.x() - dragStartPosition.x;
                    const dy = e.target.y() - dragStartPosition.y;
                    
                    const next = shapes.map(s => {
                      const isSelected = selectedShapes.some(sel => sel.id === s.id);
                      const isUnlocked = !s.locked;
                      
                      if (isSelected && isUnlocked) {
                        if (s.type === 'line') {
                          const p = (s as LineShape).points as number[];
                          return { 
                            ...s, 
                            points: [p[0] + dx, p[1] + dy, p[2] + dx, p[3] + dy] 
                          };
                        } else {
                          return { 
                            ...s, 
                            x: (s as any).x + dx, 
                            y: (s as any).y + dy 
                          };
                        }
                      }
                      return s;
                    });
                    
                    onAddShape(next);
                    
                    const updSel = selectedShapes.map(sh => 
                      next.find(ns => ns.id === sh.id) ?? sh
                    );
                    
                    setSelectionBounds(calcBounds(updSel));
                  }}
                />
              )}
              
              {/* Corner handles */}
              {!selectedShapes.every(s => 
                s.groupId && selectedShapes.every(ss => ss.groupId === s.groupId)
              ) && (
                [
                  { x: selectionBounds.x - 4 / zoomLevel, y: selectionBounds.y - 4 / zoomLevel },
                  { x: selectionBounds.x + selectionBounds.width + 4 / zoomLevel, y: selectionBounds.y - 4 / zoomLevel },
                  { x: selectionBounds.x - 4 / zoomLevel, y: selectionBounds.y + selectionBounds.height + 4 / zoomLevel },
                  { x: selectionBounds.x + selectionBounds.width + 4 / zoomLevel, y: selectionBounds.y + selectionBounds.height + 4 / zoomLevel },
                ].map((p, i) => (
                  <Rect 
                    key={`handle-${i}`} 
                    x={p.x - 4 / zoomLevel} 
                    y={p.y - 4 / zoomLevel} 
                    width={8 / zoomLevel} 
                    height={8 / zoomLevel}
                    fill="#ff9800" 
                    stroke="#fff" 
                    strokeWidth={1 / zoomLevel} 
                    perfectDrawEnabled={false} 
                    listening={false} 
                  />
                ))
              )}
            </>
          )}
          
          {/* Radial Menu */}
          {selectedShape && !selectedShape.locked && !isRightClickSelection && !isDragging && showRadialMenu && !isPanMode && (
            <RadialMenu
              x={radialMenuPosition.x}
              y={radialMenuPosition.y}
              isOpen={radialMenuOpen}
              onToggle={toggleRadialMenu}
              onAction={handleRadialMenuAction}
              zoomLevel={zoomLevel}
              selectedShape={selectedShape}
            />
          )}
        </Layer>
        
        {/* Auto-populate overlays (non-listening) */}
        <Layer listening={false}>
          {rackObstructions.map(o => (
            <Rect 
              key={o.id} 
              x={o.x} 
              y={o.y} 
              width={o.width} 
              height={o.height}
              fill="rgba(239,68,68,0.20)" 
              stroke="#ef4444" 
              strokeWidth={1.5 / zoomLevel} 
              cornerRadius={3} 
            />
          ))}
          
          {rackSelectionRect && rackSelectionRect.width > 0 && rackSelectionRect.height > 0 && (
            <Group>
              <Rect 
                x={rackSelectionRect.x} 
                y={rackSelectionRect.y}
                width={rackSelectionRect.width} 
                height={rackSelectionRect.height}
                stroke="#93c5fd" 
                strokeWidth={2 / zoomLevel} 
                dash={[6 / zoomLevel, 4 / zoomLevel]} 
                cornerRadius={4} 
              />
              <Rect 
                x={rackSelectionRect.x} 
                y={rackSelectionRect.y}
                width={rackSelectionRect.width} 
                height={rackSelectionRect.height}
                fillLinearGradientStartPoint={{ x: 0, y: 0 }}
                fillLinearGradientEndPoint={{ x: 0, y: rackSelectionRect.height }}
                fillLinearGradientColorStops={[ 
                  0, 'rgba(59,130,246,0.15)', 
                  1, 'rgba(59,130,246,0.05)' 
                ]} 
              />
            </Group>
          )}
          
          {isDrawingAP && apDrawRect && apDrawRect.width > 0 && apDrawRect.height > 0 && (
            <Group>
              <Rect 
                x={apDrawRect.x} 
                y={apDrawRect.y} 
                width={apDrawRect.width} 
                height={apDrawRect.height}
                stroke={localAutoPopulateMode === 'selection' ? '#93c5fd' : '#ef4444'} 
                dash={[6 / zoomLevel, 4 / zoomLevel]} 
                cornerRadius={4} 
              />
              <Rect 
                x={apDrawRect.x} 
                y={apDrawRect.y} 
                width={apDrawRect.width} 
                height={apDrawRect.height}
                fill={localAutoPopulateMode === 'selection' ? 'rgba(59,130,246,0.08)' : 'rgba(239,68,68,0.08)'} 
              />
            </Group>
          )}
        </Layer>
        
        {/* Boundary visualization */}
        {boundaryRect && (
          <Layer listening={false}>
            <Rect
              x={boundaryRect.x}
              y={boundaryRect.y}
              width={boundaryRect.width}
              height={boundaryRect.height}
              stroke="#16a34a"
              strokeWidth={1.5 / zoomLevel}
              dash={[8 / zoomLevel, 4 / zoomLevel]}
              fill="rgba(22, 163, 74, 0.05)"
            />
          </Layer>
        )}
        
        {/* Section boundaries visualization */}
        <Layer listening={false}>
          {rackSections.map(section => (
            <Rect
              key={`section-${section.id}`}
              x={section.boundary.x}
              y={section.boundary.y}
              width={section.boundary.width}
              height={section.boundary.height}
              stroke={section.id === currentSectionId ? "#16a34a" : "#3b82f6"}
              strokeWidth={1.5 / zoomLevel}
              dash={[8 / zoomLevel, 4 / zoomLevel]}
              fill={section.id === currentSectionId ? 
                "rgba(22, 163, 74, 0.05)" : 
                "rgba(59, 130, 246, 0.03)"}
            />
          ))}
        </Layer>
        
        {/* Debug visualization for section IDs */}
        <Layer listening={false}>
          {shapes
            .filter(s => s.type === 'rack' && (s as any).sectionId)
            .map((rack: any) => (
              <Text
                key={`debug-${rack.id}`}
                x={rack.x + rack.width / 2}
                y={rack.y - 10 / zoomLevel}
                text={`${rack.sectionId.substring(0, 6)}...`}
                fontSize={10 / zoomLevel}
                fill="#16a34a"
                align="center"
                visible={false} // Set to true for debugging
              />
            ))
          }
        </Layer>
      </Stage>
      
      {/* Scale indicator */}
      <div 
        className="scale-indicator" 
        style={{ 
          display: showDimensions ? 'flex' : 'none',
          position: 'absolute',
          bottom: '10px',
          right: '10px',
          background: 'rgba(255, 255, 255, 0.8)',
          padding: '5px',
          borderRadius: '3px',
          border: '1px solid #ddd'
        }}
      >
        <div className="scale-bar">
          <div 
            className="scale-segment" 
            style={{ 
              width: `${scaleBar.width}px`,
              height: '4px',
              background: '#333',
              position: 'relative'
            }}
          ></div>
        </div>
        <div 
          className="scale-label"
          style={{
            fontSize: '12px',
            textAlign: 'center',
            marginTop: '2px'
          }}
        >
          {scaleBar.label}
        </div>
      </div>
      
      {/* Context Menu (single & multi) */}
      {contextMenu.visible && !isPanMode && (
        <div
          className="context-menu"
          style={{ 
            position: 'absolute', 
            top: `${contextMenu.y}px`, 
            left: `${contextMenu.x}px`, 
            background: '#fff', 
            border: '1px solid #ccc', 
            borderRadius: 4, 
            boxShadow: '0 2px 5px rgba(0,0,0,0.2)', 
            zIndex: 1000 
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {contextMenu.isMultiSelect ? (
              <>
                <li style={liStyle} onClick={() => {
                  const next = shapes.filter(sh => 
                    !selectedShapes.some(sel => sel.id === sh.id) || sh.locked
                  );
                  onAddShape(next);
                  setIsMultiSelect(false);
                  setSelectionBounds(null);
                  setContextMenu({ ...contextMenu, visible: false });
                }}>Delete Selected</li>
                <li style={liStyle} onClick={() => {
                  const dups: Shape[] = [];
                  selectedShapes.forEach(sh => {
                    if (sh.locked) return;
                    const dup = duplicateOne(sh, 20, 20, shapes);
                    if (dup) dups.push(dup);
                  });
                  if (dups.length > 0) {
                    onAddShape([...shapes, ...dups]);
                    setSelectionBounds(calcBounds(dups));
                  }
                  setContextMenu({ ...contextMenu, visible: false });
                }}>Duplicate Selected</li>
                {selectedShapes.length >= 2 && (
                  <li style={liStyle} onClick={() => { // Group
                    const groupId = `group-${Date.now()}`;
                    const next = shapes.map(sh => 
                      selectedShapes.some(sel => sel.id === sh.id) ? { ...sh, groupId } : sh
                    );
                    onAddShape(next);
                    const grouped = next.filter(s => s.groupId === groupId) as Shape[];
                    setIsMultiSelect(true);
                    setSelectionBounds(calcBounds(grouped));
                    setContextMenu({ ...contextMenu, visible: false });
                  }}>Group Elements</li>
                )}
              </>
            ) : (
              <>
                <li style={liStyle} onClick={() => { // Lock / Unlock
                  if (contextMenu.targetShape) {
                    const target = contextMenu.targetShape;
                    const isLocked = !!target.locked;
                    const gid = target.groupId;
                    const next = shapes.map(s => {
                      if (gid && s.groupId === gid) return { ...s, locked: !isLocked };
                      if (s.id === target.id) return { ...s, locked: !isLocked };
                      return s;
                    });
                    
                    setContextMenu({ ...contextMenu, visible: false });
                    onAddShape(next);
                    
                    if (selectedShape && selectedShape.id === target.id) {
                      const us = next.find(s => s.id === target.id)!;
                      if (isLocked && !gid) {
                        // unlocking -> show radial menu
                        const c = calcShapeCenter(us);
                        setTimeout(() => {
                          onShapeSelect(us);
                          setRadialMenuPosition(c);
                          setShowRadialMenu(true);
                          setRadialMenuOpen(true);
                          stageRef.current?.batchDraw();
                        }, 10);
                      } else {
                        onShapeSelect(us);
                        setShowRadialMenu(false);
                      }
                    }
                  }
                }}>{contextMenu.targetShape?.locked ? 'Unlock' : 'Lock'}</li>
                {contextMenu.targetShape?.groupId && (
                  <li style={liStyle} onClick={() => {
                    const gid = contextMenu.targetShape!.groupId!;
                    const next = shapes.map(s => 
                      s.groupId === gid ? ({ ...s, groupId: undefined }) : s
                    );
                    onAddShape(next);
                    setContextMenu({ ...contextMenu, visible: false });
                  }}>Ungroup Elements</li>
                )}
              </>
            )}
          </ul>
        </div>
      )}
      
      {/* Auto-Populate panel (right dock) */}
      {showAutoPopulate && showAutoPopulateInCanvas && (
        <div 
          className="auto-populate-panel" 
          style={{ 
            position: 'absolute', 
            top: 0, 
            right: 0, 
            bottom: 0, 
            width: '340px', 
            background: 'white', 
            borderLeft: '1px solid #1f2937', 
            padding: '16px', 
            overflow: 'auto', 
            zIndex: 10 
          }}
        >
          <AutoPopulatePanel
            controlsOnly
            stageRef={stageRef}
            selectionRect={rackSelectionRect as any}
            obstructions={rackObstructions as any}
            onToggleMode={(mode: any) => setLocalAutoPopulateMode(mode)}
            onClearObstructions={clearObstructions}
            onClearAll={clearAll}
            onGenerateRacks={handleGeneratedRacks}
            onClose={handleAutoPopulateClose}
            sectionId={currentSectionId}
          />
        </div>
      )}
      
      {/* Section indicator */}
      {currentSectionId && (
        <div 
          className="section-indicator" 
          style={{ 
            position: 'absolute', 
            bottom: '10px', 
            left: '10px', 
            background: 'rgba(22, 163, 74, 0.9)', 
            color: 'white', 
            padding: '5px 10px', 
            borderRadius: '4px',
            fontSize: '12px',
            zIndex: 100
          }}
        >
          Current Section: {currentSectionId}
        </div>
      )}
      
      {/* Pan Mode Indicator */}
      {isPanMode && (
        <div 
          className="pan-mode-overlay" 
          style={{
            position: 'absolute',
            top: '10px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(0, 0, 0, 0.7)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '4px',
            pointerEvents: 'none',
            zIndex: 1000,
            opacity: 0.8,
            transition: 'opacity 0.3s ease'
          }}
        >
          <div 
            className="pan-mode-message"
            style={{
              textAlign: 'center',
              fontSize: '14px'
            }}
          >
            Pan Mode Active
            <br />
            <small style={{ fontSize: '12px', opacity: 0.8 }}>
              Click the pan button again to exit
            </small>
          </div>
        </div>
      )}
    </div>
  );
});

export default Canvas;
