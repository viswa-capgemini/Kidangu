import React, { useRef, useEffect, useCallback, useState, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { renderEntity } from '../../../utils/canvasRenderer';
import type { Transform } from '../../../utils/canvasRenderer';
import {
    setZoom,
    setPanOffset,
    setCanvasSize,
    setActiveTool,
    setSnapPoint,
    addMeasurePoint,
    clearMeasure
} from '../../../store/slices/uiSlice';
import { setSelectedEntity, toggleSelectedEntity, deleteSelectedEntities, addBlockedArea, removeBlockedArea } from '../../../store/slices/dxfSlice';
import type { RootState } from '../../../store';

const Canvas: React.FC = () => {
    const dispatch = useDispatch();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const requestRef = useRef<number>();
    const needsRedraw = useRef(true);

    const { data: dxfData, visibleLayers, selectedEntities, blockedAreas } = useSelector((state: RootState) => state.dxf);
    const { zoom, panOffset, activeTool, theme, snapPoint, measurePoints, fitToScreenCounter } = useSelector((state: RootState) => state.ui);

    const [isDragging, setIsDragging] = useState(false);
    const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
    const [dragStartWorld, setDragStartWorld] = useState<{ x: number, y: number } | null>(null);
    const lastMouseWorldPos = useRef({ x: 0, y: 0 });

    const layerColors = useMemo(() => {
        if (!dxfData || !dxfData.layers) return {};
        return (dxfData.layers as any[]).reduce((acc, layer) => {
            acc[layer.name] = layer.rgb_color;
            return acc;
        }, {} as Record<string, string>);
    }, [dxfData]);

    const visibleLayersSet = useMemo(() => new Set(visibleLayers), [visibleLayers]);
    const selectedHandlesSet = useMemo(() => new Set(selectedEntities.map(e => e.handle)), [selectedEntities]);

    // Single source of truth for transformations
    const currentTransform = useMemo<Transform | null>(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !dxfData.extents) return null;

        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        const extents = dxfData.extents;

        const finalScale = zoom;

        const centerX = (extents.min_x + extents.max_x) / 2;
        const centerY = (extents.min_y + extents.max_y) / 2;

        return {
            scale: finalScale,
            offsetX: centerX,
            offsetY: centerY,
            canvasOffsetX: canvasWidth / 2 + panOffset.x,
            canvasOffsetY: canvasHeight / 2 + panOffset.y
        };
    }, [dxfData, zoom, panOffset]);

    // Conversion helper: Canvas to World
    const canvasToWorld = useCallback((x: number, y: number) => {
        if (!currentTransform) return { x: 0, y: 0 };
        const { scale, offsetX, offsetY, canvasOffsetX, canvasOffsetY } = currentTransform;
        return {
            x: (x - canvasOffsetX) / scale + offsetX,
            y: (canvasOffsetY - y) / scale + offsetY
        };
    }, [currentTransform]);

    // Conversion helper: World to Canvas
    const worldToCanvas = useCallback((wx: number, wy: number) => {
        if (!currentTransform) return { x: 0, y: 0 };
        const { scale, offsetX, offsetY, canvasOffsetX, canvasOffsetY } = currentTransform;
        return {
            x: (wx - offsetX) * scale + canvasOffsetX,
            y: canvasOffsetY - (wy - offsetY) * scale
        };
    }, [currentTransform]);

    const drawGrid = (ctx: CanvasRenderingContext2D, canvasWidth: number, canvasHeight: number) => {
        if (!currentTransform) return;
        const gridSize = 100 * currentTransform.scale;
        if (gridSize < 10) return;

        ctx.save();
        ctx.translate(canvasWidth / 2 + panOffset.x, canvasHeight / 2 + panOffset.y);
        ctx.fillStyle = theme === 'dark' ? 'rgba(71, 85, 105, 0.2)' : 'rgba(0, 0, 0, 0.05)';

        const startX = -canvasWidth / 2 - Math.abs(panOffset.x) - gridSize;
        const endX = canvasWidth / 2 + Math.abs(panOffset.x) + gridSize;
        const startY = -canvasHeight / 2 - Math.abs(panOffset.y) - gridSize;
        const endY = canvasHeight / 2 + Math.abs(panOffset.y) + gridSize;

        for (let x = startX - (startX % gridSize); x < endX; x += gridSize) {
            for (let y = startY - (startY % gridSize); y < endY; y += gridSize) {
                ctx.beginPath();
                ctx.arc(x, y, 0.8, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        ctx.restore();
    };

    const render = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !currentTransform) return;

        if (!needsRedraw.current) {
            requestRef.current = requestAnimationFrame(render);
            return;
        }

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        ctx.clearRect(0, 0, canvasWidth, canvasHeight);

        ctx.lineWidth = 1;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';

        drawGrid(ctx, canvasWidth, canvasHeight);

        if (dxfData.entities && dxfData.entities.length > 0) {
            dxfData.entities.forEach((entity: any) => {
                const isSelected = selectedHandlesSet.has(entity.handle);
                renderEntity(ctx, entity, currentTransform, layerColors, visibleLayersSet, theme, isSelected);
            });
        }

        // Draw Blocked Areas
        blockedAreas.forEach(area => {
            const pt = worldToCanvas(area.x, area.y);
            const size = {
                w: area.width * currentTransform.scale,
                h: -area.height * currentTransform.scale // flipped Y
            };

            ctx.save();
            ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
            ctx.strokeStyle = 'rgba(239, 68, 68, 0.5)';
            ctx.lineWidth = 1;
            ctx.fillRect(pt.x, pt.y, size.w, size.h);
            ctx.strokeRect(pt.x, pt.y, size.w, size.h);

            // Draw "Blocked" label at small zoom
            if (currentTransform.scale > 0.05) {
                ctx.fillStyle = '#ef4444';
                ctx.font = '10px Inter';
                ctx.fillText('BLOCKED', pt.x + 4, pt.y - 4);
            }
            ctx.restore();
        });

        // Draw current dragging block
        if (activeTool === 'block' && dragStartWorld && lastMouseWorldPos.current) {
            const startPt = worldToCanvas(dragStartWorld.x, dragStartWorld.y);
            const currentPt = worldToCanvas(lastMouseWorldPos.current.x, lastMouseWorldPos.current.y);

            ctx.save();
            ctx.fillStyle = 'rgba(59, 130, 246, 0.1)';
            ctx.strokeStyle = '#3b82f6';
            ctx.setLineDash([4, 4]);
            ctx.strokeRect(startPt.x, startPt.y, currentPt.x - startPt.x, currentPt.y - startPt.y);
            ctx.restore();
        }

        // Draw Snap Marker
        if (snapPoint) {
            const pt = worldToCanvas(snapPoint.x, snapPoint.y);

            ctx.save();
            ctx.strokeStyle = '#00FF00';
            ctx.lineWidth = 2;
            ctx.beginPath();
            if (snapPoint.type === 'endpoint') {
                ctx.rect(pt.x - 6, pt.y - 6, 12, 12);
            } else if (snapPoint.type === 'midpoint') {
                ctx.moveTo(pt.x, pt.y - 8);
                ctx.lineTo(pt.x - 8, pt.y + 6);
                ctx.lineTo(pt.x + 8, pt.y + 6);
                ctx.closePath();
            } else if (snapPoint.type === 'center') {
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, 7, 0, Math.PI * 2);
            }
            ctx.stroke();
            ctx.restore();
        }

        // Draw Measurement
        if (measurePoints.length > 0) {
            ctx.save();
            ctx.strokeStyle = theme === 'dark' ? '#60A5FA' : '#3B82F6';
            ctx.lineWidth = 2;
            ctx.setLineDash([5, 5]);

            const startPt = worldToCanvas(measurePoints[0].x, measurePoints[0].y);
            const endCoord = snapPoint || lastMouseWorldPos.current;

            if (endCoord) {
                const endPt = worldToCanvas(endCoord.x, endCoord.y);

                ctx.beginPath();
                ctx.moveTo(startPt.x, startPt.y);
                ctx.lineTo(endPt.x, endPt.y);
                ctx.stroke();

                const dist = Math.sqrt((measurePoints[0].x - endCoord.x) ** 2 + (measurePoints[0].y - endCoord.y) ** 2);

                ctx.font = 'bold 13px "Inter", sans-serif';
                const label = `${dist.toFixed(3)} units`;
                const textWidth = ctx.measureText(label).width;
                const midX = (startPt.x + endPt.x) / 2;
                const midY = (startPt.y + endPt.y) / 2;

                ctx.fillStyle = theme === 'dark' ? 'rgba(15, 23, 42, 0.9)' : 'rgba(255, 255, 255, 0.9)';
                ctx.beginPath();
                // @ts-ignore
                if (ctx.roundRect) {
                    // @ts-ignore
                    ctx.roundRect(midX - textWidth / 2 - 8, midY - 30, textWidth + 16, 24, 6);
                } else {
                    ctx.rect(midX - textWidth / 2 - 8, midY - 30, textWidth + 16, 24);
                }
                ctx.fill();

                ctx.fillStyle = theme === 'dark' ? '#F8FAFC' : '#0F172A';
                ctx.textAlign = 'center';
                ctx.fillText(label, midX, midY - 14);
            }
            ctx.restore();
        }

        needsRedraw.current = false;
        requestRef.current = requestAnimationFrame(render);
    }, [dxfData, visibleLayersSet, layerColors, selectedHandlesSet, currentTransform, theme, snapPoint, measurePoints, worldToCanvas]);

    useEffect(() => {
        requestRef.current = requestAnimationFrame(render);
        return () => {
            if (requestRef.current) cancelAnimationFrame(requestRef.current);
        };
    }, [render]);

    useEffect(() => {
        const resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                const { width, height } = entry.contentRect;
                if (canvasRef.current) {
                    canvasRef.current.width = width;
                    canvasRef.current.height = height;
                    dispatch(setCanvasSize({ width, height }));
                    needsRedraw.current = true;
                }
            }
        });
        if (containerRef.current) resizeObserver.observe(containerRef.current);
        return () => resizeObserver.disconnect();
    }, [dispatch]);

    const handleMouseMove = (e: React.MouseEvent) => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !currentTransform) return;

        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const worldPos = canvasToWorld(x, y);
        lastMouseWorldPos.current = worldPos;

        if (isDragging) {
            const dx = e.clientX - lastMousePos.x;
            const dy = e.clientY - lastMousePos.y;

            if (activeTool === 'block' && dragStartWorld) {
                // Just for visual preview, handled in render
            } else {
                dispatch(setPanOffset({ x: panOffset.x + dx, y: panOffset.y + dy }));
            }

            setLastMousePos({ x: e.clientX, y: e.clientY });
            needsRedraw.current = true;
        } else {
            const snapThreshold = 15 / currentTransform.scale;
            let bestSnap: any = null;
            let minDist = snapThreshold;

            (dxfData.entities as any[]).forEach(entity => {
                if (!visibleLayersSet.has(entity.layer)) return;
                const geom = entity.geometry;
                if (!geom) return;

                const addSnap = (pt: any, type: string) => {
                    const d = Math.sqrt((worldPos.x - pt.x) ** 2 + (worldPos.y - pt.y) ** 2);
                    if (d < minDist) {
                        minDist = d;
                        bestSnap = { ...pt, type };
                    }
                };

                if (geom.type === 'LINE') {
                    addSnap(geom.start, 'endpoint');
                    addSnap(geom.end, 'endpoint');
                    addSnap({ x: (geom.start.x + geom.end.x) / 2, y: (geom.start.y + geom.end.y) / 2 }, 'midpoint');
                } else if (geom.type === 'CIRCLE' || geom.type === 'ARC' || geom.type === 'ELLIPSE') {
                    addSnap(geom.center, 'center');
                } else if (geom.type === 'LWPOLYLINE' || geom.type === 'POLYLINE') {
                    if (geom.points) {
                        geom.points.forEach((p: any) => addSnap(p, 'endpoint'));
                        for (let i = 0; i < geom.points.length - 1; i++) {
                            addSnap({ x: (geom.points[i].x + geom.points[i + 1].x) / 2, y: (geom.points[i].y + geom.points[i + 1].y) / 2 }, 'midpoint');
                        }
                    }
                }
            });

            if (JSON.stringify(bestSnap) !== JSON.stringify(snapPoint)) {
                dispatch(setSnapPoint(bestSnap));
                needsRedraw.current = true;
            }
        }
    };

    const handleMouseDown = (e: React.MouseEvent) => {
        if (activeTool === 'pan' || e.button === 1) {
            setIsDragging(true);
            setLastMousePos({ x: e.clientX, y: e.clientY });
            return;
        }

        if (activeTool === 'block') {
            setIsDragging(true);
            setDragStartWorld(snapPoint || lastMouseWorldPos.current);
            setLastMousePos({ x: e.clientX, y: e.clientY });
            return;
        }

        const worldCoord = snapPoint || lastMouseWorldPos.current;

        if (activeTool === 'measure') {
            if (measurePoints.length === 0) {
                dispatch(addMeasurePoint(worldCoord));
            } else {
                dispatch(clearMeasure());
                dispatch(addMeasurePoint(worldCoord));
            }
            needsRedraw.current = true;
            return;
        }

        if (activeTool === 'select') {
            handleSelect(worldCoord, e.shiftKey);
        }
    };

    const handleMouseUp = () => {
        if (activeTool === 'block' && dragStartWorld && lastMouseWorldPos.current) {
            const endWorld = lastMouseWorldPos.current;
            const width = Math.abs(endWorld.x - dragStartWorld.x);
            const height = Math.abs(endWorld.y - dragStartWorld.y);

            if (width > 0.1 && height > 0.1) {
                dispatch(addBlockedArea({
                    x: Math.min(dragStartWorld.x, endWorld.x),
                    y: Math.min(dragStartWorld.y, endWorld.y),
                    width,
                    height
                }));
            }
        }
        setIsDragging(false);
        setDragStartWorld(null);
    };

    const handleWheel = (e: React.WheelEvent) => {
        const multiplier = 1.15;
        const direction = e.deltaY > 0 ? 1 / multiplier : multiplier;

        const canvas = canvasRef.current;
        if (!canvas) return;

        const newZoom = Math.min(Math.max(zoom * direction, 0.001), 5000);
        dispatch(setZoom(newZoom));
        needsRedraw.current = true;
    };

    const handleSelect = (worldCoord: { x: number; y: number }, isMulti = false) => {
        if (!dxfData || !worldCoord || !currentTransform) return;

        const { scale } = currentTransform;
        const thresholdWorld = 15 / scale;

        let closestEntity: any = null;
        let minDistance = thresholdWorld;

        (dxfData.entities as any[]).forEach(entity => {
            if (!visibleLayersSet.has(entity.layer)) return;
            const geom = entity.geometry;
            if (!geom) return;

            let dist = Infinity;
            if (geom.type === 'LINE') dist = distToSegment(worldCoord, geom.start, geom.end);
            else if (geom.type === 'CIRCLE' || geom.type === 'ARC') dist = Math.abs(Math.sqrt((worldCoord.x - geom.center.x) ** 2 + (worldCoord.y - geom.center.y) ** 2) - geom.radius);
            else if (geom.type === 'LWPOLYLINE' || geom.type === 'POLYLINE') {
                if (geom.points) {
                    for (let i = 0; i < geom.points.length - 1; i++) {
                        dist = Math.min(dist, distToSegment(worldCoord, geom.points[i], geom.points[i + 1]));
                    }
                }
            }

            if (dist < minDistance) {
                minDistance = dist;
                closestEntity = entity;
            }
        });

        if (isMulti) dispatch(toggleSelectedEntity(closestEntity));
        else dispatch(setSelectedEntity(closestEntity));
        needsRedraw.current = true;
    };

    function distToSegment(p: { x: number; y: number }, v: { x: number; y: number }, w: { x: number; y: number }) {
        const l2 = (v.x - w.x) ** 2 + (v.y - w.y) ** 2;
        if (l2 === 0) return Math.sqrt((p.x - v.x) ** 2 + (p.y - v.y) ** 2);
        let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        t = Math.max(0, Math.min(1, t));
        return Math.sqrt((p.x - (v.x + t * (w.x - v.x))) ** 2 + (p.y - (v.y + t * (w.y - v.y))) ** 2);
    }

    const fitToScreen = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !dxfData.extents) return;

        const { width: canvasWidth, height: canvasHeight } = canvas;
        const { width: worldWidth, height: worldHeight } = dxfData.extents;

        const margin = 80;
        const availableWidth = canvasWidth - margin * 2;
        const availableHeight = canvasHeight - margin * 2;

        if (availableWidth <= 0 || availableHeight <= 0) return;

        const scaleX = availableWidth / worldWidth;
        const scaleY = availableHeight / worldHeight;
        const newZoom = Math.min(scaleX, scaleY);

        dispatch(setZoom(newZoom));
        dispatch(setPanOffset({ x: 0, y: 0 }));
        needsRedraw.current = true;
    }, [dispatch, dxfData]);

    // Auto-fit on load
    useEffect(() => {
        if (dxfData && dxfData.extents) {
            const timer = setTimeout(() => {
                fitToScreen();
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [dxfData, fitToScreen]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'v') dispatch(setActiveTool('select'));
            if (e.key === 'h') dispatch(setActiveTool('pan'));
            if (e.key === 'm') dispatch(setActiveTool('measure'));
            if (e.key === 'Delete' || e.key === 'Backspace') {
                dispatch(deleteSelectedEntities());
            }
            if (e.key === 'Escape') {
                dispatch(setActiveTool('select'));
                dispatch(clearMeasure());
                dispatch(setSelectedEntity(null));
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [dispatch]);

    useEffect(() => {
        if (fitToScreenCounter > 0) {
            fitToScreen();
        }
    }, [fitToScreenCounter, fitToScreen]);

    return (
        <div ref={containerRef} className="w-full h-full overflow-hidden touch-none relative"
            style={{ backgroundColor: '#F8FAFC' }}>
            <canvas
                ref={canvasRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onWheel={handleWheel}
                className="block cursor-crosshair"
            />
            {!dxfData && (
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-zinc-400 font-medium bg-white/5 dark:bg-black/20 px-6 py-3 rounded-full backdrop-blur-sm border border-zinc-200/10">
                        Upload a DXF to start exploring
                    </div>
                </div>
            )}
        </div>
    );
};

export default Canvas;
