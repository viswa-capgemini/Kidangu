import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    MousePointer2,
    Square,
    Pencil,
    Minus,
    Spline,
    Circle,
    Type,
    ArrowUpRight,
    Copy,
    Grid3x3,
    Target,
    Scissors,
    FileText,
    Calendar,
    MessageSquare,
    Layers,
    ChevronDown,
    Maximize,
    GitBranch,
    Wrench,
    Trash2,
    Ban
} from 'lucide-react';
import { setActiveTool, triggerFitToScreen } from '../../../store/slices/uiSlice';
import { deleteSelectedEntities } from '../../../store/slices/dxfSlice';
import type { RootState } from '../../../store';

const Toolbar: React.FC = () => {
    const dispatch = useDispatch();
    const { activeTool } = useSelector((state: RootState) => state.ui);
    const [localActive, setLocalActive] = useState('pointer');

    const handleToolClick = (label: string, reduxAction: string | null = null) => {
        setLocalActive(label);
        if (reduxAction === 'fit') {
            dispatch(triggerFitToScreen());
        } else if (reduxAction === 'delete') {
            dispatch(deleteSelectedEntities());
        } else if (reduxAction) {
            dispatch(setActiveTool(reduxAction));
        }
    };

    const toolGroups = [
        {
            tools: [
                { icon: MousePointer2, label: 'pointer', reduxAction: 'select' },
                { icon: Square, label: 'frame' },
                { icon: Pencil, label: 'pen', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: GitBranch, label: 'branch' },
                { icon: Spline, label: 'curve', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: Wrench, label: 'connector' },
                { icon: Circle, label: 'circle' },
            ]
        },
        {
            tools: [
                { icon: Minus, label: 'line' },
                { icon: Type, label: 'text' },
                { icon: ArrowUpRight, label: 'arrow', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: Copy, label: 'duplicate' },
                { icon: Grid3x3, label: 'grid' },
                { icon: Target, label: 'target', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: Spline, label: 'path' },
                { icon: Scissors, label: 'scissors', reduxAction: 'measure' },
                { icon: Target, label: 'focus' },
            ]
        },
        {
            tools: [
                { icon: FileText, label: 'file', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: Calendar, label: 'calendar', hasDropdown: true },
            ]
        },
        {
            tools: [
                { icon: Maximize, label: 'fit', reduxAction: 'fit' },
                { icon: Ban, label: 'block area', reduxAction: 'block' },
                { icon: Trash2, label: 'delete selection', reduxAction: 'delete' },
                { icon: MessageSquare, label: 'comment' },
                { icon: Layers, label: 'layers', hasDropdown: true },
            ]
        },
    ];

    const firstRowGroups = toolGroups.slice(0, 4);
    const secondRowGroups = toolGroups.slice(4);

    return (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md rounded-2xl border border-gray-200 dark:border-zinc-700 shadow-2xl z-50 p-2 min-w-[320px]">
            <div className="flex flex-col gap-2">
                {/* First Row */}
                <div className="flex items-center justify-center gap-1 px-2">
                    {firstRowGroups.map((group, groupIndex) => (
                        <div key={groupIndex} className="flex items-center">
                            <div className="flex items-center gap-0.5">
                                {group.tools.map((tool, toolIndex) => {
                                    const Icon = tool.icon;
                                    const isActive = localActive === tool.label ||
                                        (tool.reduxAction && activeTool === tool.reduxAction);

                                    return (
                                        <div key={toolIndex} className="relative">
                                            <button
                                                onClick={() => handleToolClick(tool.label, tool.reduxAction)}
                                                className={`p-2 rounded-lg transition-all relative group ${isActive
                                                    ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 scale-105 shadow-sm'
                                                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-800'
                                                    }`}
                                                title={tool.label}
                                            >
                                                <Icon className="w-5 h-5" strokeWidth={1.5} />
                                            </button>
                                            {tool.hasDropdown && (
                                                <ChevronDown className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-3 h-3 text-gray-400" strokeWidth={2} />
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                            {groupIndex < firstRowGroups.length - 1 && (
                                <div className="w-px h-6 bg-gray-200 dark:bg-zinc-700 mx-2" />
                            )}
                        </div>
                    ))}
                </div>

                {/* Row Divider */}
                <div className="h-px bg-gray-100 dark:bg-zinc-800 mx-2" />

                {/* Second Row */}
                <div className="flex items-center justify-center gap-1 px-2">
                    {secondRowGroups.map((group, groupIndex) => (
                        <div key={groupIndex} className="flex items-center">
                            <div className="flex items-center gap-0.5">
                                {group.tools.map((tool, toolIndex) => {
                                    const Icon = tool.icon;
                                    const isActive = localActive === tool.label ||
                                        (tool.reduxAction && activeTool === tool.reduxAction);

                                    return (
                                        <div key={toolIndex} className="relative">
                                            <button
                                                onClick={() => handleToolClick(tool.label, tool.reduxAction)}
                                                className={`p-2 rounded-lg transition-all relative group ${isActive
                                                    ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 scale-105 shadow-sm'
                                                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-800'
                                                    }`}
                                                title={tool.label}
                                            >
                                                <Icon className="w-5 h-5" strokeWidth={1.5} />
                                            </button>
                                            {tool.hasDropdown && (
                                                <ChevronDown className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-3 h-3 text-gray-400" strokeWidth={2} />
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                            {groupIndex < secondRowGroups.length - 1 && (
                                <div className="w-px h-6 bg-gray-200 dark:bg-zinc-700 mx-2" />
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Toolbar;
