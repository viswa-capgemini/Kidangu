import { useDxf } from '../../context/DxfContext';

export default function MetadataPanel() {
    const { state } = useDxf();
    const { dxfData } = state;

    if (!dxfData) return null;

    const { metadata, extents, total_entities, total_layers, entity_types, total_blocks, linetypes } = dxfData;

    // Sort entity types by count
    const sortedEntityTypes = Object.entries(entity_types)
        .sort((a, b) => b[1] - a[1]);

    return (
        <div className="w-80 bg-[var(--color-surface)] border-r border-[var(--color-border)] 
      flex flex-col h-full overflow-hidden">

            {/* Header */}
            <div className="p-4 border-b border-[var(--color-border)]">
                <h2 className="text-lg font-semibold text-[var(--color-text-primary)]">
                    File Information
                </h2>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6">

                {/* File Metadata */}
                <Section title="📄 File Details">
                    <PropertyRow label="Filename" value={metadata.filename} />
                    <PropertyRow label="DXF Version" value={metadata.dxf_version_name} />
                    <PropertyRow label="Version Code" value={metadata.dxf_version} />
                    <PropertyRow label="Created By" value={metadata.created_by || 'Unknown'} />
                    <PropertyRow label="File Size" value={metadata.file_size_formatted} />
                    <PropertyRow label="Units" value={metadata.units || 'Not specified'} />
                </Section>

                {/* Statistics */}
                <Section title="📊 Statistics">
                    <div className="grid grid-cols-2 gap-3">
                        <StatCard label="Layers" value={total_layers} color="var(--color-primary)" />
                        <StatCard label="Entities" value={total_entities.toLocaleString()} color="var(--color-secondary)" />
                        <StatCard label="Blocks" value={total_blocks} color="var(--color-success)" />
                        <StatCard label="Linetypes" value={linetypes.length} color="var(--color-info)" />
                    </div>
                </Section>

                {/* Extents */}
                {extents && (
                    <Section title="📐 Drawing Extents">
                        <PropertyRow label="Width" value={`${extents.width.toFixed(2)} units`} />
                        <PropertyRow label="Height" value={`${extents.height.toFixed(2)} units`} />
                        <PropertyRow label="Min X" value={extents.min_x.toFixed(2)} />
                        <PropertyRow label="Max X" value={extents.max_x.toFixed(2)} />
                        <PropertyRow label="Min Y" value={extents.min_y.toFixed(2)} />
                        <PropertyRow label="Max Y" value={extents.max_y.toFixed(2)} />
                    </Section>
                )}

                {/* Entity Types */}
                <Section title="🔧 Entity Types">
                    <div className="space-y-2">
                        {sortedEntityTypes.map(([type, count]) => (
                            <div key={type} className="flex justify-between items-center">
                                <span className="text-sm text-[var(--color-text-secondary)]">{type}</span>
                                <span className="text-sm font-mono text-[var(--color-text-primary)]">
                                    {count.toLocaleString()}
                                </span>
                            </div>
                        ))}
                    </div>
                </Section>

                {/* Linetypes */}
                {linetypes.length > 0 && (
                    <Section title="〰️ Linetypes">
                        <div className="space-y-1">
                            {linetypes.slice(0, 10).map((lt) => (
                                <div key={lt.name} className="text-sm">
                                    <span className="text-[var(--color-text-secondary)]">{lt.name}</span>
                                    {lt.description && (
                                        <span className="text-[var(--color-text-muted)] text-xs ml-2">
                                            {lt.description}
                                        </span>
                                    )}
                                </div>
                            ))}
                            {linetypes.length > 10 && (
                                <div className="text-xs text-[var(--color-text-muted)]">
                                    +{linetypes.length - 10} more...
                                </div>
                            )}
                        </div>
                    </Section>
                )}
            </div>
        </div>
    );
}

function Section({ title, children }) {
    return (
        <div>
            <h3 className="text-sm font-semibold text-[var(--color-text-primary)] mb-3">
                {title}
            </h3>
            {children}
        </div>
    );
}

function PropertyRow({ label, value }) {
    return (
        <div className="flex justify-between py-1.5 border-b border-[var(--color-border)]/50 last:border-0">
            <span className="text-sm text-[var(--color-text-muted)]">{label}</span>
            <span className="text-sm text-[var(--color-text-secondary)] font-mono truncate ml-4 max-w-[180px]">
                {value}
            </span>
        </div>
    );
}

function StatCard({ label, value, color }) {
    return (
        <div className="p-3 rounded-lg bg-[var(--color-background)] border border-[var(--color-border)]">
            <div className="text-2xl font-bold" style={{ color }}>{value}</div>
            <div className="text-xs text-[var(--color-text-muted)]">{label}</div>
        </div>
    );
}
