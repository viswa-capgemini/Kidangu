import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    Layers,
    BarChart3,
    Eye,
    EyeOff,
    Lock,
    Snowflake,
    Search,
    ChevronDown,
    ChevronRight,
    Database
} from 'lucide-react';
import { toggleLayerVisibility, setAllLayersVisibility, setSelectedLayer } from '../../../store/slices/dxfSlice';
import type { RootState } from '../../../store';

const Explorer: React.FC = () => {
    const dispatch = useDispatch();
    const { data: dxfData, visibleLayers, selectedLayer } = useSelector((state: RootState) => state.dxf);
    const [searchTerm, setSearchTerm] = useState('');
    const [expandedSection, setExpandedSection] = useState<string | null>('layers');

    if (!dxfData) return null;

    const filteredLayers = (dxfData.layers as any[]).filter(layer =>
        layer.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="h-full flex flex-col fade-in">
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2 font-semibold text-gray-800">
                <Database size={18} className="text-company-purple" />
                <span>Explorer</span>
            </div>

            <div className="flex-1 overflow-y-auto">
                {/* Statistics Section */}
                <div className="border-b border-zinc-100 dark:border-zinc-800/50">
                    <button
                        className="w-full flex items-center justify-between p-4 py-3 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 transition-colors"
                        onClick={() => setExpandedSection(expandedSection === 'stats' ? null : 'stats')}
                    >
                        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gray-500">
                            <BarChart3 size={14} />
                            <span>Statistics</span>
                        </div>
                        {expandedSection === 'stats' ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>

                    {expandedSection === 'stats' && (
                        <div className="p-4 pt-0 space-y-3 slide-up text-gray-700">
                            <StatRow label="DXF Version" value={dxfData.metadata?.dxf_version_name || 'N/A'} />
                            <StatRow label="File Size" value={dxfData.metadata?.file_size_formatted || 'N/A'} />
                            <StatRow label="Total Layers" value={dxfData.total_layers} />
                            <StatRow label="Total Entities" value={dxfData.total_entities} />
                            <div className="pt-2">
                                <p className="text-[10px] font-bold text-gray-500 uppercase mb-2">Entity Breakdown</p>
                                <div className="grid grid-cols-2 gap-2">
                                    {Object.entries(dxfData.entity_types || {}).map(([type, count]) => (
                                        <div key={type} className="bg-zinc-100 dark:bg-zinc-900 p-2 rounded text-[11px] flex justify-between">
                                            <span className="opacity-70">{type}</span>
                                            <span className="font-bold">{count as number}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Layers Section */}
                <div className="flex-1">
                    <button
                        className="w-full flex items-center justify-between p-4 py-3 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 transition-colors"
                        onClick={() => setExpandedSection(expandedSection === 'layers' ? null : 'layers')}
                    >
                        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gray-500">
                            <Layers size={14} />
                            <span>Layers ({dxfData.total_layers})</span>
                        </div>
                        {expandedSection === 'layers' ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>

                    {expandedSection === 'layers' && (
                        <div className="flex flex-col h-full overflow-hidden">
                            <div className="px-4 mb-2">
                                <div className="relative">
                                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-400" size={12} />
                                    <input
                                        type="text"
                                        placeholder="Search layers..."
                                        className="w-full bg-zinc-100 dark:bg-zinc-900 border-none rounded-md py-1.5 pl-8 pr-2 text-xs focus:ring-1 focus:ring-brand"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>

                                <div className="flex justify-between mt-3 text-[10px] font-bold text-gray-500 uppercase px-1">
                                    <button onClick={() => dispatch(setAllLayersVisibility(true))} className="hover:text-company-purple transition-colors">Show All</button>
                                    <button onClick={() => dispatch(setAllLayersVisibility(false))} className="hover:text-company-purple transition-colors">Hide All</button>
                                </div>
                            </div>

                            <div className="overflow-y-auto px-2 space-y-0.5 max-h-[400px]">
                                {filteredLayers.map((layer) => (
                                    <div
                                        key={layer.name}
                                        onClick={() => dispatch(setSelectedLayer(layer))}
                                        className={`
                      group flex items-center gap-2 p-1.5 px-2 rounded-md cursor-pointer transition-all duration-150
                      ${selectedLayer?.name === layer.name
                                                ? 'bg-company-purple/10 text-company-purple'
                                                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
                                            }
                    `}
                                    >
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                dispatch(toggleLayerVisibility(layer.name));
                                            }}
                                            className="transition-colors hover:text-company-purple"
                                        >
                                            {visibleLayers.includes(layer.name) ? <Eye size={14} /> : <EyeOff size={14} className="opacity-30" />}
                                        </button>

                                        <div
                                            className="w-2.5 h-2.5 rounded-sm border border-black/10 shrink-0"
                                            style={{ backgroundColor: layer.rgb_color }}
                                        />

                                        <span className="flex-1 truncate text-xs font-medium">
                                            {layer.name}
                                        </span>

                                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                            {layer.is_locked && <Lock size={10} className="text-gray-500" />}
                                            {layer.is_frozen && <Snowflake size={10} className="text-gray-500" />}
                                            <span className="text-[10px] text-gray-500 font-mono bg-zinc-100 dark:bg-zinc-900 px-1 rounded">
                                                {layer.entity_count}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const StatRow: React.FC<{ label: string; value: any }> = ({ label, value }) => (
    <div className="flex justify-between items-center text-[11px]">
        <span className="text-gray-500">{label}</span>
        <span className="font-bold">{value}</span>
    </div>
);

export default Explorer;
