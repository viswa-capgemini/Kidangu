import React, { useEffect, useState, useRef } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { theme } from "../../theme";
import { 
  Box, 
  Badge,
  Typography, 
  Button, 
  TextField, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Checkbox, 
  IconButton, 
  Chip, 
  Pagination, 
  Drawer, 
  Tabs, 
  Tab, 
  Stepper, 
  Step, 
  StepLabel, 
  FormControlLabel, 
  Select, 
  MenuItem, 
  InputAdornment,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  CircularProgress,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { fetchProducts, deleteProduct } from '../api/productService';
import { ModelPreviewDrawer } from '../ModelPreviewDrawer';
import { useSnackbar } from 'notistack'; // Optional, for notifications
import { DataGrid } from '@mui/x-data-grid';
import type {GridRowsProp, GridColDef} from '@mui/x-data-grid';

// Material UI Icons
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import BuildIcon from '@mui/icons-material/Build';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ClearAllIcon from '@mui/icons-material/ClearAll';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import GridOnIcon from '@mui/icons-material/GridOn';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import CloseIcon from '@mui/icons-material/Close';
import SettingsIcon from '@mui/icons-material/Settings';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import PreviewIcon from '@mui/icons-material/Preview';
import RefreshIcon from '@mui/icons-material/Refresh';
import { useNavigate } from 'react-router-dom';

// Define interfaces for styled components props
interface DropzoneAreaProps {
  isDragging: boolean;
  hasFile: boolean;
}

// Define interfaces for data structures
interface InventoryItem {
  id: number;
  p_id: string;
  name: string;
  type: string;
  size: string;
  cost: number;
  uploaded_date: string;
  person: string;
  revised_date: string;
}

interface ListItem {
  name: string;
  count: number;
  description?: string;
}

interface Category {
  name: string;
  count: number;
}

//data-grid columns
const columns: GridColDef[] = [
  { field: 'p_id', headerName: 'PRODUCT ID', width: 140 },
  { field: 'p_name', headerName: 'PRODUCT NAME', width: 160 },
  { field: 'p_group', headerName: 'PRODUCT GROUP', width: 170 },
  { field: 'category', headerName: 'CATEGORY', width: 140 },
  { field: 'c_type', headerName: 'COMPONENT TYPE', width: 170 },
  { field: 'up_date', headerName: 'UPLOADED DATE', width: 160 },
  { field: 'last_revised', headerName: 'LAST REVISED', width: 140 },
  { field: 'preview', headerName: 'PREVIEW', width: 140 },
  { field: 'actions', headerName: 'ACTIONS', width: 140 },
];

//data-grid rows 

export const rows: GridRowsProp = [
  {
    id: 1,
    p_id: 'P-001',
    p_name: 'Widget A',
    p_group: 'Group 1',
    category: 'Electrical',
    c_type: 'Type X',
    up_date: '2025-10-01',
    last_revised: '2025-12-01',
    preview: 'View',
    actions: 'Edit',
  },
  {
    id: 2,
    p_id: 'P-002',
    p_name: 'Gizmo B',
    p_group: 'Group 2',
    category: 'Mechanical',
    c_type: 'Type Y',
    up_date: '2025-10-05',
    last_revised: '2025-11-20',
    preview: 'View',
    actions: 'Edit',
  },
  
  {
    id: 3,
    p_id: 'P-003',
    p_name: 'Module C',
    p_group: 'Group 1',
    category: 'Software',
    c_type: 'Type Z',
    up_date: '2025-09-15',
    last_revised: '2025-10-30',
    preview: 'View',
    actions: 'Edit',
  },
];


// Custom styled components
const HeaderContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: theme.spacing(1, 3),
  backgroundColor: '#fff',
  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  position: 'sticky',
  top: 0,
  zIndex: 100,
}));

const LogoContainer = styled(Box)({
  display: 'flex',
  alignItems: 'center',
});

const Logo = styled('img')({
  height: 40,
});

const UserControls = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  gap: 16,
});

const MainContainer = styled(Box)({
  display: 'flex',
  height: 'calc(100vh - 64px)',
});

const SidebarContainer = styled(Box)(({ theme }) => ({
  width: 280,
  borderRight: `1px solid ${theme.palette.divider}`,
  overflowY: 'auto',
  backgroundColor: '#f8f9fa',
}));

const ContentContainer = styled(Box)({
  flex: 1,
  overflowY: 'auto',
  padding: 24,
});

const ContentHeader = styled(Box)({
  marginBottom: 24,
});

const ActionBar = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  marginBottom: theme.spacing(3),
}));

const SearchField = styled(TextField)({
  minWidth: 300,
});

const StyledTableContainer = styled(TableContainer)({
  marginBottom: 24,
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  borderRadius: 8,
});

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontWeight: 500,
}));

const PaginationContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  padding: '16px 0',
});

const DropzoneArea = styled(Box)<DropzoneAreaProps>(({ theme, isDragging, hasFile }) => ({
  border: `2px dashed ${isDragging ? theme.palette.primary.main : hasFile ? theme.palette.success.main : theme.palette.divider}`,
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(4),
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: isDragging ? 'rgba(25, 118, 210, 0.04)' : hasFile ? 'rgba(76, 175, 80, 0.04)' : 'transparent',
  cursor: 'pointer',
  transition: 'all 0.2s ease',
  minHeight: 200,
}));

const ModelCanvas = styled(Box)({
  width: '100%',
  height: 400,
  backgroundColor: '#f0f0f0',
  borderRadius: 8,
  overflow: 'hidden',
  position: 'relative',
});

const ModelControls = styled(Box)({
  position: 'absolute',
  bottom: 16,
  right: 16,
  display: 'flex',
  gap: 8,
  backgroundColor: 'rgba(255,255,255,0.7)',
  borderRadius: 24,
  padding: '4px 8px',
});

interface ColorOptionProps {
  active?: boolean;
}

const ColorOption = styled(Box)<ColorOptionProps>(({ theme, active }) => ({
  width: 32,
  height: 32,
  borderRadius: '50%',
  cursor: 'pointer',
  border: active ? `2px solid ${theme.palette.primary.main}` : '2px solid transparent',
  '&:hover': {
    transform: 'scale(1.1)',
  },
}));

const StepContent = styled(Box)({
  padding: '24px 0',
});

const MasterInventory: React.FC = () => {
  const [inventoryItems, setInventoryItems] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState<boolean>(false);
  const [activeList, setActiveList] = useState<string>('All Contacts');
  const [modalVisibleOne, setModalVisibleOne] = useState<boolean>(false);
  const [productGroupsOpen, setProductGroupsOpen] = useState<boolean>(true);
  const [componentCategoryOpen, setComponentCategoryOpen] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [modalConfigVisible, setModalConfigVisible] = useState<boolean>(false);
  const [activeConfigTab, setActiveConfigTab] = useState<number>(0);
  const [newItemName, setNewItemName] = useState<string>('');
  const [previewModel, setPreviewModel] = useState<{ url: string; name: string } | null>(null);
  const { enqueueSnackbar } = useSnackbar(); // Optional, for notifications

  const navigate = useNavigate();

  // File upload state and refs
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedSubcategories, setSelectedSubcategories] = useState<string[]>([]);
  const subcategories: string[] = [
    'Selective Pallet Racking',
    'Single-Tier Shelving',
    'Multi-Tier Shelving',
    'Mezzanine',
    'Shuttle Pallet Racking',
    'Altius Single-Tier',
    'Altius Multi-Tier'
  ];

  const [selectedComponentCategories, setSelectedComponentCategories] = useState<string[]>([]);
  const componentCategories: string[] = [
    'Frames',
    'Beams',
    'Decking',
    'Accessories',
    'Safety Equipment',
    'Shelving Units',
    'Support Structures'
  ];

  // Function to load products from DynamoDB
  const loadProducts = async () => {
    setLoading(true);
    try {
      const result = await fetchProducts();
      if (result.success && result.products) {
        setInventoryItems(result.products);
        
        // Calculate total pages based on products count
        const itemsPerPage = 10; // Adjust as needed
        setTotalPages(Math.ceil(result.products.length / itemsPerPage));
      } else {
        console.error('Failed to load products:', result.error);
        enqueueSnackbar?.('Failed to load products', { variant: 'error' });
      }
    } catch (error) {
      console.error('Error loading products:', error);
      enqueueSnackbar?.('Error loading products', { variant: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // Function to handle product deletion
  const handleDeleteProduct = async (productId: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        const result = await deleteProduct(productId);
        if (result.success) {
          enqueueSnackbar?.('Product deleted successfully', { variant: 'success' });
          // Reload products after deletion
          loadProducts();
        } else {
          enqueueSnackbar?.(`Failed to delete product: ${result.error}`, { variant: 'error' });
        }
      } catch (error) {
        console.error('Error deleting product:', error);
        enqueueSnackbar?.('Error deleting product', { variant: 'error' });
      }
    }
  };

  // Function to handle preview
  const handlePreviewModel = (url: string, name: string) => {
    setPreviewModel({ url, name });
  };

  // Load products when component mounts
  useEffect(() => {
    loadProducts();
  }, []);

  // Your existing functions...
  const handleModalVisible = () => {
    navigate('/product-upload');
    // setModalVisibleOne(true);
  };

  const handleModalVisibleClose = () => {
    setModalVisibleOne(false);
    setCurrentStep(1); // Reset to first step when closing modal
  };

  // Handler for opening/closing the config modal
  const handleConfigVisible = () => {
    setModalConfigVisible(true);
  };

  const handleConfigVisibleClose = () => {
    setModalConfigVisible(false);
    setNewItemName('');
  };

  // Handler for changing tabs
  const handleConfigTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveConfigTab(newValue);
    setNewItemName('');
  };

  // Handler for adding new items
  const handleAddNewItem = (type: string) => {
    if (!newItemName.trim()) {
      alert('Please enter a name');
      return;
    }
    
    // Here you would add the new item to your data structure
    console.log(`Added new ${type}: ${newItemName}`);
    setNewItemName('');
  };

  // Handlers for subcategories
  const handleSubcategoryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (e.target.checked) {
      setSelectedSubcategories([...selectedSubcategories, value]);
    } else {
      setSelectedSubcategories(selectedSubcategories.filter(item => item !== value));
    }
  };

  const handleSelectAllPG = () => {
    setSelectedSubcategories([...subcategories]);
  };

  const handleClearAll = () => {
    setSelectedSubcategories([]);
  };

  // Handlers for component categories
  const handleComponentCategoryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (e.target.checked) {
      setSelectedComponentCategories([...selectedComponentCategories, value]);
    } else {
      setSelectedComponentCategories(selectedComponentCategories.filter(item => item !== value));
    }
  };

  const handleSelectAllComponents = () => {
    setSelectedComponentCategories([...componentCategories]);
  };

  const handleClearAllComponents = () => {
    setSelectedComponentCategories([]);
  };

  // Handle pagination
  const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
    // In a real app, you would fetch the data for the selected page
  };

  // Handle checkbox selection
  const handleSelectItem = (id: string) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter(itemId => itemId !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  // Handle select all
  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedItems([]);
    } else {
      setSelectedItems(inventoryItems.map(item => item.product_id));
    }
    setSelectAll(!selectAll);
  };

  // Handle list selection
  const handleListSelect = (listName: string) => {
    setActiveList(listName);
    // In a real app, you would filter the data based on the selected list
  };

  // File upload handlers
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      validateAndSetFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      validateAndSetFile(file);
    }
  };

  const validateAndSetFile = (file: File) => {
    // Check file type
    const fileName = file.name.toLowerCase();
    const isGlbOrGltf = fileName.endsWith('.glb') || fileName.endsWith('.gltf');

    if (!isGlbOrGltf) {
      alert('Please select a 3D model file (.glb or .gltf format)');
      return;
    }

    // Check file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      alert('File size exceeds 10MB limit');
      return;
    }

    setSelectedFile(file);
  };

  const handleRemoveFile = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Helper function to format file size
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  const handleNextStep = () => {
    setCurrentStep(currentStep + 1);
  };

  const handlePreviousStep = () => {
    setCurrentStep(currentStep - 1);
  };

  // Config tabs
  const configTabs = [
    'Structural Components',
    'Rack Components',
    'Level Accessories',
    'Civil Layout',
    'MHE',
    'SKU',
    'Catwalk'
  ];

  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ display: "flex", minHeight: 0, overflow: "hidden", flexDirection: "column", height: "100vh" }}>
        {/* Main Content */}
        <MainContainer>
          {/* Content Area */}
          <ContentContainer>
            <ContentHeader>
              <Typography variant="h4" gutterBottom sx={{color: '#810055'}}>
                Master Inventory
              </Typography>
              <Typography variant="subtitle1" color="text.secondary">
                {inventoryItems.length} products
              </Typography>
            </ContentHeader>

            {/* Action Bar */}
            <ActionBar>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Button
                  variant="outlined"
                  startIcon={<CloudUploadIcon />}
                  onClick={handleModalVisible}
                  sx={{
                    color: "#810055", // Text color
                    borderColor: "#810055", // Border color
                    "&:hover": {
                      backgroundColor: "#810055",
                      color: "#fff",
                    },
                  }}
                >
                  Add
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<SettingsIcon />}
                  onClick={handleConfigVisible}
                  sx={{
                    color: "#810055", // Text color
                    borderColor: "#810055", // Border color
                    "&:hover": {
                      backgroundColor: "#810055",
                      color: "#fff",
                    },
                  }}
                >
                  Catalog Setup
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<FilterListIcon />}
                  sx={{
                    color: "#810055", // Text color
                    borderColor: "#810055", // Border color
                    "&:hover": {
                      backgroundColor: "#810055",
                      color: "#fff",
                    },
                  }}
                >
                  Filter
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<RefreshIcon />}
                  onClick={loadProducts}
                  disabled={loading}
                  sx={{
                    color: "#810055", // Text color
                    borderColor: "#810055", // Border color
                    "&:hover": {
                      backgroundColor: "#810055",
                      color: "#fff",
                    },
                  }}
                >
                  Refresh
                </Button>
                <SearchField
                  placeholder="Search"
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </ActionBar>

            <Paper sx={{ width: "100%" }}>
              <DataGrid
                rows={rows}
                columns={columns}
                checkboxSelection
                // autoHeight
                sx={{
                  // prevent any accidental horizontal scrollbar
                  "& .MuiDataGrid-virtualScroller": { overflowX: "hidden" },
                }}
              />
            </Paper>

            {/* Pagination */}
            <PaginationContainer>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={handlePageChange}
                color="primary"
                showFirstButton
                showLastButton
              />
            </PaginationContainer>
          </ContentContainer>
        </MainContainer>

        {/* Add Models Modal */}
        <Dialog
          open={modalVisibleOne}
          onClose={handleModalVisibleClose}
          fullWidth
          maxWidth="lg"
        >
          <DialogTitle>
            {/* Stepper Header */}
            <Stepper activeStep={currentStep - 1} alternativeLabel>
              <Step>
                <StepLabel>Select Category & Upload Model</StepLabel>
              </Step>
              <Step>
                <StepLabel>Product Details</StepLabel>
              </Step>
              <Step>
                <StepLabel>Review & Submit</StepLabel>
              </Step>
            </Stepper>
          </DialogTitle>
          <DialogContent dividers>
            {/* Step 1: Category Selection & File Upload */}
            {currentStep === 1 && (
              <StepContent>
                <Typography variant="h6" gutterBottom>
                  Select Product Category
                </Typography>

                <Box
                  sx={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr 1fr",
                    gap: 3,
                  }}
                >
                  {/* Column 1 - Categories List */}
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Structural Components
                    </Typography>
                    <List dense>
                      {[
                        { name: "Rack Components", count: 24 },
                        { name: "Rack Sample Assembly", count: 18 },
                        { name: "Level Accessories", count: 32 },
                        { name: "Rack Accessories", count: 15 },
                        { name: "Layout Accessories(Civil)", count: 27 },
                        { name: "Material Handling Equipment(MHE)", count: 12 },
                        { name: "Stock Keeping Unit(SKU)", count: 21 },
                        { name: "Catwalk Accessories", count: 21 },
                        { name: "Advanced Options", count: 21 },
                      ].map((category, index) => (
                        <ListItem
                          key={index}
                          component="button"
                          sx={{
                            borderRadius: 1,
                            width: "100%",
                            textAlign: "left",
                          }}
                        >
                          <ListItemText
                            primary={category.name}
                            secondary={`${category.count} products`}
                          />
                        </ListItem>
                      ))}
                    </List>
                  </Paper>

                  {/* Column 2 - Accordions with Checkboxes */}
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    {/* First Accordion - Product Groups */}
                    <Accordion
                      expanded={productGroupsOpen}
                      onChange={() => setProductGroupsOpen(!productGroupsOpen)}
                    >
                      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography>Select Product Groups</Typography>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 1,
                          }}
                        >
                          {subcategories.map((subcategory) => (
                            <FormControlLabel
                              key={subcategory}
                              control={
                                <Checkbox
                                  checked={selectedSubcategories.includes(
                                    subcategory
                                  )}
                                  onChange={handleSubcategoryChange}
                                  value={subcategory}
                                  size="small"
                                />
                              }
                              label={subcategory}
                            />
                          ))}
                          <Box
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                              mt: 1,
                            }}
                          >
                            <Button
                              size="small"
                              onClick={handleSelectAllPG}
                              startIcon={<CheckCircleIcon />}
                              sx={{ color: "primary.main" }}
                            >
                              Select All
                            </Button>
                            <Button
                              size="small"
                              onClick={handleClearAll}
                              startIcon={<ClearAllIcon />}
                              sx={{ color: "warning.main" }}
                            >
                              Clear All
                            </Button>
                          </Box>
                        </Box>
                      </AccordionDetails>
                    </Accordion>

                    {/* Second Accordion - Component Category */}
                    <Accordion
                      expanded={componentCategoryOpen}
                      onChange={() =>
                        setComponentCategoryOpen(!componentCategoryOpen)
                      }
                    >
                      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography>Select Component Category</Typography>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 1,
                          }}
                        >
                          {componentCategories.map((category) => (
                            <FormControlLabel
                              key={category}
                              control={
                                <Checkbox
                                  checked={selectedComponentCategories.includes(
                                    category
                                  )}
                                  onChange={handleComponentCategoryChange}
                                  value={category}
                                  size="small"
                                />
                              }
                              label={category}
                            />
                          ))}
                          <Box
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                              mt: 1,
                            }}
                          >
                            <Button
                              size="small"
                              onClick={handleSelectAllComponents}
                              startIcon={<CheckCircleIcon />}
                              sx={{ color: "primary.main" }}
                            >
                              Select All
                            </Button>
                            <Button
                              size="small"
                              onClick={handleClearAllComponents}
                              startIcon={<ClearAllIcon />}
                              sx={{ color: "warning.main" }}
                            >
                              Clear All
                            </Button>
                          </Box>
                        </Box>
                      </AccordionDetails>
                    </Accordion>
                  </Paper>

                  {/* Column 3 - File Upload */}
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Upload 3D Model
                    </Typography>
                    <DropzoneArea
                      isDragging={isDragging}
                      hasFile={!!selectedFile}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                    >
                      ```tsx
                      {!selectedFile ? (
                        <>
                          <CloudUploadIcon
                            sx={{ fontSize: 48, color: "primary.main", mb: 2 }}
                          />
                          <Typography variant="body1" align="center">
                            Drag & drop your 3D model here or{" "}
                            <Box
                              component="span"
                              sx={{ color: "primary.main", fontWeight: "bold" }}
                            >
                              browse
                            </Box>
                          </Typography>
                          <Typography
                            variant="caption"
                            color="text.secondary"
                            align="center"
                            sx={{ mt: 1 }}
                          >
                            Supported formats: .glb, .gltf
                          </Typography>
                        </>
                      ) : (
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                          }}
                        >
                          <Box sx={{ mr: 2, color: "primary.main" }}>
                            <Box component="span" sx={{ fontSize: 40 }}>
                              📦
                            </Box>
                          </Box>
                          <Box sx={{ flex: 1 }}>
                            <Typography variant="body2" noWrap>
                              {selectedFile.name}
                            </Typography>
                            <Typography
                              variant="caption"
                              color="text.secondary"
                            >
                              {formatFileSize(selectedFile.size)}
                            </Typography>
                          </Box>
                          <IconButton
                            size="small"
                            onClick={handleRemoveFile}
                            color="error"
                          >
                            <CloseIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      )}
                      <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: "none" }}
                        accept=".glb,.gltf"
                        onChange={handleFileChange}
                      />
                    </DropzoneArea>

                    {selectedFile && (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "flex-end",
                          gap: 1,
                          mt: 2,
                        }}
                      >
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={handleRemoveFile}
                        >
                          Remove
                        </Button>
                        <Button variant="contained" size="small">
                          Upload
                        </Button>
                      </Box>
                    )}

                    <Box sx={{ mt: 3 }}>
                      <Typography variant="subtitle2" gutterBottom>
                        Instructions
                      </Typography>
                      <List dense>
                        <ListItem>
                          <ListItemText primary="Upload 3D model files in GLB or GLTF format" />
                        </ListItem>
                        <ListItem>
                          <ListItemText primary="Maximum file size: 10MB" />
                        </ListItem>
                        <ListItem>
                          <ListItemText primary="Textures should be embedded in the file" />
                        </ListItem>
                      </List>
                    </Box>
                  </Paper>
                </Box>
              </StepContent>
            )}

            {/* Step 2: Product Details & 3D Model Preview */}
            {currentStep === 2 && (
              <StepContent>
                <Typography variant="h6" gutterBottom>
                  Product Details & 3D Model Preview
                </Typography>

                <Box
                  sx={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 3,
                  }}
                >
                  {/* 3D Model Viewer */}
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <ModelCanvas id="model-canvas">
                      {!selectedFile && (
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            height: "100%",
                            color: "text.secondary",
                          }}
                        >
                          <Box component="span" sx={{ fontSize: 60, mb: 2 }}>
                            📦
                          </Box>
                          <Typography>No 3D model available</Typography>
                          <Button
                            variant="outlined"
                            size="small"
                            onClick={() => setCurrentStep(1)}
                            sx={{ mt: 2 }}
                          >
                            Go Back to Upload
                          </Button>
                        </Box>
                      )}
                    </ModelCanvas>
                    <ModelControls>
                      <IconButton size="small" data-action="zoom-in">
                        <ZoomInIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" data-action="zoom-out">
                        <ZoomOutIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" data-action="reset-view">
                        <RestartAltIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" data-action="toggle-wireframe">
                        <GridOnIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" data-action="fullscreen">
                        <FullscreenIcon fontSize="small" />
                      </IconButton>
                    </ModelControls>
                  </Paper>

                  {/* Product Details Form */}
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Product Information
                    </Typography>

                    <Box
                      sx={{ display: "flex", flexDirection: "column", gap: 2 }}
                    >
                      <TextField
                        label="Product Name"
                        variant="outlined"
                        size="small"
                        fullWidth
                        placeholder="Enter product name"
                      />
                      <TextField
                        label="Product Code"
                        variant="outlined"
                        size="small"
                        fullWidth
                        placeholder="Enter product code"
                      />
                      <TextField
                        label="Description"
                        variant="outlined"
                        size="small"
                        fullWidth
                        multiline
                        rows={4}
                        placeholder="Enter product description"
                      />

                      <Box
                        sx={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: 2,
                        }}
                      >
                        <TextField
                          label="Width (mm)"
                          variant="outlined"
                          size="small"
                          type="number"
                          placeholder="Width"
                        />
                        <TextField
                          label="Height (mm)"
                          variant="outlined"
                          size="small"
                          type="number"
                          placeholder="Height"
                        />
                      </Box>

                      <Box
                        sx={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: 2,
                        }}
                      >
                        <TextField
                          label="Depth (mm)"
                          variant="outlined"
                          size="small"
                          type="number"
                          placeholder="Depth"
                        />
                        <TextField
                          label="Weight (kg)"
                          variant="outlined"
                          size="small"
                          type="number"
                          placeholder="Weight"
                        />
                      </Box>

                      <FormControl fullWidth size="small">
                        <InputLabel>Material</InputLabel>
                        <Select label="Material">
                          <MenuItem value="steel">Steel</MenuItem>
                          <MenuItem value="aluminum">Aluminum</MenuItem>
                          <MenuItem value="plastic">Plastic</MenuItem>
                          <MenuItem value="wood">Wood</MenuItem>
                          <MenuItem value="composite">Composite</MenuItem>
                        </Select>
                      </FormControl>

                      <Box>
                        <Typography variant="body2" gutterBottom>
                          Color
                        </Typography>
                        <Box sx={{ display: "flex", gap: 1 }}>
                          <ColorOption
                            sx={{ backgroundColor: "#1E88E5" }}
                            active={true}
                          />
                          <ColorOption sx={{ backgroundColor: "#43A047" }} />
                          <ColorOption sx={{ backgroundColor: "#E53935" }} />
                          <ColorOption sx={{ backgroundColor: "#FDD835" }} />
                          <ColorOption sx={{ backgroundColor: "#8E24AA" }} />
                          <ColorOption sx={{ backgroundColor: "#616161" }} />
                          <ColorOption
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                            }}
                          >
                            <AddIcon />
                          </ColorOption>
                        </Box>
                      </Box>

                      <Box>
                        <Typography variant="body2" gutterBottom>
                          Additional Options
                        </Typography>
                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                          <FormControlLabel
                            control={<Checkbox size="small" />}
                            label="Stackable"
                          />
                          <FormControlLabel
                            control={<Checkbox size="small" />}
                            label="Adjustable"
                          />
                          <FormControlLabel
                            control={<Checkbox size="small" />}
                            label="Customizable"
                          />
                        </Box>
                      </Box>
                    </Box>
                  </Paper>
                </Box>
              </StepContent>
            )}

            {/* Step 3: Review & Submit */}
            {currentStep === 3 && (
              <StepContent>
                <Typography variant="h6" gutterBottom>
                  Review & Submit
                </Typography>

                <Paper variant="outlined" sx={{ p: 3 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Product Summary
                  </Typography>
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fill, minmax(300px, 1fr))",
                      gap: 2,
                    }}
                  >
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Category
                      </Typography>
                      <Typography variant="body2">Rack Components</Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Product Group
                      </Typography>
                      <Typography variant="body2">
                        SPR, Single-Tier Shelving
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Product Name
                      </Typography>
                      <Typography variant="body2">
                        Heavy Duty Rack Frame
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Product Code
                      </Typography>
                      <Typography variant="body2">HDR-001</Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Dimensions
                      </Typography>
                      <Typography variant="body2">
                        1200mm × 800mm × 2400mm
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Weight
                      </Typography>
                      <Typography variant="body2">45 kg</Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Material
                      </Typography>
                      <Typography variant="body2">Steel</Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Color
                      </Typography>
                      <Box
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        <Box
                          sx={{
                            width: 16,
                            height: 16,
                            borderRadius: "50%",
                            backgroundColor: "#1E88E5",
                          }}
                        />
                        <Typography variant="body2">Blue</Typography>
                      </Box>
                    </Box>
                  </Box>

                  <Divider sx={{ my: 3 }} />

                  <Typography variant="subtitle1" gutterBottom>
                    3D Model Preview
                  </Typography>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <Paper
                      variant="outlined"
                      sx={{
                        width: 120,
                        height: 120,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        backgroundColor: "#f5f5f5",
                      }}
                    >
                      <Box component="span" sx={{ fontSize: 40 }}>
                        📦
                      </Box>
                    </Paper>
                    <Box>
                      <Typography variant="body2">
                        {selectedFile ? selectedFile.name : "No file selected"}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {selectedFile ? formatFileSize(selectedFile.size) : ""}
                      </Typography>
                    </Box>
                  </Box>

                  <Divider sx={{ my: 3 }} />

                  <Typography variant="subtitle1" gutterBottom>
                    Description
                  </Typography>
                  <Typography variant="body2">
                    Heavy duty rack frame designed for industrial storage
                    solutions. Features high load capacity and durable
                    construction.
                  </Typography>
                </Paper>
              </StepContent>
            )}
          </DialogContent>
          <DialogActions>
            {currentStep > 1 && (
              <Button
                onClick={handlePreviousStep}
                startIcon={<NavigateBeforeIcon />}
              >
                Back
              </Button>
            )}
            {currentStep < 3 ? (
              <Button
                variant="contained"
                onClick={handleNextStep}
                endIcon={<NavigateNextIcon />}
                disabled={currentStep === 1 && !selectedFile}
              >
                Next
              </Button>
            ) : (
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  // Handle final submission
                  alert("Product submitted successfully!");
                  handleModalVisibleClose();
                }}
              >
                Submit
              </Button>
            )}
          </DialogActions>
        </Dialog>

        {/* Product Catalog Setup Modal */}
        <Dialog
          open={modalConfigVisible}
          onClose={handleConfigVisibleClose}
          fullWidth
          maxWidth="md"
        >
          <DialogTitle>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography variant="h6">Product Catalog Setup</Typography>
              <IconButton onClick={handleConfigVisibleClose} size="small">
                <CloseIcon fontSize="small" />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Box sx={{ mb: 4 }}>
              <Typography variant="subtitle1" gutterBottom>
                Product Group Management
              </Typography>
              <Box sx={{ display: "flex", gap: 2, mb: 2, color: "#810055" }}>
                <TextField
                  label="Product Group Name"
                  variant="outlined"
                  size="small"
                  fullWidth
                  placeholder="Enter new product group name"
                  sx={{ color: "#810055" }}
                />
                <Button variant="contained" sx={{ bgcolor: "#810055" }}>
                  Add
                </Button>
              </Box>

              <Paper variant="outlined">
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    p: 1.5,
                    borderBottom: "1px solid rgba(0,0,0,0.12)",
                    bgcolor: "rgba(0,0,0,0.02)",
                  }}
                >
                  <Typography variant="subtitle2">
                    Existing Product Groups
                  </Typography>
                  <Typography variant="subtitle2">Actions</Typography>
                </Box>
                {[
                  "Selective Pallet Racking",
                  "Single-Tier Shelving",
                  "Multi-Tier Shelving",
                ].map((item, index) => (
                  <Box
                    key={index}
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      p: 1.5,
                      borderBottom:
                        index < 2 ? "1px solid rgba(0,0,0,0.12)" : "none",
                    }}
                  >
                    <Typography variant="body2">{item}</Typography>
                    <Box>
                      <IconButton size="small" color="primary">
                        <EditIcon fontSize="small" sx={{ color: "#810055" }} />
                      </IconButton>
                      <IconButton size="small" color="error">
                        <DeleteIcon
                          fontSize="small"
                          sx={{ color: "#810055" }}
                        />
                      </IconButton>
                    </Box>
                  </Box>
                ))}
              </Paper>
            </Box>

            <Box>
              <Tabs
                value={activeConfigTab}
                onChange={handleConfigTabChange}
                variant="scrollable"
                scrollButtons="auto"
                // sx={{color: "#810055"}}
              >
                {configTabs.map((tab, index) => (
                  <Tab key={index} label={tab} />
                ))}
              </Tabs>

              <Box sx={{ mt: 2 }}>
                <Box sx={{ display: "flex", gap: 2, mb: 2 }}>
                  <TextField
                    label={`Add ${configTabs[activeConfigTab]} Name`}
                    variant="outlined"
                    size="small"
                    fullWidth
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder={`Enter new ${configTabs[
                      activeConfigTab
                    ].toLowerCase()} name`}
                    sx={{ color: "#810055" }}
                  />
                  <Button
                    variant="contained"
                    onClick={() =>
                      handleAddNewItem(configTabs[activeConfigTab])
                    }
                    sx={{ bgcolor: "#810055" }}
                  >
                    Add
                  </Button>
                </Box>

                <Paper variant="outlined">
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      p: 1.5,
                      borderBottom: "1px solid rgba(0,0,0,0.12)",
                      bgcolor: "rgba(0,0,0,0.02)",
                    }}
                  >
                    <Typography variant="subtitle2">
                      Existing Components
                    </Typography>
                    <Typography variant="subtitle2">Actions</Typography>
                  </Box>
                  {["Frames", "Beams", "Decking", "Accessories"].map(
                    (item, index) => (
                      <Box
                        key={index}
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          p: 1.5,
                          borderBottom:
                            index < 3 ? "1px solid rgba(0,0,0,0.12)" : "none",
                        }}
                      >
                        <Typography variant="body2">{item}</Typography>
                        <Box>
                          <IconButton size="small" color="primary">
                            <EditIcon
                              fontSize="small"
                              sx={{ color: "#810055" }}
                            />
                          </IconButton>
                          <IconButton size="small" color="error">
                            <DeleteIcon
                              fontSize="small"
                              sx={{ color: "#810055" }}
                            />
                          </IconButton>
                        </Box>
                      </Box>
                    )
                  )}
                </Paper>
              </Box>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleConfigVisibleClose}
              sx={{ color: "#810055" }}
            >
              Close
            </Button>
            <Button
              variant="contained"
              onClick={handleConfigVisibleClose}
              sx={{ bgcolor: "#810055" }}
            >
              Save Changes
            </Button>
          </DialogActions>
        </Dialog>

        {/* Model Preview Drawer */}
        <ModelPreviewDrawer
          open={previewModel !== null}
          onClose={() => setPreviewModel(null)}
          modelUrl={previewModel?.url || ""}
          modelName={previewModel?.name || ""}
        />
      </Box>
    </ThemeProvider>
  );
};

export default MasterInventory;