import React, { useState, useEffect, useRef } from 'react';
import {
    Box,
    Stack,
    Typography,
    Button,
    IconButton,
    TextField,
    Select,
    MenuItem,
    Paper,
    Divider,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Radio,
    FormControlLabel,
    FormControl,
    InputLabel,
    InputAdornment,
    Menu,
    Tooltip,
    alpha,
    styled
} from '@mui/material';
import {
    CloudUpload,
    FileUpload,
    Link as LinkIcon,
    Search,
    FilterList,
    Download,
    Add,
    Edit,
    Save,
    Inventory,
    Settings,
    BarChart,
    GridView,
    Image as ImageIcon,
    InsertDriveFile,
    ExpandMore,
    ArrowBack,
    Delete,
    Visibility,
    ClearAll
} from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';
import {
    componentGroups,
    componentTypes,
    modelTypes,
    colors,
    GlobalSettings
} from './inventoryData';

// --- Styled Components ---

const Sidebar = styled(Box)(({ theme }) => ({
    width: 288,
    backgroundColor: '#fff',
    borderRight: `1px solid ${theme.palette.divider}`,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    [theme.breakpoints.down('lg')]: {
        display: 'none',
    },
}));

const MainContent = styled(Box)({
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
});

const CustomSelect = styled(Select)(({ theme }) => ({
    backgroundColor: '#f8fafc',
    '& .MuiOutlinedInput-notchedOutline': {
        borderColor: '#e2e8f0',
    },
    '&:hover .MuiOutlinedInput-notchedOutline': {
        borderColor: '#cbd5e1',
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
        borderColor: theme.palette.primary.main,
    },
    fontWeight: 700,
    fontSize: '0.875rem',
    borderRadius: 12,
}));

const CustomTextField = styled(TextField)(({ theme }) => ({
    '& .MuiOutlinedInput-root': {
        backgroundColor: '#f8fafc',
        borderRadius: 12,
        '& fieldset': {
            borderColor: '#e2e8f0',
        },
        '&:hover fieldset': {
            borderColor: '#cbd5e1',
        },
        '&.Mui-focused fieldset': {
            borderColor: theme.palette.primary.main,
        },
    },
    '& .MuiInputBase-input': {
        fontWeight: 700,
        fontSize: '0.875rem',
    },
}));

const OutputEngineBox = styled(Box)(({ theme }) => ({
    backgroundColor: alpha('#f8fafc', 0.5),
    borderRadius: 32,
    padding: theme.spacing(6),
    boxShadow: '0 20px 50px -15px rgba(0,0,0,0.05)',
    border: '1px solid #e2e8f0',
    position: 'relative',
    overflow: 'hidden',
    marginTop: theme.spacing(6),
}));

const UploadArea = styled(Box)(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing(5),
    border: '2px dashed #e2e8f0',
    borderRadius: 16,
    backgroundColor: '#f8fafc',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    '&:hover': {
        backgroundColor: alpha(theme.palette.primary.main, 0.05),
        borderColor: theme.palette.primary.light,
    },
})) as typeof Box;

// --- Interfaces ---

interface FormData {
    componentGroup: string;
    componentType: string;
    modelType: string;
    colour: string;
    gfaInfo: string;
    powderCode: string;
    powderType: string;
    powderWeight: string;
    cbm: string;
    cost: string;
    status: string;
    width: string;
    length: string;
    thickness: string;
    depth: string;
    height: string;
    weight: string;
    drawingNo: string;
    revNo: string;
    unspcCode: string;
    shortDescription: string;
    description: string;
    longDescription: string;
    kFactor: string;
    linkUpright: boolean;
    lipConnectorCount: string;
    // MHE Fields
    picking_aisle_width_mm: string;
    pallet_to_pallet_width_mm: string;
    cross_aisle_width_mm: string;
    end_aisle_width_mm: string;
    capacity_kg: string;
    max_loading_height_mm: string;
    overall_height_lowered_mm: string;
    straddle_outer_to_outer_mm: string;
    straddle_height_mm: string;
    // MHE Metadata Fields
    mheName: string;
    manufacturer: string;
    brand: string;
    mheCategory: string;
}

interface Solution {
    type: string;
    value: string;
}

interface SaveStatus {
    success: boolean;
    message: string;
}

interface RawFiles {
    glb: File | null;
    image: File | null;
}

interface InventoryItem {
    id: number;
    component: string;
    type: string;
    group: string;
    width: number;
    length: number;
    height: number;
    status: string;
    // Optional MHE fields
    capacity_kg?: number;
    isMHE?: boolean;
    uid?: string;
    name?: string;
}

const InventoryMasterView: React.FC = () => {
    const [selectedFile, setSelectedFile] = useState<string | null>(null);
    const [imageFile, setImageFile] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<'form' | 'table'>('form');
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const showAddMenu = Boolean(anchorEl);

    // Form State
    const [formData, setFormData] = useState<FormData>({
        componentGroup: componentGroups[0],
        componentType: '',
        modelType: '',
        colour: colors[0],
        gfaInfo: 'GFA',
        powderCode: 'PNM',
        powderType: 'Epoxy',
        powderWeight: 'GNM',
        cbm: '',
        cost: '',
        status: 'Active',
        width: '',
        length: '',
        thickness: '',
        depth: '',
        height: '10',
        weight: '',
        drawingNo: '',
        revNo: '',
        unspcCode: '',
        shortDescription: '',
        description: '',
        longDescription: '',
        kFactor: '40',
        linkUpright: false,
        lipConnectorCount: '2',
        picking_aisle_width_mm: '',
        pallet_to_pallet_width_mm: '',
        cross_aisle_width_mm: '',
        end_aisle_width_mm: '',
        capacity_kg: '',
        max_loading_height_mm: '',
        overall_height_lowered_mm: '',
        straddle_outer_to_outer_mm: '',
        straddle_height_mm: '',
        mheName: '',
        manufacturer: '',
        brand: '',
        mheCategory: ''
    });

    const [selectedSolution, setSelectedSolution] = useState<Solution>({ type: '', value: '' });
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<SaveStatus | null>(null);
    const [rawFiles, setRawFiles] = useState<RawFiles>({ glb: null, image: null });

    // Dependent Options State
    const [availableTypes, setAvailableTypes] = useState<string[]>([]);
    const [availableModels, setAvailableModels] = useState<string[]>([]);
    const [availableThickness, setAvailableThickness] = useState<number[]>([]);
    const [availableLengths, setAvailableLengths] = useState<number[]>([]);
    const [availableWidths, setAvailableWidths] = useState<number[]>([]);

    const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
    const [isLoadingList, setIsLoadingList] = useState(false);

    // Range helper
    const getRange = (min: number, max: number, step: number): number[] => {
        const res: number[] = [];
        if (!min && !max) return [];
        let start = min;
        let end = max;
        if (start > end) { [start, end] = [end, start]; }
        for (let i = start; i <= end; i += step) {
            res.push(i);
        }
        return res;
    };

    // Logic: When Group changes
    const onGroupChange = (group: string) => {
        const types = componentTypes[group] || [];
        setAvailableTypes(types);
        const firstType = types[0] || '';
        setFormData(prev => ({ ...prev, componentGroup: group, componentType: firstType }));
        onTypeChange(firstType);
    };

    // Logic: When Type changes
    const onTypeChange = (type: string) => {
        const models = modelTypes[type] || [];
        setAvailableModels(models);
        const firstModel = models[0] || '';
        setFormData(prev => ({ ...prev, componentType: type, modelType: firstModel }));
        onModelChange(firstModel, type);
    };

    // Logic: When Model changes
    const onModelChange = (model: string, type: string = formData.componentType) => {
        let thickness: number[] = [];
        let length: number[] = [];
        let width: number[] = [];

        if (type === 'Upright') {
            if (model === 'UPRIGHT G') {
                thickness = GlobalSettings.UPRIGHT_G_ThicknessValues;
                length = getRange(GlobalSettings.UPRIGHT_G_MIN_LENGTH, GlobalSettings.UPRIGHT_G_MAX_LENGTH, GlobalSettings.UPRIGH_G_STEP_VALUE);
                width = [50];
            } else {
                thickness = GlobalSettings.UPRIGHT_ThicknessValues;
                length = getRange(GlobalSettings.UPRIGHT_MIN_LENGTH, GlobalSettings.UPRIGHT_MAX_LENGTH, GlobalSettings.UPRIGHT_STEP_VALUE);
                width = GlobalSettings.UPRIGHT_widthValues;
            }
        } else if (type === 'Beams') {
            thickness = GlobalSettings.BEAM_ThicknessValues;
            length = getRange(GlobalSettings.BEAM_MIN_LENGTH, GlobalSettings.BEAM_MAX_LENGTH, GlobalSettings.BEAM_STEP_VALUE);
        } else if (model === 'HD 6B RF PANEL(GSB)') {
            width = getRange(GlobalSettings.HD6BRF_PANEL_MIN_WIDTH, GlobalSettings.HD6BRF_PANEL_MAX_WIDTH, GlobalSettings.HD6BRF_PANEL_STEP_WIDTH);
            length = getRange(GlobalSettings.HD6BRF_PANEL_MIN_LENGTH, GlobalSettings.HD6BRF_PANEL_MAX_LENGTH, GlobalSettings.HD6BRF_PANEL_STEP_VALUE);
            thickness = GlobalSettings.HD6BRF_PANEL_ThicknessValues;
        }

        setAvailableThickness(thickness);
        setAvailableLengths(length);
        setAvailableWidths(width);

        setFormData(prev => ({
            ...prev,
            modelType: model,
            thickness: thickness[0]?.toString() || '',
            length: length[0]?.toString() || '',
            width: width[0]?.toString() || '',
        }));
    };

    // Description Logic
    useEffect(() => {
        const { modelType, componentType, thickness, length, width, colour, lipConnectorCount } = formData;
        if (!modelType || !thickness || !length) return;

        const colorCode = colour.includes('-') ? colour.split('-').pop() : colour;
        let sDesc = '';
        let desc = '';
        let dwg = '';
        let rev = '';

        if (componentType === 'Upright') {
            if (modelType === 'UPRIGHT G') {
                if (thickness === '0.8') { dwg = 'IS/BL/S3/101'; rev = 'R2'; }
                else if (thickness === '1') {
                    if (colour.includes('RAL 7035')) { dwg = 'IS/BM/S3/291'; rev = 'R1'; }
                    else { dwg = 'IS/BL/S3/101'; rev = 'R2'; }
                }
            }
            sDesc = `${modelType}${width} T${thickness} L${length} ${colorCode}`;
            desc = `${modelType}${width} - L${length} x T${thickness} ${colorCode}`;
        } else if (componentType === 'Beams') {
            sDesc = `${modelType} ${thickness} L${length} ${colorCode}`;
            const hCode = modelType.split(' ').pop();
            desc = `${modelType} ${length} x 50 x ${hCode} - ${thickness} ${lipConnectorCount} LIP`;
        } else {
            sDesc = `${modelType} ${width}x${length}x${thickness} ${colorCode}`;
            desc = `${modelType} - L${length} x W${width} x T${thickness}`;
        }

        setFormData(prev => ({
            ...prev,
            shortDescription: sDesc,
            description: desc,
            longDescription: `${sDesc} ${dwg || prev.drawingNo}`,
            drawingNo: dwg || prev.drawingNo,
            revNo: rev || prev.revNo,
        }));
    }, [formData.modelType, formData.thickness, formData.length, formData.width, formData.colour]);

    useEffect(() => {
        onGroupChange(componentGroups[0]);
    }, []);

    const fetchInventory = async () => {
        setIsLoadingList(true);
        try {
            const [invRes, mheRes] = await Promise.all([
                fetch('http://localhost:5001/api/inventory'),
                fetch('http://localhost:5001/api/mhes')
            ]);

            const invData = await invRes.json();
            const mheData = await mheRes.json();

            // Harmonize data structure
            const harmonizedInv = invData.map((item: any) => ({
                id: item.uid, // Use UID as table ID for standard items
                component: item.short_description || item.description,
                type: item.component_type,
                group: item.component_group,
                status: item.status,
                isMHE: false
            }));

            const harmonizedMHE = mheData.map((item: any) => ({
                id: item.id,
                component: item.name,
                type: item.mhe_type,
                group: 'Material Handling Equipment(MHE)',
                status: item.is_active ? 'Active' : 'Inactive',
                isMHE: true,
                capacity_kg: item.attributes?.capacity_kg,
                picking_aisle_width_mm: item.attributes?.picking_aisle_width_mm
            }));

            setInventoryItems([...harmonizedInv, ...harmonizedMHE]);
        } catch (err) {
            console.error('Error fetching inventory:', err);
        } finally {
            setIsLoadingList(false);
        }
    };

    useEffect(() => {
        fetchInventory();
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'glb' | 'image') => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (type === 'glb') {
                setSelectedFile(file.name);
                setRawFiles(prev => ({ ...prev, glb: file }));
            } else {
                setImageFile(file.name);
                setRawFiles(prev => ({ ...prev, image: file }));
            }
        }
    };

    const handleSave = async () => {
        if (!formData.componentGroup || !formData.componentType) {
            alert('Component Group and Type are mandatory.');
            return;
        }
        if (!rawFiles.glb) {
            alert('GLB 3D Model file is mandatory.');
            return;
        }
        if (!selectedSolution.type || !selectedSolution.value) {
            alert('Please select a Product Solution (Pallet Rack or Shelving).');
            return;
        }

        setIsSaving(true);
        setSaveStatus(null);

        const isMHE = formData.componentGroup === 'Material Handling Equipment(MHE)';
        const endpoint = isMHE ? 'http://localhost:5001/api/mhes' : 'http://localhost:5001/api/inventory';

        const data = new FormData();

        if (isMHE) {
            // Mapping for /api/mhes
            data.append('name', formData.mheName || formData.description);
            data.append('manufacturer', formData.manufacturer);
            data.append('brand', formData.brand);
            data.append('model', formData.modelType);
            data.append('mhe_type', formData.componentType);
            data.append('mhe_category', formData.mheCategory);

            // Technical Specs bundled into attributes
            const attributes = {
                picking_aisle_width_mm: formData.picking_aisle_width_mm,
                pallet_to_pallet_width_mm: formData.pallet_to_pallet_width_mm,
                cross_aisle_width_mm: formData.cross_aisle_width_mm,
                end_aisle_width_mm: formData.end_aisle_width_mm,
                capacity_kg: formData.capacity_kg,
                max_loading_height_mm: formData.max_loading_height_mm,
                overall_height_lowered_mm: formData.overall_height_lowered_mm,
                straddle_outer_to_outer_mm: formData.straddle_outer_to_outer_mm,
                straddle_height_mm: formData.straddle_height_mm
            };
            data.append('attributes', JSON.stringify(attributes));
            data.append('created_by', 'system'); // Placeholder
        } else {
            // Standard /api/inventory
            (Object.keys(formData) as Array<keyof FormData>).forEach(key => {
                data.append(key, formData[key].toString());
            });
            data.append('solutionType', selectedSolution.type);
            data.append('selectedSolution', selectedSolution.value);
        }

        if (rawFiles.glb) data.append('glbFile', rawFiles.glb);
        if (rawFiles.image) data.append('imageFile', rawFiles.image);

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                body: data,
            });

            if (response.ok) {
                const result = await response.json();
                const idMsg = isMHE ? `MHE ID: ${result.id}` : `UID: ${result.uid}`;
                setSaveStatus({ success: true, message: `Successfully saved! ${idMsg}` });
                fetchInventory(); // Refresh the list
            } else {
                const error = await response.json();
                setSaveStatus({ success: false, message: error.error || 'Server error occurred' });
            }
        } catch (err) {
            setSaveStatus({ success: false, message: 'Could not connect to server' });
        } finally {
            setIsSaving(false);
        }
    };

    /* Removing hardcoded inventoryItems constant */

    const handleAddMenuOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
    };
    const handleAddMenuClose = () => {
        setAnchorEl(null);
    };

    return (
        <Box sx={{ display: 'flex', height: '100vh', bgcolor: '#f8fafc', overflow: 'hidden' }}>
            {/* Sidebar */}
            <Sidebar>
                <Box sx={{ p: 3, borderBottom: '1px solid #e2e8f0' }}>
                    <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2 }}>
                        <Box sx={{
                            width: 40, height: 40, bgcolor: 'primary.main',
                            borderRadius: 2, display: 'flex', alignItems: 'center',
                            justifyContent: 'center', boxShadow: '0 10px 15px -3px rgba(37, 99, 235, 0.2)'
                        }}>
                            <Inventory sx={{ color: '#fff', fontSize: 24 }} />
                        </Box>
                        <Box>
                            <Typography sx={{ fontWeight: 800, color: 'text.primary', lineHeight: 1 }}>Inventory Master</Typography>
                            <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600 }}>Component Management</Typography>
                        </Box>
                    </Stack>
                    <TextField
                        fullWidth
                        size="small"
                        placeholder="Search products..."
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Search sx={{ color: 'text.secondary', fontSize: 18 }} />
                                </InputAdornment>
                            ),
                            sx: { borderRadius: 2, bgcolor: '#f8fafc', '& fieldset': { borderColor: '#e2e8f0' } }
                        }}
                    />
                </Box>

                <Stack spacing={4} sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
                    {/* Pallet Rack Solutions */}
                    <Stack spacing={2}>
                        <Stack direction="row" justifyContent="space-between" alignItems="center">
                            <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'text.primary' }}>Pallet Rack Solutions</Typography>
                            <FilterList sx={{ fontSize: 14, color: 'text.disabled' }} />
                        </Stack>
                        <Stack spacing={1}>
                            {['Selective Pallet Racking', 'Shuttle Racking', 'Mother/Child Shuttle'].map((item) => (
                                <FormControlLabel
                                    key={item}
                                    control={
                                        <Radio
                                            size="small"
                                            checked={selectedSolution.type === 'Pallet Rack' && selectedSolution.value === item}
                                            onChange={() => setSelectedSolution({ type: 'Pallet Rack', value: item })}
                                        />
                                    }
                                    label={<Typography sx={{ fontSize: '0.75rem', fontWeight: 700 }}>{item}</Typography>}
                                    sx={{ m: 0, '& .MuiFormControlLabel-label': { ml: 0.5 } }}
                                />
                            ))}
                        </Stack>
                    </Stack>

                    {/* Shelving Solutions */}
                    <Stack spacing={2}>
                        <Stack direction="row" justifyContent="space-between" alignItems="center">
                            <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'text.primary' }}>Shelving Solutions</Typography>
                            <FilterList sx={{ fontSize: 14, color: 'text.disabled' }} />
                        </Stack>
                        <Stack spacing={1}>
                            {['Mezzanine', 'Single Tier Shelving', 'Mobile Shelving', 'Multi-Tier Shelving'].map((item) => (
                                <FormControlLabel
                                    key={item}
                                    control={
                                        <Radio
                                            size="small"
                                            checked={selectedSolution.type === 'Shelving' && selectedSolution.value === item}
                                            onChange={() => setSelectedSolution({ type: 'Shelving', value: item })}
                                        />
                                    }
                                    label={<Typography sx={{ fontSize: '0.75rem', fontWeight: 700 }}>{item}</Typography>}
                                    sx={{ m: 0, '& .MuiFormControlLabel-label': { ml: 0.5 } }}
                                />
                            ))}
                        </Stack>
                    </Stack>
                </Stack>

                <Box sx={{ p: 2, borderTop: '1px solid #e2e8f0' }}>
                    <Button
                        fullWidth
                        variant="contained"
                        sx={{ bgcolor: '#f1f5f9', color: 'text.secondary', '&:hover': { bgcolor: '#e2e8f0' }, boxShadow: 'none', fontWeight: 800, py: 1, fontSize: '0.7rem' }}
                        startIcon={<Download sx={{ fontSize: 16, color: 'primary.main' }} />}
                    >
                        Export Data
                    </Button>
                </Box>
            </Sidebar>

            {/* Main Content */}
            <MainContent>
                <Box sx={{ bgcolor: '#fff', borderBottom: '1px solid #e2e8f0', px: 4, py: 2, position: 'relative', zIndex: 30 }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Stack direction="row" spacing={2} alignItems="center">
                            <IconButton component={RouterLink} to="/" sx={{ border: '1px solid #f1f5f9' }}>
                                <ArrowBack sx={{ fontSize: 20, color: 'text.secondary' }} />
                            </IconButton>
                            <Box>
                                <Typography variant="h6" sx={{ fontWeight: 800, letterSpacing: '-0.02em', color: 'text.primary' }}>Component Master</Typography>
                                <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600 }}>Precision catalog & logic management</Typography>
                            </Box>
                        </Stack>

                        <Box>
                            <Button
                                variant="contained"
                                onClick={handleAddMenuOpen}
                                startIcon={<Add sx={{ transition: 'transform 0.3s', transform: showAddMenu ? 'rotate(45deg)' : 'none' }} />}
                                endIcon={<ExpandMore sx={{ transition: 'transform 0.3s', transform: showAddMenu ? 'rotate(180deg)' : 'none' }} />}
                                sx={{
                                    bgcolor: 'primary.main', fontWeight: 900, px: 3, py: 1.2,
                                    borderRadius: 3, letterSpacing: '0.05em', fontSize: '0.75rem',
                                    boxShadow: '0 10px 15px -3px rgba(37, 99, 235, 0.2)'
                                }}
                            >
                                Add
                            </Button>
                            <Menu
                                anchorEl={anchorEl}
                                open={showAddMenu}
                                onClose={handleAddMenuClose}
                                PaperProps={{
                                    sx: { mt: 1, borderRadius: 3, boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', minWidth: 224, p: 1 }
                                }}
                            >
                                {['Add Product group', 'Add Component group', 'Add Component type'].map((item, idx) => (
                                    <MenuItem
                                        key={item}
                                        onClick={handleAddMenuClose}
                                        sx={{
                                            fontSize: '0.65rem', fontWeight: 900, textTransform: 'uppercase', py: 1.5, px: 2.5,
                                            borderRadius: 2, '&:hover': { bgcolor: alpha('#2563eb', 0.05), color: 'primary.main' },
                                            ...(idx === 2 && { borderTop: '1px solid #f1f5f9', mt: 1, pt: 2 })
                                        }}
                                    >
                                        {item}
                                    </MenuItem>
                                ))}
                            </Menu>
                        </Box>
                    </Stack>

                    <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
                        {[
                            { id: 'form', label: 'Component Configuration' },
                            { id: 'table', label: 'Inventory List' }
                        ].map((tab) => (
                            <Button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as any)}
                                sx={{
                                    px: 3, py: 1, fontSize: '0.65rem', fontWeight: 900, letterSpacing: '0.1em',
                                    borderRadius: 0, borderBottom: '2px solid',
                                    borderColor: activeTab === tab.id ? 'primary.main' : 'transparent',
                                    color: activeTab === tab.id ? 'primary.main' : 'text.disabled',
                                    '&:hover': { bgcolor: 'transparent', color: 'text.primary' }
                                }}
                            >
                                {tab.label}
                            </Button>
                        ))}
                    </Stack>
                </Box>

                <Box sx={{ flex: 1, overflowY: 'auto', p: 4 }}>
                    {activeTab === 'form' ? (
                        <Box sx={{ maxWidth: 1152, mx: 'auto', mb: 8 }}>
                            <Paper sx={{ borderRadius: 4, border: '1px solid #e2e8f0', boxShadow: 'none', overflow: 'hidden' }}>
                                <Box sx={{ p: 5 }}>

                                    {/* Hierarchy Selection */}
                                    <Box sx={{ mb: 6 }}>
                                        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                            <GridView sx={{ fontSize: 20, color: 'primary.main' }} />
                                            <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Hierarchy Selection</Typography>
                                        </Stack>
                                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 4 }}>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Component Group</Typography>
                                                <CustomSelect value={formData.componentGroup} onChange={(e: any) => onGroupChange(e.target.value)}>
                                                    {componentGroups.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Component Type</Typography>
                                                <CustomSelect value={formData.componentType} onChange={(e: any) => onTypeChange(e.target.value)}>
                                                    {availableTypes.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Model Variant</Typography>
                                                <CustomSelect value={formData.modelType} onChange={(e: any) => onModelChange(e.target.value)}>
                                                    {availableModels.map(m => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                        </Box>
                                    </Box>

                                    {/* Material & Coating */}
                                    <Box sx={{ mb: 6 }}>
                                        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                            <Settings sx={{ fontSize: 20, color: 'primary.main' }} />
                                            <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Material & Coating</Typography>
                                        </Stack>
                                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(4, 1fr)' }, gap: 3 }}>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Colour</Typography>
                                                <CustomSelect value={formData.colour} onChange={(e: any) => setFormData({ ...formData, colour: e.target.value })}>
                                                    {colors.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>GFA Info</Typography>
                                                <CustomSelect value={formData.gfaInfo} onChange={(e: any) => setFormData({ ...formData, gfaInfo: e.target.value })}>
                                                    <MenuItem value="GFA">GFA</MenuItem>
                                                    <MenuItem value="NON GFA">NON GFA</MenuItem>
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Powder Code</Typography>
                                                <CustomTextField value={formData.powderCode} onChange={(e: any) => setFormData({ ...formData, powderCode: e.target.value })} placeholder="PNM" />
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Status</Typography>
                                                <CustomSelect value={formData.status} onChange={(e: any) => setFormData({ ...formData, status: e.target.value })}>
                                                    <MenuItem value="Active">Active</MenuItem>
                                                    <MenuItem value="Inactive">Inactive</MenuItem>
                                                    <MenuItem value="Draft">Draft</MenuItem>
                                                </CustomSelect>
                                            </FormControl>
                                        </Box>
                                    </Box>

                                    {/* Dimensions */}
                                    <Box sx={{ mb: 6 }}>
                                        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                            <InsertDriveFile sx={{ fontSize: 20, color: 'primary.main' }} />
                                            <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Dimensions</Typography>
                                        </Stack>
                                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(4, 1fr)' }, gap: 3 }}>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Length (mm)</Typography>
                                                <CustomSelect value={formData.length} onChange={(e: any) => setFormData({ ...formData, length: e.target.value })}>
                                                    {availableLengths.map(l => <MenuItem key={l} value={l}>{l}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Thickness (mm)</Typography>
                                                <CustomSelect value={formData.thickness} onChange={(e: any) => setFormData({ ...formData, thickness: e.target.value })}>
                                                    {availableThickness.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Width (mm)</Typography>
                                                <CustomSelect value={formData.width} onChange={(e: any) => setFormData({ ...formData, width: e.target.value })} disabled={!availableWidths.length}>
                                                    {availableWidths.map(w => <MenuItem key={w} value={w}>{w}</MenuItem>)}
                                                    {!availableWidths.length && <MenuItem value="">NA</MenuItem>}
                                                </CustomSelect>
                                            </FormControl>
                                            <FormControl fullWidth>
                                                <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Height (mm)</Typography>
                                                <CustomTextField value={formData.height} onChange={(e: any) => setFormData({ ...formData, height: e.target.value })} />
                                            </FormControl>
                                        </Box>
                                    </Box>

                                    {/* MHE Basic Information */}
                                    {formData.componentGroup === 'Material Handling Equipment(MHE)' && (
                                        <Box sx={{ mb: 6 }}>
                                            <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                                <ImageIcon sx={{ fontSize: 20, color: 'primary.main' }} />
                                                <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>MHE Basic Information</Typography>
                                            </Stack>
                                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(1, 1fr)' }, gap: 3, mb: 3 }}>
                                                <FormControl fullWidth>
                                                    <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>MHE Name</Typography>
                                                    <CustomTextField
                                                        value={formData.mheName}
                                                        onChange={(e: any) => setFormData({ ...formData, mheName: e.target.value })}
                                                        placeholder="e.g. Toyota Reach Truck 8FBR15"
                                                        fullWidth
                                                    />
                                                </FormControl>
                                            </Box>
                                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 3 }}>
                                                <FormControl fullWidth>
                                                    <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Manufacturer</Typography>
                                                    <CustomTextField
                                                        value={formData.manufacturer}
                                                        onChange={(e: any) => setFormData({ ...formData, manufacturer: e.target.value })}
                                                        placeholder="e.g. Toyota, Jungheinrich"
                                                    />
                                                </FormControl>
                                                <FormControl fullWidth>
                                                    <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>Brand</Typography>
                                                    <CustomTextField
                                                        value={formData.brand}
                                                        onChange={(e: any) => setFormData({ ...formData, brand: e.target.value })}
                                                        placeholder="e.g. BT, Raymond"
                                                    />
                                                </FormControl>
                                                <FormControl fullWidth>
                                                    <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>MHE Category</Typography>
                                                    <CustomSelect
                                                        value={formData.mheCategory}
                                                        onChange={(e: any) => setFormData({ ...formData, mheCategory: e.target.value })}
                                                    >
                                                        <MenuItem value="Electric">Electric</MenuItem>
                                                        <MenuItem value="Diesel">Diesel</MenuItem>
                                                        <MenuItem value="Manual">Manual</MenuItem>
                                                        <MenuItem value="Semi-Electric">Semi-Electric</MenuItem>
                                                    </CustomSelect>
                                                </FormControl>
                                            </Box>
                                        </Box>
                                    )}

                                    {/* MHE Technical Specifications */}
                                    {formData.componentGroup === 'Material Handling Equipment(MHE)' && (
                                        <Box sx={{ mb: 6 }}>
                                            <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                                <Settings sx={{ fontSize: 20, color: 'primary.main' }} />
                                                <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>MHE Technical Specifications</Typography>
                                            </Stack>
                                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 3 }}>
                                                {[
                                                    { field: 'picking_aisle_width_mm', label: 'Picking aisle (mm)' },
                                                    { field: 'pallet_to_pallet_width_mm', label: 'Pallet↔Pallet (mm)' },
                                                    { field: 'cross_aisle_width_mm', label: 'Cross aisle (mm)' },
                                                    { field: 'end_aisle_width_mm', label: 'End aisle (mm)' },
                                                    { field: 'capacity_kg', label: 'Capacity (kg)' },
                                                    { field: 'max_loading_height_mm', label: 'Max loading (mm)' },
                                                    { field: 'overall_height_lowered_mm', label: 'Overall lowered (mm)' },
                                                    { field: 'straddle_outer_to_outer_mm', label: 'Straddle o-o (mm)' },
                                                    { field: 'straddle_height_mm', label: 'Straddle height (mm)' },
                                                ].map((field) => (
                                                    <FormControl key={field.field} fullWidth>
                                                        <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', color: 'text.disabled', mb: 1, ml: 1 }}>{field.label}</Typography>
                                                        <CustomTextField
                                                            type="number"
                                                            value={formData[field.field as keyof FormData]}
                                                            onChange={(e: any) => setFormData({ ...formData, [field.field]: e.target.value })}
                                                        />
                                                    </FormControl>
                                                ))}
                                            </Box>
                                        </Box>
                                    )}

                                    {/* Output Engine */}
                                    <OutputEngineBox>
                                        <Box sx={{ position: 'absolute', top: -100, right: -100, opacity: 0.05, transform: 'scale(1.5)', zIndex: 0 }}>
                                            <Inventory sx={{ fontSize: 320, color: 'primary.dark' }} />
                                        </Box>

                                        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ borderBottom: '1px solid #cbd5e1', pb: 4, mb: 5, position: 'relative', zIndex: 1 }}>
                                            <Stack direction="row" spacing={2} alignItems="center">
                                                <Box sx={{ width: 40, height: 40, borderRadius: 3, bgcolor: alpha('#2563eb', 0.05), border: '1px solid', borderColor: alpha('#2563eb', 0.1), display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                    <BarChart sx={{ color: 'primary.main', fontSize: 20 }} />
                                                </Box>
                                                <Box>
                                                    <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'primary.main', textTransform: 'uppercase', letterSpacing: '0.2em', mb: 0.5 }}>Live Output Engine</Typography>
                                                    <Stack direction="row" spacing={1} alignItems="center">
                                                        <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#22c55e', boxShadow: '0 0 10px rgba(34,197,94,0.3)' }} />
                                                        <Typography sx={{ fontSize: '0.55rem', fontWeight: 700, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Active Processing</Typography>
                                                    </Stack>
                                                </Box>
                                            </Stack>
                                            <Box sx={{ px: 2, py: 1, borderRadius: 2, bgcolor: '#fff', border: '1px solid #e2e8f0', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                                                <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: '0.1em' }}>v1.2 Catalog</Typography>
                                            </Box>
                                        </Stack>

                                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1.2fr 1fr' }, gap: 6, position: 'relative', zIndex: 1 }}>
                                            <Stack spacing={5}>
                                                <Stack spacing={2}>
                                                    <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.2em' }}>Short Identifier</Typography>
                                                    <Box sx={{ p: 3, bgcolor: '#fff', border: '1px solid #e2e8f0', borderRadius: 4, cursor: 'default', transition: 'all 0.2s', '&:hover': { borderColor: alpha('#2563eb', 0.3) }, boxShadow: '0 1px 3px rgba(0,0,0,0.02)' }}>
                                                        <Typography sx={{ fontSize: '1.875rem', fontWeight: 900, color: 'text.primary', fontFamily: 'monospace', letterSpacing: '-0.05em', lineHeight: 1 }}>
                                                            {formData.shortDescription || 'PENDING_CONFIG'}
                                                        </Typography>
                                                    </Box>
                                                </Stack>
                                                <Stack spacing={2}>
                                                    <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.2em' }}>Technical Specification</Typography>
                                                    <Typography sx={{ fontSize: '0.9rem', fontWeight: 500, color: 'text.secondary', fontStyle: 'italic', borderLeft: '2px solid', borderColor: alpha('#2563eb', 0.3), pl: 2, fontFamily: 'monospace' }}>
                                                        {formData.description || 'Waiting for dimension parameters...'}
                                                    </Typography>
                                                </Stack>
                                            </Stack>

                                            <Box sx={{ bgcolor: alpha('#fff', 0.8), p: 4, borderRadius: 6, border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.02)' }}>
                                                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, mb: 4 }}>
                                                    <Stack spacing={1}>
                                                        <Typography sx={{ fontSize: '0.55rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Master Drawing</Typography>
                                                        <Stack direction="row" spacing={1} alignItems="center">
                                                            <LinkIcon sx={{ fontSize: 12, opacity: 0.5, color: 'primary.main' }} />
                                                            <Typography sx={{ fontSize: '0.85rem', fontWeight: 900, color: 'primary.main', fontFamily: 'monospace' }}>{formData.drawingNo || 'IS/AUTO/GEN'}</Typography>
                                                        </Stack>
                                                    </Stack>
                                                    <Stack spacing={1}>
                                                        <Typography sx={{ fontSize: '0.55rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Revision State</Typography>
                                                        <Box sx={{ bgcolor: '#f1f5f9', px: 1.5, py: 0.5, borderRadius: 1.5, display: 'inline-block', width: 'fit-content' }}>
                                                            <Typography sx={{ fontSize: '0.8rem', fontWeight: 900, color: 'text.secondary', fontFamily: 'monospace' }}>{formData.revNo || 'R-01'}</Typography>
                                                        </Box>
                                                    </Stack>
                                                </Box>

                                                <Divider sx={{ mb: 4, opacity: 0.5 }} />

                                                <Stack spacing={2}>
                                                    <Typography sx={{ fontSize: '0.55rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Selected Solution Path</Typography>
                                                    <Stack direction="row" spacing={1.5} alignItems="center">
                                                        <Box sx={{ bgcolor: alpha('#2563eb', 0.05), border: '1px solid', borderColor: alpha('#2563eb', 0.1), px: 2, py: 0.75, borderRadius: 5 }}>
                                                            <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'primary.main', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{selectedSolution.type || 'None'}</Typography>
                                                        </Box>
                                                        <ExpandMore sx={{ fontSize: 14, color: '#cbd5e1', transform: 'rotate(-90deg)' }} />
                                                        <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, color: 'text.secondary' }}>{selectedSolution.value || 'Unselected'}</Typography>
                                                    </Stack>
                                                </Stack>
                                            </Box>
                                        </Box>
                                    </OutputEngineBox>

                                    {/* Asset Management */}
                                    <Box sx={{ mt: 10 }}>
                                        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 4, borderBottom: '1px solid #f1f5f9', pb: 2 }}>
                                            <CloudUpload sx={{ fontSize: 20, color: 'primary.main' }} />
                                            <Typography sx={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Files & Assets</Typography>
                                        </Stack>
                                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 4 }}>
                                            <UploadArea component="label">
                                                <input type="file" hidden onChange={(e) => handleFileChange(e, 'glb')} accept=".glb" />
                                                <FileUpload sx={{ fontSize: 40, color: '#cbd5e1', mb: 1.5, transition: 'color 0.2s' }} className="icon" />
                                                <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>GLB Model Upload</Typography>
                                                {selectedFile && (
                                                    <Box sx={{ mt: 2, px: 2, py: 0.5, bgcolor: '#fff', borderRadius: 5, boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                                        <Typography sx={{ fontSize: '0.7rem', fontWeight: 900, color: 'primary.main' }}>{selectedFile}</Typography>
                                                    </Box>
                                                )}
                                            </UploadArea>
                                            <UploadArea component="label">
                                                <input type="file" hidden onChange={(e) => handleFileChange(e, 'image')} accept="image/*" />
                                                <ImageIcon sx={{ fontSize: 40, color: '#cbd5e1', mb: 1.5, transition: 'color 0.2s' }} className="icon" />
                                                <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Product Image Upload</Typography>
                                                {imageFile && (
                                                    <Box sx={{ mt: 2, px: 2, py: 0.5, bgcolor: '#fff', borderRadius: 5, boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                                        <Typography sx={{ fontSize: '0.7rem', fontWeight: 900, color: 'primary.main' }}>{imageFile}</Typography>
                                                    </Box>
                                                )}
                                            </UploadArea>
                                        </Box>
                                    </Box>

                                    {/* Action Footer */}
                                    <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 10, pt: 5, borderTop: '1px solid #f1f5f9' }}>
                                        <Box>
                                            {saveStatus && (
                                                <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, px: 2, py: 1, borderRadius: 2, bgcolor: saveStatus.success ? alpha('#22c55e', 0.1) : alpha('#ef4444', 0.1), color: saveStatus.success ? '#15803d' : '#b91c1c' }}>
                                                    {saveStatus.message}
                                                </Typography>
                                            )}
                                        </Box>
                                        <Stack direction="row" spacing={2}>
                                            <Button
                                                onClick={() => {
                                                    setFormData(prev => ({
                                                        ...prev,
                                                        weight: '', cbm: '', cost: '',
                                                        picking_aisle_width_mm: '',
                                                        pallet_to_pallet_width_mm: '',
                                                        cross_aisle_width_mm: '',
                                                        end_aisle_width_mm: '',
                                                        capacity_kg: '',
                                                        max_loading_height_mm: '',
                                                        overall_height_lowered_mm: '',
                                                        straddle_outer_to_outer_mm: '',
                                                        straddle_height_mm: ''
                                                    }));
                                                    setRawFiles({ glb: null, image: null });
                                                    setSelectedFile(null);
                                                    setImageFile(null);
                                                    setSaveStatus(null);
                                                }}
                                                sx={{
                                                    px: 4, py: 1.5, borderRadius: 3, fontSize: '0.75rem', fontWeight: 900,
                                                    textTransform: 'uppercase', letterSpacing: '0.05em', color: 'text.disabled',
                                                    '&:hover': { color: 'text.primary', bgcolor: 'transparent' }
                                                }}
                                            >
                                                Clear Form
                                            </Button>
                                            <Button
                                                variant="contained"
                                                disabled={isSaving}
                                                onClick={handleSave}
                                                startIcon={isSaving ? null : <Save />}
                                                sx={{
                                                    px: 4, py: 1.5, borderRadius: 3, fontSize: '0.75rem', fontWeight: 900,
                                                    textTransform: 'uppercase', letterSpacing: '0.05em', bgcolor: 'text.primary',
                                                    boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)',
                                                    '&:hover': { bgcolor: '#000', transform: 'translateY(-2px)' },
                                                    transition: 'all 0.2s', '&:active': { transform: 'scale(0.95)' }
                                                }}
                                            >
                                                {isSaving ? 'Saving...' : 'Save Record'}
                                            </Button>
                                        </Stack>
                                    </Stack>

                                </Box>
                            </Paper>
                        </Box>
                    ) : (
                        /* Table View */
                        <Box sx={{ maxWidth: 1280, mx: 'auto' }}>
                            <Paper sx={{ borderRadius: 4, border: '1px solid #e2e8f0', boxShadow: 'none', overflow: 'hidden' }}>
                                <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ p: 2, bgcolor: alpha('#f8fafc', 0.8), borderBottom: '1px solid #e2e8f0' }}>
                                    <Button
                                        variant="outlined"
                                        startIcon={<FilterList />}
                                        sx={{
                                            borderRadius: 2, px: 2, py: 1, fontSize: '0.75rem', fontWeight: 700,
                                            textTransform: 'none', borderColor: '#e2e8f0', color: 'text.primary',
                                            '&:hover': { bgcolor: '#f1f5f9', borderColor: '#cbd5e1' }
                                        }}
                                    >
                                        Filter
                                    </Button>
                                    <Typography sx={{ fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
                                        {inventoryItems.length} records found
                                    </Typography>
                                </Stack>

                                <TableContainer>
                                    <Table sx={{ minWidth: 650 }}>
                                        <TableHead sx={{ bgcolor: alpha('#f8fafc', 0.8), borderBottom: '1px solid #e2e8f0' }}>
                                            <TableRow>
                                                {['Identifier', 'Component', 'Type', 'Status', 'Actions'].map((head) => (
                                                    <TableCell key={head} sx={{ px: 3, py: 2, fontSize: '0.65rem', fontWeight: 900, color: 'text.disabled', textTransform: 'uppercase', letterSpacing: '0.1em', border: 'none' }}>
                                                        {head}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {isLoadingList ? (
                                                <TableRow>
                                                    <TableCell colSpan={5} align="center" sx={{ py: 10 }}>
                                                        <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, color: 'text.disabled' }}>Loading live data from RDS...</Typography>
                                                    </TableCell>
                                                </TableRow>
                                            ) : inventoryItems.length === 0 ? (
                                                <TableRow>
                                                    <TableCell colSpan={5} align="center" sx={{ py: 10 }}>
                                                        <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, color: 'text.disabled' }}>No inventory records found.</Typography>
                                                    </TableCell>
                                                </TableRow>
                                            ) : inventoryItems.map((item) => (
                                                <TableRow key={item.id} sx={{ '&:hover': { bgcolor: alpha('#f8fafc', 0.5) }, transition: 'all 0.2s' }}>
                                                    <TableCell sx={{ px: 3, py: 2.5, fontSize: '0.7rem', fontWeight: 700, color: 'primary.main', borderBottom: '1px solid #f1f5f9', fontFamily: 'monospace' }}>
                                                        {item.id.toString().substring(0, 12)}...
                                                    </TableCell>
                                                    <TableCell sx={{ px: 3, py: 2.5, fontSize: '0.85rem', fontWeight: 900, color: 'text.primary', borderBottom: '1px solid #f1f5f9' }}>
                                                        <Stack>
                                                            <Typography sx={{ fontWeight: 900, fontSize: '0.85rem' }}>{item.component}</Typography>
                                                            {item.group === 'Material Handling Equipment(MHE)' && (
                                                                <Typography variant="caption" sx={{ color: 'primary.main', fontWeight: 600, fontSize: '0.7rem' }}>
                                                                    MHE Record {item.capacity_kg ? `| Cap: ${item.capacity_kg}kg` : ''}
                                                                </Typography>
                                                            )}
                                                        </Stack>
                                                    </TableCell>
                                                    <TableCell sx={{ px: 3, py: 2.5, fontSize: '0.8rem', fontWeight: 700, color: 'text.secondary', borderBottom: '1px solid #f1f5f9' }}>
                                                        {item.type}
                                                    </TableCell>
                                                    <TableCell sx={{ px: 3, py: 2.5, borderBottom: '1px solid #f1f5f9' }}>
                                                        <Box sx={{
                                                            display: 'inline-flex', px: 1.5, py: 0.5, borderRadius: 5,
                                                            bgcolor: item.status === 'Active' ? alpha('#22c55e', 0.1) : '#f1f5f9',
                                                            color: item.status === 'Active' ? '#15803d' : 'text.disabled'
                                                        }}>
                                                            <Typography sx={{ fontSize: '0.6rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{item.status}</Typography>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell align="right" sx={{ px: 4, py: 2, borderBottom: '1px solid #f1f5f9' }}>
                                                        <Tooltip title="View Details">
                                                            <IconButton size="small" sx={{ '&:hover': { color: 'primary.main', bgcolor: '#fff', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }, transition: 'all 0.2s' }}>
                                                                <Visibility sx={{ fontSize: 18 }} />
                                                            </IconButton>
                                                        </Tooltip>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Box>
                    )}
                </Box>
            </MainContent>
        </Box>
    );
};

export default InventoryMasterView;
