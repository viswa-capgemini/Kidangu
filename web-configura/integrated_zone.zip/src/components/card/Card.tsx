
// src/components/common/GenericCard.tsx
import React from "react";

type CardProps = {
  "data-testid"?: string;
  widthClassName?: string;
  heightClassName?: string;
  className?: string;
  children: React.ReactNode;
  as?: keyof JSX.IntrinsicElements;
};

const Card: React.FC<CardProps> = ({
  "data-testid": dataTestId,
  widthClassName = "w-full",
  heightClassName = "h-auto",
  className = "",
  children,
  as: Root = "div",
}) => {
  const classes = `${widthClassName} ${heightClassName} ${className}`.trim();

  // Casting to any to allow dynamic tag without extra generics
  const Component = Root as any;

  return (
    <Component data-testid={dataTestId} className={classes}>
      {children}
    </Component>
  );
};

export default Card;

