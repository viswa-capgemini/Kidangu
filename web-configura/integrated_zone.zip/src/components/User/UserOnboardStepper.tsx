import React, { useEffect, useState } from "react";
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Card,
  CardContent,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormGroup,
  FormControlLabel,
  Checkbox,
  RadioGroup,
  Radio,
  Chip,
  Stack,
  Divider,
} from "@mui/material";
import type { SelectChangeEvent } from "@mui/material/Select";
import Grid from "@mui/material/Grid";

// ---- Inline types & constants ----
type Role = "Designer" | "Viewer" | "Admin";
type Product = "SPR" | "Shelving" | "Mobistack" | "Mezzanine";
type SubProduct = "Components";
type WeightOption = "With Weight" | "Without weight";
type PriceOption = "INR" | "USD" | "Both";
type OutputOption =
  | "BOM"
  | "Drawing pdf"
  | "Drawing dwg"
  | "Tech spec"
  | "3D"
  | "Assembly dwg";
type BomType = "Excel" | "pdf" | "Assembly level";
type StandardType = "GFA" | "Std1" | "Std2" | "All";

interface Access {
  products: Product[];
  subProducts: SubProduct[];
  weight: "" | WeightOption;
  price: "" | PriceOption;
  outputs: OutputOption[];
  bomType: BomType[];
  standardType: "" | StandardType;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: "" | Role;
  access: Access;
}

const ROLES: Role[] = ["Designer", "Viewer", "Admin"];
const PRODUCTS: Product[] = ["SPR", "Shelving", "Mobistack", "Mezzanine"];
const SUB_PRODUCTS: SubProduct[] = ["Components"];
const WEIGHT: WeightOption[] = ["With Weight", "Without weight"];
const PRICE: PriceOption[] = ["INR", "USD", "Both"];
const OUTPUTS: OutputOption[] = [
  "BOM",
  "Drawing pdf",
  "Drawing dwg",
  "Tech spec",
  "3D",
  "Assembly dwg",
];
const BOM_TYPE: BomType[] = ["Excel", "pdf", "Assembly level"];
const STANDARD_TYPE: StandardType[] = ["GFA", "Std1", "Std2", "All"];

const steps = [
  "User Details",
  "Access & Pricing",
  "Outputs & BOM",
  "Standards & Review",
] as const;

const safeUuid = (): string => Math.random().toString(36).slice(2);

const emptyAccess: Access = {
  products: [],
  subProducts: [],
  weight: "",
  price: "",
  outputs: [],
  bomType: [],
  standardType: "",
};

const makeEmptyUser = (id?: string): User => ({
  id: id ?? safeUuid(),
  name: "",
  email: "",
  role: "",
  access: { ...emptyAccess },
});

interface UserOnboardStepperProps {
  onSubmit: (user: User) => void;
  initialUser?: User;
}

interface UserOnboardStepperProps {
  // Update the onSubmit prop type to include validation status and error message
  onSubmit: (user: User, isValid: boolean, errorMessage?: string) => void;
  initialUser?: User;
}

export default function UserOnboardStepper({
  onSubmit,
  initialUser,
}: UserOnboardStepperProps) {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [user, setUser] = useState<User>(makeEmptyUser());

  useEffect(() => {
    if (initialUser) {
      setUser({
        id: initialUser.id ?? safeUuid(),
        name: initialUser.name ?? "",
        email: initialUser.email ?? "",
        role: initialUser.role ?? "",
        access: {
          products: initialUser.access?.products ?? [],
          subProducts: initialUser.access?.subProducts ?? [],
          weight: initialUser.access?.weight ?? "",
          price: initialUser.access?.price ?? "",
          outputs: initialUser.access?.outputs ?? [],
          bomType: initialUser.access?.bomType ?? [],
          standardType: initialUser.access?.standardType ?? "",
        },
      });
      setActiveStep(0);
    }
  }, [initialUser]);

  const next = () => setActiveStep((s) => Math.min(s + 1, steps.length - 1));
  const back = () => setActiveStep((s) => Math.max(s - 1, 0));

  const handleSubmit = () => {
    if (!user.name || !user.email || !user.role) {
      // Instead of alert, pass validation status and error message to parent
      onSubmit(user, false, "Please fill name, email and role");
      return;
    }
    // Validate email format
    if (!/^\S+@\S+\.\S+$/.test(user.email)) {
      onSubmit(user, false, "Please enter a valid email address");
      return;
    }
    onSubmit(user, true);
    setUser(makeEmptyUser());
    setActiveStep(0);
  };

  const toggleArrayValue = <T,>(arr: T[], value: T, checked: boolean) =>
    checked ? [...arr, value] : arr.filter((x) => x !== value);

  return (
    <Box>
      <Stepper
        activeStep={activeStep}
        sx={{
          mb: 3,
          // Connector line color
          "& .MuiStepConnector-line": {
            borderColor: "#810055",
          },
          // Completed connector line color
          "& .MuiStepConnector-root.Mui-completed .MuiStepConnector-line": {
            borderColor: "#810055",
          },
          // Active connector line color
          "& .MuiStepConnector-root.Mui-active .MuiStepConnector-line": {
            borderColor: "#810055",
          },

          // Step icon (circle) colors
          "& .MuiStepLabel-root .MuiStepIcon-root": {
            color: "#c7a3c3", // base (inactive) circle color - subtle purple tint
          },
          "& .MuiStepLabel-root .MuiStepIcon-root.Mui-active": {
            color: "#810055", // active step circle
          },
          "& .MuiStepLabel-root .MuiStepIcon-root.Mui-completed": {
            color: "#810055", // completed step circle
          },

          // Step label (text) color
          "& .MuiStepLabel-label": {
            color: "#810055", // base label color
          },
          "& .MuiStepLabel-label.Mui-active": {
            color: "#810055",
            fontWeight: 600,
          },
          "& .MuiStepLabel-label.Mui-completed": {
            color: "#810055",
            fontWeight: 600,
          },
        }}
      >
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {activeStep === 0 && (
        <Card
          variant="outlined"
          sx={{
            boxShadow: "none",
            border: "1px solid #e0e0e0",
            borderRadius: "8px",
            mt: 2,
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ mb: 3, fontWeight: 500 }}
            >
              Role Details
            </Typography>

            <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {/* First row: Name and Email side by side */}
              {/* <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 2 }}>
          <TextField
            fullWidth
            label="Name"
            value={user.name}
            onChange={e => setUser({ ...user, name: e.target.value })}
            sx={{
              flex: 1,
              '& .MuiOutlinedInput-root': {
                height: '56px',
              },
              // Always show purple border, even in default state
              '& .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              // Override any default focus colors
              '& .Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#810055 !important' },
              
            }}
            InputLabelProps={{
              sx: { 
                color: '#000', 
                '&.Mui-focused': { color: '#000' },
                // Ensure label never turns blue
                '&.MuiFormLabel-root.Mui-focused': { color: '#000 !important' }
              }
            }}
          />
          
          <TextField
            fullWidth
            label="Email"
            type="email"
            value={user.email}
            onChange={e => setUser({ ...user, email: e.target.value })}
            sx={{
              flex: 1,
              '& .MuiOutlinedInput-root': {
                height: '56px',
              },
              // Always show purple border, even in default state
              '& .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#810055' },
              // Override any default focus colors
              '& .Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#810055 !important' },
              
            }}
            InputLabelProps={{
              sx: { 
                color: '#000', 
                '&.Mui-focused': { color: '#000' },
                // Ensure label never turns blue
                '&.MuiFormLabel-root.Mui-focused': { color: '#000 !important' }
              }
            }}
          />
        </Box> */}

              {/* Second row: Role taking 50% width */}
              <Box>
                <FormControl
                  sx={{
                    width: { xs: "100%", md: "50%" },
                    "& .MuiOutlinedInput-root": {
                      height: "56px",
                    },
                    // Always show purple border, even in default state
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055",
                    },
                    "&:hover .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055",
                    },
                    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055",
                    },
                    // Override any default focus colors
                    "& .Mui-focused .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#810055 !important",
                    },
                  }}
                >
                  <InputLabel
                    id="role-label"
                    sx={{
                      color: "#000",
                      "&.Mui-focused": { color: "#000" },
                      // Ensure label never turns blue
                      "&.MuiFormLabel-root.Mui-focused": {
                        color: "#000 !important",
                      },
                    }}
                  >
                    Role
                  </InputLabel>
                  <Select
                    labelId="role-label"
                    label="Role"
                    value={user.role}
                    onChange={(e) => setUser({ ...user, role: e.target.value })}
                    // Override MUI's default focus color
                    sx={{
                      "&.Mui-focused": {
                        ".MuiOutlinedInput-notchedOutline": {
                          borderColor: "#810055 !important",
                        },
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        sx: {
                          "& .MuiMenuItem-root.Mui-selected": {
                            backgroundColor: "rgba(129, 0, 85, 0.16)",
                          },
                          "& .MuiMenuItem-root.Mui-selected:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.24)",
                          },
                        },
                      },
                    }}
                  >
                    {ROLES.map((r) => (
                      <MenuItem
                        key={r}
                        value={r}
                        sx={{
                          "&:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.08)",
                          },
                        }}
                      >
                        {r}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Box>
          </CardContent>
        </Card>
      )}
      {/* Step 1: Access & Pricing */}
      {activeStep === 1 && (
        <Card
          variant="outlined"
          sx={{
            boxShadow: "none",
            border: "1px solid #e0e0e0",
            borderRadius: "8px",
            mt: 2,
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ mb: 3, fontWeight: 500 }}
            >
              Access & Pricing
            </Typography>

            <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {/* First row: Products */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  Products
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {PRODUCTS.map((p) => (
                    <FormControlLabel
                      key={p}
                      control={
                        <Checkbox
                          checked={user.access.products.includes(p)}
                          onChange={(e) => {
                            const next = toggleArrayValue<Product>(
                              user.access.products,
                              p,
                              e.target.checked
                            );
                            setUser({
                              ...user,
                              access: { ...user.access, products: next },
                            });
                          }}
                          sx={{
                            color: "#810055",
                            "&.Mui-checked": { color: "#810055" },
                            "&:hover": {
                              backgroundColor: "rgba(129, 0, 85, 0.08)",
                            },
                          }}
                        />
                      }
                      label={p}
                      sx={{ minWidth: { xs: "100%", sm: "auto" } }}
                    />
                  ))}
                </Box>
              </Box>

              {/* Second row: Sub Products */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  Sub Products
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {SUB_PRODUCTS.map((sp) => (
                    <FormControlLabel
                      key={sp}
                      control={
                        <Checkbox
                          checked={user.access.subProducts.includes(sp)}
                          onChange={(e) => {
                            const next = toggleArrayValue<SubProduct>(
                              user.access.subProducts,
                              sp,
                              e.target.checked
                            );
                            setUser({
                              ...user,
                              access: { ...user.access, subProducts: next },
                            });
                          }}
                          sx={{
                            color: "#810055",
                            "&.Mui-checked": { color: "#810055" },
                            "&:hover": {
                              backgroundColor: "rgba(129, 0, 85, 0.08)",
                            },
                          }}
                        />
                      }
                      label={sp}
                      sx={{ minWidth: { xs: "100%", sm: "auto" } }}
                    />
                  ))}
                </Box>
              </Box>

              {/* Third row: Weight and Price */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: { xs: "column", md: "row" },
                  gap: 2,
                }}
              >
                {/* Weight Select */}
                <FormControl fullWidth sx={{ flex: 1 }}>
                  <InputLabel
                    id="weight-label"
                    sx={{ color: "#000", "&.Mui-focused": { color: "#000" } }}
                  >
                    Weight
                  </InputLabel>

                  <Select
                    labelId="weight-label"
                    label="Weight"
                    value={user.access.weight}
                    onChange={(e: SelectChangeEvent<WeightOption | "">) =>
                      setUser({
                        ...user,
                        access: {
                          ...user.access,
                          weight: e.target.value as WeightOption,
                        },
                      })
                    }
                    sx={{
                      "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                      "&:hover .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                      "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        sx: {
                          "& .MuiMenuItem-root.Mui-selected": {
                            backgroundColor: "rgba(129, 0, 85, 0.16)",
                          },
                          "& .MuiMenuItem-root.Mui-selected:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.24)",
                          },
                        },
                      },
                    }}
                  >
                    {WEIGHT.map((w) => (
                      <MenuItem
                        key={w}
                        value={w}
                        sx={{
                          "&:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.08)",
                          },
                        }}
                      >
                        {w}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                {/* Price Select */}
                <FormControl fullWidth sx={{ flex: 1 }}>
                  <InputLabel
                    id="price-label"
                    sx={{ color: "#000", "&.Mui-focused": { color: "#000" } }}
                  >
                    Price
                  </InputLabel>

                  <Select
                    labelId="price-label"
                    label="Price"
                    value={user.access.price}
                    onChange={(e: SelectChangeEvent<PriceOption | "">) =>
                      setUser({
                        ...user,
                        access: {
                          ...user.access,
                          price: e.target.value as PriceOption,
                        },
                      })
                    }
                    sx={{
                      "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                      "&:hover .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                      "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#810055",
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        sx: {
                          "& .MuiMenuItem-root.Mui-selected": {
                            backgroundColor: "rgba(129, 0, 85, 0.16)",
                          },
                          "& .MuiMenuItem-root.Mui-selected:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.24)",
                          },
                        },
                      },
                    }}
                  >
                    {PRICE.map((p) => (
                      <MenuItem
                        key={p}
                        value={p}
                        sx={{
                          "&:hover": {
                            backgroundColor: "rgba(129, 0, 85, 0.08)",
                          },
                        }}
                      >
                        {p}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Outputs & BOM */}
      {activeStep === 2 && (
        <Card
          variant="outlined"
          sx={{
            boxShadow: "none",
            border: "1px solid #e0e0e0",
            borderRadius: "8px",
            mt: 2,
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ mb: 3, fontWeight: 500 }}
            >
              Generate Outputs & BOM
            </Typography>

            <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {/* First row: Generate Outputs */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  Generate Outputs
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {OUTPUTS.map((o) => (
                    <FormControlLabel
                      key={o}
                      control={
                        <Checkbox
                          checked={user.access.outputs.includes(o)}
                          onChange={(e) => {
                            const next = toggleArrayValue<OutputOption>(
                              user.access.outputs,
                              o,
                              e.target.checked
                            );
                            setUser({
                              ...user,
                              access: { ...user.access, outputs: next },
                            });
                          }}
                          sx={{
                            color: "#810055",
                            "&.Mui-checked": { color: "#810055" },
                            "&:hover": {
                              backgroundColor: "rgba(129, 0, 85, 0.08)",
                            },
                          }}
                        />
                      }
                      label={o}
                      sx={{ minWidth: { xs: "100%", sm: "auto" } }}
                    />
                  ))}
                </Box>
              </Box>

              {/* Second row: BOM Type */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  BOM Type
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {BOM_TYPE.map((b) => (
                    <FormControlLabel
                      key={b}
                      control={
                        <Checkbox
                          checked={user.access.bomType.includes(b)}
                          onChange={(e) => {
                            const next = toggleArrayValue<BomType>(
                              user.access.bomType,
                              b,
                              e.target.checked
                            );
                            setUser({
                              ...user,
                              access: { ...user.access, bomType: next },
                            });
                          }}
                          sx={{
                            color: "#810055",
                            "&.Mui-checked": { color: "#810055" },
                            "&:hover": {
                              backgroundColor: "rgba(129, 0, 85, 0.08)",
                            },
                          }}
                        />
                      }
                      label={b}
                      sx={{ minWidth: { xs: "100%", sm: "auto" } }}
                    />
                  ))}
                </Box>
              </Box>

              {/* Third row: Selected items as chips */}
              {(user.access.outputs.length > 0 ||
                user.access.bomType.length > 0) && (
                <Box>
                  <Divider sx={{ mb: 2 }} />
                  <Typography
                    variant="subtitle1"
                    sx={{ mb: 1, fontWeight: 500 }}
                  >
                    Selected Options
                  </Typography>
                  <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                    {user.access.outputs.map((o) => (
                      <Chip
                        key={o}
                        label={o}
                        sx={{
                          backgroundColor: "#810055",
                          color: "white",
                          fontWeight: 500,
                        }}
                      />
                    ))}
                    {user.access.bomType.map((b) => (
                      <Chip
                        key={b}
                        label={b}
                        sx={{
                          backgroundColor: "#F9F2F6",
                          color: "#810055",
                          border: "1px solid #810055",
                          fontWeight: 500,
                        }}
                      />
                    ))}
                  </Box>
                </Box>
              )}
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Standards & Review */}
      {activeStep === 3 && (
        <Card
          variant="outlined"
          sx={{
            boxShadow: "none",
            border: "1px solid #e0e0e0",
            borderRadius: "8px",
            mt: 2,
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ mb: 3, fontWeight: 500 }}
            >
              Standards & Review
            </Typography>

            <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {/* First row: Standard Type */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  Standard Type
                </Typography>
                <FormControl component="fieldset">
                  <RadioGroup
                    row
                    value={user.access.standardType}
                    onChange={(e) =>
                      setUser({
                        ...user,
                        access: {
                          ...user.access,
                          standardType: e.target.value as StandardType,
                        },
                      })
                    }
                  >
                    {STANDARD_TYPE.map((s) => (
                      <FormControlLabel
                        key={s}
                        value={s}
                        control={
                          <Radio
                            sx={{
                              color: "#810055",
                              "&.Mui-checked": { color: "#810055" },
                              "&:hover": {
                                backgroundColor: "rgba(129, 0, 85, 0.08)",
                              },
                            }}
                          />
                        }
                        label={s}
                        sx={{
                          minWidth: { xs: "100%", sm: "auto" },
                          mr: 3, // Add more spacing between radio options
                        }}
                      />
                    ))}
                  </RadioGroup>
                </FormControl>
              </Box>

              {/* Second row: Review */}
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 500 }}>
                  Review
                </Typography>
                <Box
                  sx={{
                    p: 2,
                    bgcolor: "#f9f9f9",
                    borderRadius: 1,
                    border: "1px solid",
                    borderColor: "#e0e0e0",
                    maxHeight: "300px",
                    overflow: "auto",
                  }}
                >
                  <pre
                    style={{
                      margin: 0,
                      whiteSpace: "pre-wrap",
                      fontFamily: '"Roboto Mono", monospace',
                      fontSize: "0.875rem",
                    }}
                  >
                    {JSON.stringify(user, null, 2)}
                  </pre>
                </Box>
              </Box>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Navigation */}
      <Box sx={{ display: "flex", justifyContent: "space-between", mt: 2 }}>
        <Button
          disabled={activeStep === 0}
          variant="text"
          onClick={back}
          sx={{ color: "#810055", "&:hover": { backgroundColor: "#F9F2F6" } }}
        >
          Back
        </Button>
        {activeStep < steps.length - 1 ? (
          <Button
            variant="contained"
            onClick={next}
            sx={{
              backgroundColor: "#810055",
              color: "#fff",
              "&:hover": { backgroundColor: "#810055" },
            }}
          >
            Next
          </Button>
        ) : (
          <Button
            variant="contained"
            color="secondary"
            onClick={handleSubmit}
            sx={{
              backgroundColor: "#810055",
              color: "#fff",
              "&:hover": { backgroundColor: "#810055" },
            }}
          >
            {initialUser ? "Update User" : "Save User"}
          </Button>
        )}
      </Box>
    </Box>
  );
}
