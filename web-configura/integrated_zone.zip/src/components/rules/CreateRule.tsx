import React, { useState, useEffect, useRef, type ChangeEvent } from "react";
import dynamoDBClient from "../../aws-config";
import { useNavigate, Navigate } from "react-router-dom";
import { UpdateItemCommand, AttributeValue } from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import { useSearchParams } from "react-router-dom";
import { PutItemCommand, GetItemCommand } from "@aws-sdk/client-dynamodb";

// Define TypeScript interfaces
interface Rule {
  id: string;
  name: string;
  type: "validation" | "calculation";
  severity?: "warning" | "error" | "info";
  active: boolean;
  expression: string;
  description?: string;
}

interface RuleForm {
  name: string;
  type: "validation" | "calculation";
  severity: "warning" | "error" | "info";
  expression: string;
  description: string;
}

interface TestResult {
  visible: boolean;
  success: boolean;
  text: string;
}

interface Variables {
  warehouseClearHeight: number;
  palletHeight: number;
  mheWorkingHeight: number;
  mheMFH: number;
  mheBasis: string;
  topClearance: number;
  pitch: number;
  unitType: string;
  singleFrameDepth: number;
  doubleFrameDepth1: number;
  doubleFrameDepth2: number;
  rowConnector: number;
  palletLoad: number;
}

interface Outputs {
  lastLoadingLevel: number;
  rackHeight: number;
  computedDepth: number;
  hdr: number;
}

interface Operator {
  display: string;
  value: string;
}

const styles = `
:root {
  --bg: #F1F1ED; /* Background */
  --card: #F9F2F6; /* Light card background */
  --muted: #707070; /* Secondary text */
  --text: #333333; /* Primary text */
  --accent: #810055; /* company Purple */
  --accent-2: #00B5D6; /* company Blue */
  --danger: #E1142E; /* Red */
  --warn: #FFA814; /* Yellow */
  --success: #33C037; /* Green */
}
* { 
  box-sizing: border-box; 
}

body, .rack-height-calculator {
  margin: 0;
  font-family: 'G&B', sans-serif;
  background: var(--bg);
  color: var(--text);
  font-size: 14px;
  line-height: 24px;
}

h1 {
  font-size: 48px;
  line-height: 58px;
  font-weight: bold;
  margin: 0;
}

.container {
  padding: 20px 24px;
  max-width: 1200px;
  margin: 0 auto;
}

.tabs {
  display: flex;
  gap: 8px;
  margin: 12px 0 24px;
}

.tab {
  padding: 10px 14px;
  border: 1px solid var(--muted);
  color: var(--muted);
  background: var(--card);
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
}

.tab.active {
  color: var(--text);
  border-color: var(--accent);
  box-shadow: 0 0 0 2px rgba(129,0,85,.2) inset;
}

.grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 16px;
}

.card {
  background: var(--card);
  border: 1px solid var(--muted);
  border-radius: 12px;
  padding: 16px;
}

.card h2 {
  font-size: 32px;
  line-height: 42px;
  font-weight: bold;
  margin: 0 0 10px;
}

label {
  font-size: 12px;
  line-height: 22px;
  color: var(--muted);
  display: block;
  margin-bottom: 6px;
}

input[type="number"], 
select, 
textarea, 
input[type="text"] { 
  width: 100%; 
  padding: 10px 12px; 
  background: #FFFFFF;
  border: 1px solid var(--muted);
  color: var(--text);
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}

input:focus,
select:focus,
textarea:focus {
  border-color: var(--accent);
}

textarea {
  min-height: 100px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

.row {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 12px;
  border: 1px solid var(--muted);
  color: var(--muted);
}

.chip.success {  
  color: var(--success); 
  border-color: #33C03744; 
  background: rgba(51,192,55,.08);
}

.chip.warn {
  color: var(--warn);
  border-color: #FFA81444;
  background: rgba(255,168,20,.08);
}

.chip.danger {
  color: var(--danger);
  border-color: #E1142E44;
  background: rgba(225,20,46,.08);
}

.btn {  
  font-size: 14px;  
  padding: 10px 16px;  
  border-radius: 8px;  
  cursor: pointer;
}

.btn.primary {
  background: var(--accent);
  color: #fff;
  border: none;
}

.btn.secondary {
  background: transparent;
  border: 1px solid var(--accent);
  color: var(--accent);
}

.btn.ghost {
  background: transparent;
  border: 1px solid var(--muted);
  color: var(--muted);
}

.btn.small {
  padding: 6px 8px;
  font-size: 12px;
}

.btn:disabled {
  opacity: .5;
  cursor: not-allowed;
}

.operators {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.op {   
  background: var(--card); 
  border: 1px dashed var(--muted); 
  color: var(--text);  
  padding: 6px 10px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
}

.table {
  width: 100%;
  border-collapse: collapse;
}

.table th,
.table td {
  padding: 10px;
  border-bottom: 1px solid var(--muted);
  font-size: 13px;
  text-align: left;
}

.tag {
  display: inline-block;
  padding: 2px 8px;
  font-size: 11px;
  border-radius: 999px;
  background: #123a2f;
  color: var(--success);
  border: 1px solid #1e654d;
}

.tag.warn {
  background: #3a2f12;
  color: var(--warn);
  border-color: #6a510f;
}

.muted {
  color: var(--muted);
  font-size: 12px;
}

.value {
  font-family: ui-monospace, Menlo, Monaco, Consolas, "Courier New", monospace;
  font-weight: 600;
}

.sr {
  position: absolute;
  left: -9999px;
  width: 1px;
  height: 1px;
  overflow: hidden;
}

.kpi {
  font-size: 22px;
  font-weight: 700;
}

.footer {
  margin-top: 10px;
  font-size: 12px;
  color: var(--muted);
}

.inline {
  display: inline;
}

pre {
  background: var(--card);
  padding: 10px;
  border-radius: 8px;
  overflow: auto;
  max-height: 300px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 13px;
  margin: 8px 0;
}

@media (max-width: 900px) {
  .grid {
    grid-template-columns: repeat(6, 1fr);
  }
}

@media (max-width: 600px) {
  .grid {
    grid-template-columns: repeat(1, 1fr);
  }
}

.fixed {
  position: fixed;
}

.top-1\\/2 {
  top: 50%;
}

.left-1\\/2 {
  left: 50%;
}

.transform {
  transform: translate(-50%, -50%);
}

.z-50 {
  z-index: 50;
}

.w-full {
  width: 100%;
}

.max-w-xl {
  max-width: 36rem;
}

.min-h-\\[100px\\] {
  min-height: 100px;
}

.bg-white {
  background-color: white;
}

.border {
  border-width: 1px;
}

.border-\\[\\#707070\\] {
  border-color: #707070;
}

.text-\\[\\#333333\\] {
  color: #333333;
}

.px-10 {
  padding-left: 2.5rem;
  padding-right: 2.5rem;
}

.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}

.rounded-xl {
  border-radius: 0.75rem;
}

.shadow-lg {
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

.absolute {
  position: absolute;
}

.top-4 {
  top: 1rem;
}

.right-4 {
  right: 1rem;
}

.text-\\[\\#810055\\] {
  color: #810055;
}

.hover\\:text-\\[\\#990066\\]:hover {
  color: #990066;
}

.text-xl {
  font-size: 1.25rem;
}

.font-bold {
  font-weight: 700;
}

.flex {
  display: flex;
}

.flex-col {
  flex-direction: column;
}

.justify-between {
  justify-content: space-between;
}

.h-full {
  height: 100%;
}

.text-center {
  text-align: center;
}

.items-center {
  align-items: center;
}

.text-\\[16px\\] {
  font-size: 16px;
}

.leading-\\[26px\\] {
  line-height: 26px;
}

.font-semibold {
  font-weight: 600;
}

.mb-6 {
  margin-bottom: 1.5rem;
}

.gap-6 {
  gap: 1.5rem;
}

.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}

.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}

.text-sm {
  font-size: 0.875rem;
}

.font-medium {
  font-weight: 500;
}

.text-white {
  color: white;
}

.bg-\\[\\#810055\\] {
  background-color: #810055;
}

.rounded-full {
  border-radius: 9999px;
}

.hover\\:bg-\\[\\#F1F1ED\\]:hover {
  background-color: #F1F1ED;
}

.focus\\:outline-none:focus {
  outline: none;
}

.hover\\:bg-\\[\\#990066\\]:hover {
  background-color: #990066;
}

.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\\:ring-\\[\\#d48ac0\\]:focus {
  --tw-ring-color: #d48ac0;
}
`;

const DynamicRules: React.FC = () => {
  // Helper functions
  function cryptoRandomId(): string {
    return "r_" + Math.random().toString(36).slice(2, 9);
  }

  // State management
  const [rules, setRules] = useState<Rule[]>([
    // Built-in guideline rule for HDR
    {
      id: cryptoRandomId(),
      name: "HDR must be ≤ 6",
      type: "validation",
      severity: "warning",
      active: true,
      expression: "hdr <= 6",
      description:
        "Height:Depth ratio ({{hdr}}) exceeds 6. Consider stability components.",
    },
  ]);

  const [searchParams] = useSearchParams();
  const ruleIdToEdit = searchParams.get("id");
  const [isEditMode, setIsEditMode] = useState<boolean>(false);

  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [ruleForm, setRuleForm] = useState<RuleForm>({
    name: "",
    type: "validation",
    severity: "warning",
    expression: "",
    description: "",
  });
  const [testResult, setTestResult] = useState<TestResult>({
    visible: false,
    success: false,
    text: "",
  });
  const [exportedJson, setExportedJson] = useState<string>("");
  const navigate = useNavigate();

  // Add CSS injection here
  useEffect(() => {
    // Create style element
    const styleElement = document.createElement("style");
    styleElement.innerHTML = styles;
    document.head.appendChild(styleElement);

    // Cleanup on unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Sample state variables and outputs (would normally come from the Design tab)
  const [vars] = useState<Variables>({
    warehouseClearHeight: 8000,
    palletHeight: 1200,
    mheWorkingHeight: 6200,
    mheMFH: 6500,
    mheBasis: "WorkingHeight",
    topClearance: 300,
    pitch: 100,
    unitType: "single",
    singleFrameDepth: 1100,
    doubleFrameDepth1: 1100,
    doubleFrameDepth2: 1100,
    rowConnector: 200,
    palletLoad: 100,
  });

  const [outputs] = useState<Outputs>({
    lastLoadingLevel: 5000,
    rackHeight: 5300,
    computedDepth: 1100,
    hdr: 4.55,
  });

  const expressionRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>("");
  const [showToast, setShowToast] = useState<boolean>(false);
  const [toastAction, setToastAction] = useState<(() => void) | null>(null);

  function camelize(str: string): string {
    return String(str)
      .replace(/[^a-zA-Z0-9]+(.)/g, (_, c) => c.toUpperCase())
      .replace(/^[A-Z]/, (m) => m.toLowerCase());
  }

  function insertAtCursor(text: string): void {
    if (!expressionRef.current) return;

    const textarea = expressionRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const value = textarea.value;

    const newValue = value.slice(0, start) + text + value.slice(end);

    setRuleForm((prev) => ({
      ...prev,
      expression: newValue,
    }));

    // Focus and set cursor position after the inserted text
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + text.length;
    }, 0);
  }

  function safeEval(expr: string, context: Record<string, any>): any {
    try {
      // eslint-disable-next-line no-new-func
      const fn = new Function(
        "vars",
        "Math",
        "with(vars){ return (" + expr + ") }"
      );
      return fn(context, Math);
    } catch (e) {
      return { __error: String(e) };
    }
  }

  function handleRuleFormChange(
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ): void {
    const { name, value } = e.target;
    setRuleForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  function clearRuleForm(): void {
    setRuleForm({
      name: "",
      type: "validation",
      severity: "warning",
      expression: "",
      description: "",
    });
    setEditingRuleId(null);
    setTestResult({ visible: false, success: false, text: "" });
  }

  function loadRuleIntoForm(rule: Rule): void {
    setEditingRuleId(rule.id);
    setRuleForm({
      name: rule.name,
      type: rule.type,
      severity: rule.severity || "warning",
      expression: rule.expression,
      description: rule.description || "",
    });
    setTestResult({ visible: false, success: false, text: "" });
  }

  // Function to save rule to DynamoDB
  const saveRuleToDynamoDB = async (rule: Rule): Promise<boolean> => {
    const params = {
      TableName: "RulesTable",
      Item: marshall(rule),
    };

    try {
      await dynamoDBClient.send(new PutItemCommand(params));
      console.log("Rule saved to DynamoDB successfully");
      setIsLoading(false);
      return true;
    } catch (error) {
      console.error("Error saving rule to DynamoDB:", error);
      setIsLoading(false);
      return false;
    }
  };

  // Function to fetch rule data from DynamoDB
  const fetchRuleFromDynamoDB = async (id: string): Promise<Rule | null> => {
    const params = {
      TableName: "RulesTable",
      Key: {
        id: { S: id },
      },
    };

    try {
      setIsLoading(true);
      const command = new GetItemCommand(params);
      const response = await dynamoDBClient.send(command);

      if (response.Item) {
        // Convert DynamoDB format to JavaScript object
        const rule: Rule = {
          id: response.Item.id.S || "",
          name: response.Item.name?.S || "",
          type:
            (response.Item.type?.S as "validation" | "calculation") ||
            "validation",
          expression: response.Item.expression?.S || "",
          active:
            response.Item.active?.BOOL !== undefined
              ? response.Item.active.BOOL
              : true,
        };

        // Add optional fields if they exist
        if (response.Item.severity?.S) {
          rule.severity = response.Item.severity.S as
            | "warning"
            | "error"
            | "info";
        }

        if (response.Item.description?.S) {
          rule.description = response.Item.description.S;
        }

        console.log("Fetched rule:", rule);
        return rule;
      }
      return null;
    } catch (error) {
      console.error("Error fetching rule from DynamoDB:", error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };
  // Load rule data when in edit mode
  useEffect(() => {
    const loadRuleData = async () => {
      if (ruleIdToEdit) {
        setIsEditMode(true);
        const rule = await fetchRuleFromDynamoDB(ruleIdToEdit);

        if (rule) {
          setEditingRuleId(rule.id);
          setRuleForm({
            name: rule.name || "",
            type: rule.type || "validation",
            severity: rule.severity || "warning",
            expression: rule.expression || "",
            description: rule.description || "",
          });
        } else {
          showToastNotification(
            "Failed to load rule data. Rule may not exist."
          );
          navigate("/rules");
        }
      }
    };

    loadRuleData();
  }, [ruleIdToEdit]);

  // Function to update rule in DynamoDB
  const updateRuleInDynamoDB = async (rule: Rule): Promise<boolean> => {
    try {
      const expressionAttributeValues: Record<string, AttributeValue> = {
        ":name": { S: rule.name },
        ":type": { S: rule.type },
        ":expression": { S: rule.expression },
        ":active": { BOOL: rule.active },
      };

      let updateExpression =
        "set #name = :name, #type = :type, #expression = :expression, #active = :active";
      const expressionAttributeNames: Record<string, string> = {
        "#name": "name",
        "#type": "type",
        "#expression": "expression",
        "#active": "active",
      };

      if (rule.type === "validation" && rule.severity) {
        updateExpression += ", #severity = :severity";
        expressionAttributeNames["#severity"] = "severity";
        expressionAttributeValues[":severity"] = { S: rule.severity };
      }

      if (rule.description) {
        updateExpression += ", #description = :description";
        expressionAttributeNames["#description"] = "description";
        expressionAttributeValues[":description"] = { S: rule.description };
      }

      const params = {
        TableName: "RulesTable",
        Key: {
          id: { S: rule.id },
        },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: "UPDATED_NEW" as const,
      };

      console.log("Update params:", JSON.stringify(params, null, 2));

      const command = new UpdateItemCommand(params);
      await dynamoDBClient.send(command);
      console.log("Rule updated in DynamoDB successfully");
      return true;
    } catch (error) {
      console.error("Error updating rule in DynamoDB:", error);
      return false;
    }
  };
  const showToastNotification = (message: string): void => {
    setToastMessage(message);
    setShowToast(true);
  };

  const handleAddOrUpdateRule = async (): Promise<void> => {
    const { name, type, severity, expression, description } = ruleForm;

    if (!name.trim()) {
      showToastNotification("Please enter a rule name.");
      return;
    }

    if (!expression.trim()) {
      showToastNotification("Please enter an expression.");
      return;
    }

    const newRule: Partial<Rule> = { name, type, expression };
    if (type === "validation") {
      newRule.severity = severity;
      newRule.description = description;
    }

    try {
      setIsLoading(true);

      if (editingRuleId) {
        const updatedRule: Rule = {
          id: editingRuleId,
          ...newRule,
          active: true,
        } as Rule;
        const success = await updateRuleInDynamoDB(updatedRule);

        if (success) {
          setRules((prevRules) =>
            prevRules.map((rule) =>
              rule.id === editingRuleId
                ? ({ ...rule, ...newRule } as Rule)
                : rule
            )
          );
          setEditingRuleId(null);
          showToastNotification("Rule updated successfully.");
        } else {
          showToastNotification(
            "Failed to update rule in database. Please try again."
          );
        }
      } else {
        const ruleId = cryptoRandomId();
        const completeRule: Rule = {
          id: ruleId,
          active: true,
          ...newRule,
        } as Rule;
        const success = await saveRuleToDynamoDB(completeRule);

        if (success) {
          setRules((prevRules) => [...prevRules, completeRule]);
          setToastMessage("Rule added successfully.");
          setShowToast(true);

          // Set a callback for navigation after OK
          setToastAction(() => () => navigate("/rules"));
        } else {
          setToastMessage("Failed to save rule to database. Please try again.");
          setShowToast(true);
          setToastAction(null);
        }
      }

      clearRuleForm();
    } catch (error) {
      console.error("Error in handleAddOrUpdateRule:", error);
      showToastNotification("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestRule = (): void => {
    const { expression } = ruleForm;

    if (!expression.trim()) {
      setTestResult({ visible: false, success: false, text: "" });
      return;
    }

    const ctx = { ...vars, ...outputs };
    const res = safeEval(expression, ctx);

    if (res && res.__error) {
      setTestResult({
        visible: true,
        success: false,
        text: "Error: " + res.__error,
      });
    } else {
      setTestResult({
        visible: true,
        success: true,
        text: "Result: " + String(res),
      });
    }
  };

  function handleToggleRule(id: string, active: boolean): void {
    setRules((prevRules) =>
      prevRules.map((rule) => (rule.id === id ? { ...rule, active } : rule))
    );
  }

  //delete
  function handleDeleteRule(id: string): void {
    if (window.confirm("Delete this rule?")) {
      setRules((prevRules) => prevRules.filter((rule) => rule.id !== id));
      setToastMessage("Rule deleted successfully");
      setShowToast(true);
      setToastAction(null); // or set a callback if needed
    }
  }

  function handleExportRules(): void {
    const json = JSON.stringify(rules, null, 2);
    setExportedJson(json);
  }

  function handleImportClick(): void {
    fileInputRef.current?.click();
  }

  function handleImportFile(e: ChangeEvent<HTMLInputElement>): void {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const arr = JSON.parse(reader.result as string);
        if (Array.isArray(arr)) {
          // Basic validation
          const validatedRules = arr.map((x) => ({
            id: x.id || cryptoRandomId(),
            name: x.name || "Unnamed",
            type: x.type || "validation",
            severity: x.severity || "warning",
            active: x.active !== false,
            expression: x.expression || "true",
            description: x.description || "",
          }));
          setRules(validatedRules);
        } else {
          alert("Invalid JSON: expected an array");
        }
      } catch (err) {
        alert("Invalid JSON: " + err);
      }
    };
    reader.readAsText(file);

    // Reset the file input
    e.target.value = "";
  }

  const handleSelect = (option: string): void => {
    console.log(`You selected option: ${option}`);
    // Do something with the selected option
  };

  const operators: Operator[] = [
    { display: "+", value: "+" },
    { display: "-", value: "-" },
    { display: "×", value: "*" },
    { display: "÷", value: "/" },
    { display: "(", value: "(" },
    { display: ")", value: ")" },
    { display: "<", value: "<" },
    { display: ">", value: ">" },
    { display: "≤", value: "<=" },
    { display: "≥", value: ">=" },
    { display: "==", value: "==" },
    { display: "AND", value: "&&" },
    { display: "OR", value: "||" },
    { display: "min()", value: "min(a,b)" },
    { display: "max()", value: "max(a,b)" },
    { display: "round()", value: "Math.round(x)" },
    { display: "floor()", value: "Math.floor(x)" },
    { display: "ceil()", value: "Math.ceil(x)" },
    { display: "pow()", value: "Math.pow(a,b)" },
    { display: "abs()", value: "Math.abs(x)" },
  ];
  return (
    <div className="rack-height-calculator">
      <div className="container">
        <header className="font-sans text-[48px] leading-[58px] text-[#810055] mb-4">
          Create Rule{" "}
        </header>

        <div className="grid">
          <div className="card" style={{ gridColumn: "span 7" }}>
            <header className="font-sans text-[40px] h-[50px]">
              Rule Builder
            </header>
            <div className="grid">
              <div className="relative flex items-center" style={{ gridColumn: "span 6" }}>
                <input
                  type="text"
                  name="name"
                  id="rule-name"
                  value={ruleForm.name}
                  onChange={handleRuleFormChange}
                  placeholder="e.g., HDR must be ≤ 6"
                  className="peer block w-full border border-gray-300 rounded-md px-4 pt-5 pb-2 text-[15px] text-black placeholder-transparent outline-none focus:ring-1 focus:ring-company-grey"
                />
                <label
                  htmlFor="rule-name"
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-[15px] transition-all duration-200 ease-in-out px-1 peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-[15px] peer-placeholder-shown:-translate-y-1/2 peer-focus:top-2 peer-focus:translate-y-0 peer-focus:text-company-grey peer-focus:text-[13px]"
                >
                  Rule name*
                </label>
              </div>
              <div style={{ gridColumn: "span 3" }} className="-mt-[20px]">
                <label>Type</label>
                <select
                  name="type"
                  value={ruleForm.type}
                  onChange={handleRuleFormChange}
                >
                  <option value="validation">Validation</option>
                  <option value="calculation">Calculation</option>
                </select>
              </div>
              <div
                style={{
                  gridColumn: "span 3",
                  display: ruleForm.type === "validation" ? "block" : "none",
                }}
                className="-mt-[20px]"
              >
                <label>Severity</label>
                <select
                  name="severity"
                  value={ruleForm.severity}
                  onChange={handleRuleFormChange}
                >
                  <option value="warning">Warning</option>
                  <option value="error">Error</option>
                  <option value="info">Info</option>
                </select>
              </div>
              <div style={{ gridColumn: "span 12" }}>
                <label>Expression</label>
                <textarea
                  ref={expressionRef}
                  name="expression"
                  value={ruleForm.expression}
                  onChange={handleRuleFormChange}
                  placeholder="JS-style expression returning boolean (for validation) or numeric/string (for calculation)"
                />
                <div className="operators" style={{ marginTop: "8px" }}>
                  <span className="muted" style={{ alignSelf: "center" }}>
                    Operators:
                  </span>
                  {operators.map((op, index) => (
                    <button
                      key={index}
                      className="op"
                      onClick={() => insertAtCursor(op.value)}
                    >
                      {op.display}
                    </button>
                  ))}
                </div>
                <div className="muted" style={{ marginTop: "6px" }}>
                  Tip: variables and outputs on the right can be clicked to
                  insert into the expression.
                </div>
              </div>
              <div
                style={{
                  gridColumn: "span 12",
                  display: ruleForm.type === "validation" ? "block" : "none",
                }}
              >
                <label>Description template (for validation)</label>
                <input
                  type="text"
                  name="description"
                  value={ruleForm.description}
                  onChange={handleRuleFormChange}
                  placeholder="e.g., Height:Depth ratio ({{hdr}}) exceeds 6. Consider stability components."
                />
              </div>
              <div style={{ gridColumn: "span 12" }}>
                <div className="row">
                  <button
                    className="btn primary"
                    onClick={handleAddOrUpdateRule}
                    disabled={isLoading}
                  >
                    {isLoading
                      ? "Saving..."
                      : editingRuleId
                        ? "Update Rule"
                        : "Add Rule"}
                  </button>
                  <button className="btn" onClick={handleTestRule}>
                    Test expression
                  </button>
                  {testResult.visible && (
                    <span
                      className={`chip ${testResult.success ? "success" : "danger"
                        }`}
                    >
                      {testResult.text}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="card" style={{ gridColumn: "span 5" }}>
            <h2>Variables & Outputs</h2>
            <div className="grid">
              <div style={{ gridColumn: "span 12" }}>
                <label>Click to insert into expression</label>
                <div className="row" style={{ gap: "8px", flexWrap: "wrap" }}>
                  {/* Input variables */}
                  {Object.entries(vars).map(([key, value]) => (
                    <button
                      key={key}
                      className="op"
                      title={String(value)}
                      onClick={() => insertAtCursor(key)}
                    >
                      {key}
                    </button>
                  ))}

                  {/* Output variables */}
                  {Object.entries(outputs).map(([key, value]) => (
                    <button
                      key={key}
                      className="op"
                      title={String(value)}
                      onClick={() => insertAtCursor(key)}
                    >
                      {key}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Commented out Rules table section */}
          {/* <div className="card" style={{ gridColumn: 'span 12' }}>
            <h2>Rules</h2>
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Severity</th>
                  <th>Active</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rules.map(rule => (
                  <tr key={rule.id}>
                    <td>{rule.name}</td>
                    <td><span className="tag">{rule.type}</span></td>
                    <td>
                      {rule.type === 'validation' ? (
                        <span className={`tag ${rule.severity === 'warning' ? 'warn' : ''}`}>
                          {rule.severity || ''}
                        </span>
                      ) : '-'}
                    </td>
                    <td>
                      <input
                        type="checkbox"
                        checked={rule.active}
                        onChange={(e) => handleToggleRule(rule.id, e.target.checked)}
                      />
                    </td>
                    <button
                      className="btn small"
                      onClick={() => loadRuleIntoForm(rule)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn small ghost"
                      onClick={() => handleDeleteRule(rule.id)}
                    >
                      Delete
                    </button>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="row" style={{ marginTop: '10px' }}>
              <button className="btn" onClick={handleExportRules}>Export JSON</button>
              <button className="btn ghost" onClick={handleImportClick}>Import JSON</button>
              <input
                type="file"
                ref={fileInputRef}
                accept="application/json"
                style={{ display: 'none' }}
                onChange={handleImportFile}
              />
            </div>
            {exportedJson && (
              <div className="footer" style={{ marginTop: '8px' }}>
                <div><strong>Exported JSON</strong></div>
                <pre style={{ whiteSpace: 'pre-wrap' }}>{exportedJson}</pre>
              </div>
            )}
          </div> */}
        </div>
      </div>
      {showToast && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-xl min-h-[100px] bg-white border border-[#707070] text-[#333333] px-10 py-8 rounded-xl shadow-lg">
          <button
            onClick={() => setShowToast(false)}
            className="absolute top-4 right-4 text-[#810055] hover:text-[#990066] text-xl font-bold"
            aria-label="Close"
          >
            ✕
          </button>

          <div className="flex flex-col justify-between h-full text-center items-center">
            <span className="text-[16px] leading-[26px] font-semibold mb-6">
              {toastMessage}
            </span>

            <div className="flex gap-6">
              <button
                onClick={() => setShowToast(false)}
                className="px-6 py-2 text-sm font-medium text-[#333333] bg-white border border-[#707070] rounded-full hover:bg-[#F1F1ED] focus:outline-none"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowToast(false);
                  if (toastAction) toastAction(); // Navigate if action is set
                }}
                className="px-6 py-2 text-sm font-medium text-white bg-[#810055] rounded-full hover:bg-[#990066] focus:outline-none focus:ring-2 focus:ring-[#d48ac0]"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DynamicRules;
