import React, { useState, useEffect } from "react";

interface SearchProps {
  placeholder?: string;
  onSearch: (query: string) => void;
  debounceTime?: number;
}

const Search: React.FC<SearchProps> = ({
  placeholder = "Search...",
  onSearch,
  debounceTime = 300,
}) => {
  const [query, setQuery] = useState("");

  useEffect(() => {
    const handler = setTimeout(() => {
      onSearch(query);
    }, debounceTime);

    return () => clearTimeout(handler);
  }, [query, debounceTime, onSearch]);

  return (
    <div className="w-full max-w-sm mx-auto">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2 border border-gray-600 rounded-md shadow-sm focus:outline-none "
      />
    </div>
  );
};

export default Search;
