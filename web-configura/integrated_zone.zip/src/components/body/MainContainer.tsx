import { Outlet } from "react-router";
import Layout from "../../pages/layout-details/Layout";
import Header from "../header/Header";


const MainContainer = () => {
  return (
    <div data-testid="main-container" className="flex-1 z-0">
      {/* <Header /> */}
      <Outlet/>
    </div>
  )
}

export default MainContainer;
