import LeftSidePanel from "../../pages/left-panel/LeftSidePanel";
import { useState } from "react";
import leftPanelFields from "../../config/leftPanelFields";
import { useAuth } from "../../context/AuthContext";
import MainContainer from "./MainContainer";
import { useLocation } from "react-router";

interface BodyProps {
  isSidebarOpen: boolean;
}

const Body: React.FC<BodyProps> = ({ isSidebarOpen }) => {
  const [showLabels, setShowLabels] = useState(false);
  const { user } = useAuth();
  // default to first visible field for the current user (or null)
  const defaultKey = (() => {
    if (!user) return null;
    const visible = leftPanelFields.find((f) => f.roles.includes(user.role));
    return visible ? visible.slug : null;
  })();
  const [selectedKey, setSelectedKey] = useState<string | null>(defaultKey);

  const location = useLocation();
  const reduceLeftSidePanel = ["/layout-design"];
  const reducedLeftPan = reduceLeftSidePanel.includes(location.pathname);

  return (
    <div
      data-testid="bodyContainer"
      className="relative h-screen flex overflow-hidden"
    >
      <div className="absolute top-0 left-0 h-[50px] w-10 bg-white flex items-center px-3 border-b shadow">
        {/* <div className="relative"> */}
          <button onClick={() => setShowLabels(!showLabels)}>
            <span
              data-testid="hamburger-icon"
              className="icon-[solar--hamburger-menu-outline]"
              style={{ color: "black" }}
            ></span>
          </button>
        {/* </div> */}
      </div>

      <LeftSidePanel
        showLabels={showLabels}
        setShowLabels={setShowLabels}
        selectedKey={selectedKey}
        setSelectedKey={(k) => setSelectedKey(k)}
        isOpen={isSidebarOpen}
        reducedLeftPan={reducedLeftPan}
      />

      <main data-testid="mainWrapper" className="ml-10 flex-1  overflow-y-auto">
        <MainContainer />
      </main>
    </div>
  );
};

export default Body;
