import React from "react";

type CounterButtonProps = {
  heading?: string;
  label?: string;
  onClick?: () => void;
  className?: string;
};
const CounterButton: React.FC<CounterButtonProps> = ({
  heading,
  label,
  onClick,
  className,
}) => {
  return (
    <div>
      <button
        data-testid="counter-button"
        onClick={onClick}
        className={`px-2 py-1 border border-gray-300 rounded-md hover:bg-gray-100`}
      >
        {label}
      </button>
    </div>
  );
};

export default CounterButton;
