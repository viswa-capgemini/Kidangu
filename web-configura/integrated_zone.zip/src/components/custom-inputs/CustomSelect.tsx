import { useState } from "react";

interface CustomSelectProps {
  options: string[];
  selectedPeriod: string | null;
  onSelect: (value: string) => void;
  isOpen: boolean;
  onToggle(): void;
  placeholder?: string;
}

const CustomSelect: React.FC<CustomSelectProps> = ({
  options,
  selectedPeriod,
  onToggle,
  onSelect,
  isOpen,
  placeholder = "Select...",
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const filteredOptions = options.filter((option) =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (val: string) => {
    onSelect(val);
    setSearchTerm("");
  };
  const selectedTime = options.find((opt) => opt === selectedPeriod);
  return (
    <div data-testid="customSelectContainer" className="relative w-[120px] text-xs">
      <button
        data-testid="customSelectBtn"
        onClick={onToggle}
        className={`border border-gray-300 rounded-full px-2 py-1 m-2 w-full text-left flex justify-between items-center
    ${
      selectedPeriod ? "bg-rose-100" : "bg-white"
    } hover:bg-rose-200 focus:bg-rose-200 transition-colors duration-300`}
      >
        {selectedTime || placeholder}
        {!isOpen ? (
          <span className="icon-[ri--arrow-drop-down-line] text-xl"></span>
        ) : (
          <span className="icon-[ri--arrow-drop-up-line] text-xl"></span>
        )}
      </button>
      {isOpen && (
        <div data-testid="customSelectOpen" className="absolute z-10 w-full bg-white border border-gray-300 rounded shadow-lg mt-1 max-h-[120px] overflow-y-auto">
          <ul>
            {filteredOptions.map((option, index) => (
              <li
                data-testid={`customSelectOption-${index}`}
                key={option}
                onClick={() => handleSelect(option)}
                className="px-2 py-1 hover:bg-rose-100 cursor-pointer"
              >
                {option}
              </li>
            ))}
            {filteredOptions.length === 0 && (
              <li data-testid="customSelect-NoOption" className="px-2 py-1 text-gray-500">No options found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default CustomSelect;
