import React, { useState } from "react";

const FloatingTextArea = () => {
  const [message, setMessage] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (e.target.value.length <= 200) {
      setMessage(e.target.value);
    }
  };

  return (
    <div data-testid="floatingTextContainer" className="relative w-[320px]">
      <textarea
        data-testid="floatingTextArea"
        id="message"
        name="message"
        value={message}
        onChange={handleChange}
        placeholder=" "
        className="peer border border-gray-300 rounded-md text-sm resize-none focus:outline-none focus:ring-1 focus:ring-company-grey px-2 pt-5 h-24 w-full"
        maxLength={200}
        rows={4}
      />

      <label
        data-testid="floatingTextLabel"
        htmlFor="message"
        className={`absolute left-2 transition-all duration-200 ease-in-out px-1
        ${message
            ? "top-[2px] text-[11px] text-company-grey"
            : "top-[10px] text-sm text-gray-400 peer-focus:top-[2px] peer-focus:text-[11px] peer-focus:text-company-grey peer-placeholder-shown:top-[10px] peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-400"
          }`}
      >
        Add your message<span>*</span>
      </label>

      <div data-testid="floatingTextHelperText" className="text-left text-xs text-gray-500 mt-1">
        {message.length}/200
      </div>
    </div>
  );
};

export default FloatingTextArea;
