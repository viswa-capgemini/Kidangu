import React, { useState } from "react";
import { Combobox } from "@headlessui/react";

interface DropdownProps<T> {
  label: string;
  options: T[];
  displayKey?: keyof T;
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
  allowUseCurrentLocation?: boolean;
}

const GenericDropdown = <T extends string | Record<string, any>>({
  label,
  options,
  displayKey,
  value,
  onChange,
  placeholder = "search...",
  allowUseCurrentLocation = false,
}: DropdownProps<T>) => {
  const [query, setQuery] = useState("");

  const getDisplayedValue = (item: T) => {
    if (typeof item === "string") return item;
    return displayKey ? String(item[displayKey]) : JSON.stringify(item);
  };

  const filtered =
    query === ""
      ? options
      : options.filter((item) =>
          getDisplayedValue(item).toLowerCase().includes(query.toLowerCase())
        );

  return (
    <div className="w-80">
      <label
        className={`block text-sm font-medium transition-all ${
          value ? "-translate-y-5 text-blue-600 text-sm" : "text-gray-500"
        }`}
      >
        {label}
      </label>

      <Combobox value={value} onChange={onChange}>
        <div className="relative mt-1">
          <Combobox.Input
            className="w-full border border-gray-300 rounded-md bg-white py-2 pl-3 text-sm leading-5 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            displayValue={(item: T) => (item ? getDisplayedValue(item) : "")}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={placeholder}
          />
          <Combobox.Options className="absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white text-sm shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
            {allowUseCurrentLocation && (
              <Combobox.Option
                value={"Use current Location" as unknown as T}
                className={({ active }) =>
                  `cursor-pointer select-none py-2 pl-4 pr-4 ${
                    active ? "bg-blue-100" : "text-gray-900"
                  }`
                }
              >
                Use Current Location
              </Combobox.Option>
            )}
            {filtered.length === 0 ? (
              <div className="cursor-default select-none py-2 px-4 text-gray-500">
                No result found
              </div>
            ) : (
              filtered.map((item, idx) => (
                <Combobox.Option
                  key={idx}
                  value={item}
                  className={({ active }) =>
                    `cursor-pointer select-none py-2 pl-4 pr-4 ${
                      active ? "bg-blue-100" : "text-gray-900"
                    }`
                  }
                >
                  {getDisplayedValue(item)}
                </Combobox.Option>
              ))
            )}
          </Combobox.Options>
        </div>
      </Combobox>
    </div>
  );
};

export default GenericDropdown;
