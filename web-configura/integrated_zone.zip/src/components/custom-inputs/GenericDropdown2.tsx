import React, { useState } from "react";
import {
  Combobox,
  ComboboxInput,
  ComboboxOption,
  ComboboxOptions,
  ComboboxButton,
  Label,
} from "@headlessui/react";
import { MagnifyingGlassIcon, MapPinIcon } from "@heroicons/react/20/solid";

interface DropdownProps<T> {
  label: string;
  options: T[];
  displayKey?: keyof T;
  value: T | null;
  onChange: (value: T | null) => void;
  placeholder?: string;
  allowUseCurrentLocation?: boolean;
  error?: string;
}

const GenericDropdown = <T extends string | Record<string, any>>({
  label,
  options,
  displayKey,
  value,
  onChange,
  placeholder = "Search company.com",
  allowUseCurrentLocation = false,
  error,
}: DropdownProps<T>) => {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const getDisplayedValue = (item: T) => {
    if (typeof item === "string") return item;
    return displayKey ? String(item[displayKey]) : JSON.stringify(item);
  };

  const filteredOptions =
    query === ""
      ? options
      : options.filter((item) =>
        getDisplayedValue(item).toLowerCase().includes(query.toLowerCase())
      );

  return (
    <div className="w-80 relative">
      <Combobox
        value={value}
        onChange={(val) => {
          onChange(val);
          setQuery("");
          setIsOpen(false);
        }}
      >
        {({ open }) => (
          <div className="relative">
            {/* Floating Label */}
            <Label
              className={`absolute left-3 transition-all duration-200 pointer-events-none ${value || query
                  ? "top-1 text-xs text-blue-600"
                  : "top-[24px] transform -translate-y-1/2 text-sm text-gray-500"
                } ${error ? "text-red-600" : ""}`}
            >
              {label}
            </Label>

            {/* Clickable Wrapper */}
            <div
              className="peer w-full border rounded-md bg-white pt-5 pb-2 pl-3 pr-10 text-sm text-left h-12 cursor-pointer flex items-center"
              onClick={() => setIsOpen(!open)}
            >
              {value ? getDisplayedValue(value) : ""}
              <ComboboxButton className="absolute inset-y-0 right-0 flex items-center pr-2">
                <span className="text-gray-400 top-1/2">&#x25BC;</span>
              </ComboboxButton>
            </div>

            {/* Dropdown Panel */}
            {open && (
              <ComboboxOptions className="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 text-sm border border-gray-300 max-h-60 overflow-auto">
                {/* Search Box with Icon */}
                <div className="flex items-center px-3 py-2 border-b border-gray-200 bg-gray-50 sticky top-0 z-10">
                  <MagnifyingGlassIcon className="h-4 w-4 text-gray-400 mr-2" />
                  <input
                    type="text"
                    className="w-full text-sm bg-transparent focus:outline-none"
                    placeholder={placeholder}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    autoFocus
                  />
                </div>

                {/* Use Current Location Option */}
                {allowUseCurrentLocation && (
                  <ComboboxOption
                    value={"Use current location" as unknown as T}
                    className={({ active }) =>
                      `flex items-center gap-2 cursor-pointer select-none py-2 px-4 ${active ? "bg-blue-100" : "text-gray-900"
                      }`
                    }
                  >
                    <MapPinIcon className="h-4 w-4 text-blue-500" />
                    Use current location
                  </ComboboxOption>
                )}

                {/* Filtered Options */}
                {filteredOptions.length === 0 ? (
                  <div className="cursor-default select-none py-2 px-4 text-gray-500">
                    No results found
                  </div>
                ) : (
                  filteredOptions.map((item, idx) => (
                    <ComboboxOption
                      key={idx}
                      value={item}
                      className={({ active }) =>
                        `cursor-pointer select-none py-2 px-4 ${active ? "bg-blue-100" : "text-gray-900"
                        }`
                      }
                    >
                      {getDisplayedValue(item)}
                    </ComboboxOption>
                  ))
                )}
              </ComboboxOptions>
            )}

            {/* Error Message */}
            {error && (
              <p className="mt-1 text-sm text-red-600">{error}</p>
            )}
          </div>
        )}
      </Combobox>
    </div>
  );
};

export default GenericDropdown;