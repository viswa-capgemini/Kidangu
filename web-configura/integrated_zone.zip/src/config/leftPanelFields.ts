import type { Role } from "../types/auth";

export interface LeftField {
  slug: string;
  iconClass: string;
  label: string;
  roles: Role[];
}

export const leftPanelFields: LeftField[] = [
  // Dealer-visible options
  { slug: 'dashboard', iconClass: 'icon-[material-symbols--dashboard-outline]', label: 'Dashboard', roles: ['dealer'] },
  { slug: 'mhe-details', iconClass: 'icon-[lsicon--user-all-filled]', label: 'MHE Details', roles: ['dealer'] },
  { slug: 'design-deck', iconClass: 'icon-[mingcute--layout-line]', label: 'Design Deck', roles: ['dealer'] },
  { slug: 'analytics', iconClass: 'icon-[hugeicons--analytics-up]', label: 'Analytics', roles: ['dealer'] },
  { slug: 'pg-comparison', iconClass: 'icon-[hugeicons--analytics-up]', label: 'PG Comparison', roles: ['dealer'] },
  { slug: 'reckoner', iconClass: 'icon-[hugeicons--analytics-up]', label: 'Reckoner', roles: ['dealer'] },
  { slug: 'enquiry-form', iconClass: 'icon-[icon-park-outline--form-one]', label: 'Enquiry Form', roles: ['dealer'] },
  { slug: 'previews', iconClass: 'icon-[material-symbols--preview-outline]', label: 'Previews', roles: ['dealer'] },

  // Admin-visible options
  { slug: 'user-management', iconClass: 'icon-[lsicon--user-all-filled]', label: 'User Management', roles: ['admin'] },
   { slug: 'inventory-master-view', iconClass: 'icon-[lsicon--user-all-filled]', label: 'Inventory Master View', roles: ['admin'] },
  { slug: 'rules-configuration', iconClass: 'icon-[material-symbols--rule]', label: 'Rules Configuration', roles: ['admin'] },
  { slug: 'master-inventory', iconClass: 'icon-[ant-design--product-outlined]', label: 'Master Inventory', roles: ['admin'] },
  { slug: 'product-groups', iconClass: 'icon-[eos-icons--products-outlined]', label: 'Product Groups', roles: ['admin'] },
  { slug: '3d-models-configuration', iconClass: 'icon-[eos-icons--products-outlined]', label: '3D Models Configuration', roles: ['admin'] },
  { slug: 'pre-defined-configuration', iconClass: 'icon-[eos-icons--products-outlined]', label: 'Pre-defined Configuration', roles: ['admin'] },
  { slug: '2-factor-approval', iconClass: 'icon-[eos-icons--products-outlined]', label: '2 Factor Approval', roles: ['admin'] },
];

export default leftPanelFields;
