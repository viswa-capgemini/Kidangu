/**
 * API Service for DXF file operations
 */

const API_BASE_URL = '/api';

/**
 * Upload a DXF file and get parsed data
 * @param {File} file - The DXF file to upload
 * @param {Function} onProgress - Progress callback (0-100)
 * @returns {Promise<Object>} Parsed DXF data
 */
export async function uploadDxfFile(file, onProgress = null) {
    const formData = new FormData();
    formData.append('file', file);

    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        xhr.open('POST', `${API_BASE_URL}/dxf/upload`);

        // Track upload progress
        if (onProgress) {
            xhr.upload.addEventListener('progress', (event) => {
                if (event.lengthComputable) {
                    const progress = Math.round((event.loaded / event.total) * 100);
                    onProgress(progress);
                }
            });
        }

        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    const data = JSON.parse(xhr.responseText);
                    resolve(data);
                } catch (e) {
                    reject(new Error('Failed to parse response'));
                }
            } else {
                try {
                    const error = JSON.parse(xhr.responseText);
                    reject(new Error(error.detail || 'Upload failed'));
                } catch {
                    reject(new Error(`Upload failed with status ${xhr.status}`));
                }
            }
        };

        xhr.onerror = () => {
            reject(new Error('Network error occurred'));
        };

        xhr.send(formData);
    });
}

/**
 * Health check
 * @returns {Promise<Object>}
 */
export async function healthCheck() {
    const response = await fetch(`${API_BASE_URL}/health`);
    if (!response.ok) {
        throw new Error('API health check failed');
    }
    return response.json();
}
