/**
 * Canvas rendering utilities for DXF entities
 */

// ACI color index to RGB mapping
const ACI_COLORS = {
    0: '#000000',  // ByBlock
    1: '#FF0000',  // Red
    2: '#FFFF00',  // Yellow
    3: '#00FF00',  // Green
    4: '#00FFFF',  // Cyan
    5: '#0000FF',  // Blue
    6: '#FF00FF',  // Magenta
    7: '#FFFFFF',  // White
    8: '#808080',  // Dark Gray
    9: '#C0C0C0',  // Light Gray
    256: '#FFFFFF', // ByLayer
};

/**
 * Get color for an entity based on its color index and layer, with theme awareness
 * @param {number} colorIndex - ACI color index
 * @param {Object} layerColors - Map of layer names to colors
 * @param {string} layerName - Entity's layer name
 * @param {string} theme - Current UI theme ('light' or 'dark')
 * @returns {string} Hex color
 */
export function getEntityColor(colorIndex, layerColors, layerName, theme = 'dark') {
    let baseColor;

    if (colorIndex === 256 || colorIndex === undefined) {
        // ByLayer - use layer color
        baseColor = layerColors[layerName] || '#FFFFFF';
    } else if (colorIndex === 0) {
        // ByBlock - default to white/black based on theme
        baseColor = theme === 'dark' ? '#FFFFFF' : '#000000';
    } else {
        baseColor = ACI_COLORS[colorIndex] || `hsl(${(colorIndex * 137.508) % 360}, 70%, 50%)`;
    }

    // "Smart Color" logic for high-fidelity replication:
    // ACI 7 is strictly White/Black. In CAD software, it flips based on background.
    if (colorIndex === 7 || (colorIndex === 256 && baseColor.toUpperCase() === '#FFFFFF')) {
        return theme === 'dark' ? '#FFFFFF' : '#000000';
    }

    // Ensure sufficient contrast for other colors against light background
    if (theme === 'light' && baseColor.toUpperCase() === '#FFFFFF') {
        return '#000000';
    }

    return baseColor;
}

/**
 * Common DXF linetype patterns (multiples of scale)
 */
const LINETYPE_PATTERNS = {
    'CONTINUOUS': [],
    'DASHED': [10, 5],
    'HIDDEN': [5, 5],
    'CENTER': [20, 5, 5, 5],
    'DOT': [1, 5],
    'PHANTOM': [30, 5, 5, 5, 5, 5],
    'DASHDOT': [10, 5, 2, 5],
};

/**
 * Get line dash pattern for a linetype name
 */
export function getLineDash(linetype) {
    if (!linetype) return [];
    const name = linetype.toUpperCase();
    return LINETYPE_PATTERNS[name] || [];
}

/**
 * Get canvas line width from DXF lineweight (1/100mm)
 * Implements "Precision Weights" for small details
 */
export function getLineWidth(lineweight, transformScale) {
    // Convert 1/100mm to units
    const mmWidth = (lineweight && lineweight > 0) ? lineweight / 100 : 0.25; // Default to 0.25mm

    // Scale to canvas pixels
    const canvasWidth = mmWidth * transformScale * 0.5;

    // "Minimum Visual Weight" to ensure small architectural details (toilets, hinges) 
    // are visible even when zoomed out.
    return Math.max(0.6, canvasWidth);
}

/**
 * Transform a DXF coordinate to canvas coordinate
 */
export function transformPoint(point, transform) {
    if (!point) return { x: 0, y: 0 };

    // Scale and flip Y for canvas
    const x = (point.x - transform.offsetX) * transform.scale + transform.canvasOffsetX;
    const y = transform.canvasOffsetY - (point.y - transform.offsetY) * transform.scale;

    return { x, y };
}

/**
 * Draw a line entity
 */
export function drawLine(ctx, geometry, transform, color) {
    if (!geometry.start || !geometry.end) return;

    const start = transformPoint(geometry.start, transform);
    const end = transformPoint(geometry.end, transform);

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();
}

/**
 * Draw a circle entity
 */
export function drawCircle(ctx, geometry, transform, color) {
    if (!geometry.center || !geometry.radius) return;

    const center = transformPoint(geometry.center, transform);
    const radius = geometry.radius * transform.scale;

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.arc(center.x, center.y, radius, 0, Math.PI * 2);
    ctx.stroke();
}

/**
 * Draw an arc entity
 */
export function drawArc(ctx, geometry, transform, color) {
    if (!geometry.center || !geometry.radius) return;

    const center = transformPoint(geometry.center, transform);
    const radius = geometry.radius * transform.scale;

    // DXF angles are CCW from positive X-axis
    // Canvas angles are also from positive X-axis, but direction depends on Y-flip
    const startAngle = (-geometry.start_angle * Math.PI) / 180;
    const endAngle = (-geometry.end_angle * Math.PI) / 180;

    ctx.beginPath();
    ctx.strokeStyle = color;
    // Use anticlockwise=true because we flipped the Y-axis calculation in transformPoint
    ctx.arc(center.x, center.y, radius, startAngle, endAngle, true);
    ctx.stroke();
}

/**
 * Draw a polyline entity with support for bulges (curves)
 */
export function drawPolyline(ctx, geometry, transform, color) {
    if (!geometry.points || geometry.points.length < 2) return;

    ctx.beginPath();
    ctx.strokeStyle = color;

    const points = geometry.points;
    const firstPoint = transformPoint(points[0], transform);
    ctx.moveTo(firstPoint.x, firstPoint.y);

    for (let i = 0; i < points.length - 1; i++) {
        const p1 = points[i];
        const p2 = points[i + 1];
        const bulge = p1.bulge || 0;

        if (bulge === 0) {
            const pt2 = transformPoint(p2, transform);
            ctx.lineTo(pt2.x, pt2.y);
        } else {
            // Draw arc segment for bulge
            drawBulgeArc(ctx, p1, p2, bulge, transform);
        }
    }

    if (geometry.closed) {
        const pLast = points[points.length - 1];
        const pFirst = points[0];
        const bulge = pLast.bulge || 0;

        if (bulge === 0) {
            ctx.lineTo(firstPoint.x, firstPoint.y);
        } else {
            drawBulgeArc(ctx, pLast, pFirst, bulge, transform);
        }
        ctx.closePath();
    }

    ctx.stroke();
}

/**
 * Helper to draw an arc between two points based on a bulge value
 */
function drawBulgeArc(ctx, p1, p2, bulge, transform) {
    const b = bulge;
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const L = Math.sqrt(dx * dx + dy * dy);
    if (L === 0) return;

    // The angle between the chord and the tangent at the start point
    const alpha = 4 * Math.atan(b); // Included angle of the arc
    // Radius of the arc
    const R = Math.abs(L / (2 * Math.sin(alpha / 2)));

    // Distance from the chord midpoint to the arc center
    const h = (L / 2) * (1 - b * b) / (2 * b);

    // Chord midpoint
    const mx = (p1.x + p2.x) / 2;
    const my = (p1.y + p2.y) / 2;

    // Direction of the chord
    const ux = dx / L;
    const uy = dy / L;

    // Arc center (perpendicular to chord)
    const cx = mx - h * uy;
    const cy = my + h * ux;

    // Angles to start and end points from center
    const startAngle = Math.atan2(p1.y - cy, p1.x - cx);
    const endAngle = Math.atan2(p2.y - cy, p2.x - cx);

    const centerCanvas = transformPoint({ x: cx, y: cy }, transform);
    const radiusCanvas = R * transform.scale;

    // Determine direction
    const counterClockwise = bulge > 0;

    // Canvas arc is flipped because of coordinate system
    ctx.arc(centerCanvas.x, centerCanvas.y, radiusCanvas, -startAngle, -endAngle, counterClockwise);
}

/**
 * Draw an ellipse entity
 */
export function drawEllipse(ctx, geometry, transform, color) {
    if (!geometry.center || !geometry.major_axis) return;

    const center = transformPoint(geometry.center, transform);
    const radiusX = Math.sqrt(
        geometry.major_axis.x ** 2 + geometry.major_axis.y ** 2
    ) * transform.scale;
    const radiusY = radiusX * geometry.ratio;
    const rotation = Math.atan2(geometry.major_axis.y, geometry.major_axis.x);

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.ellipse(
        center.x, center.y,
        radiusX, radiusY,
        rotation,
        geometry.start_param,
        geometry.end_param
    );
    ctx.stroke();
}

/**
 * Draw a point entity
 */
export function drawPoint(ctx, geometry, transform, color) {
    if (!geometry.location) return;

    const point = transformPoint(geometry.location, transform);

    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.arc(point.x, point.y, 2, 0, Math.PI * 2);
    ctx.fill();
}

/**
 * Draw text entity
 */
export function drawText(ctx, geometry, transform, color) {
    if (!geometry.insert || !geometry.text) return;

    const point = transformPoint(geometry.insert, transform);
    const fontSize = geometry.height ? (geometry.height * transform.scale) :
        (geometry.char_height ? (geometry.char_height * transform.scale) : (12 * transform.scale));

    // Strip MTEXT formatting
    let cleanText = geometry.text
        .replace(/\{[^\}]*\}/g, '')
        .replace(/\\[A-Z0-9]+;/gi, '')
        .replace(/\\P/g, '\n');

    const lines = cleanText.split('\n');

    ctx.font = `${fontSize}px "Inter", "Roboto", sans-serif`;
    ctx.fillStyle = color;
    ctx.save();
    ctx.translate(point.x, point.y);

    // DXF rotation is counter-clockwise.
    // However, since our Y is flipped for canvas, CCW appears CW if not careful.
    // Text should be upright relative to the screen.
    ctx.rotate(-(geometry.rotation || 0) * Math.PI / 180);

    ctx.textBaseline = 'alphabetic';

    lines.forEach((line, index) => {
        // Since Y increases downwards on canvas, offset lines downwards
        const yOffset = index * fontSize * 1.2;
        ctx.fillText(line, 0, yOffset);
    });

    ctx.restore();
}

/**
 * Draw a solid/3dface entity
 */
export function drawSolid(ctx, geometry, transform, color) {
    if (!geometry.points || geometry.points.length < 3) return;

    const points = geometry.points.map(p => transformPoint(p, transform));

    ctx.beginPath();
    ctx.fillStyle = color + '40'; // Semi-transparent
    ctx.strokeStyle = color;

    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
}

/**
 * Draw spline entity (simplified as polyline through control points)
 */
export function drawSpline(ctx, geometry, transform, color) {
    if (!geometry.control_points || geometry.control_points.length < 2) return;

    const points = geometry.control_points.map(p => transformPoint(p, transform));

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.moveTo(points[0].x, points[0].y);

    // Simple curve through points
    for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
    }

    ctx.stroke();
}

/**
 * Draw dimension entity
 */
export function drawDimension(ctx, geometry, transform, color) {
    ctx.strokeStyle = color;
    ctx.fillStyle = color;

    // Draw dimension lines between defpoints
    if (geometry.defpoint && geometry.defpoint2) {
        const p1 = transformPoint(geometry.defpoint, transform);
        const p2 = transformPoint(geometry.defpoint2, transform);

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
    }

    if (geometry.defpoint && geometry.defpoint3) {
        const p1 = transformPoint(geometry.defpoint, transform);
        const p3 = transformPoint(geometry.defpoint3, transform);

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p3.x, p3.y);
        ctx.stroke();
    }

    // Draw dimension text
    if (geometry.text_midpoint && geometry.text) {
        const textPos = transformPoint(geometry.text_midpoint, transform);
        const fontSize = Math.max(10, 12 * transform.scale);
        ctx.font = `bold ${fontSize}px "Inter", sans-serif`;
        ctx.textAlign = 'center';
        ctx.save();
        ctx.translate(textPos.x, textPos.y);
        // Upright text orientation
        ctx.fillText(geometry.text, 0, 0);
        ctx.restore();
    }
}

/**
 * Draw leader entity
 */
export function drawLeader(ctx, geometry, transform, color) {
    if (!geometry.vertices || geometry.vertices.length < 2) return;

    const points = geometry.vertices.map(p => transformPoint(p, transform));

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.moveTo(points[0].x, points[0].y);

    for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.stroke();

    // Draw arrowhead at first point
    if (geometry.has_arrowhead && points.length >= 2) {
        const arrowSize = 8;
        const angle = Math.atan2(points[1].y - points[0].y, points[1].x - points[0].x);

        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.moveTo(points[0].x, points[0].y);
        ctx.lineTo(
            points[0].x + arrowSize * Math.cos(angle - Math.PI / 6),
            points[0].y + arrowSize * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
            points[0].x + arrowSize * Math.cos(angle + Math.PI / 6),
            points[0].y + arrowSize * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();
    }
}

/**
 * Draw a hatch entity with edge loops
 */
export function drawHatch(ctx, geometry, transform, color) {
    if (!geometry.paths || geometry.paths.length === 0) return;

    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = color + '33'; // 20% opacity fill
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;

    geometry.paths.forEach(path => {
        if (!path.points || path.points.length < 2) return;

        const first = transformPoint(path.points[0], transform);
        ctx.moveTo(first.x, first.y);

        for (let i = 1; i < path.points.length; i++) {
            const pt = transformPoint(path.points[i], transform);
            ctx.lineTo(pt.x, pt.y);
        }

        if (path.type === 'polyline') {
            ctx.closePath();
        }
    });

    ctx.fill();
    ctx.stroke();
    ctx.restore();
}

/**
 * Draw INSERT (block reference) - simplified as a marker
 */
export function drawInsert(ctx, geometry, transform, color) {
    if (!geometry.insert) return;

    const point = transformPoint(geometry.insert, transform);
    const size = 4;

    // Draw a small cross to mark block insertion point
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(point.x - size, point.y);
    ctx.lineTo(point.x + size, point.y);
    ctx.moveTo(point.x, point.y - size);
    ctx.lineTo(point.x, point.y + size);
    ctx.stroke();
}


/**
 * Main function to render an entity
 */
export function renderEntity(ctx, entity, transform, layerColors, visibleLayers, theme = 'dark', isSelected = false) {
    // Check if layer is visible
    if (!visibleLayers.has(entity.layer)) return;

    let baseColor = getEntityColor(entity.color, layerColors, entity.layer, theme);

    // High-fidelity Selection Glow
    if (isSelected) {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#3B82F6';
        ctx.lineWidth = getLineWidth(entity.lineweight, transform.scale) + 2;
        baseColor = '#3B82F6'; // Professional CAD selection blue
    }
    const geometry = entity.geometry;

    if (!geometry) return;

    // Set styles
    ctx.strokeStyle = baseColor;
    ctx.fillStyle = baseColor;
    ctx.lineWidth = getLineWidth(entity.lineweight, transform.scale);

    const dash = getLineDash(entity.linetype);
    ctx.setLineDash(dash.map(d => d * transform.scale));

    switch (geometry.type) {
        case 'LINE':
            drawLine(ctx, geometry, transform, baseColor);
            break;
        case 'CIRCLE':
            drawCircle(ctx, geometry, transform, baseColor);
            break;
        case 'ARC':
            drawArc(ctx, geometry, transform, baseColor);
            break;
        case 'LWPOLYLINE':
        case 'POLYLINE':
            drawPolyline(ctx, geometry, transform, baseColor);
            break;
        case 'ELLIPSE':
            drawEllipse(ctx, geometry, transform, baseColor);
            break;
        case 'POINT':
            drawPoint(ctx, geometry, transform, baseColor);
            break;
        case 'TEXT':
        case 'MTEXT':
            drawText(ctx, geometry, transform, baseColor);
            break;
        case 'SOLID':
        case '3DFACE':
            drawSolid(ctx, geometry, transform, baseColor);
            break;
        case 'SPLINE':
            drawSpline(ctx, geometry, transform, baseColor);
            break;
        case 'DIMENSION':
            drawDimension(ctx, geometry, transform, baseColor);
            break;
        case 'LEADER':
            drawLeader(ctx, geometry, transform, baseColor);
            break;
        case 'HATCH':
            drawHatch(ctx, geometry, transform, baseColor);
            break;
        case 'INSERT':
            drawInsert(ctx, geometry, transform, baseColor);
            break;
        default:
            break;
    }

    // Reset dash for next entity
    ctx.setLineDash([]);

    if (isSelected) {
        ctx.restore();
    }
}
