import React, { useState, useRef } from "react";
import { Stage, Layer, Line, Rect } from "react-konva";
import { MousePointer2, Move, Pen, Ruler } from "lucide-react";

const API = "http://localhost:9000/api/parse-dxf";

export default function App() {
  const stageRef = useRef(null);

  const [entities, setEntities] = useState([]);
  const [layers, setLayers] = useState([]);
  const [visibleLayers, setVisibleLayers] = useState(new Set());
  const [loading, setLoading] = useState(false);

  const [tool, setTool] = useState("select");
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  /* ================= SAFE BOUNDS ================= */

  function computeBounds(entities) {
    let minX = Infinity, minY = Infinity;
    let maxX = -Infinity, maxY = -Infinity;
    let found = false;

    entities.forEach(e => {
      const g = e;

      if (g.points?.length) {
        g.points.forEach(p => {
          if (Number.isFinite(p[0]) && Number.isFinite(p[1])) {
            minX = Math.min(minX, p[0]);
            minY = Math.min(minY, p[1]);
            maxX = Math.max(maxX, p[0]);
            maxY = Math.max(maxY, p[1]);
            found = true;
          }
        });
      }

      if (g.start && g.end) {
        [g.start, g.end].forEach(p => {
          if (Number.isFinite(p[0]) && Number.isFinite(p[1])) {
            minX = Math.min(minX, p[0]);
            minY = Math.min(minY, p[1]);
            maxX = Math.max(maxX, p[0]);
            maxY = Math.max(maxY, p[1]);
            found = true;
          }
        });
      }
    });

    return found ? { minX, minY, maxX, maxY } : null;
  }

  /* ================= LOAD DXF ================= */

  const loadDXF = async (file) => {
    setLoading(true);

    const fd = new FormData();
    fd.append("file", file);

    const res = await fetch(API, { method: "POST", body: fd });
    const data = await res.json();

    setEntities(data.entities);
    setLayers(data.layers);
    setVisibleLayers(new Set(data.layers));

    const bounds = computeBounds(data.entities);
    if (bounds) {
      const w = bounds.maxX - bounds.minX;
      const h = bounds.maxY - bounds.minY;
      const s = Math.min(900 / w, 600 / h);
      setScale(Number.isFinite(s) ? s : 1);
      setOffset({ x: -bounds.minX, y: -bounds.minY });
    } else {
      setScale(1);
      setOffset({ x: 0, y: 0 });
    }

    setLoading(false);
  };

  /* ================= ZOOM ================= */

  const handleWheel = (e) => {
    e.evt.preventDefault();
    const k = e.evt.deltaY > 0 ? 0.9 : 1.1;
    setScale(prev => Math.min(50, Math.max(0.1, prev * k)));
  };

  const safeScale = Number.isFinite(scale) ? scale : 1;
  const safeX = Number.isFinite(offset.x) ? offset.x * safeScale : 0;
  const safeY = Number.isFinite(offset.y) ? offset.y * safeScale : 0;

  const stageWidth = window.innerWidth - 256;
  const stageHeight = window.innerHeight - 48;

  /* ================= RENDER ================= */

  return (
    <div className="h-screen flex flex-col bg-gray-100">

      {/* TOP TOOLBAR */}
      <div className="h-12 bg-white border-b flex items-center px-3 gap-2">
        <button onClick={() => setTool("select")}><MousePointer2 /></button>
        <button onClick={() => setTool("pan")}><Move /></button>
        <button onClick={() => setTool("polyline")}><Pen /></button>
        <button onClick={() => setTool("measure")}><Ruler /></button>

        <input
          type="file"
          accept=".dxf"
          className="ml-auto text-sm"
          onChange={(e) => loadDXF(e.target.files[0])}
        />
      </div>

      <div className="flex flex-1">

        {/* LEFT PANEL */}
        <div className="w-64 bg-white border-r p-3 overflow-auto">
          <h3 className="font-semibold mb-2">Layers</h3>

          {layers.map(layer => (
            <label key={layer} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={visibleLayers.has(layer)}
                onChange={() => {
                  const v = new Set(visibleLayers);
                  v.has(layer) ? v.delete(layer) : v.add(layer);
                  setVisibleLayers(v);
                }}
              />
              {layer}
            </label>
          ))}
        </div>

        {/* CANVAS */}
        <div className="flex-1 relative bg-gray-50">
          {loading && (
            <div className="absolute inset-0 bg-white/80 z-10 flex items-center justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
            </div>
          )}

          <Stage
            ref={stageRef}
            width={stageWidth}
            height={stageHeight}
            scaleX={safeScale}
            scaleY={-safeScale}
            x={safeX}
            y={stageHeight - safeY}
            onWheel={handleWheel}
            draggable={tool === "pan"}
          >
            <Layer listening={false}>
              <Rect x={-10000} y={-10000} width={20000} height={20000} stroke="#e5e7eb" />
            </Layer>

            {layers.map(layer =>
              visibleLayers.has(layer) && (
                <Layer key={layer} listening={false}>
                  {entities
                    .filter(e => e.layer === layer)
                    .map(e => {
                      if (e.type === "POLYLINE" && e.points?.length) {
                        return (
                          <Line
                            key={e.id}
                            points={e.points.flatMap(p => [p[0], p[1]])}
                            stroke="black"
                            strokeWidth={1 / safeScale}
                          />
                        );
                      }

                      if (e.type === "LINE" && e.start && e.end) {
                        return (
                          <Line
                            key={e.id}
                            points={[e.start[0], e.start[1], e.end[0], e.end[1]]}
                            stroke="black"
                            strokeWidth={1 / safeScale}
                          />
                        );
                      }

                      return null;
                    })}
                </Layer>
              )
            )}
          </Stage>
        </div>
      </div>
    </div>
  );
}
