# DXF Viewer - Complete Setup Guide

A professional DXF file viewer for civil layouts with multiple file support, layer management, and 2D/3D viewing modes.

## 🚀 Features

- ✅ Multiple DXF file upload and management
- ✅ Layer visibility controls
- ✅ 2D plan view and 3D perspective view
- ✅ Smart color coding for civil layers (walls, doors, windows, etc.)
- ✅ Zoom, pan, and rotate controls
- ✅ Support for LINE, POLYLINE, LWPOLYLINE, CIRCLE, ARC, SPLINE, ELLIPSE
- ✅ Real-time rendering with Three.js

## 📋 Prerequisites

- Python 3.8 or higher
- Node.js 16 or higher
- npm or yarn

## 🔧 Installation

### Step 1: Backend Setup (Flask + ezdxf)

```bash
# Create a backend directory
mkdir dxf-backend
cd dxf-backend

# Install Python dependencies
pip install flask flask-cors ezdxf

# Create server.py file (use the code provided in flask-backend artifact)
```

### Step 2: Frontend Setup (React + Vite + Three.js)

```bash
# Create frontend project
npm create vite@latest dxf-viewer -- --template react
cd dxf-viewer

# Install dependencies
npm install

# Install additional packages
npm install three lucide-react
npm install -D tailwindcss postcss autoprefixer

# Initialize Tailwind CSS
npx tailwindcss init -p
```

### Step 3: Configure Frontend Files

Create/Update these files in your `dxf-viewer` directory:

1. **package.json** - Use the provided frontend-package-json artifact
2. **vite.config.js** - Use the provided vite-config artifact
3. **tailwind.config.js** - Use the provided tailwind-config artifact
4. **postcss.config.js** - Use the provided postcss-config artifact
5. **index.html** - Use the provided index-html artifact
6. **src/main.jsx** - Use the provided main-jsx artifact
7. **src/index.css** - Use the provided index-css artifact
8. **src/App.jsx** - Use the provided app-jsx artifact

## 🏃 Running the Application

### Terminal 1: Start Backend Server

```bash
cd dxf-backend
python server.py
```

You should see:
```
============================================================
DXF Parser Flask Server
============================================================
Server starting on http://localhost:9000
CORS enabled for all origins
Endpoints:
  - POST /api/parse-dxf (Upload DXF file)
  - GET  /api/health (Health check)
============================================================
 * Running on http://0.0.0.0:9000
```

### Terminal 2: Start Frontend Server

```bash
cd dxf-viewer
npm run dev
```

You should see:
```
  VITE v4.4.5  ready in 500 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

### Step 4: Open Browser

Navigate to: **http://localhost:3000**

## 🎯 Usage

1. **Upload Files**: Click "Upload DXF Files" or drag and drop .dxf files
2. **Switch Files**: Click on file names in the sidebar to switch between uploaded files
3. **Toggle Layers**: Click on layer names or eye icons to show/hide layers
4. **View Modes**: 
   - **2D View**: Top-down orthographic view (default for civil layouts)
   - **3D View**: Perspective view with rotation
5. **Navigation**:
   - **Drag**: Rotate (3D) or Pan (2D)
   - **Shift + Drag**: Pan in any mode
   - **Mouse Wheel**: Zoom in/out
   - **Reset Button**: Return to default view

## 🔍 Troubleshooting

### "Access to localhost was denied" Error

**Solution**: The backend code has been updated with proper CORS configuration:
```python
CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})
```

Also, the server runs on `0.0.0.0` instead of `localhost` to accept all connections.

### Files not displaying

1. Check browser console (F12) for errors
2. Verify Flask server is running on port 9000
3. Test backend: `curl http://localhost:9000/api/health`
4. Ensure CORS is properly configured

### Python dependencies missing

```bash
pip install --upgrade flask flask-cors ezdxf
```

### Frontend build errors

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

## 📁 Project Structure

```
dxf-project/
├── dxf-backend/
│   └── server.py                 # Flask backend server
│
└── dxf-viewer/                   # React frontend
    ├── index.html
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    ├── postcss.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx               # Main component
        └── index.css
```

## 🎨 Layer Color Coding

The viewer automatically assigns colors based on layer names:
- **Walls**: Blue (#1e40af)
- **Doors**: Green (#059669)
- **Windows**: Purple (#7c3aed)
- **Pillars/Columns**: Red (#dc2626)
- **Dimensions**: Gray (#6b7280)
- **Text**: Orange (#f59e0b)
- **Furniture**: Cyan (#0891b2)
- **Stairs**: Pink (#db2777)
- **Slabs**: Lime (#65a30d)
- **Beams**: Orange (#ea580c)
- **Plumbing**: Blue (#0284c7)
- **Electrical**: Yellow (#eab308)
- **HVAC**: Green (#16a34a)

## 🛠️ Technology Stack

- **Frontend**: React 18, Vite, Three.js r128, Tailwind CSS, Lucide Icons
- **Backend**: Python 3, Flask, ezdxf, Flask-CORS
- **Rendering**: WebGL via Three.js

## 📝 API Endpoints

### POST /api/parse-dxf
Upload and parse a DXF file

**Request**: multipart/form-data with 'file' field
**Response**: 
```json
{
  "entities": [...],
  "layer_count": 25,
  "filename": "floor_plan.dxf"
}
```

### GET /api/health
Health check endpoint

**Response**:
```json
{
  "status": "ok",
  "message": "Flask server is running"
}
```

## 📄 License

MIT License - feel free to use in your projects!

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify all dependencies are installed
3. Check browser console for errors
4. Ensure backend server is running

---

**Happy Viewing! 🎉**