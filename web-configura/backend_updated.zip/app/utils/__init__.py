"""Utility functions module"""
