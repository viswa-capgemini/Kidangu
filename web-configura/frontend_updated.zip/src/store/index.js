import { configureStore } from '@reduxjs/toolkit';
import dxfReducer from './slices/dxfSlice';
import uiReducer from './slices/uiSlice';

export const store = configureStore({
    reducer: {
        dxf: dxfReducer,
        ui: uiReducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: {
                // Ignore potentially non-serializable DXF data for performance
                ignoredActions: ['dxf/setDxfData'],
                ignoredPaths: ['dxf.data'],
            },
        }),
});
