import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    theme: 'light', // 'light' or 'dark'
    activeTool: 'pan', // 'select', 'pan'
    zoom: 1,
    panOffset: { x: 0, y: 0 },
    canvasSize: { width: 0, height: 0 },
    snapPoint: null, // { x, y, type: 'endpoint'|'midpoint'|'center' }
    measurePoints: [], // Array of world points for measurement
    sidebarVisible: true,
    isLoaded: false,
    fitToScreenCounter: 0,
};

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        setTheme: (state, action) => {
            state.theme = action.payload;
        },
        toggleTheme: (state) => {
            state.theme = state.theme === 'dark' ? 'light' : 'dark';
        },
        setActiveTool: (state, action) => {
            state.activeTool = action.payload;
        },
        setZoom: (state, action) => {
            state.zoom = action.payload;
        },
        setPanOffset: (state, action) => {
            state.panOffset = action.payload;
        },
        setCanvasSize: (state, action) => {
            state.canvasSize = action.payload;
        },
        // Intelligent Zoom (centers on canvas)
        zoomByFactor: (state, action) => {
            const factor = action.payload;
            const { width, height } = state.canvasSize;

            // If we don't have canvas size, just do a simple zoom
            if (width === 0 || height === 0) {
                state.zoom *= factor;
                return;
            }

            // Pivot point is center of canvas
            const pivotX = width / 2;
            const pivotY = height / 2;

            // Calculate how much the pan needs to shift to keep the center fixed
            const dx = (pivotX - (width / 2 + state.panOffset.x)) * (1 - factor);
            const dy = (pivotY - (height / 2 + state.panOffset.y)) * (1 - factor);

            state.zoom *= factor;
            state.panOffset.x += dx;
            state.panOffset.y += dy;
        },
        setSnapPoint: (state, action) => {
            state.snapPoint = action.payload;
        },
        addMeasurePoint: (state, action) => {
            state.measurePoints.push(action.payload);
        },
        clearMeasure: (state) => {
            state.measurePoints = [];
        },
        toggleSidebar: (state) => {
            state.sidebarVisible = !state.sidebarVisible;
        },
        setAppLoaded: (state, action) => {
            state.isLoaded = action.payload;
        },
        triggerFitToScreen: (state) => {
            state.fitToScreenCounter += 1;
        },
    },
});

export const {
    setTheme,
    toggleTheme,
    setActiveTool,
    setZoom,
    setPanOffset,
    setCanvasSize,
    zoomByFactor,
    setSnapPoint,
    addMeasurePoint,
    clearMeasure,
    toggleSidebar,
    setAppLoaded,
    triggerFitToScreen,
} = uiSlice.actions;

export default uiSlice.reducer;
