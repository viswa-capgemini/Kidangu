import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { uploadDxfFile as uploadDxfApi } from '../../services/api';

export const uploadDxf = createAsyncThunk(
    'dxf/upload',
    async ({ file, onProgress }, { rejectWithValue }) => {
        try {
            const response = await uploadDxfApi(file, onProgress);
            return response;
        } catch (error) {
            return rejectWithValue(error.message || 'Failed to upload DXF file');
        }
    }
);

const initialState = {
    data: null,
    loading: false,
    error: null,
    uploadProgress: 0,
    visibleLayers: [], // Array of layer names that are visible
    selectedLayer: null,
    selectedEntity: null,
    selectedEntities: [], // For multi-selection and grouping
};

const dxfSlice = createSlice({
    name: 'dxf',
    initialState,
    reducers: {
        setDxfData: (state, action) => {
            state.data = action.payload;
            state.visibleLayers = action.payload?.layers?.map(l => l.name) || [];
            state.loading = false;
            state.error = null;
        },
        toggleLayerVisibility: (state, action) => {
            const layerName = action.payload;
            if (state.visibleLayers.includes(layerName)) {
                state.visibleLayers = state.visibleLayers.filter(l => l !== layerName);
            } else {
                state.visibleLayers.push(layerName);
            }
        },
        setAllLayersVisibility: (state, action) => {
            const visible = action.payload;
            if (visible && state.data) {
                state.visibleLayers = state.data.layers.map(l => l.name);
            } else {
                state.visibleLayers = [];
            }
        },
        setSelectedLayer: (state, action) => {
            state.selectedLayer = action.payload;
        },
        setSelectedEntity: (state, action) => {
            state.selectedEntity = action.payload;
            if (action.payload) {
                state.selectedEntities = [action.payload];
            } else {
                state.selectedEntities = [];
            }
        },
        toggleSelectedEntity: (state, action) => {
            const entity = action.payload;
            if (!entity) return;

            const index = state.selectedEntities.findIndex(e => e.handle === entity.handle);
            if (index >= 0) {
                state.selectedEntities.splice(index, 1);
            } else {
                state.selectedEntities.push(entity);
            }
            state.selectedEntity = state.selectedEntities[state.selectedEntities.length - 1] || null;
        },
        clearSelection: (state) => {
            state.selectedEntity = null;
            state.selectedEntities = [];
        },
        setUploadProgress: (state, action) => {
            state.uploadProgress = action.payload;
        },
        resetDxfState: (state) => {
            return initialState;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(uploadDxf.pending, (state) => {
                state.loading = true;
                state.error = null;
                state.uploadProgress = 0;
            })
            .addCase(uploadDxf.fulfilled, (state, action) => {
                state.data = action.payload;
                state.visibleLayers = (action.payload.layers || []).map(l => l.name);
                state.loading = false;
                state.uploadProgress = 100;
            })
            .addCase(uploadDxf.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            });
    },
});

export const {
    setDxfData,
    toggleLayerVisibility,
    setAllLayersVisibility,
    setSelectedLayer,
    setSelectedEntity,
    toggleSelectedEntity,
    clearSelection,
    setUploadProgress,
    resetDxfState,
} = dxfSlice.actions;

export default dxfSlice.reducer;
