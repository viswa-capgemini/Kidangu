import React, { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useDropzone } from 'react-dropzone';
import { Upload, FileCode, AlertCircle, CheckCircle2 } from 'lucide-react';
import { uploadDxf, setUploadProgress } from '../../store/slices/dxfSlice';

const FileUpload = ({ forcedError }) => {
    const dispatch = useDispatch();
    const { loading, error: reduxError, uploadProgress } = useSelector((state) => state.dxf);
    const { theme } = useSelector((state) => state.ui);

    const displayError = forcedError || reduxError;

    const onDrop = useCallback((acceptedFiles) => {
        if (acceptedFiles.length > 0) {
            const file = acceptedFiles[0];
            dispatch(uploadDxf({
                file,
                onProgress: (progress) => dispatch(setUploadProgress(progress))
            }));
        }
    }, [dispatch]);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'application/dxf': ['.dxf'],
            'image/vnd.dxf': ['.dxf']
        },
        multiple: false,
        disabled: loading
    });

    return (
        <div className="w-full max-w-2xl slide-up">
            <div
                {...getRootProps()}
                className={`
          relative border-2 border-dashed rounded-3xl p-12 transition-all duration-300 flex flex-col items-center justify-center gap-6 cursor-pointer
          ${isDragActive ? 'border-brand bg-brand/5 scale-102' : 'border-zinc-200 dark:border-zinc-800 hover:border-brand/50 hover:bg-zinc-50 dark:hover:bg-zinc-900/50'}
          ${loading ? 'opacity-50 cursor-wait' : ''}
          glass
        `}
            >
                <input {...getInputProps()} />

                <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mb-2 shadow-2xl transition-transform duration-500 ${isDragActive ? 'scale-110' : ''}`}>
                    {loading ? (
                        <div className="w-full h-full rounded-2xl border-4 border-brand border-t-transparent animate-spin" />
                    ) : (
                        <div className="bg-brand text-white w-full h-full rounded-2xl flex items-center justify-center">
                            <Upload size={32} />
                        </div>
                    )}
                </div>

                <div className="text-center space-y-2">
                    <h2 className="text-2xl font-bold tracking-tight">
                        {isDragActive ? 'Drop the file here' : 'Explore your DXF'}
                    </h2>
                    <p className="text-secondary font-medium">
                        Drag and drop your civil layout drawings here, or <span className="text-brand">browse files</span>
                    </p>
                    <div className="flex items-center justify-center gap-4 pt-4">
                        <Badge label="DXF Only" icon={<FileCode size={12} />} />
                        <Badge label="Up to 100MB" icon={<CheckCircle2 size={12} />} />
                    </div>
                </div>

                {/* Upload Progress */}
                {loading && (
                    <div className="w-full max-w-sm mt-4 space-y-2">
                        <div className="flex justify-between text-xs font-bold uppercase tracking-wider text-secondary">
                            <span>Uploading File...</span>
                            <span>{uploadProgress}%</span>
                        </div>
                        <div className="h-2 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-brand transition-all duration-300"
                                style={{ width: `${uploadProgress}%` }}
                            />
                        </div>
                    </div>
                )}

                {/* Error Message */}
                {displayError && (
                    <div className="mt-4 p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 flex items-center gap-3 text-sm font-medium fade-in">
                        <AlertCircle size={18} />
                        <p>{displayError}</p>
                    </div>
                )}
            </div>

            <div className="mt-8 text-center text-[11px] font-bold text-zinc-400 uppercase tracking-[0.2em]">
                Professional CAD Extraction Engine
            </div>
        </div>
    );
};

const Badge = ({ label, icon }) => (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-secondary font-bold text-[10px] uppercase tracking-wider border border-zinc-200 dark:border-zinc-700/50">
        {icon}
        <span>{label}</span>
    </div>
);

export default FileUpload;
