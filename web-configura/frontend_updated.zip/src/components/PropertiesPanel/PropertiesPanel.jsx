import React from 'react';
import { useSelector } from 'react-redux';
import { Info, Layers, Maximize, Activity } from 'lucide-react';

const PropertiesPanel = () => {
    const { selectedEntity, selectedLayer, data: dxfData } = useSelector((state) => state.dxf);

    if (!selectedEntity && !selectedLayer) {
        return (
            <div className="h-full flex flex-col items-center justify-center p-8 text-secondary text-center">
                <div className="bg-tertiary p-4 rounded-full mb-4 opacity-50">
                    <Info size={40} />
                </div>
                <p className="font-medium">No selection</p>
                <p className="text-sm mt-2 opacity-70">Select an entity on the canvas or a layer to view its properties.</p>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col fade-in">
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2 font-semibold">
                <Activity size={18} className="text-brand" />
                <span>Inspector</span>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                {selectedEntity && (
                    <section className="space-y-3">
                        <h3 className="text-xs font-bold uppercase tracking-wider text-secondary flex items-center gap-2">
                            <Maximize size={14} />
                            Entity Details
                        </h3>
                        <div className="bg-zinc-50 dark:bg-zinc-900/50 rounded-lg p-3 border border-zinc-200 dark:border-zinc-800 space-y-2">
                            <PropertyRow label="Type" value={selectedEntity.entity_type} />
                            <PropertyRow label="Layer" value={selectedEntity.layer} />
                            <PropertyRow label="Status" value={selectedEntity.is_virtual ? 'Exploded Block' : 'Primary Entity'} />
                            <PropertyRow label="Color Index" value={selectedEntity.color} />
                            <PropertyRow label="Lineweight" value={selectedEntity.lineweight > 0 ? `${selectedEntity.lineweight / 100}mm` : 'Default'} />
                            <PropertyRow label="Linetype" value={selectedEntity.linetype} />
                            <PropertyRow label="Handle" value={selectedEntity.handle || 'N/A'} />

                            {selectedEntity.bbox && (
                                <>
                                    <div className="w-px h-2" />
                                    <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800/50">
                                        <PropertyRow
                                            label="BBox Width"
                                            value={`${(selectedEntity.bbox.max_x - selectedEntity.bbox.min_x).toFixed(4)} unidades`}
                                        />
                                        <PropertyRow
                                            label="BBox Height"
                                            value={`${(selectedEntity.bbox.max_y - selectedEntity.bbox.min_y).toFixed(4)} unidades`}
                                        />
                                    </div>
                                </>
                            )}

                            {selectedEntity.dimension_text && (
                                <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800/50">
                                    <PropertyRow label="Dim Text" value={selectedEntity.dimension_text} />
                                    <PropertyRow label="Dim Type" value={selectedEntity.dimension_type} />
                                </div>
                            )}
                        </div>

                        {/* Specific geometry info could go here */}
                        {selectedEntity.geometry && (
                            <div className="space-y-2 mt-4">
                                <p className="text-xs font-medium text-secondary">Geometry Data</p>
                                <div className="bg-zinc-50 dark:bg-zinc-900/50 rounded-lg p-2 font-mono text-[10px] break-all border border-zinc-200 dark:border-zinc-800 opacity-80">
                                    {JSON.stringify(selectedEntity.geometry).substring(0, 500)}...
                                </div>
                            </div>
                        )}
                    </section>
                )}

                {selectedLayer && (
                    <section className="space-y-3">
                        <h3 className="text-xs font-bold uppercase tracking-wider text-secondary flex items-center gap-2">
                            <Layers size={14} />
                            Layer Properties
                        </h3>
                        <div className="bg-zinc-50 dark:bg-zinc-900/50 rounded-lg p-3 border border-zinc-200 dark:border-zinc-800 space-y-2">
                            <PropertyRow label="Name" value={selectedLayer.name} />
                            <PropertyRow
                                label="Color"
                                value={
                                    <div className="flex items-center gap-2">
                                        <div
                                            className="w-3 h-3 rounded-full border border-black/10"
                                            style={{ backgroundColor: selectedLayer.rgb_color }}
                                        />
                                        <span>{selectedLayer.rgb_color}</span>
                                    </div>
                                }
                            />
                            <PropertyRow label="Linetype" value={selectedLayer.linetype} />
                            <PropertyRow label="Entities" value={selectedLayer.entity_count} />
                            <PropertyRow label="Locked" value={selectedLayer.is_locked ? 'Yes' : 'No'} />
                            <PropertyRow label="Frozen" value={selectedLayer.is_frozen ? 'Yes' : 'No'} />
                            <PropertyRow label="Off" value={selectedLayer.is_off ? 'Yes' : 'No'} />
                        </div>
                    </section>
                )}
            </div>
        </div>
    );
};

const PropertyRow = ({ label, value }) => (
    <div className="flex justify-between items-center text-sm py-1 border-b border-zinc-100 dark:border-zinc-800/50 last:border-0">
        <span className="text-secondary">{label}</span>
        <span className="font-medium text-right truncate pl-4">{value}</span>
    </div>
);

export default PropertiesPanel;
