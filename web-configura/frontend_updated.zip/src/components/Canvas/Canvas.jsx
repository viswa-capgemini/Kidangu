import React, { useRef, useEffect, useCallback, useState, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { renderEntity, transformPoint } from '../../utils/canvasRenderer';
import {
    setZoom,
    setPanOffset,
    setCanvasSize,
    setActiveTool,
    setSnapPoint,
    addMeasurePoint,
    clearMeasure
} from '../../store/slices/uiSlice';
import { setSelectedEntity, toggleSelectedEntity } from '../../store/slices/dxfSlice';

const Canvas = () => {
    const dispatch = useDispatch();
    const canvasRef = useRef(null);
    const containerRef = useRef(null);
    const requestRef = useRef();
    const needsRedraw = useRef(true);

    const { data: dxfData, visibleLayers, selectedEntities } = useSelector((state) => state.dxf);
    const { zoom, panOffset, activeTool, theme, snapPoint, measurePoints, fitToScreenCounter } = useSelector((state) => state.ui);

    const [isDragging, setIsDragging] = useState(false);
    const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
    const lastMouseWorldPos = useRef({ x: 0, y: 0 });

    const layerColors = useMemo(() => {
        if (!dxfData) return {};
        return dxfData.layers.reduce((acc, layer) => {
            acc[layer.name] = layer.rgb_color;
            return acc;
        }, {});
    }, [dxfData]);

    const visibleLayersSet = useMemo(() => new Set(visibleLayers), [visibleLayers]);
    const selectedHandlesSet = useMemo(() => new Set(selectedEntities.map(e => e.handle)), [selectedEntities]);

    // Single source of truth for transformations
    const currentTransform = useMemo(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !dxfData.extents) return null;

        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        const extents = dxfData.extents;

        // The scale is now directly controlled by the 'zoom' value from Redux
        // which we will set appropriately in fitToScreen
        const finalScale = zoom;

        const centerX = (extents.min_x + extents.max_x) / 2;
        const centerY = (extents.min_y + extents.max_y) / 2;

        return {
            scale: finalScale,
            offsetX: centerX,
            offsetY: centerY,
            canvasOffsetX: canvasWidth / 2 + panOffset.x,
            canvasOffsetY: canvasHeight / 2 + panOffset.y,
            canvasHeight: canvasHeight
        };
    }, [dxfData, zoom, panOffset]);

    // Conversion helper: Canvas to World
    const canvasToWorld = useCallback((x, y) => {
        if (!currentTransform) return { x: 0, y: 0 };
        const { scale, offsetX, offsetY, canvasOffsetX, canvasOffsetY } = currentTransform;
        return {
            x: (x - canvasOffsetX) / scale + offsetX,
            y: (canvasOffsetY - y) / scale + offsetY
        };
    }, [currentTransform]);

    // Conversion helper: World to Canvas
    const worldToCanvas = useCallback((wx, wy) => {
        if (!currentTransform) return { x: 0, y: 0 };
        const { scale, offsetX, offsetY, canvasOffsetX, canvasOffsetY } = currentTransform;
        return {
            x: (wx - offsetX) * scale + canvasOffsetX,
            y: canvasOffsetY - (wy - offsetY) * scale
        };
    }, [currentTransform]);

    const drawGrid = (ctx, canvasWidth, canvasHeight) => {
        if (!currentTransform) return;
        const gridSize = 100 * currentTransform.scale;
        if (gridSize < 10) return;

        ctx.save();
        ctx.translate(canvasWidth / 2 + panOffset.x, canvasHeight / 2 + panOffset.y);
        ctx.fillStyle = theme === 'dark' ? 'rgba(71, 85, 105, 0.2)' : 'rgba(0, 0, 0, 0.05)';

        const startX = -canvasWidth / 2 - Math.abs(panOffset.x) - gridSize;
        const endX = canvasWidth / 2 + Math.abs(panOffset.x) + gridSize;
        const startY = -canvasHeight / 2 - Math.abs(panOffset.y) - gridSize;
        const endY = canvasHeight / 2 + Math.abs(panOffset.y) + gridSize;

        for (let x = startX - (startX % gridSize); x < endX; x += gridSize) {
            for (let y = startY - (startY % gridSize); y < endY; y += gridSize) {
                ctx.beginPath();
                ctx.arc(x, y, 0.8, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        ctx.restore();
    };

    const render = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !currentTransform) return;

        if (!needsRedraw.current) {
            requestRef.current = requestAnimationFrame(render);
            return;
        }

        const ctx = canvas.getContext('2d');
        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        ctx.clearRect(0, 0, canvasWidth, canvasHeight);

        ctx.lineWidth = 1;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';

        drawGrid(ctx, canvasWidth, canvasHeight);

        if (dxfData.entities && dxfData.entities.length > 0) {
            dxfData.entities.forEach(entity => {
                const isSelected = selectedHandlesSet.has(entity.handle);
                renderEntity(ctx, entity, currentTransform, layerColors, visibleLayersSet, theme, isSelected);
            });
        }

        // Draw Snap Marker
        if (snapPoint) {
            const pt = worldToCanvas(snapPoint.x, snapPoint.y);

            ctx.save();
            ctx.strokeStyle = '#00FF00';
            ctx.lineWidth = 2;
            ctx.beginPath();
            if (snapPoint.type === 'endpoint') {
                ctx.rect(pt.x - 6, pt.y - 6, 12, 12);
            } else if (snapPoint.type === 'midpoint') {
                ctx.moveTo(pt.x, pt.y - 8);
                ctx.lineTo(pt.x - 8, pt.y + 6);
                ctx.lineTo(pt.x + 8, pt.y + 6);
                ctx.closePath();
            } else if (snapPoint.type === 'center') {
                ctx.arc(pt.x, pt.y, 7, 0, Math.PI * 2);
            }
            ctx.stroke();
            ctx.restore();
        }

        // Draw Measurement
        if (measurePoints.length > 0) {
            ctx.save();
            ctx.strokeStyle = theme === 'dark' ? '#60A5FA' : '#3B82F6';
            ctx.lineWidth = 2;
            ctx.setLineDash([5, 5]);

            const startPt = worldToCanvas(measurePoints[0].x, measurePoints[0].y);
            const endCoord = snapPoint || lastMouseWorldPos.current;

            if (endCoord) {
                const endPt = worldToCanvas(endCoord.x, endCoord.y);

                ctx.beginPath();
                ctx.moveTo(startPt.x, startPt.y);
                ctx.lineTo(endPt.x, endPt.y);
                ctx.stroke();

                const dist = Math.sqrt((measurePoints[0].x - endCoord.x) ** 2 + (measurePoints[0].y - endCoord.y) ** 2);

                ctx.font = 'bold 13px "Inter", sans-serif';
                const label = `${dist.toFixed(3)} units`;
                const textWidth = ctx.measureText(label).width;
                const midX = (startPt.x + endPt.x) / 2;
                const midY = (startPt.y + endPt.y) / 2;

                ctx.fillStyle = theme === 'dark' ? 'rgba(15, 23, 42, 0.9)' : 'rgba(255, 255, 255, 0.9)';
                ctx.beginPath();
                ctx.roundRect(midX - textWidth / 2 - 8, midY - 30, textWidth + 16, 24, 6);
                ctx.fill();

                ctx.fillStyle = theme === 'dark' ? '#F8FAFC' : '#0F172A';
                ctx.textAlign = 'center';
                ctx.fillText(label, midX, midY - 14);
            }
            ctx.restore();
        }

        needsRedraw.current = false;
        requestRef.current = requestAnimationFrame(render);
    }, [dxfData, visibleLayersSet, layerColors, selectedHandlesSet, currentTransform, theme, snapPoint, measurePoints, worldToCanvas]);

    useEffect(() => {
        requestRef.current = requestAnimationFrame(render);
        return () => cancelAnimationFrame(requestRef.current);
    }, [render]);

    useEffect(() => {
        const resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                const { width, height } = entry.contentRect;
                if (canvasRef.current) {
                    canvasRef.current.width = width;
                    canvasRef.current.height = height;
                    dispatch(setCanvasSize({ width, height }));
                    needsRedraw.current = true;
                }
            }
        });
        if (containerRef.current) resizeObserver.observe(containerRef.current);
        return () => resizeObserver.disconnect();
    }, [dispatch]);

    const handleMouseMove = (e) => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !currentTransform) return;

        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const worldPos = canvasToWorld(x, y);
        lastMouseWorldPos.current = worldPos;

        if (isDragging) {
            const dx = e.clientX - lastMousePos.x;
            const dy = e.clientY - lastMousePos.y;
            dispatch(setPanOffset({ x: panOffset.x + dx, y: panOffset.y + dy }));
            setLastMousePos({ x: e.clientX, y: e.clientY });
            needsRedraw.current = true;
        } else {
            const snapThreshold = 15 / currentTransform.scale;
            let bestSnap = null;
            let minDist = snapThreshold;

            dxfData.entities.forEach(entity => {
                if (!visibleLayersSet.has(entity.layer)) return;
                const geom = entity.geometry;
                if (!geom) return;

                const addSnap = (pt, type) => {
                    const d = Math.sqrt((worldPos.x - pt.x) ** 2 + (worldPos.y - pt.y) ** 2);
                    if (d < minDist) {
                        minDist = d;
                        bestSnap = { ...pt, type };
                    }
                };

                if (geom.type === 'LINE') {
                    addSnap(geom.start, 'endpoint');
                    addSnap(geom.end, 'endpoint');
                    addSnap({ x: (geom.start.x + geom.end.x) / 2, y: (geom.start.y + geom.end.y) / 2 }, 'midpoint');
                } else if (geom.type === 'CIRCLE' || geom.type === 'ARC' || geom.type === 'ELLIPSE') {
                    addSnap(geom.center, 'center');
                } else if (geom.type === 'LWPOLYLINE' || geom.type === 'POLYLINE') {
                    if (geom.points) {
                        geom.points.forEach(p => addSnap(p, 'endpoint'));
                        for (let i = 0; i < geom.points.length - 1; i++) {
                            addSnap({ x: (geom.points[i].x + geom.points[i + 1].x) / 2, y: (geom.points[i].y + geom.points[i + 1].y) / 2 }, 'midpoint');
                        }
                    }
                }
            });

            if (JSON.stringify(bestSnap) !== JSON.stringify(snapPoint)) {
                dispatch(setSnapPoint(bestSnap));
                needsRedraw.current = true;
            }
        }
    };

    const handleMouseDown = (e) => {
        if (activeTool === 'pan' || e.button === 1) {
            setIsDragging(true);
            setLastMousePos({ x: e.clientX, y: e.clientY });
            return;
        }

        const worldCoord = snapPoint || lastMouseWorldPos.current;

        if (activeTool === 'measure') {
            if (measurePoints.length === 0) {
                dispatch(addMeasurePoint(worldCoord));
            } else {
                dispatch(clearMeasure());
                dispatch(addMeasurePoint(worldCoord));
            }
            needsRedraw.current = true;
            return;
        }

        if (activeTool === 'select') {
            handleSelect(worldCoord, e.shiftKey);
        }
    };

    const handleMouseUp = () => setIsDragging(false);

    const handleWheel = (e) => {
        e.preventDefault();
        const multiplier = 1.15;
        const direction = e.deltaY > 0 ? 1 / multiplier : multiplier;

        const canvas = canvasRef.current;
        if (!canvas) return;
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        // Perform zoom toward cursor
        const worldAtMouse = canvasToWorld(mouseX, mouseY);
        const newZoom = Math.min(Math.max(zoom * direction, 0.001), 5000);

        dispatch(setZoom(newZoom));

        // Re-calculate pan to keep worldAtMouse at (mouseX, mouseY)
        // This math is integrated into the next render via currentTransform useMemo
        // but for smooth feel we can estimate here or just let Redux flow.
        needsRedraw.current = true;
    };

    const handleSelect = (worldCoord, isMulti = false) => {
        if (!dxfData || !worldCoord || !currentTransform) return;

        const { scale } = currentTransform;
        const thresholdWorld = 15 / scale;

        let closestEntity = null;
        let minDistance = thresholdWorld;

        dxfData.entities.forEach(entity => {
            if (!visibleLayersSet.has(entity.layer)) return;
            const geom = entity.geometry;
            if (!geom) return;

            let dist = Infinity;
            if (geom.type === 'LINE') dist = distToSegment(worldCoord, geom.start, geom.end);
            else if (geom.type === 'CIRCLE' || geom.type === 'ARC') dist = Math.abs(Math.sqrt((worldCoord.x - geom.center.x) ** 2 + (worldCoord.y - geom.center.y) ** 2) - geom.radius);
            else if (geom.type === 'LWPOLYLINE' || geom.type === 'POLYLINE') {
                if (geom.points) {
                    for (let i = 0; i < geom.points.length - 1; i++) {
                        dist = Math.min(dist, distToSegment(worldCoord, geom.points[i], geom.points[i + 1]));
                    }
                }
            }

            if (dist < minDistance) {
                minDistance = dist;
                closestEntity = entity;
            }
        });

        if (isMulti) dispatch(toggleSelectedEntity(closestEntity));
        else dispatch(setSelectedEntity(closestEntity));
        needsRedraw.current = true;
    };

    function distToSegment(p, v, w) {
        const l2 = (v.x - w.x) ** 2 + (v.y - w.y) ** 2;
        if (l2 === 0) return Math.sqrt((p.x - v.x) ** 2 + (p.y - v.y) ** 2);
        let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        t = Math.max(0, Math.min(1, t));
        return Math.sqrt((p.x - (v.x + t * (w.x - v.x))) ** 2 + (p.y - (v.y + t * (w.y - v.y))) ** 2);
    }

    const fitToScreen = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas || !dxfData || !dxfData.extents) return;

        const { width: canvasWidth, height: canvasHeight } = canvas;
        const { width: worldWidth, height: worldHeight, min_x, max_x, min_y, max_y } = dxfData.extents;

        const margin = 80;
        const availableWidth = canvasWidth - margin * 2;
        const availableHeight = canvasHeight - margin * 2;

        if (availableWidth <= 0 || availableHeight <= 0) return;

        const scaleX = availableWidth / worldWidth;
        const scaleY = availableHeight / worldHeight;
        const newZoom = Math.min(scaleX, scaleY);

        dispatch(setZoom(newZoom));
        dispatch(setPanOffset({ x: 0, y: 0 }));
        needsRedraw.current = true;
    }, [dispatch, dxfData]);

    // Auto-fit on load
    useEffect(() => {
        if (dxfData && dxfData.extents) {
            // Small delay to ensure canvas size is updated
            const timer = setTimeout(() => {
                fitToScreen();
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [dxfData, fitToScreen]);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === 'v') dispatch(setActiveTool('select'));
            if (e.key === 'h') dispatch(setActiveTool('pan'));
            if (e.key === 'm') dispatch(setActiveTool('measure'));
            if (e.key === 'Escape') {
                dispatch(setActiveTool('select'));
                dispatch(clearMeasure());
                dispatch(setSelectedEntity(null));
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [dispatch]);

    useEffect(() => {
        if (fitToScreenCounter > 0) {
            fitToScreen();
        }
    }, [fitToScreenCounter, fitToScreen]);

    return (
        <div ref={containerRef} className="w-full h-full overflow-hidden touch-none relative"
            style={{ backgroundColor: '#F8FAFC' }}>
            <canvas
                ref={canvasRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onWheel={handleWheel}
                className="block cursor-crosshair"
            />
            {!dxfData && (
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-zinc-400 font-medium bg-white/5 dark:bg-black/20 px-6 py-3 rounded-full backdrop-blur-sm border border-zinc-200/10">
                        Upload a DXF to start exploring
                    </div>
                </div>
            )}
        </div>
    );
};

export default Canvas;
