export const componentGroups = [
    "Structural Components",
    "Level Accessories",
    "Rack Accessories",
    "Catwalk Accessories",
    "Material Handling Equipment(MHE)",
    "Stock Keeping Unit(SKU)",
    "Civil Layout Accessories",
    "Rack Full sample Assembly"
];

export const componentTypes = {
    "Structural Components": [
        "Upright", "Beams", "Beams+Cleat", "Beam Connector", "Sigma Beams", "Shuttle Beams",
        "Horizontal Bracing", "Diagonal Bracing", "Bracing Spacer", "Base plate",
        "Base plate with Jack bolt", "Shim", "Cement pad", "Stiffeners", "Bottom Stiffeners",
        "Splice", "Rear Splice"
    ],
    "Level Accessories": [
        "Decking panel", "Grating Decking panel", "Panel", "Shelf Panel", "Shelf Panel stiffener",
        "Shelf Panel stopper", "Catwalk panels", "Panel support Bar", "Pallet Stopper",
        "Fixed divider", "Mid mesh divider", "Adjustable divider", "Strip type divider",
        "Tube divider", "Fork Entry Bar", "GOH bays", "Guided Type Pallet Support",
        "P&D Station", "Underpass Rear Mesh", "Drum Caddle ", "Pallet", "Plan Bracing",
        "Pallet Rail", "Pallet Guide", "Entry Arm", "Mid support Arm"
    ],
    "Rack Accessories": [
        "Upright Guard", "Upright Connector (G50)", "Upright deflector", "Upright protector",
        "Row guard", "Mesh Cladding", "Row Connector", "Back Tie Rod", "Wall connector",
        "Tie Beam", "Sign board", "Nylon Netting", "Stability Beam", "Boltless stability beam",
        "Mezzanine column guard", "Cross Ties & Turn buckle", "Cross bracing cleat",
        "Knee bracing", "Pheripery Mesh cldding", "Chequered plate", "Threaded pipe",
        "End Cladding G50", "Rear Cladding G50", "Inner Cladding G50"
    ],
    "Catwalk Accessories": [
        "Walkway panel", "Gap panel", "Column gap panel", "Panel fixing clamp",
        "Angle welded beam GSB", "Tie beams", "Tie beams+PSB", "Cross Aisle beams",
        "Cross Aisle beams+PSB", "PSB Beams", "Beam L-Angle", "Joist Beam", "J-Clamp ",
        "Cross Aisle Channel", "Cross Aisle Channel Splice", "OH Stability beam Hem+",
        "Kick plate", "Aisle beading", "Joist beam end cover", "Formed Angle",
        "Catwalk Support bracket", "Chequered plate", "Chequered plate for VRC",
        "VRC tie beams", "VRC Cross aisle beams", "Picking Aisle Channel (G50)",
        "Cross Aisle channel (G50)", "Angle welded beam (Hem+)", "Railing Pipe and accessories"
    ],
    "Material Handling Equipment(MHE)": [
        "Stacker", "Forklift", "Articulated forklift", "Reach truck", "HPT", "Trolley",
        "Tow tractor", "Double deep Reach truch", "TSP"
    ],
    "Stock Keeping Unit(SKU)": [
        "Pallets", "Bins", "Crates", "Gunny bags", "Loose items"
    ],
    "Civil Layout Accessories": [
        "Aisle Ties", "Sliding gate", "Swing gate", "VRC", "Spiral chute", "Gravity chute",
        "Conveyors", "Vertiflow", "Staircase", "MHE Stopper", "Bracing tower"
    ],
    "Rack Full sample Assembly": []
};

export const modelTypes = {
    "Upright": ["UPRIGHT G", "UPRIGHT GX", "UPRIGHT GXL"],
    "Beams": ["BEAM GBX", "BEAM GBHX", "BEAM HEM+", "BEAM GSB"],
    "Horizontal Bracing": ["HORZ BRAC-G50", "HORZ BRAC-GLX", "HORZ BRAC-GX"],
    "Diagonal Bracing": ["DIAG BRAC-GLX", "DIAG BRAC-GX"],
    "Decking panel": ["HD 6B RF PANEL(GSB)", "HD 6B FLAT END PANEL", "RF 4B PLAIN PANEL", "4B PANEL"],
    "Panel support Bar": ["Chnl 4B PSB", "PLTSUPBAR WLD"],
    "Tie Beam": ["TIE BM HEM+"],
    "Angle welded beam GSB": ["Angle Welded Beam GSB"],
    "Cross Aisle Channel": ["Chnl CA X65"]
};

export const colors = [
    "NONE", "Sky Blue-SB", "Deep Orange-OR", "Galvanised-GA", "Graphite Grey-GG",
    "GREY", "LG+GG", "Light Grey-LG", "Orange", "Oxford Blue-OB",
    "PP (Light Grey)-LG", "RAL 2004", "RAL 7035-LG", "SHELL WHITE-SW",
    "Yellow-YE", "Yellow (RAL 1006)-YE", "GREEN PALVS", "Foam", "Acrylic",
    "Plastic", "RUBBER", "Nylon", "STD"
];

export const GlobalSettings = {
    // UPRIGHT GX & GXL
    UPRIGHT_MIN_LENGTH: 1500,
    UPRIGHT_MAX_LENGTH: 12000,
    UPRIGHT_STEP_VALUE: 100,
    UPRIGHT_ThicknessValues: [1.2, 1.6, 1.8, 2.0, 2.5, 3.15],
    UPRIGHT_widthValues: [50, 70, 90, 110, 120],

    // UPRIGHT G Series
    UPRIGHT_G_ThicknessValues: [0.8, 1.0, 1.2],
    UPRIGHT_G_MIN_LENGTH: 1495,
    UPRIGHT_G_MAX_LENGTH: 5995,
    UPRIGH_G_STEP_VALUE: 100,

    // Beam
    BEAM_MIN_LENGTH: 1000,
    BEAM_MAX_LENGTH: 4000,
    BEAM_STEP_VALUE: 100,
    BEAM_ThicknessValues: [1.0, 1.2, 1.5],
    LIP_CNT_MIN_LENGTH: 2,
    LIP_CNT_MAX_LENGTH: 5,
    LIP_CNT_STEP_VALUE: 1,

    // HorzBracing
    HORZBRAC_MIN_LENGTH: 100,
    HORZBRAC_MAX_LENGTH: 1500,
    HORZBRAC_STEP_VALUE: 1,
    HORZBRAC_ThicknessValues: [1.2, 1.4],
    HORZBRAC_MIN_DEPTH: 500,
    HORZBRAC_MAX_DEPTH: 1500,
    HORZBRAC_STEP_DEPTH: 50,

    // DIA Bracing
    DIAGBRAC_MIN_LENGTH: 100,
    DIAGBRAC_MAX_LENGTH: 1500,
    DIAGBRAC_STEP_VALUE: 1,
    DIAGBRAC_ThicknessValues: [1.2, 1.4],
    DIAGBRAC_MIN_DEPTH: 500,
    DIAGBRAC_MAX_DEPTH: 1500,
    DIAGBRAC_STEP_DEPTH: 50,

    // HD 6B RF PANEL(GSB)
    HD6BRF_PANEL_MIN_WIDTH: 150,
    HD6BRF_PANEL_MAX_WIDTH: 300,
    HD6BRF_PANEL_STEP_WIDTH: 50,
    HD6BRF_PANEL_MIN_LENGTH: 600,
    HD6BRF_PANEL_MAX_LENGTH: 1500,
    HD6BRF_PANEL_STEP_VALUE: 50,
    HD6BRF_PANEL_ThicknessValues: [0.6, 0.7, 0.8, 1.0],
    HD6BRF_PANEL_MIN_DEPTH: 500,
    HD6BRF_PANEL_MAX_DEPTH: 1500,
    HD6BRF_PANEL_STEP_DEPTH: 50,
    HD6BRF_PANEL_MIN_HEIGHT: 500, // Note: VB said 500 min, 300 max which is weird, but I'll follow it
    HD6BRF_PANEL_MAX_HEIGHT: 300,
    HD6BRF_PANEL_STEP_HEIGHT: 50,

    // HD 6B FLAT END PANEL
    HD6B_FLAT_END_PANEL_MIN_WIDTH: 200,
    HD6B_FLAT_END_PANEL_MAX_WIDTH: 300,
    HD6B_FLAT_END_PANEL_STEP_WIDTH: 100,
    HD6B_FLAT_END_PANEL_MIN_LENGTH: 800,
    HHD6B_FLAT_END_PANEL_MAX_LENGTH: 1200,
    HD6B_FLAT_END_PANEL_STEP_VALUE: 200,
    HD6B_FLAT_END_PANEL_ThicknessValues: [1.2, 1.6],
    HD6B_FLAT_END_PANEL_MIN_DEPTH: 500,
    HD6B_FLAT_END_PANEL_MAX_DEPTH: 1500,
    HD6B_FLAT_END_PANEL_STEP_DEPTH: 50,
    HD6B_FLAT_END_PANEL_MIN_HEIGHT: 500,
    HD6B_FLAT_END_PANEL_MAX_HEIGHT: 300,
    HD6B_FLAT_END_PANEL_STEP_HEIGHT: 50,

    // RF 4B PLAIN PANEL
    RF4B_PLAIN_PANEL_MIN_WIDTH: 150,
    RF4B_PLAIN_PANEL_MAX_WIDTH: 250,
    RF4B_PLAIN_PANEL_STEP_WIDTH: 50,
    RF4B_PLAIN_PANEL_MIN_LENGTH: 900,
    RF4B_PLAIN_PANEL_MAX_LENGTH: 3000,
    RF4B_PLAIN_PANEL_STEP_VALUE: 1,
    RF4B_PLAIN_PANEL_ThicknessValues: [1.2],
    RF4B_PLAIN_PANEL_MIN_DEPTH: 500,
    RF4B_PLAIN_PANEL_MAX_DEPTH: 1500,
    RF4B_PLAIN_PANEL_STEP_DEPTH: 50,
    RF4B_PLAIN_PANEL_MIN_HEIGHT: 500,
    RF4B_PLAIN_PANEL_MAX_HEIGHT: 300,
    RF4B_PLAIN_PANEL_STEP_HEIGHT: 50,

    // 4B PANEL
    PANEL_4B_MIN_WIDTH: 20,
    PANEL_4B_MAX_WIDTH: 100,
    PANEL_4B_STEP_WIDTH: 1,
    PANEL_4BL_MIN_LENGTH: 1000,
    PANEL_4B_LENGTH: 3000,
    PANEL_4BL_STEP_VALUE: 100,
    PANEL_4BL_ThicknessValues: [1.2, 1.5, 2.0],
    PANEL_4BL_MIN_DEPTH: 500,
    PANEL_4BL_MAX_DEPTH: 1500,
    PANEL_4B_STEP_DEPTH: 50,
    PANEL_4B_MIN_HEIGHT: 10,
    PANEL_4BL_MAX_HEIGHT: 50,
    PANEL_4B_STEP_HEIGHT: 1,

    // Chnl_4B_PanelSupportBar
    CHNL_4B_PSB_MIN_WIDTH: 20,
    PCHNL_4B_PSB_MAX_WIDTH: 100,
    CHNL_4B_PSB_STEP_WIDTH: 1,
    CHNL_4B_PSB_MIN_LENGTH: 600,
    CHNL_4B_PSB_MAX_LENGTH: 1500,
    CHNL_4B_PSB_STEP_VALUE: 50,
    CHNL_4B_PSB_ThicknessValues: [1.6],
    CHNL_4B_PSBL_MIN_DEPTH: 500,
    CHNL_4B_PSB_MAX_DEPTH: 1500,
    CHNL_4B_PSB_STEP_DEPTH: 50,
    CHNL_4B_PSB_MIN_HEIGHT: 48,
    CHNL_4B_PSB_MAX_HEIGHT: 48,
    CHNL_4B_PSB_STEP_HEIGHT: 1,

    // Welded PanelSupportBar
    PLT_SUPBAR_WLD_MIN_LENGTH: 600,
    PLT_SUPBAR_WLD_MAX_LENGTH: 1200,
    PLT_SUPBAR_WLD_STEP_LENGTH: 50,
    PLT_SUPBAR_WLD_ThicknessValues: [1.2, 1.5, 2, 2.5, 3.15],

    // TIE BEAM HEM+
    TIE_BEAMHEM__MIN_LENGTH: 900,
    TIE_BEAMHEM_MAX_LENGTH: 4500,
    TIE_BEAMHEM_STEP_VALUE: 100,
    TIE_BEAMHEML_ThicknessValues: [1.5],
    TIE_BEAMHEM_MIN_HEIGHT: 110,
    TIE_BEAMHEM_MAX_HEIGHT: 110,
    TIE_BEAMHEM_STEP_HEIGHT: 1,

    // Angle Welded Beam GSB
    ANGLE_WELDED_BEAM_PSB_ThicknessValues: [1.5],

    // Cross Aisle Channel
    ChnlCAX65_ThicknessValues: [1.5]
};
