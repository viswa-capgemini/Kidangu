import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Routes, Route } from 'react-router-dom';
import { setAppLoaded } from './store/slices/uiSlice';

import Header from './components/Header/Header';
import Toolbar from './components/Toolbar/Toolbar';
import Explorer from './components/LayerPanel/LayerPanel';
import Canvas from './components/Canvas/Canvas';
import PropertiesPanel from './components/PropertiesPanel/PropertiesPanel';
import FileUpload from './components/FileUpload/FileUpload';
import MasterInventory from './pages/MasterInventory';

// DXF Viewer Page Component
const DXFViewerPage = () => {
  const { theme, sidebarVisible } = useSelector((state) => state.ui);
  const { data: dxfData, loading: dxfLoading } = useSelector((state) => state.dxf);

  // If no DXF, loading, or parsing failed, show upload screen
  if (!dxfData || dxfLoading || dxfData.success === false) {
    return (
      <div className={`min-h-screen ${theme === 'dark' ? 'bg-zinc-950' : 'bg-white'}`}>
        <Header />
        <main className="flex items-center justify-center p-8 h-[calc(100vh-64px)]">
          <FileUpload forcedError={dxfData?.success === false ? dxfData.message : null} />
        </main>
      </div>
    );
  }

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${theme === 'dark' ? 'dark' : ''}`}>
      <Header />

      <div className="flex flex-1 relative overflow-hidden bg-primary">
        {/* Left Pane - Explorer */}
        <aside
          className={`w-72 border-r border-zinc-200 dark:border-zinc-800 transition-all duration-300 z-10 glass
            ${sidebarVisible ? 'translate-x-0' : '-translate-x-full fixed'}`}
        >
          <Explorer />
        </aside>

        {/* Center Pane - Canvas Viewer */}
        <main className="flex-1 relative overflow-hidden cad-grid">
          <Canvas />

          {/* Bottom Center Toolbar */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 slide-up">
            <Toolbar />
          </div>
        </main>

        {/* Right Pane - Properties */}
        <aside className="w-80 border-l border-zinc-200 dark:border-zinc-800 glass z-10">
          <PropertiesPanel />
        </aside>
      </div>
    </div>
  );
};

const App = () => {
  const dispatch = useDispatch();
  const { theme } = useSelector((state) => state.ui);

  // Apply theme to body
  useEffect(() => {
    if (theme === 'dark') {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    dispatch(setAppLoaded(true));
  }, [dispatch]);

  return (
    <Routes>
      <Route path="/" element={<DXFViewerPage />} />
      <Route path="/master-inventory" element={<MasterInventory />} />
    </Routes>
  );
};

export default App;
