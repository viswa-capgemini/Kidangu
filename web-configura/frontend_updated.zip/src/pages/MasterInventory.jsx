import React, { useState, useEffect, useRef } from 'react';
import {
    Upload,
    FileUp,
    Link2,
    Search,
    Filter,
    Download,
    Plus,
    Edit,
    Trash2,
    Save,
    X,
    Eye,
    Package,
    Settings,
    BarChart3,
    Grid3x3,
    Image as ImageIcon,
    File,
    ChevronDown,
    ArrowLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';
import {
    componentGroups,
    componentTypes,
    modelTypes,
    colors,
    GlobalSettings
} from '../data/inventoryData';

const MasterInventory = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [imageFile, setImageFile] = useState(null);
    const [activeTab, setActiveTab] = useState('form');
    const [showAddMenu, setShowAddMenu] = useState(false);
    const addMenuRef = useRef(null);

    // Form State
    const [formData, setFormData] = useState({
        componentGroup: componentGroups[0],
        componentType: '',
        modelType: '',
        colour: colors[0],
        gfaInfo: 'GFA',
        powderCode: 'PNM',
        powderType: 'Epoxy',
        powderWeight: 'GNM',
        cbm: '',
        cost: '',
        status: 'Active',
        width: '',
        length: '',
        thickness: '',
        depth: '',
        height: '10',
        weight: '',
        drawingNo: '',
        revNo: '',
        unspcCode: '',
        shortDescription: '',
        description: '',
        longDescription: '',
        kFactor: '40',
        linkUpright: false,
        lipConnectorCount: '2'
    });

    const [selectedSolution, setSelectedSolution] = useState({ type: '', value: '' });
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState(null); // { success: boolean, message: string }
    const [rawFiles, setRawFiles] = useState({ glb: null, image: null });

    // Dependent Options State
    const [availableTypes, setAvailableTypes] = useState([]);
    const [availableModels, setAvailableModels] = useState([]);
    const [availableThickness, setAvailableThickness] = useState([]);
    const [availableLengths, setAvailableLengths] = useState([]);
    const [availableWidths, setAvailableWidths] = useState([]);

    // Range helper
    const getRange = (min, max, step) => {
        const res = [];
        if (!min && !max) return [];
        let start = min;
        let end = max;
        if (start > end) { [start, end] = [end, start]; }
        for (let i = start; i <= end; i += step) {
            res.push(i);
        }
        return res;
    };

    // Logic: When Group changes
    const onGroupChange = (group) => {
        const types = componentTypes[group] || [];
        setAvailableTypes(types);
        const firstType = types[0] || '';
        setFormData(prev => ({ ...prev, componentGroup: group, componentType: firstType }));
        onTypeChange(firstType);
    };

    // Logic: When Type changes
    const onTypeChange = (type) => {
        const models = modelTypes[type] || [];
        setAvailableModels(models);
        const firstModel = models[0] || '';
        setFormData(prev => ({ ...prev, componentType: type, modelType: firstModel }));
        onModelChange(firstModel, type);
    };

    // Logic: When Model changes
    const onModelChange = (model, type = formData.componentType) => {
        let thickness = [];
        let length = [];
        let width = [];

        if (type === 'Upright') {
            if (model === 'UPRIGHT G') {
                thickness = GlobalSettings.UPRIGHT_G_ThicknessValues;
                length = getRange(GlobalSettings.UPRIGHT_G_MIN_LENGTH, GlobalSettings.UPRIGHT_G_MAX_LENGTH, GlobalSettings.UPRIGH_G_STEP_VALUE);
                width = [50];
            } else {
                thickness = GlobalSettings.UPRIGHT_ThicknessValues;
                length = getRange(GlobalSettings.UPRIGHT_MIN_LENGTH, GlobalSettings.UPRIGHT_MAX_LENGTH, GlobalSettings.UPRIGHT_STEP_VALUE);
                width = GlobalSettings.UPRIGHT_widthValues;
            }
        } else if (type === 'Beams') {
            thickness = GlobalSettings.BEAM_ThicknessValues;
            length = getRange(GlobalSettings.BEAM_MIN_LENGTH, GlobalSettings.BEAM_MAX_LENGTH, GlobalSettings.BEAM_STEP_VALUE);
        } else if (model === 'HD 6B RF PANEL(GSB)') {
            width = getRange(GlobalSettings.HD6BRF_PANEL_MIN_WIDTH, GlobalSettings.HD6BRF_PANEL_MAX_WIDTH, GlobalSettings.HD6BRF_PANEL_STEP_WIDTH);
            length = getRange(GlobalSettings.HD6BRF_PANEL_MIN_LENGTH, GlobalSettings.HD6BRF_PANEL_MAX_LENGTH, GlobalSettings.HD6BRF_PANEL_STEP_VALUE);
            thickness = GlobalSettings.HD6BRF_PANEL_ThicknessValues;
        }

        setAvailableThickness(thickness);
        setAvailableLengths(length);
        setAvailableWidths(width);

        setFormData(prev => ({
            ...prev,
            modelType: model,
            thickness: thickness[0]?.toString() || '',
            length: length[0]?.toString() || '',
            width: width[0]?.toString() || '',
        }));
    };

    // Description Logic
    useEffect(() => {
        const { modelType, componentType, thickness, length, width, colour, lipConnectorCount } = formData;
        if (!modelType || !thickness || !length) return;

        const colorCode = colour.includes('-') ? colour.split('-').pop() : colour;
        let sDesc = '';
        let desc = '';
        let dwg = '';
        let rev = '';

        if (componentType === 'Upright') {
            if (modelType === 'UPRIGHT G') {
                if (thickness === '0.8') { dwg = 'IS/BL/S3/101'; rev = 'R2'; }
                else if (thickness === '1') {
                    if (colour.includes('RAL 7035')) { dwg = 'IS/BM/S3/291'; rev = 'R1'; }
                    else { dwg = 'IS/BL/S3/101'; rev = 'R2'; }
                }
            }
            sDesc = `${modelType}${width} T${thickness} L${length} ${colorCode}`;
            desc = `${modelType}${width} - L${length} x T${thickness} ${colorCode}`;
        } else if (componentType === 'Beams') {
            sDesc = `${modelType} ${thickness} L${length} ${colorCode}`;
            const hCode = modelType.split(' ').pop();
            desc = `${modelType} ${length} x 50 x ${hCode} - ${thickness} ${lipConnectorCount} LIP`;
        } else {
            sDesc = `${modelType} ${width}x${length}x${thickness} ${colorCode}`;
            desc = `${modelType} - L${length} x W${width} x T${thickness}`;
        }

        setFormData(prev => ({
            ...prev,
            shortDescription: sDesc,
            description: desc,
            longDescription: `${sDesc} ${dwg || prev.drawingNo}`,
            drawingNo: dwg || prev.drawingNo,
            revNo: rev || prev.revNo,
        }));
    }, [formData.modelType, formData.thickness, formData.length, formData.width, formData.colour]);

    useEffect(() => {
        onGroupChange(componentGroups[0]);

        // Close dropdown on click outside
        const handleClickOutside = (event) => {
            if (addMenuRef.current && !addMenuRef.current.contains(event.target)) {
                setShowAddMenu(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const handleFileChange = (e, type) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (type === 'glb') {
                setSelectedFile(file.name);
                setRawFiles(prev => ({ ...prev, glb: file }));
            } else {
                setImageFile(file.name);
                setRawFiles(prev => ({ ...prev, image: file }));
            }
        }
    };

    const handleSave = async () => {
        // 1. Mandatory Validation
        if (!formData.componentGroup || !formData.componentType) {
            alert('Component Group and Type are mandatory.');
            return;
        }
        if (!rawFiles.glb) {
            alert('GLB 3D Model file is mandatory.');
            return;
        }
        if (!selectedSolution.type || !selectedSolution.value) {
            alert('Please select a Product Solution (Pallet Rack or Shelving).');
            return;
        }

        setIsSaving(true);
        setSaveStatus(null);

        const data = new FormData();
        // Append basic fields
        Object.keys(formData).forEach(key => data.append(key, formData[key]));

        // Append solution data
        data.append('solutionType', selectedSolution.type);
        data.append('selectedSolution', selectedSolution.value);

        // Append files
        data.append('glbFile', rawFiles.glb);
        if (rawFiles.image) data.append('imageFile', rawFiles.image);

        try {
            const response = await fetch('http://localhost:5000/api/inventory', {
                method: 'POST',
                body: data,
            });

            if (response.ok) {
                const result = await response.json();
                setSaveStatus({ success: true, message: `Successfully saved! UID: ${result.uid}` });
                // Optionally clear form here
            } else {
                const error = await response.json();
                setSaveStatus({ success: false, message: error.error || 'Server error occurred' });
            }
        } catch (err) {
            setSaveStatus({ success: false, message: 'Could not connect to server' });
        } finally {
            setIsSaving(false);
        }
    };

    const inventoryItems = [
        { id: 1, component: 'Upright Frame', type: 'Frame', group: 'Pallet Racking', width: 50, length: 1495, height: 10, status: 'Active' },
        { id: 2, component: 'Beam Connector', type: 'Connector', group: 'Accessories', width: 75, length: 2400, height: 15, status: 'Active' },
        { id: 3, component: 'Base Plate', type: 'Support', group: 'Foundation', width: 100, length: 100, height: 5, status: 'Inactive' },
    ];

    return (
        <div className="flex h-screen bg-gray-50 text-slate-900 overflow-hidden">
            {/* Sidebar - Reverting to previous clean style */}
            <aside className="w-72 bg-white border-r border-gray-200 flex flex-col hidden lg:flex">
                <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-100">
                            <Package className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-gray-900 font-bold">Inventory Master</h2>
                            <p className="text-xs text-gray-500 font-medium">Component Management</p>
                        </div>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search products..."
                            className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-gray-50/50"
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                    {/* Pallet Rack Solutions */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <h3 className="text-xs font-black text-gray-900 uppercase tracking-widest">Pallet Rack Solutions</h3>
                            <Filter className="w-3 h-3 text-gray-400" />
                        </div>
                        <div className="space-y-2">
                            {[
                                'Selective Pallet Racking',
                                'Shuttle Racking',
                                'Mother/Child Shuttle'
                            ].map((item) => (
                                <label key={item} className="flex items-center gap-2 text-gray-700 cursor-pointer hover:text-blue-600 group transition-all">
                                    <input
                                        type="radio"
                                        name="solution"
                                        checked={selectedSolution.type === 'Pallet Rack' && selectedSolution.value === item}
                                        onChange={() => setSelectedSolution({ type: 'Pallet Rack', value: item })}
                                        className="rounded-full border-gray-300 text-blue-600 focus:ring-blue-500"
                                    />
                                    <span className="text-xs font-bold leading-none">{item}</span>
                                </label>
                            ))}
                        </div>
                    </div>

                    {/* Shelving Solutions */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <h3 className="text-xs font-black text-gray-900 uppercase tracking-widest">Shelving Solutions</h3>
                            <Filter className="w-3 h-3 text-gray-400" />
                        </div>
                        <div className="space-y-2">
                            {[
                                'Mezzanine',
                                'Single Tier Shelving',
                                'Mobile Shelving',
                                'Multi-Tier Shelving'
                            ].map((item) => (
                                <label key={item} className="flex items-center gap-2 text-gray-700 cursor-pointer hover:text-blue-600 group transition-all">
                                    <input
                                        type="radio"
                                        name="solution"
                                        checked={selectedSolution.type === 'Shelving' && selectedSolution.value === item}
                                        onChange={() => setSelectedSolution({ type: 'Shelving', value: item })}
                                        className="rounded-full border-gray-300 text-blue-600 focus:ring-blue-500"
                                    />
                                    <span className="text-xs font-bold leading-none">{item}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="p-4 border-t border-gray-200 space-y-2">
                    <button className="w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider">
                        <Download className="w-4 h-4 text-blue-600" />
                        Export Data
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col overflow-hidden">
                <header className="bg-white border-b border-gray-200 px-8 py-4 shadow-sm relative z-30">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <Link to="/" className="p-2 hover:bg-gray-50 rounded-full transition-colors border border-gray-100">
                                <ArrowLeft className="w-5 h-5 text-gray-500" />
                            </Link>
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 tracking-tight">Component Master</h1>
                                <p className="text-sm text-gray-500 font-medium">Precision catalog & logic management</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-3 relative" ref={addMenuRef}>
                            <button
                                onClick={() => setShowAddMenu(!showAddMenu)}
                                className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all flex items-center gap-2 text-xs font-black uppercase tracking-widest shadow-lg shadow-blue-100"
                            >
                                <Plus className={`w-4 h-4 transition-transform duration-300 ${showAddMenu ? 'rotate-45' : ''}`} />
                                Add
                                <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${showAddMenu ? 'rotate-180' : ''}`} />
                            </button>

                            {showAddMenu && (
                                <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-100 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                                    <button className="w-full text-left px-5 py-3 text-xs font-black uppercase tracking-widest text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all">Add Product group</button>
                                    <button className="w-full text-left px-5 py-3 text-xs font-black uppercase tracking-widest text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all">Add Component group</button>
                                    <button className="w-full text-left px-5 py-3 text-xs font-black uppercase tracking-widest text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all border-t border-gray-50 pt-3">Add Component type</button>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="flex gap-1 mt-4 border-b border-gray-200">
                        <button
                            onClick={() => setActiveTab('form')}
                            className={`px-6 py-2.5 text-[11px] font-black uppercase tracking-widest transition-all border-b-2 ${activeTab === 'form'
                                ? 'border-blue-600 text-blue-600'
                                : 'border-transparent text-gray-500 hover:text-gray-900'
                                }`}
                        >
                            Component Configuration
                        </button>
                        <button
                            onClick={() => setActiveTab('table')}
                            className={`px-6 py-2.5 text-[11px] font-black uppercase tracking-widest transition-all border-b-2 ${activeTab === 'table'
                                ? 'border-blue-600 text-blue-600'
                                : 'border-transparent text-gray-500 hover:text-gray-900'
                                }`}
                        >
                            Inventory List
                        </button>
                    </div>
                </header>

                <div className="flex-1 overflow-y-auto p-8 bg-gray-50/50">
                    {activeTab === 'form' ? (
                        <div className="max-w-6xl mx-auto space-y-8">
                            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                                <div className="p-8 space-y-10">

                                    {/* Basic Information */}
                                    <section className="space-y-6">
                                        <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
                                            <Grid3x3 className="w-5 h-5 text-blue-600" />
                                            <h2 className="text-sm font-black uppercase tracking-wider text-gray-800">Hierarchy Selection</h2>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                            <div className="space-y-3">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Component Group</label>
                                                <select value={formData.componentGroup} onChange={(e) => onGroupChange(e.target.value)} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl bg-gray-50 font-bold text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all">
                                                    {componentGroups.map(g => <option key={g} value={g}>{g}</option>)}
                                                </select>
                                            </div>
                                            <div className="space-y-3">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Component Type</label>
                                                <select value={formData.componentType} onChange={(e) => onTypeChange(e.target.value)} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl bg-gray-50 font-bold text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all">
                                                    {availableTypes.map(t => <option key={t} value={t}>{t}</option>)}
                                                </select>
                                            </div>
                                            <div className="space-y-3">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Model Variant</label>
                                                <select value={formData.modelType} onChange={(e) => onModelChange(e.target.value)} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl bg-gray-50 font-bold text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all">
                                                    {availableModels.map(m => <option key={m} value={m}>{m}</option>)}
                                                </select>
                                            </div>
                                        </div>
                                    </section>

                                    {/* Material & Coating */}
                                    <section className="space-y-6">
                                        <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
                                            <Settings className="w-5 h-5 text-blue-600" />
                                            <h2 className="text-sm font-black uppercase tracking-wider text-gray-800">Material & Coating</h2>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Colour</label>
                                                <select value={formData.colour} onChange={(e) => setFormData({ ...formData, colour: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none">
                                                    {colors.map(c => <option key={c} value={c}>{c}</option>)}
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">GFA Info</label>
                                                <select value={formData.gfaInfo} onChange={(e) => setFormData({ ...formData, gfaInfo: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none">
                                                    <option value="GFA">GFA</option>
                                                    <option value="NON GFA">NON GFA</option>
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Powder Code</label>
                                                <input type="text" value={formData.powderCode} onChange={(e) => setFormData({ ...formData, powderCode: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none" placeholder="PNM" />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Status</label>
                                                <select value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none">
                                                    <option>Active</option>
                                                    <option>Inactive</option>
                                                    <option>Draft</option>
                                                </select>
                                            </div>
                                        </div>
                                    </section>

                                    {/* Dimensions */}
                                    <section className="space-y-6">
                                        <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
                                            <File className="w-5 h-5 text-blue-600" />
                                            <h2 className="text-sm font-black uppercase tracking-wider text-gray-800">Dimensions</h2>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Length (mm)</label>
                                                <select value={formData.length} onChange={(e) => setFormData({ ...formData, length: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none">
                                                    {availableLengths.map(l => <option key={l} value={l}>{l}</option>)}
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Thickness (mm)</label>
                                                <select value={formData.thickness} onChange={(e) => setFormData({ ...formData, thickness: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none">
                                                    {availableThickness.map(t => <option key={t} value={t}>{t}</option>)}
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Width (mm)</label>
                                                <select value={formData.width} onChange={(e) => setFormData({ ...formData, width: e.target.value })} disabled={!availableWidths.length} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none disabled:opacity-50">
                                                    {availableWidths.map(w => <option key={w} value={w}>{w}</option>)}
                                                    {!availableWidths.length && <option value="">NA</option>}
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Height (mm)</label>
                                                <input type="text" value={formData.height} onChange={(e) => setFormData({ ...formData, height: e.target.value })} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl font-bold text-xs outline-none" />
                                            </div>
                                        </div>
                                    </section>

                                    {/* Descriptions (Live Output Generator Redesign - Light & Elegant) */}
                                    <div className="bg-slate-50/50 rounded-[2rem] p-12 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.05)] space-y-10 mt-12 overflow-hidden relative border border-slate-200">
                                        <div className="absolute -top-24 -right-24 opacity-[0.05] pointer-events-none scale-150">
                                            <Package className="w-80 h-80 text-blue-900" />
                                        </div>

                                        <div className="flex items-center justify-between border-b border-slate-200 pb-8 relative z-10">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-xl bg-blue-600/5 flex items-center justify-center border border-blue-600/10">
                                                    <BarChart3 className="w-5 h-5 text-blue-600" />
                                                </div>
                                                <div>
                                                    <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] mb-1">Live Output Engine</h4>
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.3)]"></div>
                                                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Active Processing</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="px-4 py-2 rounded-lg bg-white border border-slate-200 shadow-sm">
                                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">v1.2 Catalog</span>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 relative z-10">
                                            <div className="space-y-10">
                                                <div className="space-y-4">
                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Short Identifier</p>
                                                    <div className="p-6 rounded-2xl bg-white border border-slate-200 group hover:border-blue-500/30 transition-all shadow-sm">
                                                        <p className="text-3xl font-black text-slate-900 font-mono tracking-tighter leading-none group-hover:text-blue-600 transition-colors">
                                                            {formData.shortDescription || 'PENDING_CONFIG'}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div className="space-y-4">
                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Technical Specification</p>
                                                    <p className="text-base font-medium text-slate-600 italic leading-relaxed font-mono pl-4 border-l-2 border-blue-500/30">
                                                        {formData.description || 'Waiting for dimension parameters...'}
                                                    </p>
                                                </div>
                                            </div>

                                            <div className="space-y-8 bg-white/80 p-8 rounded-3xl border border-slate-200 shadow-sm">
                                                <div className="grid grid-cols-2 gap-8">
                                                    <div className="space-y-3">
                                                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Master Drawing</p>
                                                        <p className="text-sm font-black text-blue-600 font-mono flex items-center gap-2">
                                                            <Link2 className="w-3 h-3 opacity-50" />
                                                            {formData.drawingNo || 'IS/AUTO/GEN'}
                                                        </p>
                                                    </div>
                                                    <div className="space-y-3">
                                                        <p className="text-[9px] font-black text-slate-400 uppercase tracking_widest">Revision State</p>
                                                        <p className="text-sm font-black text-slate-700 font-mono bg-slate-100 px-3 py-1 rounded-md inline-block">
                                                            {formData.revNo || 'R-01'}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div className="pt-6 border-t border-slate-100 space-y-4">
                                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Selected Solution Path</p>
                                                    <div className="flex items-center gap-3">
                                                        <div className="px-3 py-1.5 rounded-full bg-blue-50 border border-blue-100">
                                                            <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">
                                                                {selectedSolution.type || 'None'}
                                                            </span>
                                                        </div>
                                                        <ChevronDown className="w-3 h-3 text-slate-300 -rotate-90" />
                                                        <span className="text-xs font-bold text-slate-600">
                                                            {selectedSolution.value || 'Unselected'}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Asset Management */}
                                    <section className="space-y-6 pt-10">
                                        <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
                                            <Upload className="w-5 h-5 text-blue-600" />
                                            <h2 className="text-sm font-black uppercase tracking-wider text-gray-800">Files & Assets</h2>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                            <label className="relative group cursor-pointer">
                                                <input type="file" className="hidden" onChange={(e) => handleFileChange(e, 'glb')} accept=".glb" />
                                                <div className="flex flex-col items-center justify-center p-10 border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50 hover:bg-blue-50/50 hover:border-blue-300 transition-all cursor-pointer group">
                                                    <FileUp className="w-10 h-10 text-gray-300 mb-3 group-hover:text-blue-500 transition-colors" />
                                                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 group-hover:text-blue-600">GLB Model Upload</p>
                                                    {selectedFile && <span className="mt-2 text-xs font-black text-blue-600 px-3 py-1 bg-white rounded-full shadow-sm">{selectedFile}</span>}
                                                </div>
                                            </label>
                                            <label className="relative group cursor-pointer">
                                                <input type="file" className="hidden" onChange={(e) => handleFileChange(e, 'image')} accept="image/*" />
                                                <div className="flex flex-col items-center justify-center p-10 border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50 hover:bg-blue-50/50 hover:border-blue-300 transition-all cursor-pointer group">
                                                    <ImageIcon className="w-10 h-10 text-gray-300 mb-3 group-hover:text-blue-500 transition-colors" />
                                                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 group-hover:text-blue-600">Product Image Upload</p>
                                                    {imageFile && <span className="mt-2 text-xs font-black text-blue-600 px-3 py-1 bg-white rounded-full shadow-sm">{imageFile}</span>}
                                                </div>
                                            </label>
                                        </div>
                                    </section>

                                    {/* Save Logic & Feedback */}
                                    <div className="pt-12 border-t border-gray-100 flex items-center justify-between gap-4">
                                        <div>
                                            {saveStatus && (
                                                <div className={`px-4 py-2 rounded-lg text-xs font-bold ${saveStatus.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                                    {saveStatus.message}
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button
                                                onClick={() => {
                                                    setFormData(prev => ({ ...prev, weight: '', cbm: '', cost: '' }));
                                                    setRawFiles({ glb: null, image: null });
                                                    setSelectedFile(null);
                                                    setImageFile(null);
                                                    setSaveStatus(null);
                                                }}
                                                className="px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest text-gray-400 hover:text-gray-900 transition-all"
                                            >
                                                Clear Form
                                            </button>
                                            <button
                                                onClick={handleSave}
                                                disabled={isSaving}
                                                className="px-10 py-3 bg-slate-900 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-2xl shadow-slate-200 hover:scale-105 active:scale-95 transition-all flex items-center gap-3 disabled:opacity-50"
                                            >
                                                {isSaving ? <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div> : <Save className="w-4 h-4" />}
                                                {isSaving ? 'Saving...' : 'Save Record'}
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    ) : (
                        /* Table View */
                        <div className="max-w-7xl mx-auto">
                            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                                <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gray-50/30">
                                    <div className="flex items-center gap-3">
                                        <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2 text-xs font-bold text-gray-700">
                                            <Filter className="w-4 h-4" />
                                            Filter
                                        </button>
                                    </div>
                                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                        {inventoryItems.length} records found
                                    </div>
                                </div>

                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead className="bg-gray-50/80 border-b border-gray-200">
                                            <tr>
                                                <th className="px-6 py-4 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">ID</th>
                                                <th className="px-6 py-4 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Component</th>
                                                <th className="px-6 py-4 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Type</th>
                                                <th className="px-6 py-4 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                                                <th className="px-8 py-5 text-right text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-100">
                                            {inventoryItems.map((item) => (
                                                <tr key={item.id} className="hover:bg-gray-50/50 transition-all group">
                                                    <td className="px-6 py-4 text-sm font-bold text-gray-400">#{item.id}</td>
                                                    <td className="px-6 py-4 text-sm font-black text-gray-900">{item.component}</td>
                                                    <td className="px-6 py-4 text-sm font-bold text-gray-500">{item.type}</td>
                                                    <td className="px-6 py-4">
                                                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${item.status === 'Active'
                                                            ? 'bg-green-100 text-green-700'
                                                            : 'bg-gray-100 text-gray-500'
                                                            }`}>
                                                            {item.status}
                                                        </span>
                                                    </td>
                                                    <td className="px-8 py-5 text-right">
                                                        <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all">
                                                            <button className="p-2.5 text-gray-400 hover:text-blue-600 hover:bg-white hover:shadow-lg rounded-xl transition-all">
                                                                <Edit className="w-4 h-4" />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default MasterInventory;
