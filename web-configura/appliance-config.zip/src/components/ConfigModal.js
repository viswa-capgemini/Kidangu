import React, { useState, useEffect } from 'react';

const ConfigModal = ({ item, designData, onClose, onSave }) => {
  const [config, setConfig] = useState({});

  useEffect(() => {
    if (item && designData) {
      setConfig(item.config);
    }
  }, [item, designData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setConfig({ ...config, [name]: value });
  };

  const handleSave = () => {
    onSave(config);
    onClose();
  };

  const renderOptions = (options) => {
    return options.map(option => (
      <option key={option} value={option}>{option}</option>
    ));
  };

  return (
    <div className="modal">
      <h2>Configure {item.type}</h2>
      {item.type === 'Refrigerator' && (
        <>
          <label>
            Number of Shelves:
            <select name="shelves" value={config.shelves || ''} onChange={handleChange}>
              {renderOptions(designData.refrigerator.options.shelves)}
            </select>
          </label>
          <label>
            Height:
            <input
              type="number"
              name="height"
              value={config.height || ''}
              min={designData.refrigerator.options.heightRange.min}
              max={designData.refrigerator.options.heightRange.max}
              onChange={handleChange}
            />
          </label>
          <label>
            Handle Type:
            <select name="handleType" value={config.handleType || ''} onChange={handleChange}>
              {renderOptions(designData.refrigerator.options.handleTypes)}
            </select>
          </label>
        </>
      )}
      {item.type === 'Washing Machine' && (
        <>
          <label>
            Capacity:
            <select name="capacity" value={config.capacity || ''} onChange={handleChange}>
              {renderOptions(designData.washingMachine.options.capacity)}
            </select>
          </label>
          <label>
            Type:
            <select name="type" value={config.type || ''} onChange={handleChange}>
              {renderOptions(designData.washingMachine.options.types)}
            </select>
          </label>
        </>
      )}
      <button onClick={handleSave}>Save</button>
      <button onClick={onClose}>Close</button>
    </div>
  );
};

export default ConfigModal;