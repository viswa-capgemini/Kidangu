import React from 'react';
import { Group, Rect, Text } from 'react-konva';

const CWashingMachine = ({ id, prefix, x, y, config, dimensions, onClick }) => (
  <Group x={x} y={y} draggable onClick={onClick}>
    <Rect width={dimensions.width} height={config.height} fill="blue" />
    <Text x={10} y={10} text={`${prefix}${id}`} fontSize={15} fill="white" />
  </Group>
);

export default CWashingMachine;