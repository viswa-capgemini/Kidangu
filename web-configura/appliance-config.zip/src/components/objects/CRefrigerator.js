import React, { useState } from 'react';
import { Group, Rect, Line, Text, Image } from 'react-konva';
import useImage from 'use-image';

const CRefrigerator = ({ id, prefix, x, y, config, dimensions, onClick }) => {
  const [selectedShelf, setSelectedShelf] = useState(null);
  const [hoveredShelf, setHoveredShelf] = useState(null);
  const [pencilIcon] = useImage('pencil.png'); // Replace with the actual path to the pencil icon

  const handleShelfClick = (shelfIndex) => {
    setSelectedShelf(shelfIndex);
  };

  const handleShelfTypeChange = (shelfType) => {
    const updatedConfig = { ...config, shelfType };
    // Update the config with the new shelf type
    // This should be passed to a parent component or handled via a callback
    setSelectedShelf(null);
  };

  return (
    <Group x={x} y={y} draggable onClick={onClick}>
      <Rect width={dimensions.width} height={config.height} fill="grey" strokeWidth={config.steeelwidth} stroke="red"/>
      {Array.from({ length: config.shelves }).map((_, shelfIndex) => (
        <Group key={shelfIndex}>
          <Line
            points={[
              0,
              (shelfIndex + 1) * (config.height / (config.shelves + 1)),
              dimensions.width,
              (shelfIndex + 1) * (config.height / (config.shelves + 1))
            ]}
            stroke="black"
            onMouseEnter={() => setHoveredShelf(shelfIndex)}
            onMouseLeave={() => setHoveredShelf(null)}
            onClick={() => handleShelfClick(shelfIndex)}
          />
          {hoveredShelf === shelfIndex && (
            <Image
              image={pencilIcon}
              x={dimensions.width - 20}
              y={(shelfIndex + 1) * (config.height / (config.shelves + 1)) - 10}
              width={16}
              height={16}
              onClick={() => handleShelfClick(shelfIndex)}
            />
          )}
        </Group>
      ))}
      <Text x={10} y={10} text={` ${prefix}${id}`} fontSize={15} fill="white" />
      {selectedShelf !== null && (
        <Group>
          <Rect
            x={dimensions.width + 10}
            y={(selectedShelf + 1) * (config.height / (config.shelves + 1)) - 10}
            width={150}
            height={100}
            fill="white"
            stroke="black"
          />
          <Text
            x={dimensions.width + 20}
            y={(selectedShelf + 1) * (config.height / (config.shelves + 1))}
            text="Select Shelf Type"
            fontSize={15}
            fill="black"
          />
          {config.ShelveTypes.map((shelfType, index) => (
            <Text
              key={index}
              x={dimensions.width + 20}
              y={(selectedShelf + 1) * (config.height / (config.shelves + 1)) + 20 + index * 20}
              text={shelfType}
              fontSize={15}
              fill="blue"
              onClick={() => handleShelfTypeChange(shelfType)}
            />
          ))}
          <Text
            x={dimensions.width + 20}
            y={(selectedShelf + 1) * (config.height / (config.shelves + 1)) + 80}
            text="Cancel"
            fontSize={15}
            fill="red"
            onClick={() => setSelectedShelf(null)}
          />
        </Group>
      )}
    </Group>
  );
};

export default CRefrigerator;