import React, { useState, useEffect } from 'react';
import { Stage, Layer } from 'react-konva';
import ConfigModal from './ConfigModal';
import CRefrigerator from './objects/CRefrigerator';
import CWashingMachine from './objects/CWashingMachine';

const TYPES = {
  'Refrigerator': CRefrigerator,
  'Washing Machine': CWashingMachine,
  // Add more types here as needed
};

const Canvas = ({ selectedItem, designData }) => {
  const [items, setItems] = useState([]);
  const [selectedConfigItem, setSelectedConfigItem] = useState(null);

  useEffect(() => {
    console.log('Selected Item Canvas:', selectedItem); // Log the selectedItem to the console

    if (selectedItem) {
      const prefix = selectedItem.metadata.code; // Use the code from designData.json
      const newItem = {
        id: items.length + 1, // Unique ID
        type: selectedItem.metadata.name,
        prefix: prefix,
        x: 50, // Default position
        y: 50, // Default position
        config: selectedItem.default,
        dimensions: selectedItem.dimensions
      };
      setItems([...items, newItem]);
    }
  }, [selectedItem]);

  const handleItemClick = (item) => {
    setSelectedConfigItem(item);
  };

  const handleSaveConfig = (config) => {
    setItems(items.map(item => item === selectedConfigItem ? { ...item, config } : item));
    setSelectedConfigItem(null);
  };

  return (
    <>
      <Stage width={window.innerWidth} height={window.innerHeight}>
        <Layer>
          {items.map((item) => {
            const Component = TYPES[item.type];
            return (
              <Component
                key={`${item.prefix}${item.id}`}
                {...item}
                onClick={() => handleItemClick(item)}
              />
            );
          })}
        </Layer>
      </Stage>
      {selectedConfigItem && (
        <ConfigModal
          item={selectedConfigItem}
          designData={designData}
          onClose={() => setSelectedConfigItem(null)}
          onSave={handleSaveConfig}
        />
      )}
    </>
  );
};

export default Canvas;