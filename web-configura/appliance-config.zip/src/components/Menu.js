// src/components/Menu.js
import React from 'react';
 
const Menu = ({ onSelect,data }) => {
  console.log('Menu data:', data); // Log the data to the console

  return (
    <div>
      <button onClick={() => onSelect(data.refrigerator)}>Refrigerator</button>
      <button onClick={() => onSelect(data.washingMachine)}>Washing Machine</button>
    </div>
  );
};
 
export default Menu;
 