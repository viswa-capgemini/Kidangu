import React, { useState, useEffect } from 'react';
import Menu from './components/Menu';
import Canvas from './components/Canvas';

const App = () => {
  const [selectedItem, setSelectedItem] = useState(null);
  const [designData, setDesignData] = useState(null);
// No need for decorators here, simply remove the placeholder
  useEffect(() => {
    fetch('/designData.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        setDesignData(data);
        console.log('Design Data:', data); // Log the designData to the console
      })
      .catch(error => console.error('Error fetching design data:', error));
  }, []);

  const handleSelect = (item) => {
    setSelectedItem(item);
    console.log(item);
   
  };

  return (
    <div>
      <Menu onSelect={handleSelect} data={designData} />
      {designData && <Canvas selectedItem={selectedItem} designData={designData} />}
    </div>
  );
};

export default App;