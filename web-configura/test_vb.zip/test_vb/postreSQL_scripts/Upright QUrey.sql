WITH RankedCapacities AS (
    SELECT 
        S.Series_code,
        V.Variant_code,
        thickness,
        USL,
        b.bracing_code,
        C.capacity,
        ROW_NUMBER() OVER (
            PARTITION BY USL
            ORDER BY C.capacity ASC
        ) AS rn
    FROM upright_series S
    JOIN Upright_variant V ON S.Series_id = V.Series_id
    JOIN Upright_Capacity C ON C.variant_id = V.variant_id
    JOIN bracing_type b ON b.bracing_id = C.bracing_id
  --  WHERE USL = 1700 AND C.capacity >= 18000
)
SELECT 
    Series_code,
    Variant_code,
    thickness,
    USL,
	rn,
    bracing_code,
    capacity,
    5000 AS Upright_Height
FROM RankedCapacities
--WHERE rn <= 4