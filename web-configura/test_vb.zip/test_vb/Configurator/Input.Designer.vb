﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Input
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        ComboBox10 = New ComboBox()
        Label78 = New Label()
        ComboBox9 = New ComboBox()
        Label77 = New Label()
        ComboBox8 = New ComboBox()
        Label76 = New Label()
        ComboBox7 = New ComboBox()
        Label7 = New Label()
        TextBox7 = New TextBox()
        TextBox6 = New TextBox()
        Label6 = New Label()
        TextBox5 = New TextBox()
        Label5 = New Label()
        TextBox4 = New TextBox()
        Label4 = New Label()
        TextBox3 = New TextBox()
        Label1 = New Label()
        Label3 = New Label()
        TextBox2 = New TextBox()
        Label2 = New Label()
        TabControl1 = New TabControl()
        TabPage1 = New TabPage()
        GroupBox9 = New GroupBox()
        Label75 = New Label()
        TextBox72 = New TextBox()
        TextBox73 = New TextBox()
        TextBox74 = New TextBox()
        TextBox75 = New TextBox()
        TextBox76 = New TextBox()
        TextBox77 = New TextBox()
        TextBox78 = New TextBox()
        TextBox79 = New TextBox()
        TextBox80 = New TextBox()
        TextBox81 = New TextBox()
        TextBox82 = New TextBox()
        TextBox83 = New TextBox()
        TextBox84 = New TextBox()
        TextBox85 = New TextBox()
        TextBox86 = New TextBox()
        TextBox87 = New TextBox()
        TextBox88 = New TextBox()
        TextBox89 = New TextBox()
        TextBox90 = New TextBox()
        TextBox91 = New TextBox()
        Label74 = New Label()
        TextBox71 = New TextBox()
        Label73 = New Label()
        TextBox70 = New TextBox()
        TextBox1 = New TextBox()
        TextBox52 = New TextBox()
        TextBox53 = New TextBox()
        TextBox54 = New TextBox()
        TextBox55 = New TextBox()
        TextBox56 = New TextBox()
        TextBox57 = New TextBox()
        TextBox58 = New TextBox()
        TextBox59 = New TextBox()
        TextBox60 = New TextBox()
        TextBox61 = New TextBox()
        TextBox62 = New TextBox()
        TextBox63 = New TextBox()
        TextBox64 = New TextBox()
        TextBox65 = New TextBox()
        TextBox66 = New TextBox()
        TextBox67 = New TextBox()
        TextBox68 = New TextBox()
        TextBox69 = New TextBox()
        ComboBox6 = New ComboBox()
        Label56 = New Label()
        Label55 = New Label()
        Label51 = New Label()
        TextBox36 = New TextBox()
        Label52 = New Label()
        TextBox37 = New TextBox()
        Label53 = New Label()
        TextBox38 = New TextBox()
        Label54 = New Label()
        TextBox39 = New TextBox()
        Label47 = New Label()
        TextBox32 = New TextBox()
        Label48 = New Label()
        TextBox33 = New TextBox()
        Label49 = New Label()
        TextBox34 = New TextBox()
        Label50 = New Label()
        TextBox35 = New TextBox()
        Label43 = New Label()
        TextBox28 = New TextBox()
        Label44 = New Label()
        TextBox29 = New TextBox()
        Label45 = New Label()
        TextBox30 = New TextBox()
        Label46 = New Label()
        TextBox31 = New TextBox()
        Label39 = New Label()
        TextBox24 = New TextBox()
        Label40 = New Label()
        TextBox25 = New TextBox()
        Label41 = New Label()
        TextBox26 = New TextBox()
        Label42 = New Label()
        TextBox27 = New TextBox()
        Label36 = New Label()
        TextBox22 = New TextBox()
        Label38 = New Label()
        TextBox23 = New TextBox()
        Label35 = New Label()
        TextBox21 = New TextBox()
        Label37 = New Label()
        TextBox18 = New TextBox()
        GroupBox5 = New GroupBox()
        Label25 = New Label()
        Label21 = New Label()
        ComboBox3 = New ComboBox()
        TextBox16 = New TextBox()
        Label22 = New Label()
        Label23 = New Label()
        TextBox17 = New TextBox()
        Label24 = New Label()
        GroupBox7 = New GroupBox()
        Label18 = New Label()
        Label19 = New Label()
        ComboBox4 = New ComboBox()
        TextBox9 = New TextBox()
        Label20 = New Label()
        Label26 = New Label()
        TextBox10 = New TextBox()
        Label29 = New Label()
        GroupBox8 = New GroupBox()
        Label30 = New Label()
        Label31 = New Label()
        ComboBox5 = New ComboBox()
        TextBox11 = New TextBox()
        Label32 = New Label()
        Label33 = New Label()
        TextBox12 = New TextBox()
        Label34 = New Label()
        GroupBox4 = New GroupBox()
        Label11 = New Label()
        Label10 = New Label()
        Label17 = New Label()
        TextBox8 = New TextBox()
        GroupBox6 = New GroupBox()
        TextBox20 = New TextBox()
        Label27 = New Label()
        TextBox19 = New TextBox()
        Label28 = New Label()
        GroupBox3 = New GroupBox()
        Label9 = New Label()
        ComboBox2 = New ComboBox()
        ComboBox1 = New ComboBox()
        Label12 = New Label()
        Label15 = New Label()
        TextBox15 = New TextBox()
        Label16 = New Label()
        GroupBox2 = New GroupBox()
        Label8 = New Label()
        Label13 = New Label()
        TextBox13 = New TextBox()
        TextBox14 = New TextBox()
        Label14 = New Label()
        TabPage7 = New TabPage()
        GroupBox11 = New GroupBox()
        TextBox92 = New TextBox()
        Label67 = New Label()
        Label63 = New Label()
        TextBox46 = New TextBox()
        Label62 = New Label()
        TextBox45 = New TextBox()
        Label61 = New Label()
        TextBox44 = New TextBox()
        Label58 = New Label()
        TextBox41 = New TextBox()
        Label57 = New Label()
        TextBox40 = New TextBox()
        TextBox42 = New TextBox()
        Label59 = New Label()
        TextBox43 = New TextBox()
        Label60 = New Label()
        TextBox47 = New TextBox()
        Label64 = New Label()
        Label65 = New Label()
        TextBox48 = New TextBox()
        TextBox49 = New TextBox()
        Label66 = New Label()
        GroupBox14 = New GroupBox()
        TextBox100 = New TextBox()
        Label91 = New Label()
        GroupBox15 = New GroupBox()
        TextBox101 = New TextBox()
        Label92 = New Label()
        Label93 = New Label()
        TextBox102 = New TextBox()
        TextBox103 = New TextBox()
        Label94 = New Label()
        GroupBox13 = New GroupBox()
        Label71 = New Label()
        Label72 = New Label()
        Label81 = New Label()
        Label82 = New Label()
        Label83 = New Label()
        TextBox50 = New TextBox()
        TextBox51 = New TextBox()
        Label84 = New Label()
        TextBox94 = New TextBox()
        Label85 = New Label()
        TextBox95 = New TextBox()
        Label86 = New Label()
        TextBox96 = New TextBox()
        Label87 = New Label()
        Label88 = New Label()
        TextBox97 = New TextBox()
        TextBox98 = New TextBox()
        Label89 = New Label()
        TabPage8 = New TabPage()
        GroupBox16 = New GroupBox()
        ComboBox25 = New ComboBox()
        ComboBox26 = New ComboBox()
        ComboBox27 = New ComboBox()
        ComboBox28 = New ComboBox()
        TextBox111 = New TextBox()
        Label112 = New Label()
        TextBox112 = New TextBox()
        ComboBox29 = New ComboBox()
        Label113 = New Label()
        ComboBox30 = New ComboBox()
        Label114 = New Label()
        Label115 = New Label()
        ComboBox31 = New ComboBox()
        Label116 = New Label()
        Label117 = New Label()
        TextBox113 = New TextBox()
        Label118 = New Label()
        Label119 = New Label()
        Label120 = New Label()
        Label121 = New Label()
        TextBox114 = New TextBox()
        Label122 = New Label()
        GroupBox12 = New GroupBox()
        ComboBox18 = New ComboBox()
        ComboBox19 = New ComboBox()
        ComboBox20 = New ComboBox()
        ComboBox21 = New ComboBox()
        TextBox93 = New TextBox()
        Label101 = New Label()
        TextBox104 = New TextBox()
        ComboBox22 = New ComboBox()
        Label102 = New Label()
        ComboBox23 = New ComboBox()
        Label103 = New Label()
        Label104 = New Label()
        ComboBox24 = New ComboBox()
        Label105 = New Label()
        Label106 = New Label()
        TextBox106 = New TextBox()
        Label107 = New Label()
        Label108 = New Label()
        Label109 = New Label()
        Label110 = New Label()
        TextBox107 = New TextBox()
        Label111 = New Label()
        TextBox99 = New TextBox()
        Label90 = New Label()
        GroupBox10 = New GroupBox()
        ComboBox17 = New ComboBox()
        ComboBox16 = New ComboBox()
        ComboBox15 = New ComboBox()
        ComboBox13 = New ComboBox()
        TextBox110 = New TextBox()
        Label100 = New Label()
        TextBox109 = New TextBox()
        ComboBox11 = New ComboBox()
        Label68 = New Label()
        ComboBox12 = New ComboBox()
        Label69 = New Label()
        Label70 = New Label()
        ComboBox14 = New ComboBox()
        Label79 = New Label()
        Label80 = New Label()
        TextBox105 = New TextBox()
        Label95 = New Label()
        Label96 = New Label()
        Label97 = New Label()
        Label98 = New Label()
        TextBox108 = New TextBox()
        Label99 = New Label()
        TabPage9 = New TabPage()
        GroupBox33 = New GroupBox()
        TextBox193 = New TextBox()
        Label231 = New Label()
        GroupBox31 = New GroupBox()
        TextBox186 = New TextBox()
        ComboBox48 = New ComboBox()
        Label214 = New Label()
        TextBox185 = New TextBox()
        Label215 = New Label()
        Label216 = New Label()
        GroupBox30 = New GroupBox()
        ComboBox47 = New ComboBox()
        Label211 = New Label()
        TextBox184 = New TextBox()
        ComboBox46 = New ComboBox()
        Label212 = New Label()
        Label213 = New Label()
        GroupBox29 = New GroupBox()
        TextBox180 = New TextBox()
        ComboBox45 = New ComboBox()
        TextBox181 = New TextBox()
        TextBox182 = New TextBox()
        Label206 = New Label()
        Label207 = New Label()
        Label208 = New Label()
        Label209 = New Label()
        TextBox183 = New TextBox()
        Label210 = New Label()
        GroupBox28 = New GroupBox()
        TextBox176 = New TextBox()
        Label202 = New Label()
        TextBox177 = New TextBox()
        TextBox178 = New TextBox()
        Label203 = New Label()
        Label204 = New Label()
        TextBox179 = New TextBox()
        Label205 = New Label()
        Label201 = New Label()
        TextBox167 = New TextBox()
        Label191 = New Label()
        TextBox168 = New TextBox()
        TextBox169 = New TextBox()
        TextBox170 = New TextBox()
        Label192 = New Label()
        Label193 = New Label()
        Label194 = New Label()
        TextBox171 = New TextBox()
        Label195 = New Label()
        TextBox172 = New TextBox()
        ComboBox44 = New ComboBox()
        TextBox173 = New TextBox()
        TextBox174 = New TextBox()
        Label196 = New Label()
        Label197 = New Label()
        Label198 = New Label()
        Label199 = New Label()
        TextBox175 = New TextBox()
        Label200 = New Label()
        GroupBox20 = New GroupBox()
        ComboBox34 = New ComboBox()
        Label144 = New Label()
        TextBox130 = New TextBox()
        Label145 = New Label()
        GroupBox19 = New GroupBox()
        TextBox128 = New TextBox()
        TextBox127 = New TextBox()
        TextBox126 = New TextBox()
        TextBox125 = New TextBox()
        Label142 = New Label()
        TextBox124 = New TextBox()
        TextBox119 = New TextBox()
        ComboBox33 = New ComboBox()
        ComboBox35 = New ComboBox()
        Label126 = New Label()
        TextBox121 = New TextBox()
        Label130 = New Label()
        Label131 = New Label()
        Label132 = New Label()
        ComboBox41 = New ComboBox()
        Label133 = New Label()
        Label134 = New Label()
        TextBox122 = New TextBox()
        Label137 = New Label()
        Label138 = New Label()
        Label139 = New Label()
        Label140 = New Label()
        TextBox123 = New TextBox()
        Label141 = New Label()
        GroupBox18 = New GroupBox()
        TextBox118 = New TextBox()
        TextBox117 = New TextBox()
        ComboBox40 = New ComboBox()
        Label127 = New Label()
        Label128 = New Label()
        Label129 = New Label()
        ComboBox39 = New ComboBox()
        Label135 = New Label()
        TextBox120 = New TextBox()
        Label136 = New Label()
        GroupBox17 = New GroupBox()
        Label124 = New Label()
        TextBox115 = New TextBox()
        ComboBox32 = New ComboBox()
        Label123 = New Label()
        TextBox116 = New TextBox()
        Label125 = New Label()
        TabPage10 = New TabPage()
        GroupBox32 = New GroupBox()
        Label220 = New Label()
        TextBox190 = New TextBox()
        Label229 = New Label()
        Label228 = New Label()
        Label227 = New Label()
        Label226 = New Label()
        ComboBox50 = New ComboBox()
        TextBox187 = New TextBox()
        TextBox188 = New TextBox()
        TextBox189 = New TextBox()
        Label217 = New Label()
        Label218 = New Label()
        Label219 = New Label()
        TextBox191 = New TextBox()
        ComboBox49 = New ComboBox()
        TextBox192 = New TextBox()
        Label221 = New Label()
        Label222 = New Label()
        Label223 = New Label()
        Label224 = New Label()
        TextBox194 = New TextBox()
        Label225 = New Label()
        GroupBox27 = New GroupBox()
        TextBox166 = New TextBox()
        Label190 = New Label()
        TextBox158 = New TextBox()
        TextBox159 = New TextBox()
        TextBox160 = New TextBox()
        Label181 = New Label()
        Label182 = New Label()
        Label183 = New Label()
        TextBox161 = New TextBox()
        Label184 = New Label()
        TextBox162 = New TextBox()
        ComboBox43 = New ComboBox()
        TextBox163 = New TextBox()
        TextBox164 = New TextBox()
        Label185 = New Label()
        Label186 = New Label()
        Label187 = New Label()
        Label188 = New Label()
        TextBox165 = New TextBox()
        Label189 = New Label()
        GroupBox26 = New GroupBox()
        TextBox157 = New TextBox()
        TextBox151 = New TextBox()
        TextBox152 = New TextBox()
        TextBox154 = New TextBox()
        Label174 = New Label()
        Label177 = New Label()
        Label178 = New Label()
        Label179 = New Label()
        TextBox156 = New TextBox()
        Label180 = New Label()
        GroupBox25 = New GroupBox()
        TextBox155 = New TextBox()
        TextBox153 = New TextBox()
        Label175 = New Label()
        Label176 = New Label()
        GroupBox24 = New GroupBox()
        Label173 = New Label()
        TextBox150 = New TextBox()
        Label172 = New Label()
        TextBox145 = New TextBox()
        Label171 = New Label()
        TextBox143 = New TextBox()
        Label170 = New Label()
        Label159 = New Label()
        Label169 = New Label()
        TextBox142 = New TextBox()
        ComboBox38 = New ComboBox()
        TextBox144 = New TextBox()
        Label160 = New Label()
        Label161 = New Label()
        Label162 = New Label()
        Label168 = New Label()
        GroupBox23 = New GroupBox()
        TextBox146 = New TextBox()
        ComboBox37 = New ComboBox()
        TextBox147 = New TextBox()
        TextBox148 = New TextBox()
        Label163 = New Label()
        Label164 = New Label()
        Label165 = New Label()
        Label166 = New Label()
        TextBox149 = New TextBox()
        Label167 = New Label()
        GroupBox22 = New GroupBox()
        TextBox137 = New TextBox()
        TextBox139 = New TextBox()
        TextBox140 = New TextBox()
        Label153 = New Label()
        Label154 = New Label()
        Label157 = New Label()
        TextBox141 = New TextBox()
        Label158 = New Label()
        TextBox132 = New TextBox()
        ComboBox36 = New ComboBox()
        TextBox133 = New TextBox()
        TextBox134 = New TextBox()
        Label143 = New Label()
        Label146 = New Label()
        Label150 = New Label()
        Label151 = New Label()
        TextBox136 = New TextBox()
        Label152 = New Label()
        GroupBox21 = New GroupBox()
        TextBox135 = New TextBox()
        ComboBox42 = New ComboBox()
        TextBox129 = New TextBox()
        TextBox131 = New TextBox()
        Label147 = New Label()
        Label148 = New Label()
        Label149 = New Label()
        Label155 = New Label()
        TextBox138 = New TextBox()
        Label156 = New Label()
        GroupBox1.SuspendLayout()
        TabControl1.SuspendLayout()
        TabPage1.SuspendLayout()
        GroupBox9.SuspendLayout()
        GroupBox5.SuspendLayout()
        GroupBox7.SuspendLayout()
        GroupBox8.SuspendLayout()
        GroupBox4.SuspendLayout()
        GroupBox6.SuspendLayout()
        GroupBox3.SuspendLayout()
        GroupBox2.SuspendLayout()
        TabPage7.SuspendLayout()
        GroupBox11.SuspendLayout()
        GroupBox14.SuspendLayout()
        GroupBox15.SuspendLayout()
        GroupBox13.SuspendLayout()
        TabPage8.SuspendLayout()
        GroupBox16.SuspendLayout()
        GroupBox12.SuspendLayout()
        GroupBox10.SuspendLayout()
        TabPage9.SuspendLayout()
        GroupBox33.SuspendLayout()
        GroupBox31.SuspendLayout()
        GroupBox30.SuspendLayout()
        GroupBox29.SuspendLayout()
        GroupBox28.SuspendLayout()
        GroupBox20.SuspendLayout()
        GroupBox19.SuspendLayout()
        GroupBox18.SuspendLayout()
        GroupBox17.SuspendLayout()
        TabPage10.SuspendLayout()
        GroupBox32.SuspendLayout()
        GroupBox27.SuspendLayout()
        GroupBox26.SuspendLayout()
        GroupBox25.SuspendLayout()
        GroupBox24.SuspendLayout()
        GroupBox23.SuspendLayout()
        GroupBox22.SuspendLayout()
        GroupBox21.SuspendLayout()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(ComboBox10)
        GroupBox1.Controls.Add(Label78)
        GroupBox1.Controls.Add(ComboBox9)
        GroupBox1.Controls.Add(Label77)
        GroupBox1.Controls.Add(ComboBox8)
        GroupBox1.Controls.Add(Label76)
        GroupBox1.Controls.Add(ComboBox7)
        GroupBox1.Controls.Add(Label7)
        GroupBox1.Controls.Add(TextBox7)
        GroupBox1.Controls.Add(TextBox6)
        GroupBox1.Controls.Add(Label6)
        GroupBox1.Controls.Add(TextBox5)
        GroupBox1.Controls.Add(Label5)
        GroupBox1.Controls.Add(TextBox4)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(TextBox3)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(TextBox2)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Location = New Point(15, 20)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(389, 377)
        GroupBox1.TabIndex = 2
        GroupBox1.TabStop = False
        GroupBox1.Text = "Unit details"
        ' 
        ' ComboBox10
        ' 
        ComboBox10.FormattingEnabled = True
        ComboBox10.Location = New Point(188, 100)
        ComboBox10.Name = "ComboBox10"
        ComboBox10.Size = New Size(151, 28)
        ComboBox10.TabIndex = 23
        ' 
        ' Label78
        ' 
        Label78.AutoSize = True
        Label78.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label78.Location = New Point(20, 101)
        Label78.Name = "Label78"
        Label78.Size = New Size(111, 20)
        Label78.TabIndex = 22
        Label78.Text = "Bracing Colour"
        ' 
        ' ComboBox9
        ' 
        ComboBox9.FormattingEnabled = True
        ComboBox9.Location = New Point(188, 66)
        ComboBox9.Name = "ComboBox9"
        ComboBox9.Size = New Size(151, 28)
        ComboBox9.TabIndex = 21
        ' 
        ' Label77
        ' 
        Label77.AutoSize = True
        Label77.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label77.Location = New Point(20, 67)
        Label77.Name = "Label77"
        Label77.Size = New Size(101, 20)
        Label77.TabIndex = 20
        Label77.Text = "Frame Colour"
        ' 
        ' ComboBox8
        ' 
        ComboBox8.FormattingEnabled = True
        ComboBox8.Location = New Point(188, 32)
        ComboBox8.Name = "ComboBox8"
        ComboBox8.Size = New Size(151, 28)
        ComboBox8.TabIndex = 19
        ' 
        ' Label76
        ' 
        Label76.AutoSize = True
        Label76.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label76.Location = New Point(20, 33)
        Label76.Name = "Label76"
        Label76.Size = New Size(90, 20)
        Label76.TabIndex = 18
        Label76.Text = "Seismic info"
        ' 
        ' ComboBox7
        ' 
        ComboBox7.FormattingEnabled = True
        ComboBox7.Location = New Point(188, 132)
        ComboBox7.Name = "ComboBox7"
        ComboBox7.Size = New Size(151, 28)
        ComboBox7.TabIndex = 17
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label7.Location = New Point(26, 329)
        Label7.Name = "Label7"
        Label7.Size = New Size(96, 20)
        Label7.TabIndex = 16
        Label7.Text = "Sum of Units"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(188, 324)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(151, 27)
        TextBox7.TabIndex = 15
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(188, 291)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(151, 27)
        TextBox6.TabIndex = 14
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(22, 298)
        Label6.Name = "Label6"
        Label6.Size = New Size(129, 20)
        Label6.TabIndex = 13
        Label6.Text = "No Of DF Addons"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(188, 258)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(151, 27)
        TextBox5.TabIndex = 12
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label5.Location = New Point(20, 258)
        Label5.Name = "Label5"
        Label5.Size = New Size(118, 20)
        Label5.TabIndex = 11
        Label5.Text = "No Of DF Mains"
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(188, 229)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(151, 27)
        TextBox4.TabIndex = 10
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label4.Location = New Point(20, 229)
        Label4.Name = "Label4"
        Label4.Size = New Size(126, 20)
        Label4.TabIndex = 9
        Label4.Text = "No Of SF Addons"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(188, 197)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(151, 27)
        TextBox3.TabIndex = 8
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label1.Location = New Point(20, 197)
        Label1.Name = "Label1"
        Label1.Size = New Size(115, 20)
        Label1.TabIndex = 7
        Label1.Text = "No Of SF Mains"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label3.Location = New Point(20, 133)
        Label3.Name = "Label3"
        Label3.Size = New Size(74, 20)
        Label3.TabIndex = 6
        Label3.Text = "Unit Type"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(188, 168)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(151, 27)
        TextBox2.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label2.Location = New Point(20, 168)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 20)
        Label2.TabIndex = 1
        Label2.Text = "Unit Name"
        ' 
        ' TabControl1
        ' 
        TabControl1.Controls.Add(TabPage1)
        TabControl1.Controls.Add(TabPage7)
        TabControl1.Controls.Add(TabPage8)
        TabControl1.Controls.Add(TabPage9)
        TabControl1.Controls.Add(TabPage10)
        TabControl1.Location = New Point(12, 12)
        TabControl1.Name = "TabControl1"
        TabControl1.SelectedIndex = 0
        TabControl1.Size = New Size(1729, 944)
        TabControl1.TabIndex = 13
        ' 
        ' TabPage1
        ' 
        TabPage1.BackColor = Color.Transparent
        TabPage1.Controls.Add(GroupBox9)
        TabPage1.Controls.Add(GroupBox5)
        TabPage1.Controls.Add(GroupBox7)
        TabPage1.Controls.Add(GroupBox8)
        TabPage1.Controls.Add(GroupBox4)
        TabPage1.Controls.Add(GroupBox6)
        TabPage1.Controls.Add(GroupBox3)
        TabPage1.Controls.Add(GroupBox2)
        TabPage1.Controls.Add(GroupBox1)
        TabPage1.Location = New Point(4, 29)
        TabPage1.Name = "TabPage1"
        TabPage1.Padding = New Padding(3)
        TabPage1.Size = New Size(1721, 911)
        TabPage1.TabIndex = 0
        TabPage1.Text = "Input"
        ' 
        ' GroupBox9
        ' 
        GroupBox9.Controls.Add(Label75)
        GroupBox9.Controls.Add(TextBox72)
        GroupBox9.Controls.Add(TextBox73)
        GroupBox9.Controls.Add(TextBox74)
        GroupBox9.Controls.Add(TextBox75)
        GroupBox9.Controls.Add(TextBox76)
        GroupBox9.Controls.Add(TextBox77)
        GroupBox9.Controls.Add(TextBox78)
        GroupBox9.Controls.Add(TextBox79)
        GroupBox9.Controls.Add(TextBox80)
        GroupBox9.Controls.Add(TextBox81)
        GroupBox9.Controls.Add(TextBox82)
        GroupBox9.Controls.Add(TextBox83)
        GroupBox9.Controls.Add(TextBox84)
        GroupBox9.Controls.Add(TextBox85)
        GroupBox9.Controls.Add(TextBox86)
        GroupBox9.Controls.Add(TextBox87)
        GroupBox9.Controls.Add(TextBox88)
        GroupBox9.Controls.Add(TextBox89)
        GroupBox9.Controls.Add(TextBox90)
        GroupBox9.Controls.Add(TextBox91)
        GroupBox9.Controls.Add(Label74)
        GroupBox9.Controls.Add(TextBox71)
        GroupBox9.Controls.Add(Label73)
        GroupBox9.Controls.Add(TextBox70)
        GroupBox9.Controls.Add(TextBox1)
        GroupBox9.Controls.Add(TextBox52)
        GroupBox9.Controls.Add(TextBox53)
        GroupBox9.Controls.Add(TextBox54)
        GroupBox9.Controls.Add(TextBox55)
        GroupBox9.Controls.Add(TextBox56)
        GroupBox9.Controls.Add(TextBox57)
        GroupBox9.Controls.Add(TextBox58)
        GroupBox9.Controls.Add(TextBox59)
        GroupBox9.Controls.Add(TextBox60)
        GroupBox9.Controls.Add(TextBox61)
        GroupBox9.Controls.Add(TextBox62)
        GroupBox9.Controls.Add(TextBox63)
        GroupBox9.Controls.Add(TextBox64)
        GroupBox9.Controls.Add(TextBox65)
        GroupBox9.Controls.Add(TextBox66)
        GroupBox9.Controls.Add(TextBox67)
        GroupBox9.Controls.Add(TextBox68)
        GroupBox9.Controls.Add(TextBox69)
        GroupBox9.Controls.Add(ComboBox6)
        GroupBox9.Controls.Add(Label56)
        GroupBox9.Controls.Add(Label55)
        GroupBox9.Controls.Add(Label51)
        GroupBox9.Controls.Add(TextBox36)
        GroupBox9.Controls.Add(Label52)
        GroupBox9.Controls.Add(TextBox37)
        GroupBox9.Controls.Add(Label53)
        GroupBox9.Controls.Add(TextBox38)
        GroupBox9.Controls.Add(Label54)
        GroupBox9.Controls.Add(TextBox39)
        GroupBox9.Controls.Add(Label47)
        GroupBox9.Controls.Add(TextBox32)
        GroupBox9.Controls.Add(Label48)
        GroupBox9.Controls.Add(TextBox33)
        GroupBox9.Controls.Add(Label49)
        GroupBox9.Controls.Add(TextBox34)
        GroupBox9.Controls.Add(Label50)
        GroupBox9.Controls.Add(TextBox35)
        GroupBox9.Controls.Add(Label43)
        GroupBox9.Controls.Add(TextBox28)
        GroupBox9.Controls.Add(Label44)
        GroupBox9.Controls.Add(TextBox29)
        GroupBox9.Controls.Add(Label45)
        GroupBox9.Controls.Add(TextBox30)
        GroupBox9.Controls.Add(Label46)
        GroupBox9.Controls.Add(TextBox31)
        GroupBox9.Controls.Add(Label39)
        GroupBox9.Controls.Add(TextBox24)
        GroupBox9.Controls.Add(Label40)
        GroupBox9.Controls.Add(TextBox25)
        GroupBox9.Controls.Add(Label41)
        GroupBox9.Controls.Add(TextBox26)
        GroupBox9.Controls.Add(Label42)
        GroupBox9.Controls.Add(TextBox27)
        GroupBox9.Controls.Add(Label36)
        GroupBox9.Controls.Add(TextBox22)
        GroupBox9.Controls.Add(Label38)
        GroupBox9.Controls.Add(TextBox23)
        GroupBox9.Controls.Add(Label35)
        GroupBox9.Controls.Add(TextBox21)
        GroupBox9.Controls.Add(Label37)
        GroupBox9.Controls.Add(TextBox18)
        GroupBox9.Location = New Point(886, 20)
        GroupBox9.Name = "GroupBox9"
        GroupBox9.Size = New Size(719, 868)
        GroupBox9.TabIndex = 13
        GroupBox9.TabStop = False
        GroupBox9.Text = "Level Height Details in mm"
        ' 
        ' Label75
        ' 
        Label75.AutoSize = True
        Label75.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label75.Location = New Point(526, 41)
        Label75.Name = "Label75"
        Label75.Size = New Size(84, 20)
        Label75.TabIndex = 90
        Label75.Text = "Beam Load"
        ' 
        ' TextBox72
        ' 
        TextBox72.Location = New Point(526, 717)
        TextBox72.Name = "TextBox72"
        TextBox72.Size = New Size(123, 27)
        TextBox72.TabIndex = 89
        ' 
        ' TextBox73
        ' 
        TextBox73.Location = New Point(526, 665)
        TextBox73.Name = "TextBox73"
        TextBox73.Size = New Size(123, 27)
        TextBox73.TabIndex = 88
        ' 
        ' TextBox74
        ' 
        TextBox74.Location = New Point(526, 632)
        TextBox74.Name = "TextBox74"
        TextBox74.Size = New Size(123, 27)
        TextBox74.TabIndex = 87
        ' 
        ' TextBox75
        ' 
        TextBox75.Location = New Point(526, 599)
        TextBox75.Name = "TextBox75"
        TextBox75.Size = New Size(123, 27)
        TextBox75.TabIndex = 86
        ' 
        ' TextBox76
        ' 
        TextBox76.Location = New Point(526, 567)
        TextBox76.Name = "TextBox76"
        TextBox76.Size = New Size(123, 27)
        TextBox76.TabIndex = 85
        ' 
        ' TextBox77
        ' 
        TextBox77.Location = New Point(526, 534)
        TextBox77.Name = "TextBox77"
        TextBox77.Size = New Size(123, 27)
        TextBox77.TabIndex = 84
        ' 
        ' TextBox78
        ' 
        TextBox78.Location = New Point(526, 501)
        TextBox78.Name = "TextBox78"
        TextBox78.Size = New Size(123, 27)
        TextBox78.TabIndex = 83
        ' 
        ' TextBox79
        ' 
        TextBox79.Location = New Point(526, 468)
        TextBox79.Name = "TextBox79"
        TextBox79.Size = New Size(123, 27)
        TextBox79.TabIndex = 82
        ' 
        ' TextBox80
        ' 
        TextBox80.Location = New Point(526, 435)
        TextBox80.Name = "TextBox80"
        TextBox80.Size = New Size(123, 27)
        TextBox80.TabIndex = 81
        ' 
        ' TextBox81
        ' 
        TextBox81.Location = New Point(526, 402)
        TextBox81.Name = "TextBox81"
        TextBox81.Size = New Size(123, 27)
        TextBox81.TabIndex = 80
        ' 
        ' TextBox82
        ' 
        TextBox82.Location = New Point(526, 369)
        TextBox82.Name = "TextBox82"
        TextBox82.Size = New Size(123, 27)
        TextBox82.TabIndex = 79
        ' 
        ' TextBox83
        ' 
        TextBox83.Location = New Point(526, 336)
        TextBox83.Name = "TextBox83"
        TextBox83.Size = New Size(123, 27)
        TextBox83.TabIndex = 78
        ' 
        ' TextBox84
        ' 
        TextBox84.Location = New Point(526, 303)
        TextBox84.Name = "TextBox84"
        TextBox84.Size = New Size(123, 27)
        TextBox84.TabIndex = 77
        ' 
        ' TextBox85
        ' 
        TextBox85.Location = New Point(526, 270)
        TextBox85.Name = "TextBox85"
        TextBox85.Size = New Size(123, 27)
        TextBox85.TabIndex = 76
        ' 
        ' TextBox86
        ' 
        TextBox86.Location = New Point(526, 237)
        TextBox86.Name = "TextBox86"
        TextBox86.Size = New Size(123, 27)
        TextBox86.TabIndex = 75
        ' 
        ' TextBox87
        ' 
        TextBox87.Location = New Point(526, 204)
        TextBox87.Name = "TextBox87"
        TextBox87.Size = New Size(123, 27)
        TextBox87.TabIndex = 74
        ' 
        ' TextBox88
        ' 
        TextBox88.Location = New Point(526, 173)
        TextBox88.Name = "TextBox88"
        TextBox88.Size = New Size(123, 27)
        TextBox88.TabIndex = 73
        ' 
        ' TextBox89
        ' 
        TextBox89.Location = New Point(526, 140)
        TextBox89.Name = "TextBox89"
        TextBox89.Size = New Size(123, 27)
        TextBox89.TabIndex = 72
        ' 
        ' TextBox90
        ' 
        TextBox90.Location = New Point(526, 107)
        TextBox90.Name = "TextBox90"
        TextBox90.Size = New Size(123, 27)
        TextBox90.TabIndex = 71
        ' 
        ' TextBox91
        ' 
        TextBox91.Location = New Point(526, 74)
        TextBox91.Name = "TextBox91"
        TextBox91.Size = New Size(123, 27)
        TextBox91.TabIndex = 70
        ' 
        ' Label74
        ' 
        Label74.AutoSize = True
        Label74.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label74.Location = New Point(373, 41)
        Label74.Name = "Label74"
        Label74.Size = New Size(105, 20)
        Label74.TabIndex = 68
        Label74.Text = "Load Per level"
        ' 
        ' TextBox71
        ' 
        TextBox71.Location = New Point(373, 767)
        TextBox71.Name = "TextBox71"
        TextBox71.Size = New Size(123, 27)
        TextBox71.TabIndex = 67
        ' 
        ' Label73
        ' 
        Label73.AutoSize = True
        Label73.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label73.Location = New Point(239, 767)
        Label73.Name = "Label73"
        Label73.Size = New Size(128, 20)
        Label73.TabIndex = 66
        Label73.Text = "Total Frame Load "
        ' 
        ' TextBox70
        ' 
        TextBox70.Location = New Point(373, 717)
        TextBox70.Name = "TextBox70"
        TextBox70.Size = New Size(123, 27)
        TextBox70.TabIndex = 65
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(373, 665)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(123, 27)
        TextBox1.TabIndex = 64
        ' 
        ' TextBox52
        ' 
        TextBox52.Location = New Point(373, 632)
        TextBox52.Name = "TextBox52"
        TextBox52.Size = New Size(123, 27)
        TextBox52.TabIndex = 63
        ' 
        ' TextBox53
        ' 
        TextBox53.Location = New Point(373, 599)
        TextBox53.Name = "TextBox53"
        TextBox53.Size = New Size(123, 27)
        TextBox53.TabIndex = 62
        ' 
        ' TextBox54
        ' 
        TextBox54.Location = New Point(373, 567)
        TextBox54.Name = "TextBox54"
        TextBox54.Size = New Size(123, 27)
        TextBox54.TabIndex = 61
        ' 
        ' TextBox55
        ' 
        TextBox55.Location = New Point(373, 534)
        TextBox55.Name = "TextBox55"
        TextBox55.Size = New Size(123, 27)
        TextBox55.TabIndex = 60
        ' 
        ' TextBox56
        ' 
        TextBox56.Location = New Point(373, 501)
        TextBox56.Name = "TextBox56"
        TextBox56.Size = New Size(123, 27)
        TextBox56.TabIndex = 59
        ' 
        ' TextBox57
        ' 
        TextBox57.Location = New Point(373, 468)
        TextBox57.Name = "TextBox57"
        TextBox57.Size = New Size(123, 27)
        TextBox57.TabIndex = 58
        ' 
        ' TextBox58
        ' 
        TextBox58.Location = New Point(373, 435)
        TextBox58.Name = "TextBox58"
        TextBox58.Size = New Size(123, 27)
        TextBox58.TabIndex = 57
        ' 
        ' TextBox59
        ' 
        TextBox59.Location = New Point(373, 402)
        TextBox59.Name = "TextBox59"
        TextBox59.Size = New Size(123, 27)
        TextBox59.TabIndex = 56
        ' 
        ' TextBox60
        ' 
        TextBox60.Location = New Point(373, 369)
        TextBox60.Name = "TextBox60"
        TextBox60.Size = New Size(123, 27)
        TextBox60.TabIndex = 55
        ' 
        ' TextBox61
        ' 
        TextBox61.Location = New Point(373, 336)
        TextBox61.Name = "TextBox61"
        TextBox61.Size = New Size(123, 27)
        TextBox61.TabIndex = 54
        ' 
        ' TextBox62
        ' 
        TextBox62.Location = New Point(373, 303)
        TextBox62.Name = "TextBox62"
        TextBox62.Size = New Size(123, 27)
        TextBox62.TabIndex = 53
        ' 
        ' TextBox63
        ' 
        TextBox63.Location = New Point(373, 270)
        TextBox63.Name = "TextBox63"
        TextBox63.Size = New Size(123, 27)
        TextBox63.TabIndex = 52
        ' 
        ' TextBox64
        ' 
        TextBox64.Location = New Point(373, 237)
        TextBox64.Name = "TextBox64"
        TextBox64.Size = New Size(123, 27)
        TextBox64.TabIndex = 51
        ' 
        ' TextBox65
        ' 
        TextBox65.Location = New Point(373, 204)
        TextBox65.Name = "TextBox65"
        TextBox65.Size = New Size(123, 27)
        TextBox65.TabIndex = 50
        ' 
        ' TextBox66
        ' 
        TextBox66.Location = New Point(373, 173)
        TextBox66.Name = "TextBox66"
        TextBox66.Size = New Size(123, 27)
        TextBox66.TabIndex = 49
        ' 
        ' TextBox67
        ' 
        TextBox67.Location = New Point(373, 140)
        TextBox67.Name = "TextBox67"
        TextBox67.Size = New Size(123, 27)
        TextBox67.TabIndex = 48
        ' 
        ' TextBox68
        ' 
        TextBox68.Location = New Point(373, 107)
        TextBox68.Name = "TextBox68"
        TextBox68.Size = New Size(123, 27)
        TextBox68.TabIndex = 47
        ' 
        ' TextBox69
        ' 
        TextBox69.Location = New Point(373, 74)
        TextBox69.Name = "TextBox69"
        TextBox69.Size = New Size(123, 27)
        TextBox69.TabIndex = 46
        ' 
        ' ComboBox6
        ' 
        ComboBox6.FormattingEnabled = True
        ComboBox6.Location = New Point(220, 813)
        ComboBox6.Name = "ComboBox6"
        ComboBox6.Size = New Size(123, 28)
        ComboBox6.TabIndex = 12
        ' 
        ' Label56
        ' 
        Label56.AutoSize = True
        Label56.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label56.Location = New Point(37, 816)
        Label56.Name = "Label56"
        Label56.Size = New Size(131, 20)
        Label56.TabIndex = 11
        Label56.Text = "First USL end with"
        ' 
        ' Label55
        ' 
        Label55.AutoSize = True
        Label55.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label55.Location = New Point(86, 43)
        Label55.Name = "Label55"
        Label55.Size = New Size(181, 17)
        Label55.TabIndex = 45
        Label55.Text = "USL Range : 250 to 3500 mm"
        ' 
        ' Label51
        ' 
        Label51.AutoSize = True
        Label51.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label51.Location = New Point(23, 698)
        Label51.Name = "Label51"
        Label51.Size = New Size(217, 20)
        Label51.TabIndex = 44
        Label51.Text = "Ground Level to Level 1 Height"
        ' 
        ' TextBox36
        ' 
        TextBox36.Location = New Point(220, 717)
        TextBox36.Name = "TextBox36"
        TextBox36.Size = New Size(123, 27)
        TextBox36.TabIndex = 43
        ' 
        ' Label52
        ' 
        Label52.AutoSize = True
        Label52.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label52.Location = New Point(23, 665)
        Label52.Name = "Label52"
        Label52.Size = New Size(173, 20)
        Label52.TabIndex = 42
        Label52.Text = "Level 1 to Level 2 Height"
        ' 
        ' TextBox37
        ' 
        TextBox37.Location = New Point(220, 665)
        TextBox37.Name = "TextBox37"
        TextBox37.Size = New Size(123, 27)
        TextBox37.TabIndex = 41
        ' 
        ' Label53
        ' 
        Label53.AutoSize = True
        Label53.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label53.Location = New Point(23, 632)
        Label53.Name = "Label53"
        Label53.Size = New Size(175, 20)
        Label53.TabIndex = 40
        Label53.Text = "Level 2 to Level 3 Height"
        ' 
        ' TextBox38
        ' 
        TextBox38.Location = New Point(220, 632)
        TextBox38.Name = "TextBox38"
        TextBox38.Size = New Size(123, 27)
        TextBox38.TabIndex = 39
        ' 
        ' Label54
        ' 
        Label54.AutoSize = True
        Label54.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label54.Location = New Point(23, 599)
        Label54.Name = "Label54"
        Label54.Size = New Size(176, 20)
        Label54.TabIndex = 38
        Label54.Text = "Level 3 to Level 4 Height"
        ' 
        ' TextBox39
        ' 
        TextBox39.Location = New Point(220, 599)
        TextBox39.Name = "TextBox39"
        TextBox39.Size = New Size(123, 27)
        TextBox39.TabIndex = 37
        ' 
        ' Label47
        ' 
        Label47.AutoSize = True
        Label47.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label47.Location = New Point(23, 567)
        Label47.Name = "Label47"
        Label47.Size = New Size(176, 20)
        Label47.TabIndex = 36
        Label47.Text = "Level 4 to Level 5 Height"
        ' 
        ' TextBox32
        ' 
        TextBox32.Location = New Point(220, 567)
        TextBox32.Name = "TextBox32"
        TextBox32.Size = New Size(123, 27)
        TextBox32.TabIndex = 35
        ' 
        ' Label48
        ' 
        Label48.AutoSize = True
        Label48.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label48.Location = New Point(23, 534)
        Label48.Name = "Label48"
        Label48.Size = New Size(179, 20)
        Label48.TabIndex = 34
        Label48.Text = "Level  5 to Level 6 Height"
        ' 
        ' TextBox33
        ' 
        TextBox33.Location = New Point(220, 534)
        TextBox33.Name = "TextBox33"
        TextBox33.Size = New Size(123, 27)
        TextBox33.TabIndex = 33
        ' 
        ' Label49
        ' 
        Label49.AutoSize = True
        Label49.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label49.Location = New Point(23, 501)
        Label49.Name = "Label49"
        Label49.Size = New Size(175, 20)
        Label49.TabIndex = 32
        Label49.Text = "Level 6 to Level 7 Height"
        ' 
        ' TextBox34
        ' 
        TextBox34.Location = New Point(220, 501)
        TextBox34.Name = "TextBox34"
        TextBox34.Size = New Size(123, 27)
        TextBox34.TabIndex = 31
        ' 
        ' Label50
        ' 
        Label50.AutoSize = True
        Label50.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label50.Location = New Point(23, 468)
        Label50.Name = "Label50"
        Label50.Size = New Size(175, 20)
        Label50.TabIndex = 30
        Label50.Text = "Level 7 to Level 8 Height"
        ' 
        ' TextBox35
        ' 
        TextBox35.Location = New Point(220, 468)
        TextBox35.Name = "TextBox35"
        TextBox35.Size = New Size(123, 27)
        TextBox35.TabIndex = 29
        ' 
        ' Label43
        ' 
        Label43.AutoSize = True
        Label43.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label43.Location = New Point(23, 435)
        Label43.Name = "Label43"
        Label43.Size = New Size(175, 20)
        Label43.TabIndex = 28
        Label43.Text = "Level 8 to Level 9 Height"
        ' 
        ' TextBox28
        ' 
        TextBox28.Location = New Point(220, 435)
        TextBox28.Name = "TextBox28"
        TextBox28.Size = New Size(123, 27)
        TextBox28.TabIndex = 27
        ' 
        ' Label44
        ' 
        Label44.AutoSize = True
        Label44.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label44.Location = New Point(23, 402)
        Label44.Name = "Label44"
        Label44.Size = New Size(181, 20)
        Label44.TabIndex = 26
        Label44.Text = "Level 9 to Level 10 Height"
        ' 
        ' TextBox29
        ' 
        TextBox29.Location = New Point(220, 402)
        TextBox29.Name = "TextBox29"
        TextBox29.Size = New Size(123, 27)
        TextBox29.TabIndex = 25
        ' 
        ' Label45
        ' 
        Label45.AutoSize = True
        Label45.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label45.Location = New Point(23, 369)
        Label45.Name = "Label45"
        Label45.Size = New Size(185, 20)
        Label45.TabIndex = 24
        Label45.Text = "Level 10 to Level 11 Height"
        ' 
        ' TextBox30
        ' 
        TextBox30.Location = New Point(220, 369)
        TextBox30.Name = "TextBox30"
        TextBox30.Size = New Size(123, 27)
        TextBox30.TabIndex = 23
        ' 
        ' Label46
        ' 
        Label46.AutoSize = True
        Label46.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label46.Location = New Point(23, 336)
        Label46.Name = "Label46"
        Label46.Size = New Size(189, 20)
        Label46.TabIndex = 22
        Label46.Text = "Level 11 to Level  12 Height"
        ' 
        ' TextBox31
        ' 
        TextBox31.Location = New Point(220, 336)
        TextBox31.Name = "TextBox31"
        TextBox31.Size = New Size(123, 27)
        TextBox31.TabIndex = 21
        ' 
        ' Label39
        ' 
        Label39.AutoSize = True
        Label39.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label39.Location = New Point(23, 303)
        Label39.Name = "Label39"
        Label39.Size = New Size(187, 20)
        Label39.TabIndex = 20
        Label39.Text = "Level 12 to Level 13 Height"
        ' 
        ' TextBox24
        ' 
        TextBox24.Location = New Point(220, 303)
        TextBox24.Name = "TextBox24"
        TextBox24.Size = New Size(123, 27)
        TextBox24.TabIndex = 19
        ' 
        ' Label40
        ' 
        Label40.AutoSize = True
        Label40.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label40.Location = New Point(23, 270)
        Label40.Name = "Label40"
        Label40.Size = New Size(188, 20)
        Label40.TabIndex = 18
        Label40.Text = "Level 13 to Level 14 Height"
        ' 
        ' TextBox25
        ' 
        TextBox25.Location = New Point(220, 270)
        TextBox25.Name = "TextBox25"
        TextBox25.Size = New Size(123, 27)
        TextBox25.TabIndex = 17
        ' 
        ' Label41
        ' 
        Label41.AutoSize = True
        Label41.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label41.Location = New Point(23, 237)
        Label41.Name = "Label41"
        Label41.Size = New Size(192, 20)
        Label41.TabIndex = 16
        Label41.Text = "Level 14 to Level  15 Height"
        ' 
        ' TextBox26
        ' 
        TextBox26.Location = New Point(220, 237)
        TextBox26.Name = "TextBox26"
        TextBox26.Size = New Size(123, 27)
        TextBox26.TabIndex = 15
        ' 
        ' Label42
        ' 
        Label42.AutoSize = True
        Label42.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label42.Location = New Point(23, 204)
        Label42.Name = "Label42"
        Label42.Size = New Size(187, 20)
        Label42.TabIndex = 14
        Label42.Text = "Level 15 to Level 16 Height"
        ' 
        ' TextBox27
        ' 
        TextBox27.Location = New Point(220, 204)
        TextBox27.Name = "TextBox27"
        TextBox27.Size = New Size(123, 27)
        TextBox27.TabIndex = 13
        ' 
        ' Label36
        ' 
        Label36.AutoSize = True
        Label36.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label36.Location = New Point(23, 173)
        Label36.Name = "Label36"
        Label36.Size = New Size(187, 20)
        Label36.TabIndex = 12
        Label36.Text = "Level 16 to Level 17 Height"
        ' 
        ' TextBox22
        ' 
        TextBox22.Location = New Point(220, 173)
        TextBox22.Name = "TextBox22"
        TextBox22.Size = New Size(123, 27)
        TextBox22.TabIndex = 11
        ' 
        ' Label38
        ' 
        Label38.AutoSize = True
        Label38.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label38.Location = New Point(23, 140)
        Label38.Name = "Label38"
        Label38.Size = New Size(187, 20)
        Label38.TabIndex = 10
        Label38.Text = "Level 17 to Level 18 Height"
        ' 
        ' TextBox23
        ' 
        TextBox23.Location = New Point(220, 140)
        TextBox23.Name = "TextBox23"
        TextBox23.Size = New Size(123, 27)
        TextBox23.TabIndex = 9
        ' 
        ' Label35
        ' 
        Label35.AutoSize = True
        Label35.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label35.Location = New Point(23, 107)
        Label35.Name = "Label35"
        Label35.Size = New Size(187, 20)
        Label35.TabIndex = 8
        Label35.Text = "Level 18 to Level 19 Height"
        ' 
        ' TextBox21
        ' 
        TextBox21.Location = New Point(220, 107)
        TextBox21.Name = "TextBox21"
        TextBox21.Size = New Size(123, 27)
        TextBox21.TabIndex = 7
        ' 
        ' Label37
        ' 
        Label37.AutoSize = True
        Label37.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label37.Location = New Point(23, 74)
        Label37.Name = "Label37"
        Label37.Size = New Size(189, 20)
        Label37.TabIndex = 6
        Label37.Text = "Level 19 to Level 20 Height"
        ' 
        ' TextBox18
        ' 
        TextBox18.Location = New Point(220, 74)
        TextBox18.Name = "TextBox18"
        TextBox18.Size = New Size(123, 27)
        TextBox18.TabIndex = 3
        ' 
        ' GroupBox5
        ' 
        GroupBox5.Controls.Add(Label25)
        GroupBox5.Controls.Add(Label21)
        GroupBox5.Controls.Add(ComboBox3)
        GroupBox5.Controls.Add(TextBox16)
        GroupBox5.Controls.Add(Label22)
        GroupBox5.Controls.Add(Label23)
        GroupBox5.Controls.Add(TextBox17)
        GroupBox5.Controls.Add(Label24)
        GroupBox5.Location = New Point(430, 176)
        GroupBox5.Name = "GroupBox5"
        GroupBox5.Size = New Size(389, 246)
        GroupBox5.TabIndex = 10
        GroupBox5.TabStop = False
        GroupBox5.Text = "Beam Type -1 Details"
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label25.Location = New Point(29, 206)
        Label25.Name = "Label25"
        Label25.Size = New Size(208, 17)
        Label25.TabIndex = 12
        Label25.Text = "Levels Min 1 Level - Max 20 Levels"
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label21.Location = New Point(25, 122)
        Label21.Name = "Label21"
        Label21.Size = New Size(276, 17)
        Label21.TabIndex = 11
        Label21.Text = "Load Per Level  Min : 300 Kg  - Max : 4000 Kg"
        ' 
        ' ComboBox3
        ' 
        ComboBox3.FormattingEnabled = True
        ComboBox3.Location = New Point(188, 38)
        ComboBox3.Name = "ComboBox3"
        ComboBox3.Size = New Size(151, 28)
        ComboBox3.TabIndex = 9
        ' 
        ' TextBox16
        ' 
        TextBox16.Location = New Point(188, 176)
        TextBox16.Name = "TextBox16"
        TextBox16.Size = New Size(151, 27)
        TextBox16.TabIndex = 8
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label22.Location = New Point(23, 153)
        Label22.Name = "Label22"
        Label22.Size = New Size(199, 20)
        Label22.TabIndex = 7
        Label22.Text = "Number of such Levels/Unit"
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label23.Location = New Point(23, 46)
        Label23.Name = "Label23"
        Label23.Size = New Size(83, 20)
        Label23.TabIndex = 6
        Label23.Text = "Beam Type"
        ' 
        ' TextBox17
        ' 
        TextBox17.Location = New Point(188, 79)
        TextBox17.Name = "TextBox17"
        TextBox17.Size = New Size(151, 27)
        TextBox17.TabIndex = 3
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label24.Location = New Point(23, 79)
        Label24.Name = "Label24"
        Label24.Size = New Size(105, 20)
        Label24.TabIndex = 1
        Label24.Text = "Load Per level"
        ' 
        ' GroupBox7
        ' 
        GroupBox7.Controls.Add(Label18)
        GroupBox7.Controls.Add(Label19)
        GroupBox7.Controls.Add(ComboBox4)
        GroupBox7.Controls.Add(TextBox9)
        GroupBox7.Controls.Add(Label20)
        GroupBox7.Controls.Add(Label26)
        GroupBox7.Controls.Add(TextBox10)
        GroupBox7.Controls.Add(Label29)
        GroupBox7.Location = New Point(430, 428)
        GroupBox7.Name = "GroupBox7"
        GroupBox7.Size = New Size(389, 233)
        GroupBox7.TabIndex = 11
        GroupBox7.TabStop = False
        GroupBox7.Text = "Beam  Type -2 Details"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(29, 206)
        Label18.Name = "Label18"
        Label18.Size = New Size(208, 17)
        Label18.TabIndex = 12
        Label18.Text = "Levels Min 1 Level - Max 20 Levels"
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label19.Location = New Point(25, 122)
        Label19.Name = "Label19"
        Label19.Size = New Size(276, 17)
        Label19.TabIndex = 11
        Label19.Text = "Load Per Level  Min : 300 Kg  - Max : 4000 Kg"
        ' 
        ' ComboBox4
        ' 
        ComboBox4.FormattingEnabled = True
        ComboBox4.Location = New Point(188, 38)
        ComboBox4.Name = "ComboBox4"
        ComboBox4.Size = New Size(151, 28)
        ComboBox4.TabIndex = 9
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(188, 176)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(151, 27)
        TextBox9.TabIndex = 8
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label20.Location = New Point(23, 153)
        Label20.Name = "Label20"
        Label20.Size = New Size(199, 20)
        Label20.TabIndex = 7
        Label20.Text = "Number of such Levels/Unit"
        ' 
        ' Label26
        ' 
        Label26.AutoSize = True
        Label26.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label26.Location = New Point(23, 46)
        Label26.Name = "Label26"
        Label26.Size = New Size(83, 20)
        Label26.TabIndex = 6
        Label26.Text = "Beam Type"
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(188, 79)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(151, 27)
        TextBox10.TabIndex = 3
        ' 
        ' Label29
        ' 
        Label29.AutoSize = True
        Label29.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label29.Location = New Point(23, 79)
        Label29.Name = "Label29"
        Label29.Size = New Size(105, 20)
        Label29.TabIndex = 1
        Label29.Text = "Load Per level"
        ' 
        ' GroupBox8
        ' 
        GroupBox8.Controls.Add(Label30)
        GroupBox8.Controls.Add(Label31)
        GroupBox8.Controls.Add(ComboBox5)
        GroupBox8.Controls.Add(TextBox11)
        GroupBox8.Controls.Add(Label32)
        GroupBox8.Controls.Add(Label33)
        GroupBox8.Controls.Add(TextBox12)
        GroupBox8.Controls.Add(Label34)
        GroupBox8.Location = New Point(430, 664)
        GroupBox8.Name = "GroupBox8"
        GroupBox8.Size = New Size(389, 226)
        GroupBox8.TabIndex = 12
        GroupBox8.TabStop = False
        GroupBox8.Text = "Beam  Type -3 Details"
        ' 
        ' Label30
        ' 
        Label30.AutoSize = True
        Label30.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label30.Location = New Point(29, 206)
        Label30.Name = "Label30"
        Label30.Size = New Size(208, 17)
        Label30.TabIndex = 12
        Label30.Text = "Levels Min 1 Level - Max 20 Levels"
        ' 
        ' Label31
        ' 
        Label31.AutoSize = True
        Label31.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label31.Location = New Point(25, 122)
        Label31.Name = "Label31"
        Label31.Size = New Size(276, 17)
        Label31.TabIndex = 11
        Label31.Text = "Load Per Level  Min : 300 Kg  - Max : 4000 Kg"
        ' 
        ' ComboBox5
        ' 
        ComboBox5.FormattingEnabled = True
        ComboBox5.Location = New Point(206, 38)
        ComboBox5.Name = "ComboBox5"
        ComboBox5.Size = New Size(123, 28)
        ComboBox5.TabIndex = 9
        ' 
        ' TextBox11
        ' 
        TextBox11.Location = New Point(206, 176)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(123, 27)
        TextBox11.TabIndex = 8
        ' 
        ' Label32
        ' 
        Label32.AutoSize = True
        Label32.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label32.Location = New Point(23, 153)
        Label32.Name = "Label32"
        Label32.Size = New Size(199, 20)
        Label32.TabIndex = 7
        Label32.Text = "Number of such Levels/Unit"
        ' 
        ' Label33
        ' 
        Label33.AutoSize = True
        Label33.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label33.Location = New Point(23, 46)
        Label33.Name = "Label33"
        Label33.Size = New Size(83, 20)
        Label33.TabIndex = 6
        Label33.Text = "Beam Type"
        ' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(206, 79)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(123, 27)
        TextBox12.TabIndex = 3
        ' 
        ' Label34
        ' 
        Label34.AutoSize = True
        Label34.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label34.Location = New Point(23, 79)
        Label34.Name = "Label34"
        Label34.Size = New Size(105, 20)
        Label34.TabIndex = 1
        Label34.Text = "Load Per level"
        ' 
        ' GroupBox4
        ' 
        GroupBox4.Controls.Add(Label11)
        GroupBox4.Controls.Add(Label10)
        GroupBox4.Controls.Add(Label17)
        GroupBox4.Controls.Add(TextBox8)
        GroupBox4.Location = New Point(430, 20)
        GroupBox4.Name = "GroupBox4"
        GroupBox4.Size = New Size(389, 150)
        GroupBox4.TabIndex = 9
        GroupBox4.TabStop = False
        GroupBox4.Text = "Beam Details"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(29, 117)
        Label11.Name = "Label11"
        Label11.Size = New Size(262, 17)
        Label11.TabIndex = 11
        Label11.Text = "Max  Beam Span : 4000 mm @ 50 mm Pitch"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(29, 87)
        Label10.Name = "Label10"
        Label10.Size = New Size(164, 17)
        Label10.TabIndex = 10
        Label10.Text = "Min Beam Span : 1200 mm"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label17.Location = New Point(23, 46)
        Label17.Name = "Label17"
        Label17.Size = New Size(85, 20)
        Label17.TabIndex = 6
        Label17.Text = "Beam Span"
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(188, 46)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(151, 27)
        TextBox8.TabIndex = 3
        ' 
        ' GroupBox6
        ' 
        GroupBox6.Controls.Add(TextBox20)
        GroupBox6.Controls.Add(Label27)
        GroupBox6.Controls.Add(TextBox19)
        GroupBox6.Controls.Add(Label28)
        GroupBox6.Location = New Point(15, 734)
        GroupBox6.Name = "GroupBox6"
        GroupBox6.Size = New Size(389, 156)
        GroupBox6.TabIndex = 8
        GroupBox6.TabStop = False
        GroupBox6.Text = "Frame Details"
        ' 
        ' TextBox20
        ' 
        TextBox20.Location = New Point(206, 39)
        TextBox20.Name = "TextBox20"
        TextBox20.Size = New Size(123, 27)
        TextBox20.TabIndex = 11
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label27.Location = New Point(23, 46)
        Label27.Name = "Label27"
        Label27.Size = New Size(85, 20)
        Label27.TabIndex = 6
        Label27.Text = "Under Pass"
        ' 
        ' TextBox19
        ' 
        TextBox19.Location = New Point(206, 107)
        TextBox19.Name = "TextBox19"
        TextBox19.Size = New Size(123, 27)
        TextBox19.TabIndex = 3
        ' 
        ' Label28
        ' 
        Label28.AutoSize = True
        Label28.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label28.Location = New Point(23, 79)
        Label28.Name = "Label28"
        Label28.Size = New Size(221, 17)
        Label28.TabIndex = 1
        Label28.Text = "Frame sections for Underpass unit?"
        ' 
        ' GroupBox3
        ' 
        GroupBox3.Controls.Add(Label9)
        GroupBox3.Controls.Add(ComboBox2)
        GroupBox3.Controls.Add(ComboBox1)
        GroupBox3.Controls.Add(Label12)
        GroupBox3.Controls.Add(Label15)
        GroupBox3.Controls.Add(TextBox15)
        GroupBox3.Controls.Add(Label16)
        GroupBox3.Location = New Point(15, 569)
        GroupBox3.Name = "GroupBox3"
        GroupBox3.Size = New Size(389, 159)
        GroupBox3.TabIndex = 5
        GroupBox3.TabStop = False
        GroupBox3.Text = "Frame Details"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(29, 95)
        Label9.Name = "Label9"
        Label9.Size = New Size(222, 17)
        Label9.TabIndex = 10
        Label9.Text = "Upright height be in multiples of 100"
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(188, 118)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(151, 28)
        ComboBox2.TabIndex = 9
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(188, 32)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(151, 28)
        ComboBox1.TabIndex = 8
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label12.Location = New Point(23, 121)
        Label12.Name = "Label12"
        Label12.Size = New Size(87, 20)
        Label12.TabIndex = 7
        Label12.Text = "Frame Type"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label15.Location = New Point(23, 32)
        Label15.Name = "Label15"
        Label15.Size = New Size(97, 20)
        Label15.TabIndex = 6
        Label15.Text = "Frame Depth"
        ' 
        ' TextBox15
        ' 
        TextBox15.Location = New Point(188, 65)
        TextBox15.Name = "TextBox15"
        TextBox15.Size = New Size(151, 27)
        TextBox15.TabIndex = 3
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label16.Location = New Point(23, 65)
        Label16.Name = "Label16"
        Label16.Size = New Size(101, 20)
        Label16.TabIndex = 1
        Label16.Text = "Frame Height"
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(Label8)
        GroupBox2.Controls.Add(Label13)
        GroupBox2.Controls.Add(TextBox13)
        GroupBox2.Controls.Add(TextBox14)
        GroupBox2.Controls.Add(Label14)
        GroupBox2.Location = New Point(15, 403)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(389, 160)
        GroupBox2.TabIndex = 4
        GroupBox2.TabStop = False
        GroupBox2.Text = "Pallet Details"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(107, 118)
        Label8.Name = "Label8"
        Label8.Size = New Size(198, 17)
        Label8.TabIndex = 7
        Label8.Text = "Pallet Depth Min:500-  Max 1500"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label13.Location = New Point(23, 46)
        Label13.Name = "Label13"
        Label13.Size = New Size(131, 20)
        Label13.TabIndex = 6
        Label13.Text = "No of Pallets/Unit"
        ' 
        ' TextBox13
        ' 
        TextBox13.Location = New Point(188, 79)
        TextBox13.Name = "TextBox13"
        TextBox13.Size = New Size(151, 27)
        TextBox13.TabIndex = 3
        ' 
        ' TextBox14
        ' 
        TextBox14.Location = New Point(188, 42)
        TextBox14.Name = "TextBox14"
        TextBox14.Size = New Size(151, 27)
        TextBox14.TabIndex = 2
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label14.Location = New Point(23, 79)
        Label14.Name = "Label14"
        Label14.Size = New Size(93, 20)
        Label14.TabIndex = 1
        Label14.Text = "Pallet Depth"
        ' 
        ' TabPage7
        ' 
        TabPage7.Controls.Add(GroupBox11)
        TabPage7.Controls.Add(GroupBox14)
        TabPage7.Controls.Add(GroupBox15)
        TabPage7.Controls.Add(GroupBox13)
        TabPage7.Location = New Point(4, 29)
        TabPage7.Name = "TabPage7"
        TabPage7.Padding = New Padding(3)
        TabPage7.Size = New Size(1721, 911)
        TabPage7.TabIndex = 6
        TabPage7.Text = "Upright details"
        TabPage7.UseVisualStyleBackColor = True
        ' 
        ' GroupBox11
        ' 
        GroupBox11.Controls.Add(TextBox92)
        GroupBox11.Controls.Add(Label67)
        GroupBox11.Controls.Add(Label63)
        GroupBox11.Controls.Add(TextBox46)
        GroupBox11.Controls.Add(Label62)
        GroupBox11.Controls.Add(TextBox45)
        GroupBox11.Controls.Add(Label61)
        GroupBox11.Controls.Add(TextBox44)
        GroupBox11.Controls.Add(Label58)
        GroupBox11.Controls.Add(TextBox41)
        GroupBox11.Controls.Add(Label57)
        GroupBox11.Controls.Add(TextBox40)
        GroupBox11.Controls.Add(TextBox42)
        GroupBox11.Controls.Add(Label59)
        GroupBox11.Controls.Add(TextBox43)
        GroupBox11.Controls.Add(Label60)
        GroupBox11.Controls.Add(TextBox47)
        GroupBox11.Controls.Add(Label64)
        GroupBox11.Controls.Add(Label65)
        GroupBox11.Controls.Add(TextBox48)
        GroupBox11.Controls.Add(TextBox49)
        GroupBox11.Controls.Add(Label66)
        GroupBox11.Location = New Point(37, 218)
        GroupBox11.Name = "GroupBox11"
        GroupBox11.Size = New Size(448, 442)
        GroupBox11.TabIndex = 16
        GroupBox11.TabStop = False
        GroupBox11.Text = "Input parameters"
        ' 
        ' TextBox92
        ' 
        TextBox92.Location = New Point(206, 395)
        TextBox92.Name = "TextBox92"
        TextBox92.Size = New Size(221, 27)
        TextBox92.TabIndex = 26
        ' 
        ' Label67
        ' 
        Label67.AutoSize = True
        Label67.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label67.Location = New Point(25, 395)
        Label67.Name = "Label67"
        Label67.Size = New Size(35, 20)
        Label67.TabIndex = 25
        Label67.Text = "USL"
        ' 
        ' Label63
        ' 
        Label63.AutoSize = True
        Label63.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label63.Location = New Point(25, 360)
        Label63.Name = "Label63"
        Label63.Size = New Size(90, 20)
        Label63.TabIndex = 24
        Label63.Text = "Stiffener124"
        ' 
        ' TextBox46
        ' 
        TextBox46.Location = New Point(206, 353)
        TextBox46.Name = "TextBox46"
        TextBox46.Size = New Size(221, 27)
        TextBox46.TabIndex = 23
        ' 
        ' Label62
        ' 
        Label62.AutoSize = True
        Label62.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label62.Location = New Point(23, 321)
        Label62.Name = "Label62"
        Label62.Size = New Size(90, 20)
        Label62.TabIndex = 22
        Label62.Text = "Stiffener124"
        ' 
        ' TextBox45
        ' 
        TextBox45.Location = New Point(206, 314)
        TextBox45.Name = "TextBox45"
        TextBox45.Size = New Size(221, 27)
        TextBox45.TabIndex = 21
        ' 
        ' Label61
        ' 
        Label61.AutoSize = True
        Label61.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label61.Location = New Point(23, 284)
        Label61.Name = "Label61"
        Label61.Size = New Size(74, 20)
        Label61.TabIndex = 20
        Label61.Text = "X bracing"
        ' 
        ' TextBox44
        ' 
        TextBox44.Location = New Point(206, 277)
        TextBox44.Name = "TextBox44"
        TextBox44.Size = New Size(221, 27)
        TextBox44.TabIndex = 19
        ' 
        ' Label58
        ' 
        Label58.AutoSize = True
        Label58.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label58.Location = New Point(23, 247)
        Label58.Name = "Label58"
        Label58.Size = New Size(95, 20)
        Label58.TabIndex = 18
        Label58.Text = "Frame depth"
        ' 
        ' TextBox41
        ' 
        TextBox41.Location = New Point(206, 244)
        TextBox41.Name = "TextBox41"
        TextBox41.Size = New Size(221, 27)
        TextBox41.TabIndex = 17
        ' 
        ' Label57
        ' 
        Label57.AutoSize = True
        Label57.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label57.Location = New Point(25, 218)
        Label57.Name = "Label57"
        Label57.Size = New Size(61, 20)
        Label57.TabIndex = 16
        Label57.Text = "Bracing"
        ' 
        ' TextBox40
        ' 
        TextBox40.Location = New Point(206, 211)
        TextBox40.Name = "TextBox40"
        TextBox40.Size = New Size(221, 27)
        TextBox40.TabIndex = 15
        ' 
        ' TextBox42
        ' 
        TextBox42.Location = New Point(206, 178)
        TextBox42.Name = "TextBox42"
        TextBox42.Size = New Size(221, 27)
        TextBox42.TabIndex = 12
        ' 
        ' Label59
        ' 
        Label59.AutoSize = True
        Label59.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label59.Location = New Point(23, 178)
        Label59.Name = "Label59"
        Label59.Size = New Size(62, 20)
        Label59.TabIndex = 11
        Label59.Text = "Upright"
        ' 
        ' TextBox43
        ' 
        TextBox43.Location = New Point(206, 145)
        TextBox43.Name = "TextBox43"
        TextBox43.Size = New Size(221, 27)
        TextBox43.TabIndex = 10
        ' 
        ' Label60
        ' 
        Label60.AutoSize = True
        Label60.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label60.Location = New Point(25, 145)
        Label60.Name = "Label60"
        Label60.Size = New Size(35, 20)
        Label60.TabIndex = 9
        Label60.Text = "USL"
        ' 
        ' TextBox47
        ' 
        TextBox47.Location = New Point(206, 112)
        TextBox47.Name = "TextBox47"
        TextBox47.Size = New Size(221, 27)
        TextBox47.TabIndex = 8
        ' 
        ' Label64
        ' 
        Label64.AutoSize = True
        Label64.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label64.Location = New Point(23, 112)
        Label64.Name = "Label64"
        Label64.Size = New Size(85, 20)
        Label64.TabIndex = 7
        Label64.Text = "Beam Span"
        ' 
        ' Label65
        ' 
        Label65.AutoSize = True
        Label65.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label65.Location = New Point(23, 46)
        Label65.Name = "Label65"
        Label65.Size = New Size(99, 20)
        Label65.TabIndex = 6
        Label65.Text = "Frame height"
        ' 
        ' TextBox48
        ' 
        TextBox48.Location = New Point(206, 79)
        TextBox48.Name = "TextBox48"
        TextBox48.Size = New Size(221, 27)
        TextBox48.TabIndex = 3
        ' 
        ' TextBox49
        ' 
        TextBox49.Location = New Point(206, 42)
        TextBox49.Name = "TextBox49"
        TextBox49.Size = New Size(221, 27)
        TextBox49.TabIndex = 2
        ' 
        ' Label66
        ' 
        Label66.AutoSize = True
        Label66.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label66.Location = New Point(23, 79)
        Label66.Name = "Label66"
        Label66.Size = New Size(85, 20)
        Label66.TabIndex = 1
        Label66.Text = "Frame load"
        ' 
        ' GroupBox14
        ' 
        GroupBox14.Controls.Add(TextBox100)
        GroupBox14.Controls.Add(Label91)
        GroupBox14.Location = New Point(1017, 513)
        GroupBox14.Name = "GroupBox14"
        GroupBox14.Size = New Size(389, 118)
        GroupBox14.TabIndex = 15
        GroupBox14.TabStop = False
        GroupBox14.Text = "Output"
        ' 
        ' TextBox100
        ' 
        TextBox100.Location = New Point(203, 39)
        TextBox100.Name = "TextBox100"
        TextBox100.Size = New Size(123, 27)
        TextBox100.TabIndex = 10
        ' 
        ' Label91
        ' 
        Label91.AutoSize = True
        Label91.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label91.Location = New Point(20, 39)
        Label91.Name = "Label91"
        Label91.Size = New Size(178, 20)
        Label91.TabIndex = 9
        Label91.Text = "Frame Utlisation % (FUT)"
        ' 
        ' GroupBox15
        ' 
        GroupBox15.Controls.Add(TextBox101)
        GroupBox15.Controls.Add(Label92)
        GroupBox15.Controls.Add(Label93)
        GroupBox15.Controls.Add(TextBox102)
        GroupBox15.Controls.Add(TextBox103)
        GroupBox15.Controls.Add(Label94)
        GroupBox15.Location = New Point(1017, 290)
        GroupBox15.Name = "GroupBox15"
        GroupBox15.Size = New Size(389, 175)
        GroupBox15.TabIndex = 14
        GroupBox15.TabStop = False
        GroupBox15.Text = "Output"
        ' 
        ' TextBox101
        ' 
        TextBox101.Location = New Point(206, 122)
        TextBox101.Name = "TextBox101"
        TextBox101.Size = New Size(123, 27)
        TextBox101.TabIndex = 8
        ' 
        ' Label92
        ' 
        Label92.AutoSize = True
        Label92.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label92.Location = New Point(23, 122)
        Label92.Name = "Label92"
        Label92.Size = New Size(67, 20)
        Label92.TabIndex = 7
        Label92.Text = "Stiffener"
        ' 
        ' Label93
        ' 
        Label93.AutoSize = True
        Label93.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label93.Location = New Point(23, 46)
        Label93.Name = "Label93"
        Label93.Size = New Size(128, 20)
        Label93.TabIndex = 6
        Label93.Text = "Upright Selection"
        ' 
        ' TextBox102
        ' 
        TextBox102.Location = New Point(206, 79)
        TextBox102.Name = "TextBox102"
        TextBox102.Size = New Size(123, 27)
        TextBox102.TabIndex = 3
        ' 
        ' TextBox103
        ' 
        TextBox103.Location = New Point(206, 42)
        TextBox103.Name = "TextBox103"
        TextBox103.Size = New Size(123, 27)
        TextBox103.TabIndex = 2
        ' 
        ' Label94
        ' 
        Label94.AutoSize = True
        Label94.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label94.Location = New Point(23, 79)
        Label94.Name = "Label94"
        Label94.Size = New Size(82, 20)
        Label94.TabIndex = 1
        Label94.Text = "X Bracking"
        ' 
        ' GroupBox13
        ' 
        GroupBox13.Controls.Add(Label71)
        GroupBox13.Controls.Add(Label72)
        GroupBox13.Controls.Add(Label81)
        GroupBox13.Controls.Add(Label82)
        GroupBox13.Controls.Add(Label83)
        GroupBox13.Controls.Add(TextBox50)
        GroupBox13.Controls.Add(TextBox51)
        GroupBox13.Controls.Add(Label84)
        GroupBox13.Controls.Add(TextBox94)
        GroupBox13.Controls.Add(Label85)
        GroupBox13.Controls.Add(TextBox95)
        GroupBox13.Controls.Add(Label86)
        GroupBox13.Controls.Add(TextBox96)
        GroupBox13.Controls.Add(Label87)
        GroupBox13.Controls.Add(Label88)
        GroupBox13.Controls.Add(TextBox97)
        GroupBox13.Controls.Add(TextBox98)
        GroupBox13.Controls.Add(Label89)
        GroupBox13.Location = New Point(514, 205)
        GroupBox13.Name = "GroupBox13"
        GroupBox13.Size = New Size(389, 486)
        GroupBox13.TabIndex = 13
        GroupBox13.TabStop = False
        GroupBox13.Text = "Upright Details"
        ' 
        ' Label71
        ' 
        Label71.AutoSize = True
        Label71.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label71.Location = New Point(197, 409)
        Label71.Name = "Label71"
        Label71.Size = New Size(159, 17)
        Label71.TabIndex = 20
        Label71.Text = "(Enter 0 if not applicable)"
        ' 
        ' Label72
        ' 
        Label72.AutoSize = True
        Label72.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label72.Location = New Point(197, 320)
        Label72.Name = "Label72"
        Label72.Size = New Size(159, 17)
        Label72.TabIndex = 19
        Label72.Text = "(Enter 0 if not applicable)"
        ' 
        ' Label81
        ' 
        Label81.AutoSize = True
        Label81.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label81.Location = New Point(165, 229)
        Label81.Name = "Label81"
        Label81.Size = New Size(191, 17)
        Label81.TabIndex = 18
        Label81.Text = "(Enter 1.4 thk if not applicable)"
        ' 
        ' Label82
        ' 
        Label82.AutoSize = True
        Label82.Font = New Font("Yu Gothic UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label82.Location = New Point(78, 111)
        Label82.Name = "Label82"
        Label82.Size = New Size(251, 17)
        Label82.TabIndex = 17
        Label82.Text = "(If frame height greater than 12000 mm)"
        ' 
        ' Label83
        ' 
        Label83.AutoSize = True
        Label83.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label83.Location = New Point(29, 445)
        Label83.Name = "Label83"
        Label83.Size = New Size(114, 20)
        Label83.TabIndex = 16
        Label83.Text = "Base Plate Type"
        ' 
        ' TextBox50
        ' 
        TextBox50.Location = New Point(206, 440)
        TextBox50.Name = "TextBox50"
        TextBox50.Size = New Size(125, 27)
        TextBox50.TabIndex = 15
        ' 
        ' TextBox51
        ' 
        TextBox51.Location = New Point(206, 379)
        TextBox51.Name = "TextBox51"
        TextBox51.Size = New Size(123, 27)
        TextBox51.TabIndex = 14
        ' 
        ' Label84
        ' 
        Label84.AutoSize = True
        Label84.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label84.Location = New Point(23, 356)
        Label84.Name = "Label84"
        Label84.Size = New Size(237, 20)
        Label84.TabIndex = 13
        Label84.Text = """X"" Bracking height from Ground"
        ' 
        ' TextBox94
        ' 
        TextBox94.Location = New Point(206, 280)
        TextBox94.Name = "TextBox94"
        TextBox94.Size = New Size(123, 27)
        TextBox94.TabIndex = 12
        ' 
        ' Label85
        ' 
        Label85.AutoSize = True
        Label85.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label85.Location = New Point(23, 280)
        Label85.Name = "Label85"
        Label85.Size = New Size(171, 20)
        Label85.TabIndex = 11
        Label85.Text = "No of Stiffners/ Upright"
        ' 
        ' TextBox95
        ' 
        TextBox95.Location = New Point(206, 189)
        TextBox95.Name = "TextBox95"
        TextBox95.Size = New Size(123, 27)
        TextBox95.TabIndex = 10
        ' 
        ' Label86
        ' 
        Label86.AutoSize = True
        Label86.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label86.Location = New Point(23, 189)
        Label86.Name = "Label86"
        Label86.Size = New Size(144, 20)
        Label86.TabIndex = 9
        Label86.Text = "Bracking thinckness"
        ' 
        ' TextBox96
        ' 
        TextBox96.Location = New Point(206, 144)
        TextBox96.Name = "TextBox96"
        TextBox96.Size = New Size(123, 27)
        TextBox96.TabIndex = 8
        ' 
        ' Label87
        ' 
        Label87.AutoSize = True
        Label87.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label87.Location = New Point(23, 144)
        Label87.Name = "Label87"
        Label87.Size = New Size(145, 20)
        Label87.TabIndex = 7
        Label87.Text = "Upper Upright Type"
        ' 
        ' Label88
        ' 
        Label88.AutoSize = True
        Label88.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label88.Location = New Point(23, 46)
        Label88.Name = "Label88"
        Label88.Size = New Size(98, 20)
        Label88.TabIndex = 6
        Label88.Text = "Upright Type"
        ' 
        ' TextBox97
        ' 
        TextBox97.Location = New Point(206, 79)
        TextBox97.Name = "TextBox97"
        TextBox97.Size = New Size(123, 27)
        TextBox97.TabIndex = 3
        ' 
        ' TextBox98
        ' 
        TextBox98.Location = New Point(206, 42)
        TextBox98.Name = "TextBox98"
        TextBox98.Size = New Size(123, 27)
        TextBox98.TabIndex = 2
        ' 
        ' Label89
        ' 
        Label89.AutoSize = True
        Label89.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label89.Location = New Point(23, 79)
        Label89.Name = "Label89"
        Label89.Size = New Size(165, 20)
        Label89.TabIndex = 1
        Label89.Text = "Upper -Upright Height"
        ' 
        ' TabPage8
        ' 
        TabPage8.Controls.Add(GroupBox16)
        TabPage8.Controls.Add(GroupBox12)
        TabPage8.Controls.Add(TextBox99)
        TabPage8.Controls.Add(Label90)
        TabPage8.Controls.Add(GroupBox10)
        TabPage8.Location = New Point(4, 29)
        TabPage8.Name = "TabPage8"
        TabPage8.Padding = New Padding(3)
        TabPage8.Size = New Size(1721, 911)
        TabPage8.TabIndex = 7
        TabPage8.Text = "Level details"
        TabPage8.UseVisualStyleBackColor = True
        ' 
        ' GroupBox16
        ' 
        GroupBox16.Controls.Add(ComboBox25)
        GroupBox16.Controls.Add(ComboBox26)
        GroupBox16.Controls.Add(ComboBox27)
        GroupBox16.Controls.Add(ComboBox28)
        GroupBox16.Controls.Add(TextBox111)
        GroupBox16.Controls.Add(Label112)
        GroupBox16.Controls.Add(TextBox112)
        GroupBox16.Controls.Add(ComboBox29)
        GroupBox16.Controls.Add(Label113)
        GroupBox16.Controls.Add(ComboBox30)
        GroupBox16.Controls.Add(Label114)
        GroupBox16.Controls.Add(Label115)
        GroupBox16.Controls.Add(ComboBox31)
        GroupBox16.Controls.Add(Label116)
        GroupBox16.Controls.Add(Label117)
        GroupBox16.Controls.Add(TextBox113)
        GroupBox16.Controls.Add(Label118)
        GroupBox16.Controls.Add(Label119)
        GroupBox16.Controls.Add(Label120)
        GroupBox16.Controls.Add(Label121)
        GroupBox16.Controls.Add(TextBox114)
        GroupBox16.Controls.Add(Label122)
        GroupBox16.Location = New Point(1206, 161)
        GroupBox16.Name = "GroupBox16"
        GroupBox16.Size = New Size(461, 506)
        GroupBox16.TabIndex = 16
        GroupBox16.TabStop = False
        GroupBox16.Text = "Level -3  Details"
        ' 
        ' ComboBox25
        ' 
        ComboBox25.FormattingEnabled = True
        ComboBox25.Location = New Point(232, 356)
        ComboBox25.Name = "ComboBox25"
        ComboBox25.Size = New Size(151, 28)
        ComboBox25.TabIndex = 29
        ' 
        ' ComboBox26
        ' 
        ComboBox26.FormattingEnabled = True
        ComboBox26.Location = New Point(232, 319)
        ComboBox26.Name = "ComboBox26"
        ComboBox26.Size = New Size(151, 28)
        ComboBox26.TabIndex = 29
        ' 
        ' ComboBox27
        ' 
        ComboBox27.FormattingEnabled = True
        ComboBox27.Location = New Point(232, 241)
        ComboBox27.Name = "ComboBox27"
        ComboBox27.Size = New Size(151, 28)
        ComboBox27.TabIndex = 28
        ' 
        ' ComboBox28
        ' 
        ComboBox28.FormattingEnabled = True
        ComboBox28.Location = New Point(232, 207)
        ComboBox28.Name = "ComboBox28"
        ComboBox28.Size = New Size(151, 28)
        ComboBox28.TabIndex = 27
        ' 
        ' TextBox111
        ' 
        TextBox111.Location = New Point(232, 30)
        TextBox111.Name = "TextBox111"
        TextBox111.Size = New Size(151, 27)
        TextBox111.TabIndex = 26
        ' 
        ' Label112
        ' 
        Label112.AutoSize = True
        Label112.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label112.Location = New Point(26, 414)
        Label112.Name = "Label112"
        Label112.Size = New Size(186, 20)
        Label112.TabIndex = 25
        Label112.Text = "No Of Such Levels / Unit *"
        ' 
        ' TextBox112
        ' 
        TextBox112.Location = New Point(232, 411)
        TextBox112.Name = "TextBox112"
        TextBox112.Size = New Size(151, 27)
        TextBox112.TabIndex = 24
        ' 
        ' ComboBox29
        ' 
        ComboBox29.FormattingEnabled = True
        ComboBox29.Location = New Point(232, 98)
        ComboBox29.Name = "ComboBox29"
        ComboBox29.Size = New Size(151, 28)
        ComboBox29.TabIndex = 23
        ' 
        ' Label113
        ' 
        Label113.AutoSize = True
        Label113.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label113.Location = New Point(20, 101)
        Label113.Name = "Label113"
        Label113.Size = New Size(133, 20)
        Label113.TabIndex = 22
        Label113.Text = "Accessory Type 1 *"
        ' 
        ' ComboBox30
        ' 
        ComboBox30.FormattingEnabled = True
        ComboBox30.Location = New Point(232, 64)
        ComboBox30.Name = "ComboBox30"
        ComboBox30.Size = New Size(151, 28)
        ComboBox30.TabIndex = 21
        ' 
        ' Label114
        ' 
        Label114.AutoSize = True
        Label114.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label114.Location = New Point(20, 67)
        Label114.Name = "Label114"
        Label114.Size = New Size(112, 20)
        Label114.TabIndex = 20
        Label114.Text = "Beam Section *"
        ' 
        ' Label115
        ' 
        Label115.AutoSize = True
        Label115.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label115.Location = New Point(20, 33)
        Label115.Name = "Label115"
        Label115.Size = New Size(146, 20)
        Label115.TabIndex = 18
        Label115.Text = "Single Pallet Weight"
        ' 
        ' ComboBox31
        ' 
        ComboBox31.FormattingEnabled = True
        ComboBox31.Location = New Point(232, 134)
        ComboBox31.Name = "ComboBox31"
        ComboBox31.Size = New Size(151, 28)
        ComboBox31.TabIndex = 17
        ' 
        ' Label116
        ' 
        Label116.AutoSize = True
        Label116.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label116.Location = New Point(26, 353)
        Label116.Name = "Label116"
        Label116.Size = New Size(151, 20)
        Label116.TabIndex = 16
        Label116.Text = "Application of panel "
        ' 
        ' Label117
        ' 
        Label117.AutoSize = True
        Label117.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label117.Location = New Point(22, 322)
        Label117.Name = "Label117"
        Label117.Size = New Size(170, 20)
        Label117.TabIndex = 13
        Label117.Text = "6B Panel Width ( Main )"
        ' 
        ' TextBox113
        ' 
        TextBox113.Location = New Point(232, 279)
        TextBox113.Name = "TextBox113"
        TextBox113.Size = New Size(151, 27)
        TextBox113.TabIndex = 12
        ' 
        ' Label118
        ' 
        Label118.AutoSize = True
        Label118.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label118.Location = New Point(20, 279)
        Label118.Name = "Label118"
        Label118.Size = New Size(125, 20)
        Label118.TabIndex = 11
        Label118.Text = "Accessory / Level"
        ' 
        ' Label119
        ' 
        Label119.AutoSize = True
        Label119.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label119.Location = New Point(20, 241)
        Label119.Name = "Label119"
        Label119.Size = New Size(145, 20)
        Label119.TabIndex = 9
        Label119.Text = "Accessory Thickness"
        ' 
        ' Label120
        ' 
        Label120.AutoSize = True
        Label120.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label120.Location = New Point(20, 209)
        Label120.Name = "Label120"
        Label120.Size = New Size(128, 20)
        Label120.TabIndex = 7
        Label120.Text = "Accessory Type 2 "
        ' 
        ' Label121
        ' 
        Label121.AutoSize = True
        Label121.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label121.Location = New Point(20, 133)
        Label121.Name = "Label121"
        Label121.Size = New Size(145, 20)
        Label121.TabIndex = 6
        Label121.Text = "Accessory Thickness"
        ' 
        ' TextBox114
        ' 
        TextBox114.Location = New Point(232, 168)
        TextBox114.Name = "TextBox114"
        TextBox114.Size = New Size(151, 27)
        TextBox114.TabIndex = 3
        ' 
        ' Label122
        ' 
        Label122.AutoSize = True
        Label122.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label122.Location = New Point(20, 168)
        Label122.Name = "Label122"
        Label122.Size = New Size(129, 20)
        Label122.TabIndex = 1
        Label122.Text = "Accessory / Level "
        ' 
        ' GroupBox12
        ' 
        GroupBox12.Controls.Add(ComboBox18)
        GroupBox12.Controls.Add(ComboBox19)
        GroupBox12.Controls.Add(ComboBox20)
        GroupBox12.Controls.Add(ComboBox21)
        GroupBox12.Controls.Add(TextBox93)
        GroupBox12.Controls.Add(Label101)
        GroupBox12.Controls.Add(TextBox104)
        GroupBox12.Controls.Add(ComboBox22)
        GroupBox12.Controls.Add(Label102)
        GroupBox12.Controls.Add(ComboBox23)
        GroupBox12.Controls.Add(Label103)
        GroupBox12.Controls.Add(Label104)
        GroupBox12.Controls.Add(ComboBox24)
        GroupBox12.Controls.Add(Label105)
        GroupBox12.Controls.Add(Label106)
        GroupBox12.Controls.Add(TextBox106)
        GroupBox12.Controls.Add(Label107)
        GroupBox12.Controls.Add(Label108)
        GroupBox12.Controls.Add(Label109)
        GroupBox12.Controls.Add(Label110)
        GroupBox12.Controls.Add(TextBox107)
        GroupBox12.Controls.Add(Label111)
        GroupBox12.Location = New Point(689, 161)
        GroupBox12.Name = "GroupBox12"
        GroupBox12.Size = New Size(461, 506)
        GroupBox12.TabIndex = 15
        GroupBox12.TabStop = False
        GroupBox12.Text = "Level -2  Details"
        ' 
        ' ComboBox18
        ' 
        ComboBox18.FormattingEnabled = True
        ComboBox18.Location = New Point(232, 356)
        ComboBox18.Name = "ComboBox18"
        ComboBox18.Size = New Size(151, 28)
        ComboBox18.TabIndex = 29
        ' 
        ' ComboBox19
        ' 
        ComboBox19.FormattingEnabled = True
        ComboBox19.Location = New Point(232, 319)
        ComboBox19.Name = "ComboBox19"
        ComboBox19.Size = New Size(151, 28)
        ComboBox19.TabIndex = 29
        ' 
        ' ComboBox20
        ' 
        ComboBox20.FormattingEnabled = True
        ComboBox20.Location = New Point(232, 241)
        ComboBox20.Name = "ComboBox20"
        ComboBox20.Size = New Size(151, 28)
        ComboBox20.TabIndex = 28
        ' 
        ' ComboBox21
        ' 
        ComboBox21.FormattingEnabled = True
        ComboBox21.Location = New Point(232, 207)
        ComboBox21.Name = "ComboBox21"
        ComboBox21.Size = New Size(151, 28)
        ComboBox21.TabIndex = 27
        ' 
        ' TextBox93
        ' 
        TextBox93.Location = New Point(232, 30)
        TextBox93.Name = "TextBox93"
        TextBox93.Size = New Size(151, 27)
        TextBox93.TabIndex = 26
        ' 
        ' Label101
        ' 
        Label101.AutoSize = True
        Label101.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label101.Location = New Point(26, 414)
        Label101.Name = "Label101"
        Label101.Size = New Size(186, 20)
        Label101.TabIndex = 25
        Label101.Text = "No Of Such Levels / Unit *"
        ' 
        ' TextBox104
        ' 
        TextBox104.Location = New Point(232, 411)
        TextBox104.Name = "TextBox104"
        TextBox104.Size = New Size(151, 27)
        TextBox104.TabIndex = 24
        ' 
        ' ComboBox22
        ' 
        ComboBox22.FormattingEnabled = True
        ComboBox22.Location = New Point(232, 98)
        ComboBox22.Name = "ComboBox22"
        ComboBox22.Size = New Size(151, 28)
        ComboBox22.TabIndex = 23
        ' 
        ' Label102
        ' 
        Label102.AutoSize = True
        Label102.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label102.Location = New Point(20, 101)
        Label102.Name = "Label102"
        Label102.Size = New Size(133, 20)
        Label102.TabIndex = 22
        Label102.Text = "Accessory Type 1 *"
        ' 
        ' ComboBox23
        ' 
        ComboBox23.FormattingEnabled = True
        ComboBox23.Location = New Point(232, 64)
        ComboBox23.Name = "ComboBox23"
        ComboBox23.Size = New Size(151, 28)
        ComboBox23.TabIndex = 21
        ' 
        ' Label103
        ' 
        Label103.AutoSize = True
        Label103.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label103.Location = New Point(20, 67)
        Label103.Name = "Label103"
        Label103.Size = New Size(112, 20)
        Label103.TabIndex = 20
        Label103.Text = "Beam Section *"
        ' 
        ' Label104
        ' 
        Label104.AutoSize = True
        Label104.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label104.Location = New Point(20, 33)
        Label104.Name = "Label104"
        Label104.Size = New Size(146, 20)
        Label104.TabIndex = 18
        Label104.Text = "Single Pallet Weight"
        ' 
        ' ComboBox24
        ' 
        ComboBox24.FormattingEnabled = True
        ComboBox24.Location = New Point(232, 134)
        ComboBox24.Name = "ComboBox24"
        ComboBox24.Size = New Size(151, 28)
        ComboBox24.TabIndex = 17
        ' 
        ' Label105
        ' 
        Label105.AutoSize = True
        Label105.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label105.Location = New Point(26, 353)
        Label105.Name = "Label105"
        Label105.Size = New Size(151, 20)
        Label105.TabIndex = 16
        Label105.Text = "Application of panel "
        ' 
        ' Label106
        ' 
        Label106.AutoSize = True
        Label106.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label106.Location = New Point(22, 322)
        Label106.Name = "Label106"
        Label106.Size = New Size(170, 20)
        Label106.TabIndex = 13
        Label106.Text = "6B Panel Width ( Main )"
        ' 
        ' TextBox106
        ' 
        TextBox106.Location = New Point(232, 279)
        TextBox106.Name = "TextBox106"
        TextBox106.Size = New Size(151, 27)
        TextBox106.TabIndex = 12
        ' 
        ' Label107
        ' 
        Label107.AutoSize = True
        Label107.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label107.Location = New Point(20, 279)
        Label107.Name = "Label107"
        Label107.Size = New Size(125, 20)
        Label107.TabIndex = 11
        Label107.Text = "Accessory / Level"
        ' 
        ' Label108
        ' 
        Label108.AutoSize = True
        Label108.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label108.Location = New Point(20, 241)
        Label108.Name = "Label108"
        Label108.Size = New Size(145, 20)
        Label108.TabIndex = 9
        Label108.Text = "Accessory Thickness"
        ' 
        ' Label109
        ' 
        Label109.AutoSize = True
        Label109.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label109.Location = New Point(20, 209)
        Label109.Name = "Label109"
        Label109.Size = New Size(128, 20)
        Label109.TabIndex = 7
        Label109.Text = "Accessory Type 2 "
        ' 
        ' Label110
        ' 
        Label110.AutoSize = True
        Label110.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label110.Location = New Point(20, 133)
        Label110.Name = "Label110"
        Label110.Size = New Size(145, 20)
        Label110.TabIndex = 6
        Label110.Text = "Accessory Thickness"
        ' 
        ' TextBox107
        ' 
        TextBox107.Location = New Point(232, 168)
        TextBox107.Name = "TextBox107"
        TextBox107.Size = New Size(151, 27)
        TextBox107.TabIndex = 3
        ' 
        ' Label111
        ' 
        Label111.AutoSize = True
        Label111.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label111.Location = New Point(20, 168)
        Label111.Name = "Label111"
        Label111.Size = New Size(129, 20)
        Label111.TabIndex = 1
        Label111.Text = "Accessory / Level "
        ' 
        ' TextBox99
        ' 
        TextBox99.Location = New Point(285, 56)
        TextBox99.Name = "TextBox99"
        TextBox99.Size = New Size(123, 27)
        TextBox99.TabIndex = 14
        ' 
        ' Label90
        ' 
        Label90.AutoSize = True
        Label90.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label90.Location = New Point(102, 56)
        Label90.Name = "Label90"
        Label90.Size = New Size(175, 20)
        Label90.TabIndex = 13
        Label90.Text = "Beam Utlisation % (BUT)"
        ' 
        ' GroupBox10
        ' 
        GroupBox10.Controls.Add(ComboBox17)
        GroupBox10.Controls.Add(ComboBox16)
        GroupBox10.Controls.Add(ComboBox15)
        GroupBox10.Controls.Add(ComboBox13)
        GroupBox10.Controls.Add(TextBox110)
        GroupBox10.Controls.Add(Label100)
        GroupBox10.Controls.Add(TextBox109)
        GroupBox10.Controls.Add(ComboBox11)
        GroupBox10.Controls.Add(Label68)
        GroupBox10.Controls.Add(ComboBox12)
        GroupBox10.Controls.Add(Label69)
        GroupBox10.Controls.Add(Label70)
        GroupBox10.Controls.Add(ComboBox14)
        GroupBox10.Controls.Add(Label79)
        GroupBox10.Controls.Add(Label80)
        GroupBox10.Controls.Add(TextBox105)
        GroupBox10.Controls.Add(Label95)
        GroupBox10.Controls.Add(Label96)
        GroupBox10.Controls.Add(Label97)
        GroupBox10.Controls.Add(Label98)
        GroupBox10.Controls.Add(TextBox108)
        GroupBox10.Controls.Add(Label99)
        GroupBox10.Location = New Point(196, 161)
        GroupBox10.Name = "GroupBox10"
        GroupBox10.Size = New Size(461, 506)
        GroupBox10.TabIndex = 3
        GroupBox10.TabStop = False
        GroupBox10.Text = "Level -1  Details"
        ' 
        ' ComboBox17
        ' 
        ComboBox17.FormattingEnabled = True
        ComboBox17.Location = New Point(232, 356)
        ComboBox17.Name = "ComboBox17"
        ComboBox17.Size = New Size(151, 28)
        ComboBox17.TabIndex = 29
        ' 
        ' ComboBox16
        ' 
        ComboBox16.FormattingEnabled = True
        ComboBox16.Location = New Point(232, 319)
        ComboBox16.Name = "ComboBox16"
        ComboBox16.Size = New Size(151, 28)
        ComboBox16.TabIndex = 29
        ' 
        ' ComboBox15
        ' 
        ComboBox15.FormattingEnabled = True
        ComboBox15.Location = New Point(232, 241)
        ComboBox15.Name = "ComboBox15"
        ComboBox15.Size = New Size(151, 28)
        ComboBox15.TabIndex = 28
        ' 
        ' ComboBox13
        ' 
        ComboBox13.FormattingEnabled = True
        ComboBox13.Location = New Point(232, 207)
        ComboBox13.Name = "ComboBox13"
        ComboBox13.Size = New Size(151, 28)
        ComboBox13.TabIndex = 27
        ' 
        ' TextBox110
        ' 
        TextBox110.Location = New Point(232, 30)
        TextBox110.Name = "TextBox110"
        TextBox110.Size = New Size(151, 27)
        TextBox110.TabIndex = 26
        ' 
        ' Label100
        ' 
        Label100.AutoSize = True
        Label100.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label100.Location = New Point(26, 414)
        Label100.Name = "Label100"
        Label100.Size = New Size(186, 20)
        Label100.TabIndex = 25
        Label100.Text = "No Of Such Levels / Unit *"
        ' 
        ' TextBox109
        ' 
        TextBox109.Location = New Point(232, 411)
        TextBox109.Name = "TextBox109"
        TextBox109.Size = New Size(151, 27)
        TextBox109.TabIndex = 24
        ' 
        ' ComboBox11
        ' 
        ComboBox11.FormattingEnabled = True
        ComboBox11.Location = New Point(232, 98)
        ComboBox11.Name = "ComboBox11"
        ComboBox11.Size = New Size(151, 28)
        ComboBox11.TabIndex = 23
        ' 
        ' Label68
        ' 
        Label68.AutoSize = True
        Label68.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label68.Location = New Point(20, 101)
        Label68.Name = "Label68"
        Label68.Size = New Size(133, 20)
        Label68.TabIndex = 22
        Label68.Text = "Accessory Type 1 *"
        ' 
        ' ComboBox12
        ' 
        ComboBox12.FormattingEnabled = True
        ComboBox12.Location = New Point(232, 64)
        ComboBox12.Name = "ComboBox12"
        ComboBox12.Size = New Size(151, 28)
        ComboBox12.TabIndex = 21
        ' 
        ' Label69
        ' 
        Label69.AutoSize = True
        Label69.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label69.Location = New Point(20, 67)
        Label69.Name = "Label69"
        Label69.Size = New Size(112, 20)
        Label69.TabIndex = 20
        Label69.Text = "Beam Section *"
        ' 
        ' Label70
        ' 
        Label70.AutoSize = True
        Label70.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label70.Location = New Point(20, 33)
        Label70.Name = "Label70"
        Label70.Size = New Size(146, 20)
        Label70.TabIndex = 18
        Label70.Text = "Single Pallet Weight"
        ' 
        ' ComboBox14
        ' 
        ComboBox14.FormattingEnabled = True
        ComboBox14.Location = New Point(232, 134)
        ComboBox14.Name = "ComboBox14"
        ComboBox14.Size = New Size(151, 28)
        ComboBox14.TabIndex = 17
        ' 
        ' Label79
        ' 
        Label79.AutoSize = True
        Label79.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label79.Location = New Point(26, 353)
        Label79.Name = "Label79"
        Label79.Size = New Size(151, 20)
        Label79.TabIndex = 16
        Label79.Text = "Application of panel "
        ' 
        ' Label80
        ' 
        Label80.AutoSize = True
        Label80.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label80.Location = New Point(22, 322)
        Label80.Name = "Label80"
        Label80.Size = New Size(170, 20)
        Label80.TabIndex = 13
        Label80.Text = "6B Panel Width ( Main )"
        ' 
        ' TextBox105
        ' 
        TextBox105.Location = New Point(232, 279)
        TextBox105.Name = "TextBox105"
        TextBox105.Size = New Size(151, 27)
        TextBox105.TabIndex = 12
        ' 
        ' Label95
        ' 
        Label95.AutoSize = True
        Label95.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label95.Location = New Point(20, 279)
        Label95.Name = "Label95"
        Label95.Size = New Size(125, 20)
        Label95.TabIndex = 11
        Label95.Text = "Accessory / Level"
        ' 
        ' Label96
        ' 
        Label96.AutoSize = True
        Label96.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label96.Location = New Point(20, 241)
        Label96.Name = "Label96"
        Label96.Size = New Size(145, 20)
        Label96.TabIndex = 9
        Label96.Text = "Accessory Thickness"
        ' 
        ' Label97
        ' 
        Label97.AutoSize = True
        Label97.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label97.Location = New Point(20, 209)
        Label97.Name = "Label97"
        Label97.Size = New Size(128, 20)
        Label97.TabIndex = 7
        Label97.Text = "Accessory Type 2 "
        ' 
        ' Label98
        ' 
        Label98.AutoSize = True
        Label98.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label98.Location = New Point(20, 133)
        Label98.Name = "Label98"
        Label98.Size = New Size(145, 20)
        Label98.TabIndex = 6
        Label98.Text = "Accessory Thickness"
        ' 
        ' TextBox108
        ' 
        TextBox108.Location = New Point(232, 168)
        TextBox108.Name = "TextBox108"
        TextBox108.Size = New Size(151, 27)
        TextBox108.TabIndex = 3
        ' 
        ' Label99
        ' 
        Label99.AutoSize = True
        Label99.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label99.Location = New Point(20, 168)
        Label99.Name = "Label99"
        Label99.Size = New Size(129, 20)
        Label99.TabIndex = 1
        Label99.Text = "Accessory / Level "
        ' 
        ' TabPage9
        ' 
        TabPage9.Controls.Add(GroupBox33)
        TabPage9.Controls.Add(GroupBox31)
        TabPage9.Controls.Add(GroupBox30)
        TabPage9.Controls.Add(GroupBox29)
        TabPage9.Controls.Add(GroupBox28)
        TabPage9.Controls.Add(GroupBox20)
        TabPage9.Controls.Add(GroupBox19)
        TabPage9.Controls.Add(GroupBox18)
        TabPage9.Controls.Add(GroupBox17)
        TabPage9.Location = New Point(4, 29)
        TabPage9.Name = "TabPage9"
        TabPage9.Padding = New Padding(3)
        TabPage9.Size = New Size(1721, 911)
        TabPage9.TabIndex = 8
        TabPage9.Text = "Others-1"
        TabPage9.UseVisualStyleBackColor = True
        ' 
        ' GroupBox33
        ' 
        GroupBox33.Controls.Add(TextBox193)
        GroupBox33.Controls.Add(Label231)
        GroupBox33.Location = New Point(1015, 636)
        GroupBox33.Name = "GroupBox33"
        GroupBox33.Size = New Size(502, 117)
        GroupBox33.TabIndex = 23
        GroupBox33.TabStop = False
        GroupBox33.Text = "Barcode"
        ' 
        ' TextBox193
        ' 
        TextBox193.Location = New Point(256, 43)
        TextBox193.Name = "TextBox193"
        TextBox193.Size = New Size(151, 27)
        TextBox193.TabIndex = 7
        ' 
        ' Label231
        ' 
        Label231.AutoSize = True
        Label231.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label231.Location = New Point(23, 46)
        Label231.Name = "Label231"
        Label231.Size = New Size(115, 20)
        Label231.TabIndex = 6
        Label231.Text = "Barcode Sticker"
        ' 
        ' GroupBox31
        ' 
        GroupBox31.Controls.Add(TextBox186)
        GroupBox31.Controls.Add(ComboBox48)
        GroupBox31.Controls.Add(Label214)
        GroupBox31.Controls.Add(TextBox185)
        GroupBox31.Controls.Add(Label215)
        GroupBox31.Controls.Add(Label216)
        GroupBox31.Location = New Point(505, 687)
        GroupBox31.Name = "GroupBox31"
        GroupBox31.Size = New Size(461, 158)
        GroupBox31.TabIndex = 22
        GroupBox31.TabStop = False
        GroupBox31.Text = "Under Pass Mesh"
        ' 
        ' TextBox186
        ' 
        TextBox186.Location = New Point(279, 39)
        TextBox186.Name = "TextBox186"
        TextBox186.Size = New Size(151, 27)
        TextBox186.TabIndex = 26
        ' 
        ' ComboBox48
        ' 
        ComboBox48.FormattingEnabled = True
        ComboBox48.Location = New Point(279, 76)
        ComboBox48.Name = "ComboBox48"
        ComboBox48.Size = New Size(151, 28)
        ComboBox48.TabIndex = 25
        ' 
        ' Label214
        ' 
        Label214.AutoSize = True
        Label214.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label214.Location = New Point(23, 112)
        Label214.Name = "Label214"
        Label214.Size = New Size(229, 20)
        Label214.TabIndex = 24
        Label214.Text = "Total No. off levels in the layout "
        ' 
        ' TextBox185
        ' 
        TextBox185.Location = New Point(279, 110)
        TextBox185.Name = "TextBox185"
        TextBox185.Size = New Size(151, 27)
        TextBox185.TabIndex = 23
        ' 
        ' Label215
        ' 
        Label215.AutoSize = True
        Label215.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label215.Location = New Point(23, 77)
        Label215.Name = "Label215"
        Label215.Size = New Size(196, 20)
        Label215.TabIndex = 8
        Label215.Text = "Underpass Mesh required *"
        ' 
        ' Label216
        ' 
        Label216.AutoSize = True
        Label216.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label216.Location = New Point(23, 46)
        Label216.Name = "Label216"
        Label216.Size = New Size(126, 20)
        Label216.TabIndex = 6
        Label216.Text = "Under Pass Mesh"
        ' 
        ' GroupBox30
        ' 
        GroupBox30.Controls.Add(ComboBox47)
        GroupBox30.Controls.Add(Label211)
        GroupBox30.Controls.Add(TextBox184)
        GroupBox30.Controls.Add(ComboBox46)
        GroupBox30.Controls.Add(Label212)
        GroupBox30.Controls.Add(Label213)
        GroupBox30.Location = New Point(505, 523)
        GroupBox30.Name = "GroupBox30"
        GroupBox30.Size = New Size(461, 158)
        GroupBox30.TabIndex = 21
        GroupBox30.TabStop = False
        GroupBox30.Text = "Double Deep Row Connector"
        ' 
        ' ComboBox47
        ' 
        ComboBox47.FormattingEnabled = True
        ComboBox47.Location = New Point(279, 76)
        ComboBox47.Name = "ComboBox47"
        ComboBox47.Size = New Size(151, 28)
        ComboBox47.TabIndex = 25
        ' 
        ' Label211
        ' 
        Label211.AutoSize = True
        Label211.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label211.Location = New Point(23, 112)
        Label211.Name = "Label211"
        Label211.Size = New Size(226, 20)
        Label211.TabIndex = 24
        Label211.Text = "Total Quantity ( Automated Qty)"
        ' 
        ' TextBox184
        ' 
        TextBox184.Location = New Point(279, 110)
        TextBox184.Name = "TextBox184"
        TextBox184.Size = New Size(151, 27)
        TextBox184.TabIndex = 23
        ' 
        ' ComboBox46
        ' 
        ComboBox46.FormattingEnabled = True
        ComboBox46.Location = New Point(279, 36)
        ComboBox46.Name = "ComboBox46"
        ComboBox46.Size = New Size(151, 28)
        ComboBox46.TabIndex = 22
        ' 
        ' Label212
        ' 
        Label212.AutoSize = True
        Label212.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label212.Location = New Point(23, 77)
        Label212.Name = "Label212"
        Label212.Size = New Size(232, 20)
        Label212.TabIndex = 8
        Label212.Text = "Row Connector ( Non-Seismic ) *"
        ' 
        ' Label213
        ' 
        Label213.AutoSize = True
        Label213.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label213.Location = New Point(23, 46)
        Label213.Name = "Label213"
        Label213.Size = New Size(207, 20)
        Label213.TabIndex = 6
        Label213.Text = "Double Deep Row Connector"
        ' 
        ' GroupBox29
        ' 
        GroupBox29.Controls.Add(TextBox180)
        GroupBox29.Controls.Add(ComboBox45)
        GroupBox29.Controls.Add(TextBox181)
        GroupBox29.Controls.Add(TextBox182)
        GroupBox29.Controls.Add(Label206)
        GroupBox29.Controls.Add(Label207)
        GroupBox29.Controls.Add(Label208)
        GroupBox29.Controls.Add(Label209)
        GroupBox29.Controls.Add(TextBox183)
        GroupBox29.Controls.Add(Label210)
        GroupBox29.Location = New Point(15, 573)
        GroupBox29.Name = "GroupBox29"
        GroupBox29.Size = New Size(461, 242)
        GroupBox29.TabIndex = 20
        GroupBox29.TabStop = False
        GroupBox29.Text = "Inputs"
        ' 
        ' TextBox180
        ' 
        TextBox180.Location = New Point(256, 135)
        TextBox180.Name = "TextBox180"
        TextBox180.Size = New Size(151, 27)
        TextBox180.TabIndex = 38
        ' 
        ' ComboBox45
        ' 
        ComboBox45.FormattingEnabled = True
        ComboBox45.Location = New Point(256, 25)
        ComboBox45.Name = "ComboBox45"
        ComboBox45.Size = New Size(151, 28)
        ComboBox45.TabIndex = 37
        ' 
        ' TextBox181
        ' 
        TextBox181.Location = New Point(256, 101)
        TextBox181.Name = "TextBox181"
        TextBox181.Size = New Size(151, 27)
        TextBox181.TabIndex = 36
        ' 
        ' TextBox182
        ' 
        TextBox182.Location = New Point(256, 59)
        TextBox182.Name = "TextBox182"
        TextBox182.Size = New Size(151, 27)
        TextBox182.TabIndex = 35
        ' 
        ' Label206
        ' 
        Label206.AutoSize = True
        Label206.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label206.Location = New Point(20, 101)
        Label206.Name = "Label206"
        Label206.Size = New Size(195, 20)
        Label206.TabIndex = 22
        Label206.Text = "Total No.of single Upright's"
        ' 
        ' Label207
        ' 
        Label207.AutoSize = True
        Label207.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label207.Location = New Point(20, 67)
        Label207.Name = "Label207"
        Label207.Size = New Size(82, 20)
        Label207.TabIndex = 20
        Label207.Text = "Gap Depth"
        ' 
        ' Label208
        ' 
        Label208.AutoSize = True
        Label208.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label208.Location = New Point(20, 33)
        Label208.Name = "Label208"
        Label208.Size = New Size(196, 20)
        Label208.TabIndex = 18
        Label208.Text = "Inputs for 3 Upright System"
        ' 
        ' Label209
        ' 
        Label209.AutoSize = True
        Label209.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label209.Location = New Point(20, 133)
        Label209.Name = "Label209"
        Label209.Size = New Size(140, 20)
        Label209.TabIndex = 6
        Label209.Text = "Total No .of Beam's"
        ' 
        ' TextBox183
        ' 
        TextBox183.Location = New Point(256, 168)
        TextBox183.Name = "TextBox183"
        TextBox183.Size = New Size(151, 27)
        TextBox183.TabIndex = 3
        ' 
        ' Label210
        ' 
        Label210.AutoSize = True
        Label210.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label210.Location = New Point(20, 168)
        Label210.Name = "Label210"
        Label210.Size = New Size(169, 20)
        Label210.TabIndex = 1
        Label210.Text = "No.of Bracings/Upright"
        ' 
        ' GroupBox28
        ' 
        GroupBox28.Controls.Add(TextBox176)
        GroupBox28.Controls.Add(Label202)
        GroupBox28.Controls.Add(TextBox177)
        GroupBox28.Controls.Add(TextBox178)
        GroupBox28.Controls.Add(Label203)
        GroupBox28.Controls.Add(Label204)
        GroupBox28.Controls.Add(TextBox179)
        GroupBox28.Controls.Add(Label205)
        GroupBox28.Controls.Add(Label201)
        GroupBox28.Controls.Add(TextBox167)
        GroupBox28.Controls.Add(Label191)
        GroupBox28.Controls.Add(TextBox168)
        GroupBox28.Controls.Add(TextBox169)
        GroupBox28.Controls.Add(TextBox170)
        GroupBox28.Controls.Add(Label192)
        GroupBox28.Controls.Add(Label193)
        GroupBox28.Controls.Add(Label194)
        GroupBox28.Controls.Add(TextBox171)
        GroupBox28.Controls.Add(Label195)
        GroupBox28.Controls.Add(TextBox172)
        GroupBox28.Controls.Add(ComboBox44)
        GroupBox28.Controls.Add(TextBox173)
        GroupBox28.Controls.Add(TextBox174)
        GroupBox28.Controls.Add(Label196)
        GroupBox28.Controls.Add(Label197)
        GroupBox28.Controls.Add(Label198)
        GroupBox28.Controls.Add(Label199)
        GroupBox28.Controls.Add(TextBox175)
        GroupBox28.Controls.Add(Label200)
        GroupBox28.Location = New Point(1015, 20)
        GroupBox28.Name = "GroupBox28"
        GroupBox28.Size = New Size(502, 567)
        GroupBox28.TabIndex = 19
        GroupBox28.TabStop = False
        GroupBox28.Text = "Mesh Cladding Details"
        ' 
        ' TextBox176
        ' 
        TextBox176.Location = New Point(256, 522)
        TextBox176.Name = "TextBox176"
        TextBox176.Size = New Size(151, 27)
        TextBox176.TabIndex = 57
        ' 
        ' Label202
        ' 
        Label202.AutoSize = True
        Label202.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label202.Location = New Point(20, 522)
        Label202.Name = "Label202"
        Label202.Size = New Size(124, 20)
        Label202.TabIndex = 56
        Label202.Text = "No.of Such Sides"
        ' 
        ' TextBox177
        ' 
        TextBox177.Location = New Point(256, 450)
        TextBox177.Name = "TextBox177"
        TextBox177.Size = New Size(151, 27)
        TextBox177.TabIndex = 55
        ' 
        ' TextBox178
        ' 
        TextBox178.Location = New Point(256, 417)
        TextBox178.Name = "TextBox178"
        TextBox178.Size = New Size(151, 27)
        TextBox178.TabIndex = 54
        ' 
        ' Label203
        ' 
        Label203.AutoSize = True
        Label203.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Label203.Location = New Point(20, 417)
        Label203.Name = "Label203"
        Label203.Size = New Size(164, 20)
        Label203.TabIndex = 53
        Label203.Text = "Side Inner Mesh Width"
        ' 
        ' Label204
        ' 
        Label204.AutoSize = True
        Label204.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label204.Location = New Point(20, 449)
        Label204.Name = "Label204"
        Label204.Size = New Size(207, 20)
        Label204.TabIndex = 52
        Label204.Text = "Height @ Which Mesh Starts "
        ' 
        ' TextBox179
        ' 
        TextBox179.Location = New Point(256, 484)
        TextBox179.Name = "TextBox179"
        TextBox179.Size = New Size(151, 27)
        TextBox179.TabIndex = 51
        ' 
        ' Label205
        ' 
        Label205.AutoSize = True
        Label205.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label205.Location = New Point(20, 484)
        Label205.Name = "Label205"
        Label205.Size = New Size(175, 20)
        Label205.TabIndex = 50
        Label205.Text = "Height To Be Cladded     "
        ' 
        ' Label201
        ' 
        Label201.AutoSize = True
        Label201.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label201.Location = New Point(40, 63)
        Label201.Name = "Label201"
        Label201.Size = New Size(187, 17)
        Label201.TabIndex = 49
        Label201.Text = "For 0,25,50,75,100,125,150 mm"
        ' 
        ' TextBox167
        ' 
        TextBox167.Location = New Point(256, 375)
        TextBox167.Name = "TextBox167"
        TextBox167.Size = New Size(151, 27)
        TextBox167.TabIndex = 48
        ' 
        ' Label191
        ' 
        Label191.AutoSize = True
        Label191.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label191.Location = New Point(20, 375)
        Label191.Name = "Label191"
        Label191.Size = New Size(124, 20)
        Label191.TabIndex = 47
        Label191.Text = "No.of Such Sides"
        ' 
        ' TextBox168
        ' 
        TextBox168.Location = New Point(256, 303)
        TextBox168.Name = "TextBox168"
        TextBox168.Size = New Size(151, 27)
        TextBox168.TabIndex = 46
        ' 
        ' TextBox169
        ' 
        TextBox169.Location = New Point(256, 270)
        TextBox169.Name = "TextBox169"
        TextBox169.Size = New Size(151, 27)
        TextBox169.TabIndex = 45
        ' 
        ' TextBox170
        ' 
        TextBox170.Location = New Point(256, 225)
        TextBox170.Name = "TextBox170"
        TextBox170.Size = New Size(151, 27)
        TextBox170.TabIndex = 44
        ' 
        ' Label192
        ' 
        Label192.AutoSize = True
        Label192.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Label192.Location = New Point(20, 270)
        Label192.Name = "Label192"
        Label192.Size = New Size(167, 20)
        Label192.TabIndex = 43
        Label192.Text = "Side Outer Mesh Width"
        ' 
        ' Label193
        ' 
        Label193.AutoSize = True
        Label193.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label193.Location = New Point(20, 228)
        Label193.Name = "Label193"
        Label193.Size = New Size(104, 20)
        Label193.TabIndex = 42
        Label193.Text = "No of Addons"
        ' 
        ' Label194
        ' 
        Label194.AutoSize = True
        Label194.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label194.Location = New Point(20, 302)
        Label194.Name = "Label194"
        Label194.Size = New Size(211, 20)
        Label194.TabIndex = 41
        Label194.Text = "Height @ Which Mesh Starts  "
        ' 
        ' TextBox171
        ' 
        TextBox171.Location = New Point(256, 337)
        TextBox171.Name = "TextBox171"
        TextBox171.Size = New Size(151, 27)
        TextBox171.TabIndex = 40
        ' 
        ' Label195
        ' 
        Label195.AutoSize = True
        Label195.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label195.Location = New Point(20, 337)
        Label195.Name = "Label195"
        Label195.Size = New Size(175, 20)
        Label195.TabIndex = 39
        Label195.Text = "Height To Be Cladded     "
        ' 
        ' TextBox172
        ' 
        TextBox172.Location = New Point(256, 149)
        TextBox172.Name = "TextBox172"
        TextBox172.Size = New Size(151, 27)
        TextBox172.TabIndex = 38
        ' 
        ' ComboBox44
        ' 
        ComboBox44.FormattingEnabled = True
        ComboBox44.Location = New Point(256, 26)
        ComboBox44.Name = "ComboBox44"
        ComboBox44.Size = New Size(151, 28)
        ComboBox44.TabIndex = 37
        ' 
        ' TextBox173
        ' 
        TextBox173.Location = New Point(256, 115)
        TextBox173.Name = "TextBox173"
        TextBox173.Size = New Size(151, 27)
        TextBox173.TabIndex = 36
        ' 
        ' TextBox174
        ' 
        TextBox174.Location = New Point(256, 73)
        TextBox174.Name = "TextBox174"
        TextBox174.Size = New Size(151, 27)
        TextBox174.TabIndex = 35
        ' 
        ' Label196
        ' 
        Label196.AutoSize = True
        Label196.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label196.Location = New Point(20, 114)
        Label196.Name = "Label196"
        Label196.Size = New Size(207, 20)
        Label196.TabIndex = 22
        Label196.Text = "Height @ Which Mesh Starts "
        ' 
        ' Label197
        ' 
        Label197.AutoSize = True
        Label197.Font = New Font("Yu Gothic UI", 10.2F, FontStyle.Bold Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Label197.Location = New Point(20, 80)
        Label197.Name = "Label197"
        Label197.Size = New Size(148, 23)
        Label197.TabIndex = 20
        Label197.Text = "Rear Mesh Width "
        ' 
        ' Label198
        ' 
        Label198.AutoSize = True
        Label198.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label198.Location = New Point(20, 33)
        Label198.Name = "Label198"
        Label198.Size = New Size(106, 20)
        Label198.TabIndex = 18
        Label198.Text = "Mesh Calding "
        ' 
        ' Label199
        ' 
        Label199.AutoSize = True
        Label199.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label199.Location = New Point(20, 146)
        Label199.Name = "Label199"
        Label199.Size = New Size(167, 20)
        Label199.TabIndex = 6
        Label199.Text = "Height To Be Cladded   "
        ' 
        ' TextBox175
        ' 
        TextBox175.Location = New Point(256, 186)
        TextBox175.Name = "TextBox175"
        TextBox175.Size = New Size(151, 27)
        TextBox175.TabIndex = 3
        ' 
        ' Label200
        ' 
        Label200.AutoSize = True
        Label200.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label200.Location = New Point(20, 189)
        Label200.Name = "Label200"
        Label200.Size = New Size(93, 20)
        Label200.TabIndex = 1
        Label200.Text = "No of Mains"
        ' 
        ' GroupBox20
        ' 
        GroupBox20.Controls.Add(ComboBox34)
        GroupBox20.Controls.Add(Label144)
        GroupBox20.Controls.Add(TextBox130)
        GroupBox20.Controls.Add(Label145)
        GroupBox20.Location = New Point(15, 445)
        GroupBox20.Name = "GroupBox20"
        GroupBox20.Size = New Size(461, 117)
        GroupBox20.TabIndex = 9
        GroupBox20.TabStop = False
        GroupBox20.Text = "MCAS"
        ' 
        ' ComboBox34
        ' 
        ComboBox34.FormattingEnabled = True
        ComboBox34.Location = New Point(256, 38)
        ComboBox34.Name = "ComboBox34"
        ComboBox34.Size = New Size(151, 28)
        ComboBox34.TabIndex = 22
        ' 
        ' Label144
        ' 
        Label144.AutoSize = True
        Label144.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label144.Location = New Point(23, 78)
        Label144.Name = "Label144"
        Label144.Size = New Size(84, 20)
        Label144.TabIndex = 8
        Label144.Text = "MCAS- Qty"
        ' 
        ' TextBox130
        ' 
        TextBox130.Location = New Point(256, 78)
        TextBox130.Name = "TextBox130"
        TextBox130.Size = New Size(151, 27)
        TextBox130.TabIndex = 7
        ' 
        ' Label145
        ' 
        Label145.AutoSize = True
        Label145.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label145.Location = New Point(23, 46)
        Label145.Name = "Label145"
        Label145.Size = New Size(50, 20)
        Label145.TabIndex = 6
        Label145.Text = "MCAS"
        ' 
        ' GroupBox19
        ' 
        GroupBox19.Controls.Add(TextBox128)
        GroupBox19.Controls.Add(TextBox127)
        GroupBox19.Controls.Add(TextBox126)
        GroupBox19.Controls.Add(TextBox125)
        GroupBox19.Controls.Add(Label142)
        GroupBox19.Controls.Add(TextBox124)
        GroupBox19.Controls.Add(TextBox119)
        GroupBox19.Controls.Add(ComboBox33)
        GroupBox19.Controls.Add(ComboBox35)
        GroupBox19.Controls.Add(Label126)
        GroupBox19.Controls.Add(TextBox121)
        GroupBox19.Controls.Add(Label130)
        GroupBox19.Controls.Add(Label131)
        GroupBox19.Controls.Add(Label132)
        GroupBox19.Controls.Add(ComboBox41)
        GroupBox19.Controls.Add(Label133)
        GroupBox19.Controls.Add(Label134)
        GroupBox19.Controls.Add(TextBox122)
        GroupBox19.Controls.Add(Label137)
        GroupBox19.Controls.Add(Label138)
        GroupBox19.Controls.Add(Label139)
        GroupBox19.Controls.Add(Label140)
        GroupBox19.Controls.Add(TextBox123)
        GroupBox19.Controls.Add(Label141)
        GroupBox19.Location = New Point(505, 9)
        GroupBox19.Name = "GroupBox19"
        GroupBox19.Size = New Size(461, 506)
        GroupBox19.TabIndex = 8
        GroupBox19.TabStop = False
        GroupBox19.Text = "Stability Members"
        ' 
        ' TextBox128
        ' 
        TextBox128.Location = New Point(279, 100)
        TextBox128.Name = "TextBox128"
        TextBox128.Size = New Size(151, 27)
        TextBox128.TabIndex = 36
        ' 
        ' TextBox127
        ' 
        TextBox127.Location = New Point(279, 58)
        TextBox127.Name = "TextBox127"
        TextBox127.Size = New Size(151, 27)
        TextBox127.TabIndex = 35
        ' 
        ' TextBox126
        ' 
        TextBox126.Location = New Point(279, 200)
        TextBox126.Name = "TextBox126"
        TextBox126.Size = New Size(151, 27)
        TextBox126.TabIndex = 34
        ' 
        ' TextBox125
        ' 
        TextBox125.Location = New Point(279, 321)
        TextBox125.Name = "TextBox125"
        TextBox125.Size = New Size(151, 27)
        TextBox125.TabIndex = 33
        ' 
        ' Label142
        ' 
        Label142.AutoSize = True
        Label142.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label142.Location = New Point(26, 459)
        Label142.Name = "Label142"
        Label142.Size = New Size(189, 20)
        Label142.TabIndex = 32
        Label142.Text = "Qty Required in DF Addon"
        ' 
        ' TextBox124
        ' 
        TextBox124.Location = New Point(279, 455)
        TextBox124.Name = "TextBox124"
        TextBox124.Size = New Size(151, 27)
        TextBox124.TabIndex = 31
        ' 
        ' TextBox119
        ' 
        TextBox119.Location = New Point(279, 25)
        TextBox119.Name = "TextBox119"
        TextBox119.Size = New Size(151, 27)
        TextBox119.TabIndex = 30
        ' 
        ' ComboBox33
        ' 
        ComboBox33.FormattingEnabled = True
        ComboBox33.Location = New Point(279, 355)
        ComboBox33.Name = "ComboBox33"
        ComboBox33.Size = New Size(151, 28)
        ComboBox33.TabIndex = 29
        ' 
        ' ComboBox35
        ' 
        ComboBox35.FormattingEnabled = True
        ComboBox35.Location = New Point(279, 240)
        ComboBox35.Name = "ComboBox35"
        ComboBox35.Size = New Size(151, 28)
        ComboBox35.TabIndex = 28
        ' 
        ' Label126
        ' 
        Label126.AutoSize = True
        Label126.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label126.Location = New Point(26, 414)
        Label126.Name = "Label126"
        Label126.Size = New Size(178, 20)
        Label126.TabIndex = 25
        Label126.Text = "Qty Required in DF Main"
        ' 
        ' TextBox121
        ' 
        TextBox121.Location = New Point(279, 410)
        TextBox121.Name = "TextBox121"
        TextBox121.Size = New Size(151, 27)
        TextBox121.TabIndex = 24
        ' 
        ' Label130
        ' 
        Label130.AutoSize = True
        Label130.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label130.Location = New Point(20, 101)
        Label130.Name = "Label130"
        Label130.Size = New Size(193, 20)
        Label130.TabIndex = 22
        Label130.Text = "Last Loading Level (Height)"
        ' 
        ' Label131
        ' 
        Label131.AutoSize = True
        Label131.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label131.Location = New Point(20, 67)
        Label131.Name = "Label131"
        Label131.Size = New Size(133, 20)
        Label131.TabIndex = 20
        Label131.Text = "Last Loading Level"
        ' 
        ' Label132
        ' 
        Label132.AutoSize = True
        Label132.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label132.Location = New Point(20, 33)
        Label132.Name = "Label132"
        Label132.Size = New Size(154, 20)
        Label132.TabIndex = 18
        Label132.Text = "Tie rod & Turn-buckle  "
        ' 
        ' ComboBox41
        ' 
        ComboBox41.FormattingEnabled = True
        ComboBox41.Location = New Point(279, 133)
        ComboBox41.Name = "ComboBox41"
        ComboBox41.Size = New Size(151, 28)
        ComboBox41.TabIndex = 17
        ' 
        ' Label133
        ' 
        Label133.AutoSize = True
        Label133.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label133.Location = New Point(26, 353)
        Label133.Name = "Label133"
        Label133.Size = New Size(184, 20)
        Label133.TabIndex = 16
        Label133.Text = "DF Row Connector length"
        ' 
        ' Label134
        ' 
        Label134.AutoSize = True
        Label134.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label134.Location = New Point(22, 322)
        Label134.Name = "Label134"
        Label134.Size = New Size(186, 20)
        Label134.TabIndex = 13
        Label134.Text = "Total Tie Braced SF Addon"
        ' 
        ' TextBox122
        ' 
        TextBox122.Location = New Point(279, 278)
        TextBox122.Name = "TextBox122"
        TextBox122.Size = New Size(151, 27)
        TextBox122.TabIndex = 12
        ' 
        ' Label137
        ' 
        Label137.AutoSize = True
        Label137.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label137.Location = New Point(20, 279)
        Label137.Name = "Label137"
        Label137.Size = New Size(175, 20)
        Label137.TabIndex = 11
        Label137.Text = "Total Tie Braced SF Main"
        ' 
        ' Label138
        ' 
        Label138.AutoSize = True
        Label138.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label138.Location = New Point(20, 241)
        Label138.Name = "Label138"
        Label138.Size = New Size(185, 20)
        Label138.TabIndex = 9
        Label138.Text = "SF Row Connector length "
        ' 
        ' Label139
        ' 
        Label139.AutoSize = True
        Label139.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label139.Location = New Point(20, 209)
        Label139.Name = "Label139"
        Label139.Size = New Size(166, 20)
        Label139.TabIndex = 7
        Label139.Text = "Total Tie Braced Addon"
        ' 
        ' Label140
        ' 
        Label140.AutoSize = True
        Label140.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label140.Location = New Point(20, 133)
        Label140.Name = "Label140"
        Label140.Size = New Size(77, 20)
        Label140.TabIndex = 6
        Label140.Text = "Overhang"
        ' 
        ' TextBox123
        ' 
        TextBox123.Location = New Point(279, 167)
        TextBox123.Name = "TextBox123"
        TextBox123.Size = New Size(151, 27)
        TextBox123.TabIndex = 3
        ' 
        ' Label141
        ' 
        Label141.AutoSize = True
        Label141.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label141.Location = New Point(20, 168)
        Label141.Name = "Label141"
        Label141.Size = New Size(155, 20)
        Label141.TabIndex = 1
        Label141.Text = "Total Tie Braced Main"
        ' 
        ' GroupBox18
        ' 
        GroupBox18.Controls.Add(TextBox118)
        GroupBox18.Controls.Add(TextBox117)
        GroupBox18.Controls.Add(ComboBox40)
        GroupBox18.Controls.Add(Label127)
        GroupBox18.Controls.Add(Label128)
        GroupBox18.Controls.Add(Label129)
        GroupBox18.Controls.Add(ComboBox39)
        GroupBox18.Controls.Add(Label135)
        GroupBox18.Controls.Add(TextBox120)
        GroupBox18.Controls.Add(Label136)
        GroupBox18.Location = New Point(15, 174)
        GroupBox18.Name = "GroupBox18"
        GroupBox18.Size = New Size(461, 256)
        GroupBox18.TabIndex = 7
        GroupBox18.TabStop = False
        GroupBox18.Text = "Connector  Details"
        ' 
        ' TextBox118
        ' 
        TextBox118.Location = New Point(256, 101)
        TextBox118.Name = "TextBox118"
        TextBox118.Size = New Size(151, 27)
        TextBox118.TabIndex = 32
        ' 
        ' TextBox117
        ' 
        TextBox117.Location = New Point(256, 64)
        TextBox117.Name = "TextBox117"
        TextBox117.Size = New Size(151, 27)
        TextBox117.TabIndex = 31
        ' 
        ' ComboBox40
        ' 
        ComboBox40.FormattingEnabled = True
        ComboBox40.Location = New Point(256, 25)
        ComboBox40.Name = "ComboBox40"
        ComboBox40.Size = New Size(151, 28)
        ComboBox40.TabIndex = 30
        ' 
        ' Label127
        ' 
        Label127.AutoSize = True
        Label127.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label127.Location = New Point(20, 108)
        Label127.Name = "Label127"
        Label127.Size = New Size(141, 20)
        Label127.TabIndex = 22
        Label127.Text = "Additional quantity"
        ' 
        ' Label128
        ' 
        Label128.AutoSize = True
        Label128.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label128.Location = New Point(20, 67)
        Label128.Name = "Label128"
        Label128.Size = New Size(113, 20)
        Label128.TabIndex = 20
        Label128.Text = "Automated Qty"
        ' 
        ' Label129
        ' 
        Label129.AutoSize = True
        Label129.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label129.Location = New Point(20, 33)
        Label129.Name = "Label129"
        Label129.Size = New Size(236, 20)
        Label129.TabIndex = 18
        Label129.Text = "Row Connector ( Non-Seismic ) * "
        ' 
        ' ComboBox39
        ' 
        ComboBox39.FormattingEnabled = True
        ComboBox39.Location = New Point(256, 141)
        ComboBox39.Name = "ComboBox39"
        ComboBox39.Size = New Size(151, 28)
        ComboBox39.TabIndex = 17
        ' 
        ' Label135
        ' 
        Label135.AutoSize = True
        Label135.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label135.Location = New Point(20, 140)
        Label135.Name = "Label135"
        Label135.Size = New Size(114, 20)
        Label135.TabIndex = 6
        Label135.Text = "Wall Connector"
        ' 
        ' TextBox120
        ' 
        TextBox120.Location = New Point(256, 175)
        TextBox120.Name = "TextBox120"
        TextBox120.Size = New Size(151, 27)
        TextBox120.TabIndex = 3
        ' 
        ' Label136
        ' 
        Label136.AutoSize = True
        Label136.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label136.Location = New Point(20, 175)
        Label136.Name = "Label136"
        Label136.Size = New Size(89, 20)
        Label136.TabIndex = 1
        Label136.Text = "Manual Qty"
        ' 
        ' GroupBox17
        ' 
        GroupBox17.Controls.Add(Label124)
        GroupBox17.Controls.Add(TextBox115)
        GroupBox17.Controls.Add(ComboBox32)
        GroupBox17.Controls.Add(Label123)
        GroupBox17.Controls.Add(TextBox116)
        GroupBox17.Controls.Add(Label125)
        GroupBox17.Location = New Point(15, 9)
        GroupBox17.Name = "GroupBox17"
        GroupBox17.Size = New Size(461, 158)
        GroupBox17.TabIndex = 6
        GroupBox17.TabStop = False
        GroupBox17.Text = "Drum Cradle"
        ' 
        ' Label124
        ' 
        Label124.AutoSize = True
        Label124.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label124.Location = New Point(23, 112)
        Label124.Name = "Label124"
        Label124.Size = New Size(123, 20)
        Label124.TabIndex = 24
        Label124.Text = "Size of the Drum"
        ' 
        ' TextBox115
        ' 
        TextBox115.Location = New Point(256, 112)
        TextBox115.Name = "TextBox115"
        TextBox115.Size = New Size(151, 27)
        TextBox115.TabIndex = 23
        ' 
        ' ComboBox32
        ' 
        ComboBox32.FormattingEnabled = True
        ComboBox32.Location = New Point(256, 38)
        ComboBox32.Name = "ComboBox32"
        ComboBox32.Size = New Size(151, 28)
        ComboBox32.TabIndex = 22
        ' 
        ' Label123
        ' 
        Label123.AutoSize = True
        Label123.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label123.Location = New Point(23, 77)
        Label123.Name = "Label123"
        Label123.Size = New Size(182, 20)
        Label123.TabIndex = 8
        Label123.Text = "No of Drum Cradle / Unit"
        ' 
        ' TextBox116
        ' 
        TextBox116.Location = New Point(256, 77)
        TextBox116.Name = "TextBox116"
        TextBox116.Size = New Size(151, 27)
        TextBox116.TabIndex = 7
        ' 
        ' Label125
        ' 
        Label125.AutoSize = True
        Label125.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label125.Location = New Point(23, 46)
        Label125.Name = "Label125"
        Label125.Size = New Size(105, 20)
        Label125.TabIndex = 6
        Label125.Text = "Drum Crandle"
        ' 
        ' TabPage10
        ' 
        TabPage10.Controls.Add(GroupBox32)
        TabPage10.Controls.Add(GroupBox27)
        TabPage10.Controls.Add(GroupBox26)
        TabPage10.Controls.Add(GroupBox25)
        TabPage10.Controls.Add(GroupBox24)
        TabPage10.Controls.Add(GroupBox23)
        TabPage10.Controls.Add(GroupBox22)
        TabPage10.Controls.Add(GroupBox21)
        TabPage10.Location = New Point(4, 29)
        TabPage10.Name = "TabPage10"
        TabPage10.Padding = New Padding(3)
        TabPage10.Size = New Size(1721, 911)
        TabPage10.TabIndex = 9
        TabPage10.Text = "Others-2"
        TabPage10.UseVisualStyleBackColor = True
        ' 
        ' GroupBox32
        ' 
        GroupBox32.Controls.Add(Label220)
        GroupBox32.Controls.Add(TextBox190)
        GroupBox32.Controls.Add(Label229)
        GroupBox32.Controls.Add(Label228)
        GroupBox32.Controls.Add(Label227)
        GroupBox32.Controls.Add(Label226)
        GroupBox32.Controls.Add(ComboBox50)
        GroupBox32.Controls.Add(TextBox187)
        GroupBox32.Controls.Add(TextBox188)
        GroupBox32.Controls.Add(TextBox189)
        GroupBox32.Controls.Add(Label217)
        GroupBox32.Controls.Add(Label218)
        GroupBox32.Controls.Add(Label219)
        GroupBox32.Controls.Add(TextBox191)
        GroupBox32.Controls.Add(ComboBox49)
        GroupBox32.Controls.Add(TextBox192)
        GroupBox32.Controls.Add(Label221)
        GroupBox32.Controls.Add(Label222)
        GroupBox32.Controls.Add(Label223)
        GroupBox32.Controls.Add(Label224)
        GroupBox32.Controls.Add(TextBox194)
        GroupBox32.Controls.Add(Label225)
        GroupBox32.Location = New Point(1000, 496)
        GroupBox32.Name = "GroupBox32"
        GroupBox32.Size = New Size(692, 398)
        GroupBox32.TabIndex = 18
        GroupBox32.TabStop = False
        GroupBox32.Text = "Nylon Netting"
        ' 
        ' Label220
        ' 
        Label220.AutoSize = True
        Label220.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label220.Location = New Point(20, 341)
        Label220.Name = "Label220"
        Label220.Size = New Size(236, 20)
        Label220.TabIndex = 53
        Label220.Text = "Price of Nylon netting for 25sq.m"
        ' 
        ' TextBox190
        ' 
        TextBox190.Location = New Point(300, 341)
        TextBox190.Name = "TextBox190"
        TextBox190.Size = New Size(222, 27)
        TextBox190.TabIndex = 52
        ' 
        ' Label229
        ' 
        Label229.AutoSize = True
        Label229.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label229.Location = New Point(475, 289)
        Label229.Name = "Label229"
        Label229.Size = New Size(196, 17)
        Label229.TabIndex = 51
        Label229.Text = "(If SF back is with Nylon Netting)"
        ' 
        ' Label228
        ' 
        Label228.AutoSize = True
        Label228.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label228.Location = New Point(469, 256)
        Label228.Name = "Label228"
        Label228.Size = New Size(192, 17)
        Label228.TabIndex = 50
        Label228.Text = " (If the system is with overhang)"
        ' 
        ' Label227
        ' 
        Label227.AutoSize = True
        Label227.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label227.Location = New Point(471, 228)
        Label227.Name = "Label227"
        Label227.Size = New Size(207, 17)
        Label227.TabIndex = 49
        Label227.Text = "(If the system is without overhang)"
        ' 
        ' Label226
        ' 
        Label226.AutoSize = True
        Label226.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label226.Location = New Point(473, 173)
        Label226.Name = "Label226"
        Label226.Size = New Size(207, 17)
        Label226.TabIndex = 48
        Label226.Text = "(If the system is without overhang)"
        ' 
        ' ComboBox50
        ' 
        ComboBox50.FormattingEnabled = True
        ComboBox50.Location = New Point(300, 63)
        ComboBox50.Name = "ComboBox50"
        ComboBox50.Size = New Size(151, 28)
        ComboBox50.TabIndex = 47
        ' 
        ' TextBox187
        ' 
        TextBox187.Location = New Point(300, 290)
        TextBox187.Name = "TextBox187"
        TextBox187.Size = New Size(151, 27)
        TextBox187.TabIndex = 46
        ' 
        ' TextBox188
        ' 
        TextBox188.Location = New Point(300, 257)
        TextBox188.Name = "TextBox188"
        TextBox188.Size = New Size(151, 27)
        TextBox188.TabIndex = 45
        ' 
        ' TextBox189
        ' 
        TextBox189.Location = New Point(300, 220)
        TextBox189.Name = "TextBox189"
        TextBox189.Size = New Size(151, 27)
        TextBox189.TabIndex = 44
        ' 
        ' Label217
        ' 
        Label217.AutoSize = True
        Label217.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label217.Location = New Point(20, 257)
        Label217.Name = "Label217"
        Label217.Size = New Size(270, 20)
        Label217.TabIndex = 43
        Label217.Text = "Total no. off Row connectors in layout "
        ' 
        ' Label218
        ' 
        Label218.AutoSize = True
        Label218.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label218.Location = New Point(20, 223)
        Label218.Name = "Label218"
        Label218.Size = New Size(182, 20)
        Label218.TabIndex = 42
        Label218.Text = "Total no. off Levels in row"
        ' 
        ' Label219
        ' 
        Label219.AutoSize = True
        Label219.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label219.Location = New Point(20, 289)
        Label219.Name = "Label219"
        Label219.Size = New Size(193, 20)
        Label219.TabIndex = 41
        Label219.Text = "Additional row connectors "
        ' 
        ' TextBox191
        ' 
        TextBox191.Location = New Point(300, 136)
        TextBox191.Name = "TextBox191"
        TextBox191.Size = New Size(151, 27)
        TextBox191.TabIndex = 38
        ' 
        ' ComboBox49
        ' 
        ComboBox49.FormattingEnabled = True
        ComboBox49.Location = New Point(300, 26)
        ComboBox49.Name = "ComboBox49"
        ComboBox49.Size = New Size(151, 28)
        ComboBox49.TabIndex = 37
        ' 
        ' TextBox192
        ' 
        TextBox192.Location = New Point(300, 102)
        TextBox192.Name = "TextBox192"
        TextBox192.Size = New Size(151, 27)
        TextBox192.TabIndex = 36
        ' 
        ' Label221
        ' 
        Label221.AutoSize = True
        Label221.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label221.Location = New Point(20, 101)
        Label221.Name = "Label221"
        Label221.Size = New Size(250, 20)
        Label221.TabIndex = 22
        Label221.Text = "Height of the System to be Cladded"
        ' 
        ' Label222
        ' 
        Label222.AutoSize = True
        Label222.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label222.Location = New Point(20, 67)
        Label222.Name = "Label222"
        Label222.Size = New Size(206, 20)
        Label222.TabIndex = 20
        Label222.Text = "Nylon Netting Configuration"
        ' 
        ' Label223
        ' 
        Label223.AutoSize = True
        Label223.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label223.Location = New Point(20, 33)
        Label223.Name = "Label223"
        Label223.Size = New Size(111, 20)
        Label223.TabIndex = 18
        Label223.Text = "Nylon Netting "
        ' 
        ' Label224
        ' 
        Label224.AutoSize = True
        Label224.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label224.Location = New Point(20, 133)
        Label224.Name = "Label224"
        Label224.Size = New Size(229, 20)
        Label224.TabIndex = 6
        Label224.Text = "Length of the row to be Cladded"
        ' 
        ' TextBox194
        ' 
        TextBox194.Location = New Point(300, 169)
        TextBox194.Name = "TextBox194"
        TextBox194.Size = New Size(151, 27)
        TextBox194.TabIndex = 3
        ' 
        ' Label225
        ' 
        Label225.AutoSize = True
        Label225.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label225.Location = New Point(20, 168)
        Label225.Name = "Label225"
        Label225.Size = New Size(166, 20)
        Label225.TabIndex = 1
        Label225.Text = "No off frames in a row "
        ' 
        ' GroupBox27
        ' 
        GroupBox27.Controls.Add(TextBox166)
        GroupBox27.Controls.Add(Label190)
        GroupBox27.Controls.Add(TextBox158)
        GroupBox27.Controls.Add(TextBox159)
        GroupBox27.Controls.Add(TextBox160)
        GroupBox27.Controls.Add(Label181)
        GroupBox27.Controls.Add(Label182)
        GroupBox27.Controls.Add(Label183)
        GroupBox27.Controls.Add(TextBox161)
        GroupBox27.Controls.Add(Label184)
        GroupBox27.Controls.Add(TextBox162)
        GroupBox27.Controls.Add(ComboBox43)
        GroupBox27.Controls.Add(TextBox163)
        GroupBox27.Controls.Add(TextBox164)
        GroupBox27.Controls.Add(Label185)
        GroupBox27.Controls.Add(Label186)
        GroupBox27.Controls.Add(Label187)
        GroupBox27.Controls.Add(Label188)
        GroupBox27.Controls.Add(TextBox165)
        GroupBox27.Controls.Add(Label189)
        GroupBox27.Location = New Point(498, 482)
        GroupBox27.Name = "GroupBox27"
        GroupBox27.Size = New Size(461, 412)
        GroupBox27.TabIndex = 17
        GroupBox27.TabStop = False
        GroupBox27.Text = "TSP guide Rail"
        ' 
        ' TextBox166
        ' 
        TextBox166.Location = New Point(256, 362)
        TextBox166.Name = "TextBox166"
        TextBox166.Size = New Size(151, 27)
        TextBox166.TabIndex = 48
        ' 
        ' Label190
        ' 
        Label190.AutoSize = True
        Label190.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label190.Location = New Point(20, 362)
        Label190.Name = "Label190"
        Label190.Size = New Size(241, 20)
        Label190.TabIndex = 47
        Label190.Text = "Inner to inner of the guide rail (D)"
        ' 
        ' TextBox158
        ' 
        TextBox158.Location = New Point(256, 290)
        TextBox158.Name = "TextBox158"
        TextBox158.Size = New Size(151, 27)
        TextBox158.TabIndex = 46
        ' 
        ' TextBox159
        ' 
        TextBox159.Location = New Point(256, 257)
        TextBox159.Name = "TextBox159"
        TextBox159.Size = New Size(151, 27)
        TextBox159.TabIndex = 45
        ' 
        ' TextBox160
        ' 
        TextBox160.Location = New Point(256, 220)
        TextBox160.Name = "TextBox160"
        TextBox160.Size = New Size(151, 27)
        TextBox160.TabIndex = 44
        ' 
        ' Label181
        ' 
        Label181.AutoSize = True
        Label181.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label181.Location = New Point(20, 257)
        Label181.Name = "Label181"
        Label181.Size = New Size(200, 20)
        Label181.TabIndex = 43
        Label181.Text = "Frame Depth                   ( B )"
        ' 
        ' Label182
        ' 
        Label182.AutoSize = True
        Label182.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label182.Location = New Point(20, 223)
        Label182.Name = "Label182"
        Label182.Size = New Size(198, 20)
        Label182.TabIndex = 42
        Label182.Text = "Rail outer to outer         ( A )"
        ' 
        ' Label183
        ' 
        Label183.AutoSize = True
        Label183.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label183.Location = New Point(20, 289)
        Label183.Name = "Label183"
        Label183.Size = New Size(201, 20)
        Label183.TabIndex = 41
        Label183.Text = "Rail section                      ( C )"
        ' 
        ' TextBox161
        ' 
        TextBox161.Location = New Point(256, 324)
        TextBox161.Name = "TextBox161"
        TextBox161.Size = New Size(151, 27)
        TextBox161.TabIndex = 40
        ' 
        ' Label184
        ' 
        Label184.AutoSize = True
        Label184.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label184.Location = New Point(20, 324)
        Label184.Name = "Label184"
        Label184.Size = New Size(82, 20)
        Label184.TabIndex = 39
        Label184.Text = "MHE Entry"
        ' 
        ' TextBox162
        ' 
        TextBox162.Location = New Point(256, 136)
        TextBox162.Name = "TextBox162"
        TextBox162.Size = New Size(151, 27)
        TextBox162.TabIndex = 38
        ' 
        ' ComboBox43
        ' 
        ComboBox43.FormattingEnabled = True
        ComboBox43.Location = New Point(256, 26)
        ComboBox43.Name = "ComboBox43"
        ComboBox43.Size = New Size(151, 28)
        ComboBox43.TabIndex = 37
        ' 
        ' TextBox163
        ' 
        TextBox163.Location = New Point(256, 102)
        TextBox163.Name = "TextBox163"
        TextBox163.Size = New Size(151, 27)
        TextBox163.TabIndex = 36
        ' 
        ' TextBox164
        ' 
        TextBox164.Location = New Point(256, 60)
        TextBox164.Name = "TextBox164"
        TextBox164.Size = New Size(151, 27)
        TextBox164.TabIndex = 35
        ' 
        ' Label185
        ' 
        Label185.AutoSize = True
        Label185.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label185.Location = New Point(20, 101)
        Label185.Name = "Label185"
        Label185.Size = New Size(133, 20)
        Label185.TabIndex = 22
        Label185.Text = "No of SF Row - LH"
        ' 
        ' Label186
        ' 
        Label186.AutoSize = True
        Label186.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label186.Location = New Point(20, 67)
        Label186.Name = "Label186"
        Label186.Size = New Size(135, 20)
        Label186.TabIndex = 20
        Label186.Text = "No of SF Row - RH"
        ' 
        ' Label187
        ' 
        Label187.AutoSize = True
        Label187.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label187.Location = New Point(20, 33)
        Label187.Name = "Label187"
        Label187.Size = New Size(107, 20)
        Label187.TabIndex = 18
        Label187.Text = "TSP Guide Rail"
        ' 
        ' Label188
        ' 
        Label188.AutoSize = True
        Label188.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label188.Location = New Point(20, 133)
        Label188.Name = "Label188"
        Label188.Size = New Size(104, 20)
        Label188.TabIndex = 6
        Label188.Text = "No of DF Row"
        ' 
        ' TextBox165
        ' 
        TextBox165.Location = New Point(256, 187)
        TextBox165.Name = "TextBox165"
        TextBox165.Size = New Size(151, 27)
        TextBox165.TabIndex = 3
        ' 
        ' Label189
        ' 
        Label189.AutoSize = True
        Label189.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label189.Location = New Point(20, 168)
        Label189.Name = "Label189"
        Label189.Size = New Size(263, 20)
        Label189.TabIndex = 1
        Label189.Text = "Row Length (outer to outer of Frame)"
        ' 
        ' GroupBox26
        ' 
        GroupBox26.Controls.Add(TextBox157)
        GroupBox26.Controls.Add(TextBox151)
        GroupBox26.Controls.Add(TextBox152)
        GroupBox26.Controls.Add(TextBox154)
        GroupBox26.Controls.Add(Label174)
        GroupBox26.Controls.Add(Label177)
        GroupBox26.Controls.Add(Label178)
        GroupBox26.Controls.Add(Label179)
        GroupBox26.Controls.Add(TextBox156)
        GroupBox26.Controls.Add(Label180)
        GroupBox26.Location = New Point(20, 652)
        GroupBox26.Name = "GroupBox26"
        GroupBox26.Size = New Size(461, 242)
        GroupBox26.TabIndex = 16
        GroupBox26.TabStop = False
        GroupBox26.Text = "Sign Board"
        ' 
        ' TextBox157
        ' 
        TextBox157.Location = New Point(256, 33)
        TextBox157.Name = "TextBox157"
        TextBox157.Size = New Size(151, 27)
        TextBox157.TabIndex = 39
        ' 
        ' TextBox151
        ' 
        TextBox151.Location = New Point(256, 138)
        TextBox151.Name = "TextBox151"
        TextBox151.Size = New Size(151, 27)
        TextBox151.TabIndex = 38
        ' 
        ' TextBox152
        ' 
        TextBox152.Location = New Point(256, 104)
        TextBox152.Name = "TextBox152"
        TextBox152.Size = New Size(151, 27)
        TextBox152.TabIndex = 36
        ' 
        ' TextBox154
        ' 
        TextBox154.Location = New Point(256, 62)
        TextBox154.Name = "TextBox154"
        TextBox154.Size = New Size(151, 27)
        TextBox154.TabIndex = 35
        ' 
        ' Label174
        ' 
        Label174.AutoSize = True
        Label174.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label174.Location = New Point(20, 101)
        Label174.Name = "Label174"
        Label174.Size = New Size(163, 20)
        Label174.TabIndex = 22
        Label174.Text = "05  ( Warning Notice ) "
        ' 
        ' Label177
        ' 
        Label177.AutoSize = True
        Label177.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label177.Location = New Point(20, 67)
        Label177.Name = "Label177"
        Label177.Size = New Size(220, 20)
        Label177.TabIndex = 20
        Label177.Text = "04  ( Pick Only Unitised loads ) "
        ' 
        ' Label178
        ' 
        Label178.AutoSize = True
        Label178.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label178.Location = New Point(20, 33)
        Label178.Name = "Label178"
        Label178.Size = New Size(174, 20)
        Label178.TabIndex = 18
        Label178.Text = "03  ( Pallet Positioning ) "
        ' 
        ' Label179
        ' 
        Label179.AutoSize = True
        Label179.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label179.Location = New Point(20, 133)
        Label179.Name = "Label179"
        Label179.Size = New Size(186, 20)
        Label179.TabIndex = 6
        Label179.Text = "06  ( Loading On System ) "
        ' 
        ' TextBox156
        ' 
        TextBox156.Location = New Point(256, 171)
        TextBox156.Name = "TextBox156"
        TextBox156.Size = New Size(151, 27)
        TextBox156.TabIndex = 3
        ' 
        ' Label180
        ' 
        Label180.AutoSize = True
        Label180.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label180.Location = New Point(20, 168)
        Label180.Name = "Label180"
        Label180.Size = New Size(174, 20)
        Label180.TabIndex = 1
        Label180.Text = "07  ( Loading on Pallet ) "
        ' 
        ' GroupBox25
        ' 
        GroupBox25.Controls.Add(TextBox155)
        GroupBox25.Controls.Add(TextBox153)
        GroupBox25.Controls.Add(Label175)
        GroupBox25.Controls.Add(Label176)
        GroupBox25.Location = New Point(1231, 320)
        GroupBox25.Name = "GroupBox25"
        GroupBox25.Size = New Size(461, 146)
        GroupBox25.TabIndex = 15
        GroupBox25.TabStop = False
        GroupBox25.Text = "Aisle Placards"
        ' 
        ' TextBox155
        ' 
        TextBox155.Location = New Point(310, 24)
        TextBox155.Name = "TextBox155"
        TextBox155.Size = New Size(119, 27)
        TextBox155.TabIndex = 39
        ' 
        ' TextBox153
        ' 
        TextBox153.Location = New Point(310, 88)
        TextBox153.Name = "TextBox153"
        TextBox153.Size = New Size(119, 27)
        TextBox153.TabIndex = 35
        ' 
        ' Label175
        ' 
        Label175.AutoSize = True
        Label175.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label175.Location = New Point(20, 93)
        Label175.Name = "Label175"
        Label175.Size = New Size(279, 20)
        Label175.TabIndex = 20
        Label175.Text = "Quantity of Aisle Placards (Double Line)"
        ' 
        ' Label176
        ' 
        Label176.AutoSize = True
        Label176.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label176.Location = New Point(20, 27)
        Label176.Name = "Label176"
        Label176.Size = New Size(271, 20)
        Label176.TabIndex = 18
        Label176.Text = "Quantity of Aisle Placards (Single Line)"
        ' 
        ' GroupBox24
        ' 
        GroupBox24.Controls.Add(Label173)
        GroupBox24.Controls.Add(TextBox150)
        GroupBox24.Controls.Add(Label172)
        GroupBox24.Controls.Add(TextBox145)
        GroupBox24.Controls.Add(Label171)
        GroupBox24.Controls.Add(TextBox143)
        GroupBox24.Controls.Add(Label170)
        GroupBox24.Controls.Add(Label159)
        GroupBox24.Controls.Add(Label169)
        GroupBox24.Controls.Add(TextBox142)
        GroupBox24.Controls.Add(ComboBox38)
        GroupBox24.Controls.Add(TextBox144)
        GroupBox24.Controls.Add(Label160)
        GroupBox24.Controls.Add(Label161)
        GroupBox24.Controls.Add(Label162)
        GroupBox24.Controls.Add(Label168)
        GroupBox24.Location = New Point(498, 24)
        GroupBox24.Name = "GroupBox24"
        GroupBox24.Size = New Size(706, 442)
        GroupBox24.TabIndex = 14
        GroupBox24.TabStop = False
        GroupBox24.Text = "Extended frame"
        ' 
        ' Label173
        ' 
        Label173.AutoSize = True
        Label173.Font = New Font("Nirmala Text", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label173.Location = New Point(34, 380)
        Label173.Name = "Label173"
        Label173.Size = New Size(294, 17)
        Label173.TabIndex = 46
        Label173.Text = "Total Tie Beam quantity (Enter 0 if not applicable)"
        ' 
        ' TextBox150
        ' 
        TextBox150.Location = New Point(536, 352)
        TextBox150.Name = "TextBox150"
        TextBox150.Size = New Size(151, 27)
        TextBox150.TabIndex = 45
        ' 
        ' Label172
        ' 
        Label172.AutoSize = True
        Label172.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label172.Location = New Point(20, 355)
        Label172.Name = "Label172"
        Label172.Size = New Size(168, 20)
        Label172.TabIndex = 44
        Label172.Text = "Total Tie Beam quantity"
        ' 
        ' TextBox145
        ' 
        TextBox145.Location = New Point(536, 299)
        TextBox145.Name = "TextBox145"
        TextBox145.Size = New Size(151, 27)
        TextBox145.TabIndex = 43
        ' 
        ' Label171
        ' 
        Label171.AutoSize = True
        Label171.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label171.Location = New Point(20, 302)
        Label171.Name = "Label171"
        Label171.Size = New Size(202, 20)
        Label171.TabIndex = 42
        Label171.Text = "How many Frames extended"
        ' 
        ' TextBox143
        ' 
        TextBox143.Location = New Point(536, 248)
        TextBox143.Name = "TextBox143"
        TextBox143.Size = New Size(151, 27)
        TextBox143.TabIndex = 41
        ' 
        ' Label170
        ' 
        Label170.AutoSize = True
        Label170.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label170.Location = New Point(20, 251)
        Label170.Name = "Label170"
        Label170.Size = New Size(364, 20)
        Label170.TabIndex = 40
        Label170.Text = "Aisle Width (Upright Face to Face distance) ( in mm )"
        ' 
        ' Label159
        ' 
        Label159.AutoSize = True
        Label159.Enabled = False
        Label159.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label159.Location = New Point(20, 133)
        Label159.Name = "Label159"
        Label159.Size = New Size(492, 20)
        Label159.TabIndex = 39
        Label159.Text = "Enter Upper upright height, if one more splice required to fix Tie beam"
        ' 
        ' Label169
        ' 
        Label169.AutoSize = True
        Label169.Enabled = False
        Label169.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label169.Location = New Point(20, 62)
        Label169.Name = "Label169"
        Label169.Size = New Size(217, 20)
        Label169.TabIndex = 19
        Label169.Text = "Extended Frame for Cable Tray"
        ' 
        ' TextBox142
        ' 
        TextBox142.Location = New Point(536, 185)
        TextBox142.Name = "TextBox142"
        TextBox142.Size = New Size(151, 27)
        TextBox142.TabIndex = 38
        ' 
        ' ComboBox38
        ' 
        ComboBox38.FormattingEnabled = True
        ComboBox38.Location = New Point(536, 41)
        ComboBox38.Name = "ComboBox38"
        ComboBox38.Size = New Size(151, 28)
        ComboBox38.TabIndex = 37
        ' 
        ' TextBox144
        ' 
        TextBox144.Location = New Point(536, 103)
        TextBox144.Name = "TextBox144"
        TextBox144.Size = New Size(151, 27)
        TextBox144.TabIndex = 35
        ' 
        ' Label160
        ' 
        Label160.AutoSize = True
        Label160.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label160.Location = New Point(20, 100)
        Label160.Name = "Label160"
        Label160.Size = New Size(97, 20)
        Label160.TabIndex = 20
        Label160.Text = "Pallet Height"
        ' 
        ' Label161
        ' 
        Label161.AutoSize = True
        Label161.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label161.Location = New Point(20, 33)
        Label161.Name = "Label161"
        Label161.Size = New Size(209, 20)
        Label161.TabIndex = 18
        Label161.Text = "Extended Frame for TIE Beam"
        ' 
        ' Label162
        ' 
        Label162.AutoSize = True
        Label162.Enabled = False
        Label162.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label162.Location = New Point(20, 171)
        Label162.Name = "Label162"
        Label162.Size = New Size(219, 20)
        Label162.TabIndex = 6
        Label162.Text = "Last Level Beam to Upright Top"
        ' 
        ' Label168
        ' 
        Label168.AutoSize = True
        Label168.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label168.Location = New Point(20, 206)
        Label168.Name = "Label168"
        Label168.Size = New Size(165, 20)
        Label168.TabIndex = 1
        Label168.Text = "Last  level Pallet height"
        ' 
        ' GroupBox23
        ' 
        GroupBox23.Controls.Add(TextBox146)
        GroupBox23.Controls.Add(ComboBox37)
        GroupBox23.Controls.Add(TextBox147)
        GroupBox23.Controls.Add(TextBox148)
        GroupBox23.Controls.Add(Label163)
        GroupBox23.Controls.Add(Label164)
        GroupBox23.Controls.Add(Label165)
        GroupBox23.Controls.Add(Label166)
        GroupBox23.Controls.Add(TextBox149)
        GroupBox23.Controls.Add(Label167)
        GroupBox23.Location = New Point(1231, 49)
        GroupBox23.Name = "GroupBox23"
        GroupBox23.Size = New Size(461, 265)
        GroupBox23.TabIndex = 13
        GroupBox23.TabStop = False
        GroupBox23.Text = "Pallet Stopper"
        ' 
        ' TextBox146
        ' 
        TextBox146.Location = New Point(256, 163)
        TextBox146.Name = "TextBox146"
        TextBox146.Size = New Size(151, 27)
        TextBox146.TabIndex = 38
        ' 
        ' ComboBox37
        ' 
        ComboBox37.FormattingEnabled = True
        ComboBox37.Location = New Point(256, 26)
        ComboBox37.Name = "ComboBox37"
        ComboBox37.Size = New Size(151, 28)
        ComboBox37.TabIndex = 37
        ' 
        ' TextBox147
        ' 
        TextBox147.Location = New Point(256, 128)
        TextBox147.Name = "TextBox147"
        TextBox147.Size = New Size(151, 27)
        TextBox147.TabIndex = 36
        ' 
        ' TextBox148
        ' 
        TextBox148.Location = New Point(256, 60)
        TextBox148.Name = "TextBox148"
        TextBox148.Size = New Size(151, 27)
        TextBox148.TabIndex = 35
        ' 
        ' Label163
        ' 
        Label163.AutoSize = True
        Label163.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label163.Location = New Point(20, 101)
        Label163.Name = "Label163"
        Label163.Size = New Size(279, 20)
        Label163.TabIndex = 22
        Label163.Text = "No.off level with pallet stopper in a row"
        ' 
        ' Label164
        ' 
        Label164.AutoSize = True
        Label164.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label164.Location = New Point(20, 67)
        Label164.Name = "Label164"
        Label164.Size = New Size(162, 20)
        Label164.TabIndex = 20
        Label164.Text = "No off frames in a row"
        ' 
        ' Label165
        ' 
        Label165.AutoSize = True
        Label165.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label165.Location = New Point(20, 33)
        Label165.Name = "Label165"
        Label165.Size = New Size(105, 20)
        Label165.TabIndex = 18
        Label165.Text = "Pallet Stopper"
        ' 
        ' Label166
        ' 
        Label166.AutoSize = True
        Label166.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label166.Location = New Point(20, 160)
        Label166.Name = "Label166"
        Label166.Size = New Size(171, 20)
        Label166.TabIndex = 6
        Label166.Text = "Total no.off similar rows"
        ' 
        ' TextBox149
        ' 
        TextBox149.Location = New Point(256, 214)
        TextBox149.Name = "TextBox149"
        TextBox149.Size = New Size(151, 27)
        TextBox149.TabIndex = 3
        ' 
        ' Label167
        ' 
        Label167.AutoSize = True
        Label167.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label167.Location = New Point(20, 195)
        Label167.Name = "Label167"
        Label167.Size = New Size(390, 20)
        Label167.TabIndex = 1
        Label167.Text = "Pallet Stopper Bracket length (For 0, 50, 75, 100, 150 OH)"
        ' 
        ' GroupBox22
        ' 
        GroupBox22.Controls.Add(TextBox137)
        GroupBox22.Controls.Add(TextBox139)
        GroupBox22.Controls.Add(TextBox140)
        GroupBox22.Controls.Add(Label153)
        GroupBox22.Controls.Add(Label154)
        GroupBox22.Controls.Add(Label157)
        GroupBox22.Controls.Add(TextBox141)
        GroupBox22.Controls.Add(Label158)
        GroupBox22.Controls.Add(TextBox132)
        GroupBox22.Controls.Add(ComboBox36)
        GroupBox22.Controls.Add(TextBox133)
        GroupBox22.Controls.Add(TextBox134)
        GroupBox22.Controls.Add(Label143)
        GroupBox22.Controls.Add(Label146)
        GroupBox22.Controls.Add(Label150)
        GroupBox22.Controls.Add(Label151)
        GroupBox22.Controls.Add(TextBox136)
        GroupBox22.Controls.Add(Label152)
        GroupBox22.Location = New Point(20, 278)
        GroupBox22.Name = "GroupBox22"
        GroupBox22.Size = New Size(461, 368)
        GroupBox22.TabIndex = 12
        GroupBox22.TabStop = False
        GroupBox22.Text = "Row Guard"
        ' 
        ' TextBox137
        ' 
        TextBox137.Location = New Point(256, 290)
        TextBox137.Name = "TextBox137"
        TextBox137.Size = New Size(151, 27)
        TextBox137.TabIndex = 46
        ' 
        ' TextBox139
        ' 
        TextBox139.Location = New Point(256, 257)
        TextBox139.Name = "TextBox139"
        TextBox139.Size = New Size(151, 27)
        TextBox139.TabIndex = 45
        ' 
        ' TextBox140
        ' 
        TextBox140.Location = New Point(256, 220)
        TextBox140.Name = "TextBox140"
        TextBox140.Size = New Size(151, 27)
        TextBox140.TabIndex = 44
        ' 
        ' Label153
        ' 
        Label153.AutoSize = True
        Label153.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label153.Location = New Point(20, 257)
        Label153.Name = "Label153"
        Label153.Size = New Size(230, 20)
        Label153.TabIndex = 43
        Label153.Text = "Calculated single piece qty in DF"
        ' 
        ' Label154
        ' 
        Label154.AutoSize = True
        Label154.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label154.Location = New Point(20, 223)
        Label154.Name = "Label154"
        Label154.Size = New Size(171, 20)
        Label154.TabIndex = 42
        Label154.Text = "Row guard length in DF"
        ' 
        ' Label157
        ' 
        Label157.AutoSize = True
        Label157.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label157.Location = New Point(20, 289)
        Label157.Name = "Label157"
        Label157.Size = New Size(181, 20)
        Label157.TabIndex = 41
        Label157.Text = "Additional quantity in DF"
        ' 
        ' TextBox141
        ' 
        TextBox141.Location = New Point(256, 324)
        TextBox141.Name = "TextBox141"
        TextBox141.Size = New Size(151, 27)
        TextBox141.TabIndex = 40
        ' 
        ' Label158
        ' 
        Label158.AutoSize = True
        Label158.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label158.Location = New Point(20, 324)
        Label158.Name = "Label158"
        Label158.Size = New Size(142, 20)
        Label158.TabIndex = 39
        Label158.Text = "Total quantity in DF"
        ' 
        ' TextBox132
        ' 
        TextBox132.Location = New Point(256, 136)
        TextBox132.Name = "TextBox132"
        TextBox132.Size = New Size(151, 27)
        TextBox132.TabIndex = 38
        ' 
        ' ComboBox36
        ' 
        ComboBox36.FormattingEnabled = True
        ComboBox36.Location = New Point(256, 26)
        ComboBox36.Name = "ComboBox36"
        ComboBox36.Size = New Size(151, 28)
        ComboBox36.TabIndex = 37
        ' 
        ' TextBox133
        ' 
        TextBox133.Location = New Point(256, 102)
        TextBox133.Name = "TextBox133"
        TextBox133.Size = New Size(151, 27)
        TextBox133.TabIndex = 36
        ' 
        ' TextBox134
        ' 
        TextBox134.Location = New Point(256, 60)
        TextBox134.Name = "TextBox134"
        TextBox134.Size = New Size(151, 27)
        TextBox134.TabIndex = 35
        ' 
        ' Label143
        ' 
        Label143.AutoSize = True
        Label143.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label143.Location = New Point(20, 101)
        Label143.Name = "Label143"
        Label143.Size = New Size(178, 20)
        Label143.TabIndex = 22
        Label143.Text = "Calculated quantity in SF"
        ' 
        ' Label146
        ' 
        Label146.AutoSize = True
        Label146.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label146.Location = New Point(20, 67)
        Label146.Name = "Label146"
        Label146.Size = New Size(168, 20)
        Label146.TabIndex = 20
        Label146.Text = "Row guard length in SF"
        ' 
        ' Label150
        ' 
        Label150.AutoSize = True
        Label150.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label150.Location = New Point(20, 33)
        Label150.Name = "Label150"
        Label150.Size = New Size(84, 20)
        Label150.TabIndex = 18
        Label150.Text = "Row Guard"
        ' 
        ' Label151
        ' 
        Label151.AutoSize = True
        Label151.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label151.Location = New Point(20, 133)
        Label151.Name = "Label151"
        Label151.Size = New Size(178, 20)
        Label151.TabIndex = 6
        Label151.Text = "Additional quantity in SF"
        ' 
        ' TextBox136
        ' 
        TextBox136.Location = New Point(256, 169)
        TextBox136.Name = "TextBox136"
        TextBox136.Size = New Size(151, 27)
        TextBox136.TabIndex = 3
        ' 
        ' Label152
        ' 
        Label152.AutoSize = True
        Label152.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label152.Location = New Point(20, 168)
        Label152.Name = "Label152"
        Label152.Size = New Size(139, 20)
        Label152.TabIndex = 1
        Label152.Text = "Total quantity in SF"
        ' 
        ' GroupBox21
        ' 
        GroupBox21.Controls.Add(TextBox135)
        GroupBox21.Controls.Add(ComboBox42)
        GroupBox21.Controls.Add(TextBox129)
        GroupBox21.Controls.Add(TextBox131)
        GroupBox21.Controls.Add(Label147)
        GroupBox21.Controls.Add(Label148)
        GroupBox21.Controls.Add(Label149)
        GroupBox21.Controls.Add(Label155)
        GroupBox21.Controls.Add(TextBox138)
        GroupBox21.Controls.Add(Label156)
        GroupBox21.Location = New Point(20, 24)
        GroupBox21.Name = "GroupBox21"
        GroupBox21.Size = New Size(461, 242)
        GroupBox21.TabIndex = 11
        GroupBox21.TabStop = False
        GroupBox21.Text = "Upright Guard"
        ' 
        ' TextBox135
        ' 
        TextBox135.Location = New Point(256, 135)
        TextBox135.Name = "TextBox135"
        TextBox135.Size = New Size(151, 27)
        TextBox135.TabIndex = 38
        ' 
        ' ComboBox42
        ' 
        ComboBox42.FormattingEnabled = True
        ComboBox42.Location = New Point(256, 25)
        ComboBox42.Name = "ComboBox42"
        ComboBox42.Size = New Size(151, 28)
        ComboBox42.TabIndex = 37
        ' 
        ' TextBox129
        ' 
        TextBox129.Location = New Point(256, 101)
        TextBox129.Name = "TextBox129"
        TextBox129.Size = New Size(151, 27)
        TextBox129.TabIndex = 36
        ' 
        ' TextBox131
        ' 
        TextBox131.Location = New Point(256, 59)
        TextBox131.Name = "TextBox131"
        TextBox131.Size = New Size(151, 27)
        TextBox131.TabIndex = 35
        ' 
        ' Label147
        ' 
        Label147.AutoSize = True
        Label147.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label147.Location = New Point(20, 101)
        Label147.Name = "Label147"
        Label147.Size = New Size(111, 20)
        Label147.TabIndex = 22
        Label147.Text = "Automated qty"
        ' 
        ' Label148
        ' 
        Label148.AutoSize = True
        Label148.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label148.Location = New Point(20, 67)
        Label148.Name = "Label148"
        Label148.Size = New Size(114, 20)
        Label148.TabIndex = 20
        Label148.Text = "Upright section"
        ' 
        ' Label149
        ' 
        Label149.AutoSize = True
        Label149.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label149.Location = New Point(20, 33)
        Label149.Name = "Label149"
        Label149.Size = New Size(108, 20)
        Label149.TabIndex = 18
        Label149.Text = "Upright Guard"
        ' 
        ' Label155
        ' 
        Label155.AutoSize = True
        Label155.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label155.Location = New Point(20, 133)
        Label155.Name = "Label155"
        Label155.Size = New Size(106, 20)
        Label155.TabIndex = 6
        Label155.Text = "Additional qty"
        ' 
        ' TextBox138
        ' 
        TextBox138.Location = New Point(256, 168)
        TextBox138.Name = "TextBox138"
        TextBox138.Size = New Size(151, 27)
        TextBox138.TabIndex = 3
        ' 
        ' Label156
        ' 
        Label156.AutoSize = True
        Label156.Font = New Font("Yu Gothic UI", 9F, FontStyle.Bold)
        Label156.Location = New Point(20, 168)
        Label156.Name = "Label156"
        Label156.Size = New Size(67, 20)
        Label156.TabIndex = 1
        Label156.Text = "Total qty"
        ' 
        ' Input
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveBorder
        ClientSize = New Size(1868, 976)
        Controls.Add(TabControl1)
        Name = "Input"
        StartPosition = FormStartPosition.CenterParent
        Text = "Input"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        TabControl1.ResumeLayout(False)
        TabPage1.ResumeLayout(False)
        GroupBox9.ResumeLayout(False)
        GroupBox9.PerformLayout()
        GroupBox5.ResumeLayout(False)
        GroupBox5.PerformLayout()
        GroupBox7.ResumeLayout(False)
        GroupBox7.PerformLayout()
        GroupBox8.ResumeLayout(False)
        GroupBox8.PerformLayout()
        GroupBox4.ResumeLayout(False)
        GroupBox4.PerformLayout()
        GroupBox6.ResumeLayout(False)
        GroupBox6.PerformLayout()
        GroupBox3.ResumeLayout(False)
        GroupBox3.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        TabPage7.ResumeLayout(False)
        GroupBox11.ResumeLayout(False)
        GroupBox11.PerformLayout()
        GroupBox14.ResumeLayout(False)
        GroupBox14.PerformLayout()
        GroupBox15.ResumeLayout(False)
        GroupBox15.PerformLayout()
        GroupBox13.ResumeLayout(False)
        GroupBox13.PerformLayout()
        TabPage8.ResumeLayout(False)
        TabPage8.PerformLayout()
        GroupBox16.ResumeLayout(False)
        GroupBox16.PerformLayout()
        GroupBox12.ResumeLayout(False)
        GroupBox12.PerformLayout()
        GroupBox10.ResumeLayout(False)
        GroupBox10.PerformLayout()
        TabPage9.ResumeLayout(False)
        GroupBox33.ResumeLayout(False)
        GroupBox33.PerformLayout()
        GroupBox31.ResumeLayout(False)
        GroupBox31.PerformLayout()
        GroupBox30.ResumeLayout(False)
        GroupBox30.PerformLayout()
        GroupBox29.ResumeLayout(False)
        GroupBox29.PerformLayout()
        GroupBox28.ResumeLayout(False)
        GroupBox28.PerformLayout()
        GroupBox20.ResumeLayout(False)
        GroupBox20.PerformLayout()
        GroupBox19.ResumeLayout(False)
        GroupBox19.PerformLayout()
        GroupBox18.ResumeLayout(False)
        GroupBox18.PerformLayout()
        GroupBox17.ResumeLayout(False)
        GroupBox17.PerformLayout()
        TabPage10.ResumeLayout(False)
        GroupBox32.ResumeLayout(False)
        GroupBox32.PerformLayout()
        GroupBox27.ResumeLayout(False)
        GroupBox27.PerformLayout()
        GroupBox26.ResumeLayout(False)
        GroupBox26.PerformLayout()
        GroupBox25.ResumeLayout(False)
        GroupBox25.PerformLayout()
        GroupBox24.ResumeLayout(False)
        GroupBox24.PerformLayout()
        GroupBox23.ResumeLayout(False)
        GroupBox23.PerformLayout()
        GroupBox22.ResumeLayout(False)
        GroupBox22.PerformLayout()
        GroupBox21.ResumeLayout(False)
        GroupBox21.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents Label76 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Label77 As Label
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents Label78 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents TextBox100 As TextBox
    Friend WithEvents Label91 As Label
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents TextBox101 As TextBox
    Friend WithEvents Label92 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents TextBox102 As TextBox
    Friend WithEvents TextBox103 As TextBox
    Friend WithEvents Label94 As Label
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents TextBox50 As TextBox
    Friend WithEvents TextBox51 As TextBox
    Friend WithEvents Label84 As Label
    Friend WithEvents TextBox94 As TextBox
    Friend WithEvents Label85 As Label
    Friend WithEvents TextBox95 As TextBox
    Friend WithEvents Label86 As Label
    Friend WithEvents TextBox96 As TextBox
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents TextBox97 As TextBox
    Friend WithEvents TextBox98 As TextBox
    Friend WithEvents Label89 As Label
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents Label68 As Label
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents TextBox105 As TextBox
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents TextBox108 As TextBox
    Friend WithEvents Label99 As Label
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents ComboBox16 As ComboBox
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents TextBox110 As TextBox
    Friend WithEvents Label100 As Label
    Friend WithEvents TextBox109 As TextBox
    Friend WithEvents GroupBox16 As GroupBox
    Friend WithEvents ComboBox25 As ComboBox
    Friend WithEvents ComboBox26 As ComboBox
    Friend WithEvents ComboBox27 As ComboBox
    Friend WithEvents ComboBox28 As ComboBox
    Friend WithEvents TextBox111 As TextBox
    Friend WithEvents Label112 As Label
    Friend WithEvents TextBox112 As TextBox
    Friend WithEvents ComboBox29 As ComboBox
    Friend WithEvents Label113 As Label
    Friend WithEvents ComboBox30 As ComboBox
    Friend WithEvents Label114 As Label
    Friend WithEvents Label115 As Label
    Friend WithEvents ComboBox31 As ComboBox
    Friend WithEvents Label116 As Label
    Friend WithEvents Label117 As Label
    Friend WithEvents TextBox113 As TextBox
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents Label120 As Label
    Friend WithEvents Label121 As Label
    Friend WithEvents TextBox114 As TextBox
    Friend WithEvents Label122 As Label
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents ComboBox18 As ComboBox
    Friend WithEvents ComboBox19 As ComboBox
    Friend WithEvents ComboBox20 As ComboBox
    Friend WithEvents ComboBox21 As ComboBox
    Friend WithEvents TextBox93 As TextBox
    Friend WithEvents Label101 As Label
    Friend WithEvents TextBox104 As TextBox
    Friend WithEvents ComboBox22 As ComboBox
    Friend WithEvents Label102 As Label
    Friend WithEvents ComboBox23 As ComboBox
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents ComboBox24 As ComboBox
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents TextBox106 As TextBox
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label109 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents TextBox107 As TextBox
    Friend WithEvents Label111 As Label
    Friend WithEvents TextBox99 As TextBox
    Friend WithEvents Label90 As Label
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents GroupBox17 As GroupBox
    Friend WithEvents ComboBox32 As ComboBox
    Friend WithEvents Label123 As Label
    Friend WithEvents TextBox116 As TextBox
    Friend WithEvents Label125 As Label
    Friend WithEvents Label124 As Label
    Friend WithEvents TextBox115 As TextBox
    Friend WithEvents GroupBox18 As GroupBox
    Friend WithEvents ComboBox40 As ComboBox
    Friend WithEvents Label127 As Label
    Friend WithEvents Label128 As Label
    Friend WithEvents Label129 As Label
    Friend WithEvents ComboBox39 As ComboBox
    Friend WithEvents Label135 As Label
    Friend WithEvents TextBox120 As TextBox
    Friend WithEvents Label136 As Label
    Friend WithEvents TextBox118 As TextBox
    Friend WithEvents TextBox117 As TextBox
    Friend WithEvents GroupBox19 As GroupBox
    Friend WithEvents ComboBox33 As ComboBox
    Friend WithEvents ComboBox35 As ComboBox
    Friend WithEvents Label126 As Label
    Friend WithEvents TextBox121 As TextBox
    Friend WithEvents Label130 As Label
    Friend WithEvents Label131 As Label
    Friend WithEvents Label132 As Label
    Friend WithEvents ComboBox41 As ComboBox
    Friend WithEvents Label133 As Label
    Friend WithEvents Label134 As Label
    Friend WithEvents TextBox122 As TextBox
    Friend WithEvents Label137 As Label
    Friend WithEvents Label138 As Label
    Friend WithEvents Label139 As Label
    Friend WithEvents Label140 As Label
    Friend WithEvents TextBox123 As TextBox
    Friend WithEvents Label141 As Label
    Friend WithEvents TextBox125 As TextBox
    Friend WithEvents Label142 As Label
    Friend WithEvents TextBox124 As TextBox
    Friend WithEvents TextBox119 As TextBox
    Friend WithEvents TextBox128 As TextBox
    Friend WithEvents TextBox127 As TextBox
    Friend WithEvents TextBox126 As TextBox
    Friend WithEvents GroupBox20 As GroupBox
    Friend WithEvents ComboBox34 As ComboBox
    Friend WithEvents Label144 As Label
    Friend WithEvents TextBox130 As TextBox
    Friend WithEvents Label145 As Label
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents GroupBox21 As GroupBox
    Friend WithEvents TextBox135 As TextBox
    Friend WithEvents ComboBox42 As ComboBox
    Friend WithEvents TextBox129 As TextBox
    Friend WithEvents TextBox131 As TextBox
    Friend WithEvents Label147 As Label
    Friend WithEvents Label148 As Label
    Friend WithEvents Label149 As Label
    Friend WithEvents Label155 As Label
    Friend WithEvents TextBox138 As TextBox
    Friend WithEvents Label156 As Label
    Friend WithEvents GroupBox22 As GroupBox
    Friend WithEvents TextBox132 As TextBox
    Friend WithEvents ComboBox36 As ComboBox
    Friend WithEvents TextBox133 As TextBox
    Friend WithEvents TextBox134 As TextBox
    Friend WithEvents Label143 As Label
    Friend WithEvents Label146 As Label
    Friend WithEvents Label150 As Label
    Friend WithEvents Label151 As Label
    Friend WithEvents TextBox136 As TextBox
    Friend WithEvents Label152 As Label
    Friend WithEvents TextBox137 As TextBox
    Friend WithEvents TextBox139 As TextBox
    Friend WithEvents TextBox140 As TextBox
    Friend WithEvents Label153 As Label
    Friend WithEvents Label154 As Label
    Friend WithEvents Label157 As Label
    Friend WithEvents TextBox141 As TextBox
    Friend WithEvents Label158 As Label
    Friend WithEvents GroupBox23 As GroupBox
    Friend WithEvents TextBox146 As TextBox
    Friend WithEvents ComboBox37 As ComboBox
    Friend WithEvents TextBox147 As TextBox
    Friend WithEvents TextBox148 As TextBox
    Friend WithEvents Label163 As Label
    Friend WithEvents Label164 As Label
    Friend WithEvents Label165 As Label
    Friend WithEvents Label166 As Label
    Friend WithEvents TextBox149 As TextBox
    Friend WithEvents Label167 As Label
    Friend WithEvents GroupBox24 As GroupBox
    Friend WithEvents Label169 As Label
    Friend WithEvents TextBox142 As TextBox
    Friend WithEvents ComboBox38 As ComboBox
    Friend WithEvents TextBox144 As TextBox
    Friend WithEvents Label160 As Label
    Friend WithEvents Label161 As Label
    Friend WithEvents Label162 As Label
    Friend WithEvents Label168 As Label
    Friend WithEvents Label159 As Label
    Friend WithEvents TextBox143 As TextBox
    Friend WithEvents Label170 As Label
    Friend WithEvents Label173 As Label
    Friend WithEvents TextBox150 As TextBox
    Friend WithEvents Label172 As Label
    Friend WithEvents TextBox145 As TextBox
    Friend WithEvents Label171 As Label
    Friend WithEvents GroupBox26 As GroupBox
    Friend WithEvents TextBox151 As TextBox
    Friend WithEvents TextBox152 As TextBox
    Friend WithEvents TextBox154 As TextBox
    Friend WithEvents Label174 As Label
    Friend WithEvents Label177 As Label
    Friend WithEvents Label178 As Label
    Friend WithEvents Label179 As Label
    Friend WithEvents TextBox156 As TextBox
    Friend WithEvents Label180 As Label
    Friend WithEvents GroupBox25 As GroupBox
    Friend WithEvents TextBox155 As TextBox
    Friend WithEvents TextBox153 As TextBox
    Friend WithEvents Label175 As Label
    Friend WithEvents Label176 As Label
    Friend WithEvents TextBox157 As TextBox
    Friend WithEvents GroupBox27 As GroupBox
    Friend WithEvents TextBox158 As TextBox
    Friend WithEvents TextBox159 As TextBox
    Friend WithEvents TextBox160 As TextBox
    Friend WithEvents Label181 As Label
    Friend WithEvents Label182 As Label
    Friend WithEvents Label183 As Label
    Friend WithEvents TextBox161 As TextBox
    Friend WithEvents Label184 As Label
    Friend WithEvents TextBox162 As TextBox
    Friend WithEvents ComboBox43 As ComboBox
    Friend WithEvents TextBox163 As TextBox
    Friend WithEvents TextBox164 As TextBox
    Friend WithEvents Label185 As Label
    Friend WithEvents Label186 As Label
    Friend WithEvents Label187 As Label
    Friend WithEvents Label188 As Label
    Friend WithEvents TextBox165 As TextBox
    Friend WithEvents Label189 As Label
    Friend WithEvents TextBox166 As TextBox
    Friend WithEvents Label190 As Label
    Friend WithEvents GroupBox28 As GroupBox
    Friend WithEvents TextBox176 As TextBox
    Friend WithEvents Label202 As Label
    Friend WithEvents TextBox177 As TextBox
    Friend WithEvents TextBox178 As TextBox
    Friend WithEvents Label203 As Label
    Friend WithEvents Label204 As Label
    Friend WithEvents TextBox179 As TextBox
    Friend WithEvents Label205 As Label
    Friend WithEvents Label201 As Label
    Friend WithEvents TextBox167 As TextBox
    Friend WithEvents Label191 As Label
    Friend WithEvents TextBox168 As TextBox
    Friend WithEvents TextBox169 As TextBox
    Friend WithEvents TextBox170 As TextBox
    Friend WithEvents Label192 As Label
    Friend WithEvents Label193 As Label
    Friend WithEvents Label194 As Label
    Friend WithEvents TextBox171 As TextBox
    Friend WithEvents Label195 As Label
    Friend WithEvents TextBox172 As TextBox
    Friend WithEvents ComboBox44 As ComboBox
    Friend WithEvents TextBox173 As TextBox
    Friend WithEvents TextBox174 As TextBox
    Friend WithEvents Label196 As Label
    Friend WithEvents Label197 As Label
    Friend WithEvents Label198 As Label
    Friend WithEvents Label199 As Label
    Friend WithEvents TextBox175 As TextBox
    Friend WithEvents Label200 As Label
    Friend WithEvents GroupBox29 As GroupBox
    Friend WithEvents TextBox180 As TextBox
    Friend WithEvents ComboBox45 As ComboBox
    Friend WithEvents TextBox181 As TextBox
    Friend WithEvents TextBox182 As TextBox
    Friend WithEvents Label206 As Label
    Friend WithEvents Label207 As Label
    Friend WithEvents Label208 As Label
    Friend WithEvents Label209 As Label
    Friend WithEvents TextBox183 As TextBox
    Friend WithEvents Label210 As Label
    Friend WithEvents GroupBox30 As GroupBox
    Friend WithEvents Label211 As Label
    Friend WithEvents TextBox184 As TextBox
    Friend WithEvents ComboBox46 As ComboBox
    Friend WithEvents Label212 As Label
    Friend WithEvents Label213 As Label
    Friend WithEvents ComboBox47 As ComboBox
    Friend WithEvents GroupBox31 As GroupBox
    Friend WithEvents TextBox186 As TextBox
    Friend WithEvents ComboBox48 As ComboBox
    Friend WithEvents Label214 As Label
    Friend WithEvents TextBox185 As TextBox
    Friend WithEvents Label215 As Label
    Friend WithEvents Label216 As Label
    Friend WithEvents GroupBox32 As GroupBox
    Friend WithEvents Label229 As Label
    Friend WithEvents Label228 As Label
    Friend WithEvents Label227 As Label
    Friend WithEvents Label226 As Label
    Friend WithEvents ComboBox50 As ComboBox
    Friend WithEvents TextBox187 As TextBox
    Friend WithEvents TextBox188 As TextBox
    Friend WithEvents TextBox189 As TextBox
    Friend WithEvents Label217 As Label
    Friend WithEvents Label218 As Label
    Friend WithEvents Label219 As Label
    Friend WithEvents TextBox191 As TextBox
    Friend WithEvents ComboBox49 As ComboBox
    Friend WithEvents TextBox192 As TextBox
    Friend WithEvents Label221 As Label
    Friend WithEvents Label222 As Label
    Friend WithEvents Label223 As Label
    Friend WithEvents Label224 As Label
    Friend WithEvents TextBox194 As TextBox
    Friend WithEvents Label225 As Label
    Friend WithEvents GroupBox33 As GroupBox
    Friend WithEvents TextBox193 As TextBox
    Friend WithEvents Label231 As Label
    Friend WithEvents Label220 As Label
    Friend WithEvents TextBox190 As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Label34 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Label75 As Label
    Friend WithEvents TextBox72 As TextBox
    Friend WithEvents TextBox73 As TextBox
    Friend WithEvents TextBox74 As TextBox
    Friend WithEvents TextBox75 As TextBox
    Friend WithEvents TextBox76 As TextBox
    Friend WithEvents TextBox77 As TextBox
    Friend WithEvents TextBox78 As TextBox
    Friend WithEvents TextBox79 As TextBox
    Friend WithEvents TextBox80 As TextBox
    Friend WithEvents TextBox81 As TextBox
    Friend WithEvents TextBox82 As TextBox
    Friend WithEvents TextBox83 As TextBox
    Friend WithEvents TextBox84 As TextBox
    Friend WithEvents TextBox85 As TextBox
    Friend WithEvents TextBox86 As TextBox
    Friend WithEvents TextBox87 As TextBox
    Friend WithEvents TextBox88 As TextBox
    Friend WithEvents TextBox89 As TextBox
    Friend WithEvents TextBox90 As TextBox
    Friend WithEvents TextBox91 As TextBox
    Friend WithEvents Label74 As Label
    Friend WithEvents TextBox71 As TextBox
    Friend WithEvents Label73 As Label
    Friend WithEvents TextBox70 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox52 As TextBox
    Friend WithEvents TextBox53 As TextBox
    Friend WithEvents TextBox54 As TextBox
    Friend WithEvents TextBox55 As TextBox
    Friend WithEvents TextBox56 As TextBox
    Friend WithEvents TextBox57 As TextBox
    Friend WithEvents TextBox58 As TextBox
    Friend WithEvents TextBox59 As TextBox
    Friend WithEvents TextBox60 As TextBox
    Friend WithEvents TextBox61 As TextBox
    Friend WithEvents TextBox62 As TextBox
    Friend WithEvents TextBox63 As TextBox
    Friend WithEvents TextBox64 As TextBox
    Friend WithEvents TextBox65 As TextBox
    Friend WithEvents TextBox66 As TextBox
    Friend WithEvents TextBox67 As TextBox
    Friend WithEvents TextBox68 As TextBox
    Friend WithEvents TextBox69 As TextBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents Label56 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents TextBox36 As TextBox
    Friend WithEvents Label52 As Label
    Friend WithEvents TextBox37 As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents Label54 As Label
    Friend WithEvents TextBox39 As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents TextBox32 As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents Label49 As Label
    Friend WithEvents TextBox34 As TextBox
    Friend WithEvents Label50 As Label
    Friend WithEvents TextBox35 As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents TextBox92 As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents TextBox46 As TextBox
    Friend WithEvents Label62 As Label
    Friend WithEvents TextBox45 As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents TextBox44 As TextBox
    Friend WithEvents Label58 As Label
    Friend WithEvents TextBox41 As TextBox
    Friend WithEvents Label57 As Label
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents TextBox42 As TextBox
    Friend WithEvents Label59 As Label
    Friend WithEvents TextBox43 As TextBox
    Friend WithEvents Label60 As Label
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents TextBox49 As TextBox
    Friend WithEvents Label66 As Label
End Class
