﻿Public Class Configurator
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub UIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UIToolStripMenuItem.Click
        Input.MdiParent = Me  ' This is the critical line
        Input.Show()
    End Sub

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click

    End Sub

    Private Sub MasterEntryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MasterEntryToolStripMenuItem.Click
        Master_Entry.MdiParent = Me  ' This is the critical line
        Master_Entry.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub
End Class
