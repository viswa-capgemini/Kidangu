﻿Imports Microsoft.VisualBasic.Devices
'spr/house/44 -excel password
Public Class Input
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label1_Click_2(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Input_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        'spr/house/44



        ' Clear any existing items
        ComboBox8.Items.Clear()

        ' Add   options
        ComboBox8.Items.Add("Non-Seismic")
        ComboBox8.Items.Add("Seismic")

        ' Select the first item
        If ComboBox8.Items.Count > 0 Then
            ComboBox8.SelectedIndex = 0
        End If


        ' Clear any existing items
        ComboBox9.Items.Clear()

        ' Add  frame colour options
        ComboBox9.Items.Add("SKY BLUE")
        ComboBox9.Items.Add("B.S.GREY")

        ' Select the first item
        If ComboBox9.Items.Count > 0 Then
            ComboBox9.SelectedIndex = 0
        End If


        ' Clear any existing items
        ComboBox10.Items.Clear()

        ' Add Bracing colour options
        ComboBox10.Items.Add("GALVANIZED")
        ComboBox10.Items.Add("SYSTEM COLOUR")

        ' Select the first item
        If ComboBox10.Items.Count > 0 Then
            ComboBox10.SelectedIndex = 0
        End If




        ' Clear any existing items
        ComboBox1.Items.Clear()

        ' Add numbers from 500 to 1500 with increments of 50
        For i As Integer = 500 To 1500 Step 50
            ComboBox1.Items.Add(i)
        Next

        ' Optionally select the first item
        If ComboBox1.Items.Count > 0 Then
            ComboBox1.SelectedIndex = 0
        End If



        ' Clear any existing items
        ComboBox2.Items.Clear()

        ' Add stiffener options
        ComboBox2.Items.Add("With Stiffener")
        ComboBox2.Items.Add("Without Stiffener")

        ' Select the first item
        If ComboBox2.Items.Count > 0 Then
            ComboBox2.SelectedIndex = 0
        End If


        ' Clear any existing items
        ComboBox3.Items.Clear()
        ComboBox4.Items.Clear()
        ComboBox5.Items.Clear()

        ' Add  options
        ComboBox3.Items.Add("Pallet storage")
        ComboBox3.Items.Add("Shelving")
        ' Add  options
        ComboBox4.Items.Add("Pallet storage")
        ComboBox4.Items.Add("Shelving")

        ' Add  options
        ComboBox5.Items.Add("Pallet storage")
        ComboBox5.Items.Add("Shelving")

        ' Select the first item
        If ComboBox3.Items.Count > 0 Then
            ComboBox3.SelectedIndex = 0
        End If

        ' Select the first item
        If ComboBox4.Items.Count > 0 Then
            ComboBox4.SelectedIndex = 0
        End If


        ' Select the first item
        If ComboBox5.Items.Count > 0 Then
            ComboBox5.SelectedIndex = 0
        End If

        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        ComboBox4.Text = ""
        ComboBox5.Text = ""



        ComboBox6.Items.Clear()
        ' Add  options
        ComboBox6.Items.Add(12)
        ComboBox6.Items.Add(62)

        ' Select the first item
        If ComboBox6.Items.Count > 0 Then
            ComboBox6.SelectedIndex = 0
        End If

        ComboBox6.Text = ""


        ComboBox7.Items.Clear()
        ' Add  options
        ComboBox7.Items.Add("Main & Addons")
        ComboBox7.Items.Add("Standalone")

        ' Select the first item
        If ComboBox7.Items.Count > 0 Then
            ComboBox7.SelectedIndex = 0
        End If

        ComboBox7.Text = ""


        ' beam load

        TextBox91.Enabled = False
        TextBox90.Enabled = False
        TextBox89.Enabled = False
        TextBox88.Enabled = False
        TextBox87.Enabled = False
        TextBox86.Enabled = False
        TextBox85.Enabled = False
        TextBox84.Enabled = False
        TextBox83.Enabled = False
        TextBox82.Enabled = False
        TextBox81.Enabled = False
        TextBox80.Enabled = False
        TextBox79.Enabled = False
        TextBox78.Enabled = False
        TextBox77.Enabled = False
        TextBox76.Enabled = False
        TextBox75.Enabled = False
        TextBox74.Enabled = False
        TextBox73.Enabled = False
        TextBox72.Enabled = False

        '  load per level

        TextBox69.Enabled = False
        TextBox68.Enabled = False
        TextBox67.Enabled = False
        TextBox66.Enabled = False
        TextBox65.Enabled = False
        TextBox64.Enabled = False
        TextBox63.Enabled = False
        TextBox62.Enabled = False
        TextBox61.Enabled = False
        TextBox60.Enabled = False
        TextBox59.Enabled = False
        TextBox58.Enabled = False
        TextBox57.Enabled = False
        TextBox56.Enabled = False
        TextBox55.Enabled = False
        TextBox54.Enabled = False
        TextBox53.Enabled = False
        TextBox52.Enabled = False
        TextBox1.Enabled = False
        TextBox70.Enabled = False



        DisableAll_USL_TextBoxes()


    End Sub





    Private Sub Label8_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label24_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label21_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label37_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label61_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label59_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label69_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox71_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub Calulate_beamload()

        'total frame load per unit 
        TextBox71.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text) + Val(TextBox53.Text) +
            Val(TextBox52.Text) + Val(TextBox1.Text) + Val(TextBox70.Text)
        '-------------------------------------------------------------------------------------------------

        'total load l1
        TextBox72.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text) + Val(TextBox53.Text) +
            Val(TextBox52.Text) + Val(TextBox1.Text) + Val(TextBox70.Text)

        'total load l2
        TextBox73.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text) + Val(TextBox53.Text) +
            Val(TextBox52.Text) + Val(TextBox1.Text)

        'total load l3
        TextBox74.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text) + Val(TextBox53.Text) +
            Val(TextBox52.Text)

        'total load l4
        TextBox75.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text) + Val(TextBox53.Text)
        'total load l5
        TextBox76.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text) + Val(TextBox54.Text)

        'total load l6
        TextBox77.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text) + Val(TextBox55.Text)

        'total load l7
        TextBox78.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text) + Val(TextBox56.Text)

        'total load l8
        TextBox79.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text) + Val(TextBox57.Text)

        'total load l9
        TextBox80.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text) + Val(TextBox58.Text)

        'total load l10
        TextBox81.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text) + Val(TextBox59.Text)

        'total load l11
        TextBox82.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text) + Val(TextBox60.Text)

        'total load l12
        TextBox83.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text) +
            Val(TextBox61.Text)


        'total load l13
        TextBox84.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text) + Val(TextBox62.Text)

        'total load l14
        TextBox85.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text) + Val(TextBox63.Text)

        'total load l15
        TextBox86.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text) + Val(TextBox64.Text)

        'total load l16
        TextBox87.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text) + Val(TextBox65.Text)

        'total load l17
        TextBox88.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text) + Val(TextBox66.Text)

        'total load l18
        TextBox89.Text = Val(TextBox69.Text) + Val(TextBox68.Text) + Val(TextBox67.Text)

        'total load l19
        TextBox90.Text = Val(TextBox69.Text) + Val(TextBox68.Text)

        'total load l20
        TextBox91.Text = Val(TextBox69.Text)

    End Sub

    Private Sub Label75_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label74_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub add_load_inputs()

        Dim total_levels As Integer

        total_levels = Val(TextBox16.Text) + Val(TextBox9.Text) + Val(TextBox11.Text)

        If total_levels < 0 Then
            Exit Sub
        End If



    End Sub
    Private Sub active_levels()
        ' Disable all TextBoxes first
        DisableAll_USL_TextBoxes()

        Dim total_levels As Integer

        total_levels = Val(TextBox16.Text) + Val(TextBox9.Text) + Val(TextBox11.Text)


        ' Check if total_levels is out of range and display warning if needed
        If total_levels < 0 Then
            MessageBox.Show("Warning: Total levels cannot be less than 0. Please check your input values.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            ' You might want to reset the values or take other appropriate action
        ElseIf total_levels > 20 Then
            MessageBox.Show("Warning: Total levels cannot exceed 20. Please reduce your input values.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            ' You might want to reset the values or take other appropriate action
        End If

        EnableLoadPerLevelTextBoxes(total_levels)

        ' Ensure value is within range
        If total_levels > 0 AndAlso total_levels <= 20 Then
            ' Create array of TextBoxes in the order they should be enabled
            Dim textBoxes() As TextBox = {
            TextBox36, TextBox37, TextBox38, TextBox39,
            TextBox32, TextBox33, TextBox34, TextBox35,
            TextBox28, TextBox29, TextBox30, TextBox31,
            TextBox24, TextBox25, TextBox26, TextBox27,
            TextBox22, TextBox23, TextBox21, TextBox18
        }

            ' Enable the appropriate number of TextBoxes
            For i As Integer = 0 To Math.Min(total_levels - 1, textBoxes.Length - 1)
                textBoxes(i).Enabled = True
            Next
        End If






    End Sub


    ' Enable load per level TextBoxes based on total_levels
    Public Sub EnableLoadPerLevelTextBoxes(total_levels As Integer)
        ' Ensure value is within range
        If total_levels > 0 AndAlso total_levels <= 20 Then
            ' Create array of TextBoxes in the order they should be enabled
            ' Starting with TextBox70 as specified
            Dim textBoxes() As TextBox = {
            TextBox70, TextBox1, TextBox52, TextBox53,
            TextBox54, TextBox55, TextBox56, TextBox57,
            TextBox58, TextBox59, TextBox60, TextBox61,
            TextBox62, TextBox63, TextBox64, TextBox65,
            TextBox66, TextBox67, TextBox68, TextBox69
        }

            ' First disable all TextBoxes
            For Each tb As TextBox In textBoxes
                tb.Enabled = False
            Next

            ' Enable the appropriate number of TextBoxes
            For i As Integer = 0 To Math.Min(total_levels - 1, textBoxes.Length - 1)
                textBoxes(i).Enabled = True
            Next
        End If
    End Sub

    Private Sub DisableAll_USL_TextBoxes()
        ' Disable all TextBoxes
        TextBox18.Enabled = False
        TextBox21.Enabled = False
        TextBox23.Enabled = False
        TextBox22.Enabled = False
        TextBox27.Enabled = False
        TextBox26.Enabled = False
        TextBox25.Enabled = False
        TextBox24.Enabled = False
        TextBox31.Enabled = False
        TextBox30.Enabled = False
        TextBox29.Enabled = False
        TextBox28.Enabled = False
        TextBox35.Enabled = False
        TextBox34.Enabled = False
        TextBox33.Enabled = False
        TextBox32.Enabled = False
        TextBox39.Enabled = False
        TextBox38.Enabled = False
        TextBox37.Enabled = False
        TextBox36.Enabled = False

        '  load per level

        TextBox69.Enabled = False
        TextBox68.Enabled = False
        TextBox67.Enabled = False
        TextBox66.Enabled = False
        TextBox65.Enabled = False
        TextBox64.Enabled = False
        TextBox63.Enabled = False
        TextBox62.Enabled = False
        TextBox61.Enabled = False
        TextBox60.Enabled = False
        TextBox59.Enabled = False
        TextBox58.Enabled = False
        TextBox57.Enabled = False
        TextBox56.Enabled = False
        TextBox55.Enabled = False
        TextBox54.Enabled = False
        TextBox53.Enabled = False
        TextBox52.Enabled = False
        TextBox1.Enabled = False
        TextBox70.Enabled = False


    End Sub

    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs)
        DisableAll_USL_TextBoxes()
        active_levels()
        'add_load_inputs()
    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs)
        DisableAll_USL_TextBoxes()
        active_levels()
        add_load_inputs()
    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs)
        DisableAll_USL_TextBoxes()
        active_levels()
        add_load_inputs()

    End Sub

    Private Sub TextBox70_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox52_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox53_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox54_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox55_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox56_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox57_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox58_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox59_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox60_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox61_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox62_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox63_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox64_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox65_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox66_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox67_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox68_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox69_TextChanged(sender As Object, e As EventArgs)
        Calulate_beamload()
    End Sub

    Private Sub TextBox36_TextChanged(sender As Object, e As EventArgs)
        'TextBox36.Text = Val(TextBox36.Text) + Val(ComboBox6.Text)
    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label77_Click(sender As Object, e As EventArgs) Handles Label77.Click

    End Sub

    Private Sub TabPage5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label65_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label70_Click(sender As Object, e As EventArgs) Handles Label70.Click

    End Sub

    Private Sub Label158_Click(sender As Object, e As EventArgs) Handles Label158.Click

    End Sub

    Private Sub Label160_Click(sender As Object, e As EventArgs) Handles Label160.Click

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged

    End Sub

    Private Sub TextBox9_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub TextBox16_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox16.TextChanged

    End Sub

    Private Sub TabPage7_Click(sender As Object, e As EventArgs) Handles TabPage7.Click

    End Sub
End Class