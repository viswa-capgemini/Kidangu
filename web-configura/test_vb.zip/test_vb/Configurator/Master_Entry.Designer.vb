﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Master_Entry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox14 = New GroupBox()
        CheckedListBox2 = New CheckedListBox()
        Label3 = New Label()
        CheckedListBox1 = New CheckedListBox()
        Label91 = New Label()
        GroupBox1 = New GroupBox()
        Label4 = New Label()
        ComboBox1 = New ComboBox()
        Label2 = New Label()
        ComboBox3 = New ComboBox()
        ComboBox2 = New ComboBox()
        Label1 = New Label()
        GroupBox4 = New GroupBox()
        Label25 = New Label()
        ComboBox14 = New ComboBox()
        Label24 = New Label()
        ComboBox13 = New ComboBox()
        Label23 = New Label()
        TextBox8 = New TextBox()
        Label22 = New Label()
        ComboBox12 = New ComboBox()
        Label21 = New Label()
        ComboBox11 = New ComboBox()
        ComboBox10 = New ComboBox()
        Label17 = New Label()
        ComboBox9 = New ComboBox()
        Label16 = New Label()
        ComboBox7 = New ComboBox()
        CheckBox1 = New CheckBox()
        TextBox7 = New TextBox()
        Label15 = New Label()
        ComboBox6 = New ComboBox()
        Label14 = New Label()
        ComboBox5 = New ComboBox()
        Label13 = New Label()
        TextBox13 = New TextBox()
        TextBox10 = New TextBox()
        TextBox12 = New TextBox()
        Label18 = New Label()
        Label19 = New Label()
        Label20 = New Label()
        TextBox6 = New TextBox()
        Label12 = New Label()
        TextBox5 = New TextBox()
        Label11 = New Label()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox1 = New TextBox()
        Label10 = New Label()
        TextBox2 = New TextBox()
        ComboBox8 = New ComboBox()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        ComboBox4 = New ComboBox()
        Label5 = New Label()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        GroupBox14.SuspendLayout()
        GroupBox1.SuspendLayout()
        GroupBox4.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox14
        ' 
        GroupBox14.Controls.Add(CheckedListBox2)
        GroupBox14.Controls.Add(Label3)
        GroupBox14.Controls.Add(CheckedListBox1)
        GroupBox14.Controls.Add(Label91)
        GroupBox14.Location = New Point(49, 36)
        GroupBox14.Name = "GroupBox14"
        GroupBox14.Size = New Size(263, 954)
        GroupBox14.TabIndex = 16
        GroupBox14.TabStop = False
        GroupBox14.Text = "Product Group"
        ' 
        ' CheckedListBox2
        ' 
        CheckedListBox2.BackColor = SystemColors.Control
        CheckedListBox2.BorderStyle = BorderStyle.None
        CheckedListBox2.CheckOnClick = True
        CheckedListBox2.FormattingEnabled = True
        CheckedListBox2.HorizontalScrollbar = True
        CheckedListBox2.Items.AddRange(New Object() {"    Mezzanine", "    Single Tier Shelving", "    Mobile Shelving ", "    Multi-Tier Shelving "})
        CheckedListBox2.Location = New Point(32, 310)
        CheckedListBox2.Name = "CheckedListBox2"
        CheckedListBox2.Size = New Size(202, 176)
        CheckedListBox2.TabIndex = 22
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label3.Location = New Point(20, 274)
        Label3.Name = "Label3"
        Label3.Size = New Size(135, 20)
        Label3.TabIndex = 21
        Label3.Text = "Shelving Solutions"
        ' 
        ' CheckedListBox1
        ' 
        CheckedListBox1.BackColor = SystemColors.Control
        CheckedListBox1.BorderStyle = BorderStyle.None
        CheckedListBox1.CheckOnClick = True
        CheckedListBox1.FormattingEnabled = True
        CheckedListBox1.HorizontalScrollbar = True
        CheckedListBox1.Items.AddRange(New Object() {"    Selective Pallet Racking    ", "    Shuttle Racking", "    Mother/Child Shuttle"})
        CheckedListBox1.Location = New Point(32, 75)
        CheckedListBox1.Name = "CheckedListBox1"
        CheckedListBox1.Size = New Size(225, 110)
        CheckedListBox1.TabIndex = 20
        ' 
        ' Label91
        ' 
        Label91.AutoSize = True
        Label91.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label91.Location = New Point(20, 39)
        Label91.Name = "Label91"
        Label91.Size = New Size(150, 20)
        Label91.TabIndex = 9
        Label91.Text = "Pallet Rack Solutions"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(ComboBox1)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(ComboBox3)
        GroupBox1.Controls.Add(ComboBox2)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Location = New Point(399, 10)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(893, 174)
        GroupBox1.TabIndex = 17
        GroupBox1.TabStop = False
        GroupBox1.Text = "Component Group"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label4.Location = New Point(20, 118)
        Label4.Name = "Label4"
        Label4.Size = New Size(95, 20)
        Label4.TabIndex = 9
        Label4.Text = "Components"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(242, 115)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(610, 28)
        ComboBox1.TabIndex = 10
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label2.Location = New Point(20, 78)
        Label2.Name = "Label2"
        Label2.Size = New Size(125, 20)
        Label2.TabIndex = 9
        Label2.Text = "Component Type"
        ' 
        ' ComboBox3
        ' 
        ComboBox3.FormattingEnabled = True
        ComboBox3.Location = New Point(242, 70)
        ComboBox3.Name = "ComboBox3"
        ComboBox3.Size = New Size(610, 28)
        ComboBox3.TabIndex = 10
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(242, 36)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(610, 28)
        ComboBox2.TabIndex = 10
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label1.Location = New Point(20, 39)
        Label1.Name = "Label1"
        Label1.Size = New Size(135, 20)
        Label1.TabIndex = 9
        Label1.Text = "Component group"
        ' 
        ' GroupBox4
        ' 
        GroupBox4.Controls.Add(Button2)
        GroupBox4.Controls.Add(Label25)
        GroupBox4.Controls.Add(ComboBox14)
        GroupBox4.Controls.Add(Label24)
        GroupBox4.Controls.Add(ComboBox13)
        GroupBox4.Controls.Add(Label23)
        GroupBox4.Controls.Add(TextBox8)
        GroupBox4.Controls.Add(Label22)
        GroupBox4.Controls.Add(ComboBox12)
        GroupBox4.Controls.Add(Label21)
        GroupBox4.Controls.Add(ComboBox11)
        GroupBox4.Controls.Add(ComboBox10)
        GroupBox4.Controls.Add(Label17)
        GroupBox4.Controls.Add(ComboBox9)
        GroupBox4.Controls.Add(Label16)
        GroupBox4.Controls.Add(ComboBox7)
        GroupBox4.Controls.Add(CheckBox1)
        GroupBox4.Controls.Add(TextBox7)
        GroupBox4.Controls.Add(Label15)
        GroupBox4.Controls.Add(ComboBox6)
        GroupBox4.Controls.Add(Label14)
        GroupBox4.Controls.Add(ComboBox5)
        GroupBox4.Controls.Add(Label13)
        GroupBox4.Controls.Add(TextBox13)
        GroupBox4.Controls.Add(TextBox10)
        GroupBox4.Controls.Add(TextBox12)
        GroupBox4.Controls.Add(Label18)
        GroupBox4.Controls.Add(Label19)
        GroupBox4.Controls.Add(Label20)
        GroupBox4.Controls.Add(TextBox6)
        GroupBox4.Controls.Add(Label12)
        GroupBox4.Controls.Add(TextBox5)
        GroupBox4.Controls.Add(Label11)
        GroupBox4.Controls.Add(TextBox4)
        GroupBox4.Controls.Add(TextBox3)
        GroupBox4.Controls.Add(TextBox1)
        GroupBox4.Controls.Add(Label10)
        GroupBox4.Controls.Add(TextBox2)
        GroupBox4.Controls.Add(ComboBox8)
        GroupBox4.Controls.Add(Label9)
        GroupBox4.Controls.Add(Label8)
        GroupBox4.Controls.Add(Label7)
        GroupBox4.Controls.Add(Label6)
        GroupBox4.Controls.Add(ComboBox4)
        GroupBox4.Controls.Add(Label5)
        GroupBox4.Location = New Point(399, 190)
        GroupBox4.Name = "GroupBox4"
        GroupBox4.Size = New Size(984, 800)
        GroupBox4.TabIndex = 20
        GroupBox4.TabStop = False
        GroupBox4.Text = "Components"
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Location = New Point(19, 719)
        Label25.Name = "Label25"
        Label25.Size = New Size(207, 20)
        Label25.TabIndex = 68
        Label25.Text = "Angle Welded Beam GSB  K ="
        ' 
        ' ComboBox14
        ' 
        ComboBox14.FormattingEnabled = True
        ComboBox14.Location = New Point(241, 711)
        ComboBox14.Name = "ComboBox14"
        ComboBox14.Size = New Size(230, 28)
        ComboBox14.TabIndex = 67
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Location = New Point(20, 688)
        Label24.Name = "Label24"
        Label24.Size = New Size(121, 20)
        Label24.TabIndex = 66
        Label24.Text = "Slot spacing for  "
        ' 
        ' ComboBox13
        ' 
        ComboBox13.FormattingEnabled = True
        ComboBox13.Location = New Point(241, 380)
        ComboBox13.Name = "ComboBox13"
        ComboBox13.Size = New Size(230, 28)
        ComboBox13.TabIndex = 65
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label23.Location = New Point(19, 388)
        Label23.Name = "Label23"
        Label23.Size = New Size(55, 20)
        Label23.TabIndex = 64
        Label23.Text = "Height"
        ' 
        ' TextBox8
        ' 
        TextBox8.BackColor = SystemColors.Menu
        TextBox8.Location = New Point(242, 623)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(714, 27)
        TextBox8.TabIndex = 63
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label22.Location = New Point(17, 630)
        Label22.Name = "Label22"
        Label22.Size = New Size(125, 20)
        Label22.TabIndex = 62
        Label22.Text = "Long Description"
        ' 
        ' ComboBox12
        ' 
        ComboBox12.FormattingEnabled = True
        ComboBox12.Location = New Point(242, 244)
        ComboBox12.Name = "ComboBox12"
        ComboBox12.Size = New Size(230, 28)
        ComboBox12.TabIndex = 61
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label21.Location = New Point(20, 248)
        Label21.Name = "Label21"
        Label21.Size = New Size(50, 20)
        Label21.TabIndex = 60
        Label21.Text = "Width"
        ' 
        ' ComboBox11
        ' 
        ComboBox11.Enabled = False
        ComboBox11.FormattingEnabled = True
        ComboBox11.Location = New Point(619, 429)
        ComboBox11.Name = "ComboBox11"
        ComboBox11.Size = New Size(89, 28)
        ComboBox11.TabIndex = 59
        ' 
        ' ComboBox10
        ' 
        ComboBox10.Enabled = False
        ComboBox10.FormattingEnabled = True
        ComboBox10.Location = New Point(619, 395)
        ComboBox10.Name = "ComboBox10"
        ComboBox10.Size = New Size(89, 28)
        ComboBox10.TabIndex = 58
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Enabled = False
        Label17.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label17.Location = New Point(516, 398)
        Label17.Name = "Label17"
        Label17.Size = New Size(104, 20)
        Label17.TabIndex = 57
        Label17.Text = "LIP Connector"
        ' 
        ' ComboBox9
        ' 
        ComboBox9.Enabled = False
        ComboBox9.FormattingEnabled = True
        ComboBox9.Location = New Point(242, 346)
        ComboBox9.Name = "ComboBox9"
        ComboBox9.Size = New Size(230, 28)
        ComboBox9.TabIndex = 56
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label16.Location = New Point(20, 354)
        Label16.Name = "Label16"
        Label16.Size = New Size(51, 20)
        Label16.TabIndex = 55
        Label16.Text = "Depth"
        ' 
        ' ComboBox7
        ' 
        ComboBox7.Enabled = False
        ComboBox7.FormattingEnabled = True
        ComboBox7.Location = New Point(516, 354)
        ComboBox7.Name = "ComboBox7"
        ComboBox7.Size = New Size(151, 28)
        ComboBox7.TabIndex = 54
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Enabled = False
        CheckBox1.Location = New Point(516, 324)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(192, 24)
        CheckBox1.TabIndex = 53
        CheckBox1.Text = "Link Upright for Bracing "
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(241, 590)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(715, 27)
        TextBox7.TabIndex = 52
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label15.Location = New Point(20, 597)
        Label15.Name = "Label15"
        Label15.Size = New Size(87, 20)
        Label15.TabIndex = 51
        Label15.Text = "Description"
        ' 
        ' ComboBox6
        ' 
        ComboBox6.FormattingEnabled = True
        ComboBox6.Location = New Point(242, 312)
        ComboBox6.Name = "ComboBox6"
        ComboBox6.Size = New Size(230, 28)
        ComboBox6.TabIndex = 50
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label14.Location = New Point(20, 316)
        Label14.Name = "Label14"
        Label14.Size = New Size(74, 20)
        Label14.TabIndex = 49
        Label14.Text = "Thickness"
        ' 
        ' ComboBox5
        ' 
        ComboBox5.FormattingEnabled = True
        ComboBox5.Location = New Point(242, 70)
        ComboBox5.Name = "ComboBox5"
        ComboBox5.Size = New Size(230, 28)
        ComboBox5.TabIndex = 48
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label13.Location = New Point(20, 73)
        Label13.Name = "Label13"
        Label13.Size = New Size(67, 20)
        Label13.TabIndex = 47
        Label13.Text = "GFA info"
        ' 
        ' TextBox13
        ' 
        TextBox13.Location = New Point(242, 104)
        TextBox13.Name = "TextBox13"
        TextBox13.Size = New Size(230, 27)
        TextBox13.TabIndex = 46
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(242, 211)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(230, 27)
        TextBox10.TabIndex = 40
        ' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(242, 140)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(230, 27)
        TextBox12.TabIndex = 37
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label18.Location = New Point(20, 211)
        Label18.Name = "Label18"
        Label18.Size = New Size(38, 20)
        Label18.TabIndex = 33
        Label18.Text = "Cost"
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label19.Location = New Point(20, 140)
        Label19.Name = "Label19"
        Label19.Size = New Size(114, 20)
        Label19.TabIndex = 32
        Label19.Text = "Powder Weight"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label20.Location = New Point(20, 103)
        Label20.Name = "Label20"
        Label20.Size = New Size(100, 20)
        Label20.TabIndex = 30
        Label20.Text = "Powder Code"
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(242, 518)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(230, 27)
        TextBox6.TabIndex = 29
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label12.Location = New Point(20, 521)
        Label12.Name = "Label12"
        Label12.Size = New Size(105, 20)
        Label12.TabIndex = 28
        Label12.Text = "UNSPSC Code"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(242, 417)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(230, 27)
        TextBox5.TabIndex = 27
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label11.Location = New Point(17, 424)
        Label11.Name = "Label11"
        Label11.Size = New Size(58, 20)
        Label11.TabIndex = 26
        Label11.Text = "Weight"
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(242, 485)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(230, 27)
        TextBox4.TabIndex = 25
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(242, 450)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(230, 27)
        TextBox3.TabIndex = 24
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(242, 178)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(230, 27)
        TextBox1.TabIndex = 23
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label10.Location = New Point(20, 169)
        Label10.Name = "Label10"
        Label10.Size = New Size(41, 20)
        Label10.TabIndex = 22
        Label10.Text = "CBM"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(242, 551)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(714, 27)
        TextBox2.TabIndex = 21
        ' 
        ' ComboBox8
        ' 
        ComboBox8.FormattingEnabled = True
        ComboBox8.Location = New Point(242, 278)
        ComboBox8.Name = "ComboBox8"
        ComboBox8.Size = New Size(230, 28)
        ComboBox8.TabIndex = 18
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label9.Location = New Point(20, 282)
        Label9.Name = "Label9"
        Label9.Size = New Size(56, 20)
        Label9.TabIndex = 17
        Label9.Text = "Length"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label8.Location = New Point(20, 490)
        Label8.Name = "Label8"
        Label8.Size = New Size(59, 20)
        Label8.TabIndex = 15
        Label8.Text = "Rev No"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label7.Location = New Point(20, 456)
        Label7.Name = "Label7"
        Label7.Size = New Size(92, 20)
        Label7.TabIndex = 13
        Label7.Text = "Drawing No"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label6.Location = New Point(20, 551)
        Label6.Name = "Label6"
        Label6.Size = New Size(128, 20)
        Label6.TabIndex = 11
        Label6.Text = "Short Description"
        ' 
        ' ComboBox4
        ' 
        ComboBox4.FormattingEnabled = True
        ComboBox4.Location = New Point(242, 36)
        ComboBox4.Name = "ComboBox4"
        ComboBox4.Size = New Size(230, 28)
        ComboBox4.TabIndex = 10
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Yu Gothic UI", 9.0F, FontStyle.Bold)
        Label5.Location = New Point(20, 39)
        Label5.Name = "Label5"
        Label5.Size = New Size(55, 20)
        Label5.TabIndex = 9
        Label5.Text = "Colour"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Location = New Point(1412, 202)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(566, 788)
        PictureBox1.TabIndex = 21
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(1468, 59)
        Button1.Name = "Button1"
        Button1.Size = New Size(343, 79)
        Button1.TabIndex = 22
        Button1.Text = "GLB files Upload"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(712, 54)
        Button2.Name = "Button2"
        Button2.Size = New Size(149, 29)
        Button2.TabIndex = 69
        Button2.Text = "Update "
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Master_Entry
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(2044, 1017)
        Controls.Add(Button1)
        Controls.Add(PictureBox1)
        Controls.Add(GroupBox4)
        Controls.Add(GroupBox1)
        Controls.Add(GroupBox14)
        Name = "Master_Entry"
        StartPosition = FormStartPosition.CenterParent
        Text = "Master_Entry"
        GroupBox14.ResumeLayout(False)
        GroupBox14.PerformLayout()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox4.ResumeLayout(False)
        GroupBox4.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents Label91 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents Label21 As Label
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents Button2 As Button
End Class
